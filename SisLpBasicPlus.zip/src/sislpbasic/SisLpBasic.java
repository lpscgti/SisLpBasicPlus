/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sislpbasic;

import controle.Conf;
import java.awt.Toolkit;
import java.net.ServerSocket;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.swing.JOptionPane;
import visual.FormLogon;

/**
 *
 * @author ProgXBERGUE
 */
public class SisLpBasic {

    private static ServerSocket s;
    Conf cfg = new Conf();
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        try {
        if (s==null){
            s = new ServerSocket(9581);
            
            FormLogon FrmLogin = new FormLogon();
            Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
            FrmLogin.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoTXT+"/"+"SisLpICO.png"));
            FrmLogin.setVisible(true);
            
        }    
        } catch (Exception e) {
        JOptionPane.showMessageDialog(null, "Desculpe, mas o SisLp já está Aberto.");
        }
        
    }
    
}
