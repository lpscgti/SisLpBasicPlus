/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author ProgXBERGUE
 */
public class ModeloDadosEmpresa {

  

    private int Cod;
    private String NF;
    private String RS;
    private String CNPJ;
    private String IE;
    private String End;
    private String Bai;
    private String Cid;
    private String Est;
    private String Cep;
    private String F1;
    private String F2;
    private String Site;
    private String Email;
    
    
      /**
     * @return the Cod
     */
    public int getCod() {
        return Cod;
    }

    /**
     * @param Cod the Cod to set
     */
    public void setCod(int Cod) {
        this.Cod = Cod;
    }
    
    /**
     * @return the NF
     */
    public String getNF() {
        return NF;
    }

    /**
     * @param NF the NF to set
     */
    public void setNF(String NF) {
        this.NF = NF;
    }

    /**
     * @return the RS
     */
    public String getRS() {
        return RS;
    }

    /**
     * @param RS the RS to set
     */
    public void setRS(String RS) {
        this.RS = RS;
    }

    /**
     * @return the CNPJ
     */
    public String getCNPJ() {
        return CNPJ;
    }

    /**
     * @param CNPJ the CNPJ to set
     */
    public void setCNPJ(String CNPJ) {
        this.CNPJ = CNPJ;
    }

    /**
     * @return the IE
     */
    public String getIE() {
        return IE;
    }

    /**
     * @param IE the IE to set
     */
    public void setIE(String IE) {
        this.IE = IE;
    }

    /**
     * @return the End
     */
    public String getEnd() {
        return End;
    }

    /**
     * @param End the End to set
     */
    public void setEnd(String End) {
        this.End = End;
    }

    /**
     * @return the Bai
     */
    public String getBai() {
        return Bai;
    }

    /**
     * @param Bai the Bai to set
     */
    public void setBai(String Bai) {
        this.Bai = Bai;
    }

    /**
     * @return the Cid
     */
    public String getCid() {
        return Cid;
    }

    /**
     * @param Cid the Cid to set
     */
    public void setCid(String Cid) {
        this.Cid = Cid;
    }
    
     /**
     * @return the Est
     */
    public String getEst() {
        return Est;
    }

    /**
     * @param Est the Bai to set
     */
    public void setEst(String Est) {
        this.Est = Est;
    }

    /**
     * @return the Cep
     */
    public String getCep() {
        return Cep;
    }

    /**
     * @param Cep the Cep to set
     */
    public void setCep(String Cep) {
        this.Cep = Cep;
    }

    /**
     * @return the F1
     */
    public String getF1() {
        return F1;
    }

    /**
     * @param F1 the F1 to set
     */
    public void setF1(String F1) {
        this.F1 = F1;
    }

    /**
     * @return the F2
     */
    public String getF2() {
        return F2;
    }

    /**
     * @param F2 the F2 to set
     */
    public void setF2(String F2) {
        this.F2 = F2;
    }

    /**
     * @return the F3
     */

    /**
     * @return the Site
     */
    public String getSite() {
        return Site;
    }

    /**
     * @param Site the Site to set
     */
    public void setSite(String Site) {
        this.Site = Site;
    }

    /**
     * @return the Email
     */
    public String getEmail() {
        return Email;
    }

    /**
     * @param Email the Email to set
     */
    public void setEmail(String Email) {
        this.Email = Email;
    }
   
}
