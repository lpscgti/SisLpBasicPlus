/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Lindembergue
 */
public class ModeloVendas {

    
    private int idVenda;
    private int idCliente;
    private String cliente;
    private String DtVenda;
    private double ValorVenda;
    private int idProduto;
    private String NomeProduto;
    private double Pr_venda_prod;
    private int qtd_produto;
    private double desconto;
    private double total_vendido;
    private String tipo_pag;
    private int id_func;

    /**
     * @return the idVenda
     */
    public int getIdVenda() {
        return idVenda;
    }

    /**
     * @param idVenda the idVenda to set
     */
    public void setIdVenda(int idVenda) {
        this.idVenda = idVenda;
    }

    /**
     * @return the idCliente
     */
    public int getIdCliente() {
        return idCliente;
    }

    /**
     * @param idCliente the idCliente to set
     */
    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    /**
     * @return the cliente
     */
    public String getCliente() {
        return cliente;
    }

    /**
     * @param cliente the cliente to set
     */
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }
    
    /**
     * @return the DtVenda
     */
    public String getDtVenda() {
        return DtVenda;
    }

    /**
     * @param DtVenda the DtVenda to set
     */
    public void setDtVenda(String DtVenda) {
        this.DtVenda = DtVenda;
    }

    /**
     * @return the ValorVenda
     */
    public double getValorVenda() {
        return ValorVenda;
    }

    /**
     * @param ValorVenda the ValorVenda to set
     */
    public void setValorVenda(double ValorVenda) {
        this.ValorVenda = ValorVenda;
    }

    /**
     * @return the idProduto
     */
    public int getIdProduto() {
        return idProduto;
    }

    /**
     * @param idProduto the idProduto to set
     */
    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }

    /**
     * @return the qtd_produto
     */
    public int getQtd_produto() {
        return qtd_produto;
    }

    /**
     * @param qtd_produto the qtd_produto to set
     */
    public void setQtd_produto(int qtd_produto) {
        this.qtd_produto = qtd_produto;
    }

    /**
     * @return the desconto
     */
    public double getDesconto() {
        return desconto;
    }

    /**
     * @param desconto the desconto to set
     */
    public void setDesconto(double desconto) {
        this.desconto = desconto;
    }

    /**
     * @return the total_vendido
     */
    public double getTotal_vendido() {
        return total_vendido;
    }

    /**
     * @param total_vendido the total_vendido to set
     */
    public void setTotal_vendido(double total_vendido) {
        this.total_vendido = total_vendido;
    }

    /**
     * @return the NomeProduto
     */
    public String getNomeProduto() {
        return NomeProduto;
    }

    /**
     * @param NomeProduto the NomeProduto to set
     */
    public void setNomeProduto(String NomeProduto) {
        this.NomeProduto = NomeProduto;
    }

    /**
     * @return the Pr_venda_prod
     */
    public double getPr_venda_prod() {
        return Pr_venda_prod;
    }

    /**
     * @param Pr_venda_prod the Pr_venda_prod to set
     */
    public void setPr_venda_prod(double Pr_venda_prod) {
        this.Pr_venda_prod = Pr_venda_prod;
    }

    /**
     * @return the tipo_pag
     */
    public String getTipo_pag() {
        return tipo_pag;
    }

    /**
     * @param tipo_pag the tipo_pag to set
     */
    public void setTipo_pag(String tipo_pag) {
        this.tipo_pag = tipo_pag;
    }

    /**
     * @return the id_func
     */
    public int getId_func() {
        return id_func;
    }

    /**
     * @param id_func the id_func to set
     */
    public void setId_func(int id_func) {
        this.id_func = id_func;
    }
    
}
