/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Lindembergue
 */
public class ModeloParcelaOrcamento {

    private int CodOrc;
    private int CodCliente;
    private int NumParcelas;
    private int ParcelaNum;
    private double ValorEntrada;
    private double ValorParcela;
    private double ValorTotal;
    private double ValorTotalTCJ;
    private String DtVenc;
    private String DtLanc;
    private String Entrada;

    /**
     * @return the CodOrc
     */
    public int getCodOrc() {
        return CodOrc;
    }

    /**
     * @param CodOrc the CodOrc to set
     */
    public void setCodOrc(int CodOrc) {
        this.CodOrc = CodOrc;
    }

    /**
     * @return the CodCliente
     */
    public int getCodCliente() {
        return CodCliente;
    }

    /**
     * @param CodCliente the CodCliente to set
     */
    public void setCodCliente(int CodCliente) {
        this.CodCliente = CodCliente;
    }

    /**
     * @return the NumParcelas
     */
    public int getNumParcelas() {
        return NumParcelas;
    }

    /**
     * @param NumParcelas the NumParcelas to set
     */
    public void setNumParcelas(int NumParcelas) {
        this.NumParcelas = NumParcelas;
    }

    /**
     * @return the ParcelaNum
     */
    public int getParcelaNum() {
        return ParcelaNum;
    }

    /**
     * @param ParcelaNum the ParcelaNum to set
     */
    public void setParcelaNum(int ParcelaNum) {
        this.ParcelaNum = ParcelaNum;
    }

    /**
     * @return the ValorEntrada
     */
    public double getValorEntrada() {
        return ValorEntrada;
    }

    /**
     * @param ValorEntrada the ValorEntrada to set
     */
    public void setValorEntrada(double ValorEntrada) {
        this.ValorEntrada = ValorEntrada;
    }

    /**
     * @return the ValorParcela
     */
    public double getValorParcela() {
        return ValorParcela;
    }

    /**
     * @param ValorParcela the ValorParcela to set
     */
    public void setValorParcela(double ValorParcela) {
        this.ValorParcela = ValorParcela;
    }

    /**
     * @return the ValorTotal
     */
    public double getValorTotal() {
        return ValorTotal;
    }

    /**
     * @param ValorTotal the ValorTotal to set
     */
    public void setValorTotal(double ValorTotal) {
        this.ValorTotal = ValorTotal;
    }

    /**
     * @return the ValorTotalTCJ
     */
    public double getValorTotalTCJ() {
        return ValorTotalTCJ;
    }

    /**
     * @param ValorTotalTCJ the ValorTotalTCJ to set
     */
    public void setValorTotalTCJ(double ValorTotalTCJ) {
        this.ValorTotalTCJ = ValorTotalTCJ;
    }

    /**
     * @return the DtVenc
     */
    public String getDtVenc() {
        return DtVenc;
    }

    /**
     * @param DtVenc the DtVenc to set
     */
    public void setDtVenc(String DtVenc) {
        this.DtVenc = DtVenc;
    }

    /**
     * @return the DtLanc
     */
    public String getDtLanc() {
        return DtLanc;
    }

    /**
     * @param DtLanc the DtLanc to set
     */
    public void setDtLanc(String DtLanc) {
        this.DtLanc = DtLanc;
    }

    /**
     * @return the Entrada
     */
    public String getEntrada() {
        return Entrada;
    }

    /**
     * @param Entrada the Entrada to set
     */
    public void setEntrada(String Entrada) {
        this.Entrada = Entrada;
    }
    
}