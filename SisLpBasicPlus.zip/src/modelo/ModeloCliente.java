/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Lindembergue
 */
public class ModeloCliente {

    
    private int id;
    private String Nome;
    private String Endereco;
    private String Bairro;
    private String Cidade;
    private String Estado;
    private String Cep;
    private String Tel1;
    private String Tel2;
    private String Tel3;
    private String Email;
    private String Site;
    private String Rg;
    private String Cpf;
    private String Cnpj;
    private String DtNascimento;
    private String Obs;
    private String Bloqueado;
    private byte[] FotoUrl;
    private String DtCadastro;
    private String pj;
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the Nome
     */
    public String getNome() {
        return Nome;
    }

    /**
     * @param Nome the Nome to set
     */
    public void setNome(String Nome) {
        this.Nome = Nome;
    }

    /**
     * @return the Endereco
     */
    public String getEndereco() {
        return Endereco;
    }

    /**
     * @param Endereco the Endereco to set
     */
    public void setEndereco(String Endereco) {
        this.Endereco = Endereco;
    }

    /**
     * @return the Bairro
     */
    public String getBairro() {
        return Bairro;
    }

    /**
     * @param Bairro the Bairro to set
     */
    public void setBairro(String Bairro) {
        this.Bairro = Bairro;
    }

    /**
     * @return the Cidade
     */
    public String getCidade() {
        return Cidade;
    }

    /**
     * @param Cidade the Cidade to set
     */
    public void setCidade(String Cidade) {
        this.Cidade = Cidade;
    }

    /**
     * @return the Estado
     */
    public String getEstado() {
        return Estado;
    }

    /**
     * @param Estado the Estado to set
     */
    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

    /**
     * @return the Cep
     */
    public String getCep() {
        return Cep;
    }

    /**
     * @param Cep the Cep to set
     */
    public void setCep(String Cep) {
        this.Cep = Cep;
    }

    /**
     * @return the Tel1
     */
    public String getTel1() {
        return Tel1;
    }

    /**
     * @param Tel1 the Tel1 to set
     */
    public void setTel1(String Tel1) {
        this.Tel1 = Tel1;
    }

    /**
     * @return the Tel2
     */
    public String getTel2() {
        return Tel2;
    }

    /**
     * @param Tel2 the Tel2 to set
     */
    public void setTel2(String Tel2) {
        this.Tel2 = Tel2;
    }

    /**
     * @return the Tel3
     */
    public String getTel3() {
        return Tel3;
    }

    /**
     * @param Tel3 the Tel3 to set
     */
    public void setTel3(String Tel3) {
        this.Tel3 = Tel3;
    }

    /**
     * @return the Email
     */
    public String getEmail() {
        return Email;
    }

    /**
     * @param Email the Email to set
     */
    public void setEmail(String Email) {
        this.Email = Email;
    }

    /**
     * @return the Site
     */
    public String getSite() {
        return Site;
    }

    /**
     * @param Site the Site to set
     */
    public void setSite(String Site) {
        this.Site = Site;
    }

    /**
     * @return the Rg
     */
    public String getRg() {
        return Rg;
    }

    /**
     * @param Rg the Rg to set
     */
    public void setRg(String Rg) {
        this.Rg = Rg;
    }

    /**
     * @return the Cpf
     */
    public String getCpf() {
        return Cpf;
    }

    /**
     * @param Cpf the Cpf to set
     */
    public void setCpf(String Cpf) {
        this.Cpf = Cpf;
    }

    /**
     * @return the Cnpj
     */
    public String getCnpj() {
        return Cnpj;
    }

    /**
     * @param Cnpj the Cnpj to set
     */
    public void setCnpj(String Cnpj) {
        this.Cnpj = Cnpj;
    }

    /**
     * @return the DtNascimento
     */
    public String getDtNascimento() {
        return DtNascimento;
    }

    /**
     * @param DtNascimento the DtNascimento to set
     */
    public void setDtNascimento(String DtNascimento) {
        this.DtNascimento = DtNascimento;
    }

       

    /**
     * @return the Obs
     */
    public String getObs() {
        return Obs;
    }

    /**
     * @param Obs the Obs to set
     */
    public void setObs(String Obs) {
        this.Obs = Obs;
    }

    /**
     * @return the Bloqueado
     */
    public String getBloqueado() {
        return Bloqueado;
    }

    /**
     * @param Bloqueado the Bloqueado to set
     */
    public void setBloqueado(String Bloqueado) {
        this.Bloqueado = Bloqueado;
    }

    /**
     * @return the FotoUrl
     */
    

    /**
     * @return the DtCadastro
     */
    public String getDtCadastro() {
        return DtCadastro;
    }

    /**
     * @param DtCadastro the DtCadastro to set
     */
    public void setDtCadastro(String DtCadastro) {
        this.DtCadastro = DtCadastro;
    }

    /**
     * @return the FotoUrl
     */
    public byte[] getFotoUrl() {
        return FotoUrl;
    }

    /**
     * @param FotoUrl the FotoUrl to set
     */
    public void setFotoUrl(byte[] FotoUrl) {
        this.FotoUrl = FotoUrl;
    }
    
    /**
     * @return the pj
     */
    public String getPj() {
        return pj;
    }

    /**
     * @param pj the pj to set
     */
    public void setPj(String pj) {
        this.pj = pj;
    }
    
}
