/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Lindembergue
 */
public class ModeloPedido {

    /**
     * @return the idPedido
     */
    public int getIdPedido() {
        return idPedido;
    }

    /**
     * @param idPedido the idPedido to set
     */
    public void setIdPedido(int idPedido) {
        this.idPedido = idPedido;
    }

    /**
     * @return the idFornecedor
     */
    public int getIdFornecedor() {
        return idFornecedor;
    }

    /**
     * @param idFornecedor the idFornecedor to set
     */
    public void setIdFornecedor(int idFornecedor) {
        this.idFornecedor = idFornecedor;
    }

    /**
     * @return the DtPedido
     */
    public String getDtPedido() {
        return DtPedido;
    }

    /**
     * @param DtPedido the DtPedido to set
     */
    public void setDtPedido(String DtPedido) {
        this.DtPedido = DtPedido;
    }

    /**
     * @return the ValorPedido
     */
    public double getValorPedido() {
        return ValorPedido;
    }

    /**
     * @param ValorPedido the ValorPedido to set
     */
    public void setValorPedido(double ValorPedido) {
        this.ValorPedido = ValorPedido;
    }

    /**
     * @return the idProduto
     */
    public int getIdProduto() {
        return idProduto;
    }

    /**
     * @param idProduto the idProduto to set
     */
    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }

    /**
     * @return the NomeProduto
     */
    public String getNomeProduto() {
        return NomeProduto;
    }

    /**
     * @param NomeProduto the NomeProduto to set
     */
    public void setNomeProduto(String NomeProduto) {
        this.NomeProduto = NomeProduto;
    }

    /**
     * @return the qtd_produto
     */
    public int getQtd_produto() {
        return qtd_produto;
    }

    /**
     * @param qtd_produto the qtd_produto to set
     */
    public void setQtd_produto(int qtd_produto) {
        this.qtd_produto = qtd_produto;
    }
    
    private int idPedido;
    private int idFornecedor;
    private String DtPedido;
    private double ValorPedido;
    private int idProduto;
    private String NomeProduto;
    private int qtd_produto;

    /**
     * @return the idVenda
     */
   
    
}
