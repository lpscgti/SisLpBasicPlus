/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Lindembergue
 */
public class ModeloProduto {

    private int id;
    private String nome;
    private int cat_id;
    private double pr_custo;
    private double pr_venda;
    private double m_lucro;
    private int estoque;
    private int forn_id;
    private String obs;
    private String dt_atual;
    private int u_medida;
    private String CodBarras;
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the cat_id
     */
    public int getCat_id() {
        return cat_id;
    }

    /**
     * @param cat_id the cat_id to set
     */
    public void setCat_id(int cat_id) {
        this.cat_id = cat_id;
    }

    /**
     * @return the pr_custo
     */
    public double getPr_custo() {
        return pr_custo;
    }

    /**
     * @param pr_custo the pr_custo to set
     */
    public void setPr_custo(double pr_custo) {
        this.pr_custo = pr_custo;
    }

    /**
     * @return the pr_venda
     */
    public double getPr_venda() {
        return pr_venda;
    }

    /**
     * @param pr_venda the pr_venda to set
     */
    public void setPr_venda(double pr_venda) {
        this.pr_venda = pr_venda;
    }

    /**
     * @return the m_lucro
     */
    public double getM_lucro() {
        return m_lucro;
    }

    /**
     * @param m_lucro the m_lucro to set
     */
    public void setM_lucro(double m_lucro) {
        this.m_lucro = m_lucro;
    }

    /**
     * @return the estoque
     */
    public int getEstoque() {
        return estoque;
    }

    /**
     * @param estoque the estoque to set
     */
    public void setEstoque(int estoque) {
        this.estoque = estoque;
    }

    /**
     * @return the forn_id
     */
    public int getForn_id() {
        return forn_id;
    }

    /**
     * @param forn_id the forn_id to set
     */
    public void setForn_id(int forn_id) {
        this.forn_id = forn_id;
    }

    /**
     * @return the obs
     */
    public String getObs() {
        return obs;
    }

    /**
     * @param obs the obs to set
     */
    public void setObs(String obs) {
        this.obs = obs;
    }

    /**
     * @return the dt_atual
     */
    public String getDt_atual() {
        return dt_atual;
    }

    /**
     * @param dt_atual the dt_atual to set
     */
    public void setDt_atual(String dt_atual) {
        this.dt_atual = dt_atual;
    }

    /**
     * @return the u_medida
     */
    public int getU_medida() {
        return u_medida;
    }

    /**
     * @param u_medida the u_medida to set
     */
    public void setU_medida(int u_medida) {
        this.u_medida = u_medida;
    }

    /**
     * @return the CodBarras
     */
    public String getCodBarras() {
        return CodBarras;
    }

    /**
     * @param CodBarras the CodBarras to set
     */
    public void setCodBarras(String CodBarras) {
        this.CodBarras = CodBarras;
    }
    
    

    /**
     * @return the id
     */
}