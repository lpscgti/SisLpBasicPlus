/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Lindembergue
 */
public class ModeloOrcamento {

    private int idOrcamento;
    private int idCliente;
    private String DtOrcamento;
    private double ValorOrcamento;
    private int idProduto;
    private String NomeProduto;
    private double Pr_venda_prod;
    private int qtd_produto;
    private double desconto;
    private double total_vendido;
    private String tipo_pag;
    
    /**
     * @return the tipo_pag
     */
    public String getTipo_pag() {
        return tipo_pag;
    }

    /**
     * @param tipo_pag the tipo_pag to set
     */
    public void setTipo_pag(String tipo_pag) {
        this.tipo_pag = tipo_pag;
    }

    /**
     * @return the idOrcamento
     */
    public int getIdOrcamento() {
        return idOrcamento;
    }

    /**
     * @param idOrcamento the idOrcamento to set
     */
    public void setIdOrcamento(int idOrcamento) {
        this.idOrcamento = idOrcamento;
    }

    /**
     * @return the idCliente
     */
    public int getIdCliente() {
        return idCliente;
    }

    /**
     * @param idCliente the idCliente to set
     */
    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    /**
     * @return the DtOrcamento
     */
    public String getDtOrcamento() {
        return DtOrcamento;
    }

    /**
     * @param DtOrcamento the DtOrcamento to set
     */
    public void setDtOrcamento(String DtOrcamento) {
        this.DtOrcamento = DtOrcamento;
    }

    /**
     * @return the ValorOrcamento
     */
    public double getValorOrcamento() {
        return ValorOrcamento;
    }

    /**
     * @param ValorOrcamento the ValorOrcamento to set
     */
    public void setValorOrcamento(double ValorOrcamento) {
        this.ValorOrcamento = ValorOrcamento;
    }

    /**
     * @return the idProduto
     */
    public int getIdProduto() {
        return idProduto;
    }

    /**
     * @param idProduto the idProduto to set
     */
    public void setIdProduto(int idProduto) {
        this.idProduto = idProduto;
    }

    /**
     * @return the NomeProduto
     */
    public String getNomeProduto() {
        return NomeProduto;
    }

    /**
     * @param NomeProduto the NomeProduto to set
     */
    public void setNomeProduto(String NomeProduto) {
        this.NomeProduto = NomeProduto;
    }

    /**
     * @return the Pr_venda_prod
     */
    public double getPr_venda_prod() {
        return Pr_venda_prod;
    }

    /**
     * @param Pr_venda_prod the Pr_venda_prod to set
     */
    public void setPr_venda_prod(double Pr_venda_prod) {
        this.Pr_venda_prod = Pr_venda_prod;
    }

    /**
     * @return the qtd_produto
     */
    public int getQtd_produto() {
        return qtd_produto;
    }

    /**
     * @param qtd_produto the qtd_produto to set
     */
    public void setQtd_produto(int qtd_produto) {
        this.qtd_produto = qtd_produto;
    }

    /**
     * @return the desconto
     */
    public double getDesconto() {
        return desconto;
    }

    /**
     * @param desconto the desconto to set
     */
    public void setDesconto(double desconto) {
        this.desconto = desconto;
    }

    /**
     * @return the total_vendido
     */
    public double getTotal_vendido() {
        return total_vendido;
    }

    /**
     * @param total_vendido the total_vendido to set
     */
    public void setTotal_vendido(double total_vendido) {
        this.total_vendido = total_vendido;
    }

    

}