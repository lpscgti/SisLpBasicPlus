/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;



/**
 *
 * @author Lindembergue
 */
public class ModeloParcelaVenda {

    /**
     * @return the ValorEntrada
     */
    public double getValorEntrada() {
        return ValorEntrada;
    }

    /**
     * @param ValorEntrada the ValorEntrada to set
     */
    public void setValorEntrada(double ValorEntrada) {
        this.ValorEntrada = ValorEntrada;
    }

    /**
     * @return the Entrada
     */
    public String getEntrada() {
        return Entrada;
    }

    /**
     * @param Entrada the Entrada to set
     */
    public void setEntrada(String Entrada) {
        this.Entrada = Entrada;
    }

    

    /**
     * @return the DtLanc
     */
    

    private int CodVenda;
    private int CodCliente;
    private int NumParcelas;
    private int ParcelaNum;
    private double ValorEntrada;
    private double ValorParcela;
    private double ValorParcelaCJ;
    private double ValorParcelaTCJ;
    private String DtVenc;
    private String DtLanc;
    private String Entrada;
    
    
    /**
     * @return the CodVenda
     */
    public int getCodVenda() {
        return CodVenda;
    }

    /**
     * @param CodVenda the CodVenda to set
     */
    public void setCodVenda(int CodVenda) {
        this.CodVenda = CodVenda;
    }

    /**
     * @return the CodCliente
     */
    public int getCodCliente() {
        return CodCliente;
    }

    /**
     * @param CodCliente the CodCliente to set
     */
    public void setCodCliente(int CodCliente) {
        this.CodCliente = CodCliente;
    }

    /**
     * @return the NumParcelas
     */
    public int getNumParcelas() {
        return NumParcelas;
    }

    /**
     * @param NumParcelas the NumParcelas to set
     */
    public void setNumParcelas(int NumParcelas) {
        this.NumParcelas = NumParcelas;
    }

    /**
     * @return the ParcelaNum
     */
    public int getParcelaNum() {
        return ParcelaNum;
    }

    /**
     * @param ParcelaNum the ParcelaNum to set
     */
    public void setParcelaNum(int ParcelaNum) {
        this.ParcelaNum = ParcelaNum;
    }

    /**
     * @return the ValorParcela
     */
    public double getValorParcela() {
        return ValorParcela;
    }

    /**
     * @param ValorParcela the ValorParcela to set
     */
    public void setValorParcela(double ValorParcela) {
        this.ValorParcela = ValorParcela;
    }

    /**
     * @return the ValorParcelaCJ
     */
    public double getValorParcelaCJ() {
        return ValorParcelaCJ;
    }

    /**
     * @param ValorParcelaCJ the ValorParcelaCJ to set
     */
    public void setValorParcelaCJ(double ValorParcelaCJ) {
        this.ValorParcelaCJ = ValorParcelaCJ;
    }

    /**
     * @return the Dt_Venc
     */
    public String getDt_Venc() {
        return DtVenc;
    }

    /**
     * @param DtVenc the Dt_Venc to set
     */
    public void setDt_Venc(String DtVenc) {
        this.DtVenc = DtVenc;
    }
    
    public String getDtLanc() {
        return DtLanc;
    }

    /**
     * @param DtLanc the DtLanc to set
     */
    public void setDtLanc(String DtLanc) {
        this.DtLanc = DtLanc;
    }

    /**
     * @return the ValorParcelaTCJ
     */
    public double getValorParcelaTCJ() {
        return ValorParcelaTCJ;
    }

    /**
     * @param ValorParcelaTCJ the ValorParcelaTCJ to set
     */
    public void setValorParcelaTCJ(double ValorParcelaTCJ) {
        this.ValorParcelaTCJ = ValorParcelaTCJ;
    }
    
    /**
     * @return the ValorRest
     */
   
    
}