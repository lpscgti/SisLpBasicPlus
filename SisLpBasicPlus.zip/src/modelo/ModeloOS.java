/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Lindembergue
 */
public class ModeloOS {
    private int id;
    private int idCliente;
    private String dt_abertura;
    private String dt_fechamento;
    private int id_funcionario;
    private String tipoPag;
    private String equipamento;
    private double Valor_obra;
    private String defeito;
    private String conserto;
    private double Total_os;
    private String status;
    private double Desconto;

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the idCliente
     */
    public int getIdCliente() {
        return idCliente;
    }

    /**
     * @param idCliente the idCliente to set
     */
    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    /**
     * @return the dt_abertura
     */
    public String getDt_abertura() {
        return dt_abertura;
    }

    /**
     * @param dt_abertura the dt_abertura to set
     */
    public void setDt_abertura(String dt_abertura) {
        this.dt_abertura = dt_abertura;
    }

    /**
     * @return the dt_fechamento
     */
    public String getDt_fechamento() {
        return dt_fechamento;
    }

    /**
     * @param dt_fechamento the dt_fechamento to set
     */
    public void setDt_fechamento(String dt_fechamento) {
        this.dt_fechamento = dt_fechamento;
    }

    /**
     * @return the id_funcionario
     */
    public int getId_funcionario() {
        return id_funcionario;
    }

    /**
     * @param id_funcionario the id_funcionario to set
     */
    public void setId_funcionario(int id_funcionario) {
        this.id_funcionario = id_funcionario;
    }

    /**
     * @return the tipoPag
     */
    public String getTipoPag() {
        return tipoPag;
    }

    /**
     * @param tipoPag the tipoPag to set
     */
    public void setTipoPag(String tipoPag) {
        this.tipoPag = tipoPag;
    }

    /**
     * @return the equipamento
     */
    public String getEquipamento() {
        return equipamento;
    }

    /**
     * @param equipamento the equipamento to set
     */
    public void setEquipamento(String equipamento) {
        this.equipamento = equipamento;
    }

    /**
     * @return the Valor_obra
     */
    public double getValor_obra() {
        return Valor_obra;
    }

    /**
     * @param Valor_obra the Valor_obra to set
     */
    public void setValor_obra(double Valor_obra) {
        this.Valor_obra = Valor_obra;
    }

    /**
     * @return the defeito
     */
    public String getDefeito() {
        return defeito;
    }

    /**
     * @param defeito the defeito to set
     */
    public void setDefeito(String defeito) {
        this.defeito = defeito;
    }

    /**
     * @return the conserto
     */
    public String getConserto() {
        return conserto;
    }

    /**
     * @param conserto the conserto to set
     */
    public void setConserto(String conserto) {
        this.conserto = conserto;
    }

    /**
     * @return the Total_os
     */
    public double getTotal_os() {
        return Total_os;
    }

    /**
     * @param Total_os the Total_os to set
     */
    public void setTotal_os(double Total_os) {
        this.Total_os = Total_os;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the Desconto
     */
    public double getDesconto() {
        return Desconto;
    }

    /**
     * @param Desconto the Desconto to set
     */
    public void setDesconto(double Desconto) {
        this.Desconto = Desconto;
    }

   
}
