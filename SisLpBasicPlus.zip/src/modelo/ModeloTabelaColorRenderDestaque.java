/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;

/**
 *
 * @author Lindembergue
 */
public class ModeloTabelaColorRenderDestaque extends DefaultTableCellRenderer {
 
    public String NomeTabela;
    
    @Override
    public Component getTableCellRendererComponent(
            JTable table, Object value,
            boolean isSelected, boolean hasFocus,
            int row, int column) {
 
        super.getTableCellRendererComponent(table, value, isSelected,
                hasFocus, row, column);
         
        // seta o resultado p/ falso porque isso sera usado em varias Jtables do sistema
        boolean result = false;
        try{
// no nosso exemplo 
 
if (table.getName() != null) { // p/ não escrever um null cada vez que carregar uma célula
                if (table.getName().equals("jTable1")) {
                    result = (Boolean) table.getModel().getValueAt(row, 3);
                }
                if (table.getName().equals("titulosAutorizacao")) {
                    result = (Boolean) table.getModel().getValueAt(row, 6);
                }
            }
        }
        catch (java.lang.NullPointerException ex){
            System.out.println(ex.getMessage());
        }
         
        //se for uma linha selecionada
        

        if (row == 0){
            
            setBackground(new Color(255, 215, 0));
            setForeground(Color.BLUE);
        }else if ((row % 2 == 0)) {
                
                setBackground(Color.WHITE);
                setForeground(Color.black);
                
        } else {
            
                setBackground(Color.LIGHT_GRAY);
                setForeground(Color.black);
        }
        
        if (isSelected) {
            
            setBackground(new Color(32, 178, 170));
            setForeground(Color.WHITE);
            setFont(new Font("Tahoma",Font.BOLD,10));
//            
//            setBorder(BorderFactory.createMatteBorder(2, 2, 2, 2, Color.RED));
//            setBackground(table.getSelectionBackground());
//            setForeground(table.getSelectionForeground());
             
        } else {
            
            if (row == 0){
            setBackground(new Color(255, 215, 0));
            setForeground(Color.RED);
            }else if ((row % 2 == 0)) {
                
                setBackground(Color.WHITE);
                setForeground(Color.black);
                
            } else {
            
                setBackground(Color.LIGHT_GRAY);
                setForeground(Color.black);
            }
        }
        return this;
    }
}

