/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.ConnectionFactory2;
import controle.ControleEmpresa;
import controle.ControleRecibo;
import controle.CurrencyWriter;
import controle.PlanodeFundoForms;
import modelo.ModeloRecibo;
import java.awt.BorderLayout;
import java.awt.Image;
import java.math.BigDecimal;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;

/**
 *
 * @author Lindembergue
 */
public class FormGeraRecibo extends javax.swing.JInternalFrame {
    ConectaBanco conRec = new ConectaBanco();
    ModeloRecibo modrec = new ModeloRecibo();
    ControleRecibo controlRec = new ControleRecibo();
    ControleEmpresa ctrl_de = new ControleEmpresa();
    
    int CodRecibo;
    String DataHoje, caminhoDb;
    double Valor, ConverteValor;
    
    public static String NomeJIF = "FormGeraRecibo";
    /**
     * Creates new form FormGeraRecibo
     */
    
    public FormGeraRecibo() {
        initComponents();
        ColocaImagemFundoFrame();
        DesativaItens();
        jTextFieldCidade.setText("BOM JESUS DA LAPA");
        jComboBoxEstado.setSelectedIndex(4);
        jTextFieldIdRecibo.setEnabled(false);
        jButtonSalvar.setEnabled(false);
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    public void limpaitens(){
    jTextFieldIdRecibo.setText("");
    jTextFieldNome.setText("");
    jTextFieldValor.setText("0.00");
    jTextFieldRef.setText("");
    jTextFieldValorExt.setText("");
    jTextFieldCidade.setText("");
    jFormattedTextFieldData.setText("");
    jTextAreaObs.setText("");
    }
    public void AtivaItens(){
    jTextFieldIdRecibo.setEnabled(true);
    jTextFieldNome.setEnabled(true);
    jTextFieldValor.setEnabled(true);
    jTextFieldRef.setEnabled(true);
    jTextFieldValorExt.setEnabled(true);
    jTextFieldCidade.setEnabled(true);
    jFormattedTextFieldData.setEnabled(true);
    jTextAreaObs.setEnabled(true);
    jComboBoxEstado.setEnabled(true);
    }
    public void DesativaItens(){
    jTextFieldIdRecibo.setEnabled(false);
    jTextFieldNome.setEnabled(false);
    jTextFieldValor.setEnabled(false);
    jTextFieldRef.setEnabled(false);
    jTextFieldValorExt.setEnabled(false);
    jTextFieldCidade.setEnabled(false);
    jFormattedTextFieldData.setEnabled(false);
    jTextAreaObs.setEnabled(false);
    jComboBoxEstado.setEnabled(false);
    }


    public void convertValorVirgula(String ValorEntrada){
        if (ValorEntrada.equals("")){
            ValorEntrada = "0";
        }else{
        ConverteValor = Double.parseDouble(ValorEntrada.replace(',', '.'));  
        }
    }  

    public  void PrintRecibo(){
        ctrl_de.Obtem_Dados_da_Empresa();
        int i = JOptionPane.showConfirmDialog(rootPane, "Recibo Gerado, Deseja realizar a impressão?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
        if(i == JOptionPane.YES_OPTION) {
            
           
            try {
            try {
                Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                Map<String, Object> parametros = new HashMap<String, Object>();
                Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                //dados empresa
                parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                parametros.put( "cnpj", ctrl_de.de_cnpj );
                parametros.put( "de_ie", ctrl_de.de_ie );
                parametros.put( "endereco", ctrl_de.de_endereco );
                parametros.put( "bairro", ctrl_de.de_bairro );
                parametros.put( "cidade", ctrl_de.de_cidade );
                parametros.put( "estado", ctrl_de.de_estado );
                parametros.put( "cep", ctrl_de.de_cep );
                parametros.put( "telefone1", ctrl_de.de_fone1 );
                parametros.put( "telefone2", ctrl_de.de_fone2 );
                parametros.put( "de_site", ctrl_de.de_site );
                parametros.put( "email", ctrl_de.de_email );
                parametros.put("logoimg",imagePath);
                parametros.put( "idrecibo", CodRecibo );
                JasperPrint jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraRecibo.jasper", parametros, ConnectionFactory2.getSlpConnection());
                JRViewer viewer = new JRViewer(jpPrint);
                viewer.setZoomRatio((float) 0.5);
                JFrame frameRelatorio = new JFrame();
                frameRelatorio.add( viewer, BorderLayout.CENTER );
                frameRelatorio.setTitle("Recibo");
                frameRelatorio.setSize( 500, 500 );
                frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                frameRelatorio.setVisible( true );
            } catch (SQLException ex) {
                Logger.getLogger(FormGeraRecibo.class.getName()).log(Level.SEVERE, null, ex);
            }
            } catch (JRException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Gerar Comprovante de Recibo para Impressão!\nErro: "+ex);
            } 
           
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jTextFieldValor = new javax.swing.JTextField();
        jTextFieldIdRecibo = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jFormattedTextFieldData = new javax.swing.JFormattedTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextAreaObs = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jTextFieldNome = new controle.ClassUpperField();
        jTextFieldRef = new controle.ClassUpperField();
        jTextFieldValorExt = new controle.ClassUpperField();
        jTextFieldCidade = new controle.ClassUpperField();
        jLabel10 = new javax.swing.JLabel();
        jComboBoxEstado = new javax.swing.JComboBox<>();
        jButtonNovo = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jButtonSair = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setTitle("Gerar Recibo");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel4.setBackground(new java.awt.Color(0, 135, 255));
        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel4.setForeground(java.awt.Color.white);
        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("R E C I B O");
        jPanelFundo.add(jLabel4);
        jLabel4.setBounds(10, 10, 590, 30);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Nº");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 60, 90, 15);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Nome");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(100, 60, 390, 15);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel3.setForeground(java.awt.Color.white);
        jLabel3.setText("Valor R$");
        jPanelFundo.add(jLabel3);
        jLabel3.setBounds(490, 60, 110, 15);

        jTextFieldValor.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldValorKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldValorKeyTyped(evt);
            }
        });
        jPanelFundo.add(jTextFieldValor);
        jTextFieldValor.setBounds(490, 80, 110, 25);

        jTextFieldIdRecibo.setFont(new java.awt.Font("Tahoma", 3, 12)); // NOI18N
        jTextFieldIdRecibo.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldIdRecibo.setMargin(new java.awt.Insets(2, 2, 2, 7));
        jTextFieldIdRecibo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldIdReciboActionPerformed(evt);
            }
        });
        jPanelFundo.add(jTextFieldIdRecibo);
        jTextFieldIdRecibo.setBounds(10, 80, 90, 25);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setForeground(java.awt.Color.white);
        jLabel5.setText("Referência");
        jPanelFundo.add(jLabel5);
        jLabel5.setBounds(10, 110, 590, 15);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel6.setForeground(java.awt.Color.white);
        jLabel6.setText("Estado:");
        jPanelFundo.add(jLabel6);
        jLabel6.setBounds(360, 220, 110, 15);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setForeground(java.awt.Color.white);
        jLabel7.setText("Data:");
        jPanelFundo.add(jLabel7);
        jLabel7.setBounds(470, 220, 130, 15);
        jPanelFundo.add(jFormattedTextFieldData);
        jFormattedTextFieldData.setBounds(470, 240, 130, 25);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel8.setForeground(java.awt.Color.white);
        jLabel8.setText("Observações:");
        jPanelFundo.add(jLabel8);
        jLabel8.setBounds(10, 270, 590, 15);

        jTextAreaObs.setColumns(20);
        jTextAreaObs.setRows(5);
        jScrollPane1.setViewportView(jTextAreaObs);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 290, 590, 50);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setForeground(java.awt.Color.white);
        jLabel9.setText("Por Extenso");
        jPanelFundo.add(jLabel9);
        jLabel9.setBounds(10, 160, 590, 15);
        jPanelFundo.add(jTextFieldNome);
        jTextFieldNome.setBounds(100, 80, 390, 25);
        jPanelFundo.add(jTextFieldRef);
        jTextFieldRef.setBounds(10, 130, 590, 25);
        jPanelFundo.add(jTextFieldValorExt);
        jTextFieldValorExt.setBounds(10, 190, 590, 25);
        jPanelFundo.add(jTextFieldCidade);
        jTextFieldCidade.setBounds(10, 240, 350, 25);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel10.setForeground(java.awt.Color.white);
        jLabel10.setText("Cidade:");
        jPanelFundo.add(jLabel10);
        jLabel10.setBounds(10, 220, 350, 15);

        jComboBoxEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR", "SC", "SE", "SP", "TO" }));
        jPanelFundo.add(jComboBoxEstado);
        jComboBoxEstado.setBounds(360, 240, 110, 25);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 10, 610, 350);

        jButtonNovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/add.png"))); // NOI18N
        jButtonNovo.setText("Novo");
        jButtonNovo.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonNovo);
        jButtonNovo.setBounds(350, 370, 90, 40);

        jButtonSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/accept.png"))); // NOI18N
        jButtonSalvar.setText("Salvar");
        jButtonSalvar.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSalvar);
        jButtonSalvar.setBounds(440, 370, 90, 40);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(530, 370, 90, 40);

        setBounds(0, 0, 634, 450);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldIdReciboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldIdReciboActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldIdReciboActionPerformed

    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed
        
        AtivaItens();
        limpaitens();
        jTextFieldCidade.setText("BOM JESUS DA LAPA");
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date hoje = new Date();
        DataHoje = (df.format(hoje));
        jFormattedTextFieldData.setText(DataHoje);
        conRec.conecta();
        try {
            PreparedStatement pst = conRec.conn.prepareStatement("insert into recibo (valor) values(?)");
            pst.setDouble(1, 0);
            pst.execute();
            conRec.executaSQL("select * from recibo order by codigo");
            conRec.rs.last();
            CodRecibo = conRec.rs.getInt("codigo");
            jTextFieldIdRecibo.setText(String.valueOf(CodRecibo));
        } catch (SQLException ex) {
            Logger.getLogger(FormGeraRecibo.class.getName()).log(Level.SEVERE, null, ex);
        }conRec.desconecta();
        jButtonNovo.setEnabled(false);
        jButtonSalvar.setEnabled(true);
        jTextFieldNome.grabFocus();
        
    }//GEN-LAST:event_jButtonNovoActionPerformed

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
        
        modrec.setId(CodRecibo);
        modrec.setNome(String.valueOf(jTextFieldNome.getText()));
        ConverteValor = 0;
        convertValorVirgula(jTextFieldValor.getText());
        modrec.setValor(ConverteValor);
        modrec.setRef(jTextFieldRef.getText());
        modrec.setCidade(jTextFieldCidade.getText());
        modrec.setEstado(String.valueOf(jComboBoxEstado.getSelectedItem()));
        modrec.setData(jFormattedTextFieldData.getText());
        modrec.setValorExt(jTextFieldValorExt.getText());
        modrec.setObs(jTextAreaObs.getText());
        controlRec.GeraRecibo(modrec);
        limpaitens();
        DesativaItens();
        jButtonNovo.setEnabled(true);
        jButtonSalvar.setEnabled(false);
        PrintRecibo();

    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jTextFieldValorKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldValorKeyReleased

        ConverteValor = 0;
        convertValorVirgula(jTextFieldValor.getText());
        Valor = ConverteValor;
        CurrencyWriter cw = new CurrencyWriter();
        String extenso = cw.write(new BigDecimal(Valor));
        jTextFieldValorExt.setText(extenso);

    }//GEN-LAST:event_jTextFieldValorKeyReleased

    private void jTextFieldValorKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldValorKeyTyped

    }//GEN-LAST:event_jTextFieldValorKeyTyped

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed

        dispose();
        
    }//GEN-LAST:event_jButtonSairActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JComboBox<String> jComboBoxEstado;
    private javax.swing.JFormattedTextField jFormattedTextFieldData;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextAreaObs;
    private controle.ClassUpperField jTextFieldCidade;
    private javax.swing.JTextField jTextFieldIdRecibo;
    private controle.ClassUpperField jTextFieldNome;
    private controle.ClassUpperField jTextFieldRef;
    private javax.swing.JTextField jTextFieldValor;
    private controle.ClassUpperField jTextFieldValorExt;
    // End of variables declaration//GEN-END:variables
}
