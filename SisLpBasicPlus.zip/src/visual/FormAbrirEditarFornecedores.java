/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.ControleFornecedor;
import controle.PlanodeFundoForms;
import modelo.ModeloFornecedor;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyVetoException;
import java.io.File;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import static javax.swing.JFileChooser.SELECTED_FILE_CHANGED_PROPERTY;
import javax.swing.JFormattedTextField;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;

/**
 *
 * @author Lindembergue
 */
public class FormAbrirEditarFornecedores extends javax.swing.JInternalFrame {
ModeloFornecedor ModFornecedor = new ModeloFornecedor();
ConectaBanco ConFornecedor = new ConectaBanco();
ControleFornecedor ControlFornecedor = new ControleFornecedor();
BufferedImage imagem;
FilePreviewer previewer;
int CodFornecedor;
String  Usuario, UsuTipo;
public static String NomeJIF = "FormAbrirEditarFornecedores";
public boolean a_form_ex = false; //identifica se o jormulario foi aberto a partir de outro formulario.
public JInternalFrame jifr; //declara classe jif para permitir que o codigo consiga restaurar a janela do formulario de origem.

    /**
     * Creates new form FormCadFornecedores
     */
    public FormAbrirEditarFornecedores() {
        
        initComponents();
        ColocaImagemFundoFrame();
        DestivaEdicaoDeItens();
        jComboBoxEstado.setEnabled(false);
        try {
            MaskFormatter cep = new MaskFormatter("#####-###");
            MaskFormatter tel = new MaskFormatter("(##) #####-####");
            MaskFormatter cpf = new MaskFormatter("###.###.###-##");
            MaskFormatter cnpj = new MaskFormatter("##.###.###/####-##");
            jFormattedTextFieldCEP.setFormatterFactory(new DefaultFormatterFactory(cep));
            jFormattedTextFieldCPF.setFormatterFactory(new DefaultFormatterFactory(cpf));
            jFormattedTextFieldCNPJ.setFormatterFactory(new DefaultFormatterFactory(cnpj));
        } catch (ParseException ex) {
            Logger.getLogger(FormCadClientes.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
    public void AbreCadFornecedor(int CodForn){
        
        CodFornecedor = CodForn;
        ConFornecedor.conecta();
        
        try {

            ConFornecedor.executaSQL("select * from fornecedores where codigo='"+CodForn+"'");
            ConFornecedor.rs.first();
            jTextFieldCod.setText(String.valueOf(ConFornecedor.rs.getInt("codigo")));
            jTextFieldNome.setText(ConFornecedor.rs.getString("nome"));
            jTextFieldEndereco.setText(ConFornecedor.rs.getString("endereco"));
            jTextFieldBairro.setText(ConFornecedor.rs.getString("bairro"));
            jTextFieldCidade.setText(ConFornecedor.rs.getString("cidade"));
            jComboBoxEstado.setSelectedItem(ConFornecedor.rs.getString("estado"));
            jFormattedTextFieldCEP.setText(ConFornecedor.rs.getString("cep"));
            jFormattedTextFieldTel1.setText(ConFornecedor.rs.getString("tel1"));
            jFormattedTextFieldTel2.setText(ConFornecedor.rs.getString("tel2"));
            jTextFieldEmail.setText(ConFornecedor.rs.getString("email"));
            jTextFieldSite.setText(ConFornecedor.rs.getString("site"));
            jFormattedTextFieldCPF.setText(ConFornecedor.rs.getString("cpf"));
            jFormattedTextFieldCNPJ.setText(ConFornecedor.rs.getString("cnpj"));
            jTextAreaOBS.setText(ConFornecedor.rs.getString("obs"));
            
            } catch (SQLException ex) {
            Logger.getLogger(FormAbreEditaClientes.class.getName()).log(Level.SEVERE, null, ex);
            }ConFornecedor.desconecta();
    }
    
    private void mudaMascaraTelefone(JFormattedTextField format) {
        try {
            format.setValue(null);
            String nome = format.getText().replaceAll("-", "").replaceAll("\\(", "").replaceAll("\\)", "");
            final MaskFormatter mask = new MaskFormatter();
            switch (nome.length()) {
                case 8:
                    mask.setMask("####-####");
                    format.setFormatterFactory(new DefaultFormatterFactory(mask));
                    break;
                case 9:
                    mask.setMask("#####-####");
                    format.setFormatterFactory(new DefaultFormatterFactory(mask));
                    break;
                case 10:
                    mask.setMask("(##)####-####");
                    format.setFormatterFactory(new DefaultFormatterFactory(mask));
                    break;
                case 11:
                    mask.setMask("(##)#####-####");
                    format.setFormatterFactory(new DefaultFormatterFactory(mask));
                    break;
                default:
                    break;
            }
            format.setText(nome);
        } catch (Exception asd) {
            System.out.println(asd);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel14 = new javax.swing.JLabel();
        jPanelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jTextFieldCod = new controle.ClassUpperField();
        jTextFieldNome = new controle.ClassUpperField();
        jTextFieldEndereco = new controle.ClassUpperField();
        jTextFieldBairro = new controle.ClassUpperField();
        jTextFieldCidade = new controle.ClassUpperField();
        jComboBoxEstado = new javax.swing.JComboBox();
        jFormattedTextFieldCEP = new javax.swing.JFormattedTextField();
        jFormattedTextFieldTel1 = new javax.swing.JFormattedTextField();
        jFormattedTextFieldTel2 = new javax.swing.JFormattedTextField();
        jTextFieldEmail = new javax.swing.JTextField();
        jTextFieldSite = new javax.swing.JTextField();
        jFormattedTextFieldCPF = new javax.swing.JFormattedTextField();
        jFormattedTextFieldCNPJ = new javax.swing.JFormattedTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextAreaOBS = new javax.swing.JTextArea();
        jButtonAbrir = new javax.swing.JButton();
        jButtonEditar = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jButtonSair = new javax.swing.JButton();

        jLabel14.setText("jLabel14");

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createTitledBorder(""))));
        setTitle("Cadastro de Fornecedores");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Código:");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 10, 100, 16);

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Nome:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(120, 10, 450, 16);

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Endereço:");
        jPanelFundo.add(jLabel3);
        jLabel3.setBounds(10, 60, 560, 16);

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Bairro:");
        jPanelFundo.add(jLabel4);
        jLabel4.setBounds(10, 110, 250, 16);

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Cidade:");
        jPanelFundo.add(jLabel5);
        jLabel5.setBounds(270, 110, 300, 16);

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Estado:");
        jPanelFundo.add(jLabel6);
        jLabel6.setBounds(10, 160, 60, 16);

        jLabel15.setForeground(java.awt.Color.white);
        jLabel15.setText("Cep:");
        jPanelFundo.add(jLabel15);
        jLabel15.setBounds(80, 160, 180, 16);

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Telefone, Celular, Contato, Fax...");
        jPanelFundo.add(jLabel7);
        jLabel7.setBounds(270, 160, 300, 16);

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("E-mail:");
        jPanelFundo.add(jLabel8);
        jLabel8.setBounds(10, 220, 270, 16);

        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Site:");
        jPanelFundo.add(jLabel9);
        jLabel9.setBounds(290, 220, 280, 16);

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("CPF:");
        jPanelFundo.add(jLabel10);
        jLabel10.setBounds(10, 270, 140, 16);

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("CNPJ:");
        jPanelFundo.add(jLabel11);
        jLabel11.setBounds(160, 270, 140, 16);

        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Obs:");
        jPanelFundo.add(jLabel12);
        jLabel12.setBounds(10, 320, 560, 16);
        jPanelFundo.add(jTextFieldCod);
        jTextFieldCod.setBounds(10, 30, 100, 25);
        jPanelFundo.add(jTextFieldNome);
        jTextFieldNome.setBounds(120, 30, 450, 25);
        jPanelFundo.add(jTextFieldEndereco);
        jTextFieldEndereco.setBounds(10, 80, 560, 25);
        jPanelFundo.add(jTextFieldBairro);
        jTextFieldBairro.setBounds(10, 130, 250, 25);
        jPanelFundo.add(jTextFieldCidade);
        jTextFieldCidade.setBounds(270, 130, 300, 25);

        jComboBoxEstado.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR", "SC", "SE", "SP", "TO" }));
        jComboBoxEstado.setBorder(null);
        jPanelFundo.add(jComboBoxEstado);
        jComboBoxEstado.setBounds(10, 180, 60, 25);

        jFormattedTextFieldCEP.setBorder(null);
        jPanelFundo.add(jFormattedTextFieldCEP);
        jFormattedTextFieldCEP.setBounds(80, 180, 180, 25);

        jFormattedTextFieldTel1.setBorder(null);
        jFormattedTextFieldTel1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jFormattedTextFieldTel1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jFormattedTextFieldTel1FocusLost(evt);
            }
        });
        jPanelFundo.add(jFormattedTextFieldTel1);
        jFormattedTextFieldTel1.setBounds(270, 180, 140, 25);

        jFormattedTextFieldTel2.setBorder(null);
        jFormattedTextFieldTel2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jFormattedTextFieldTel2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jFormattedTextFieldTel2FocusLost(evt);
            }
        });
        jPanelFundo.add(jFormattedTextFieldTel2);
        jFormattedTextFieldTel2.setBounds(420, 180, 150, 25);

        jTextFieldEmail.setBorder(null);
        jPanelFundo.add(jTextFieldEmail);
        jTextFieldEmail.setBounds(10, 240, 270, 25);

        jTextFieldSite.setBorder(null);
        jPanelFundo.add(jTextFieldSite);
        jTextFieldSite.setBounds(290, 240, 280, 25);

        jFormattedTextFieldCPF.setBorder(null);
        jPanelFundo.add(jFormattedTextFieldCPF);
        jFormattedTextFieldCPF.setBounds(10, 290, 140, 25);

        jFormattedTextFieldCNPJ.setBorder(null);
        jPanelFundo.add(jFormattedTextFieldCNPJ);
        jFormattedTextFieldCNPJ.setBounds(160, 290, 140, 25);

        jTextAreaOBS.setColumns(20);
        jTextAreaOBS.setRows(5);
        jTextAreaOBS.setBorder(null);
        jScrollPane1.setViewportView(jTextAreaOBS);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 340, 560, 80);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 10, 580, 430);

        jButtonAbrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/open folderResultado.png"))); // NOI18N
        jButtonAbrir.setText("Abrir");
        jButtonAbrir.setToolTipText("Abrir Fornecedor Cadastrado");
        jButtonAbrir.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAbrirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAbrir);
        jButtonAbrir.setBounds(140, 450, 90, 40);

        jButtonEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/editResultado.png"))); // NOI18N
        jButtonEditar.setText("Editar");
        jButtonEditar.setToolTipText("Ativar Edição de Itens");
        jButtonEditar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonEditar);
        jButtonEditar.setBounds(230, 450, 90, 40);

        jButtonSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/accept.png"))); // NOI18N
        jButtonSalvar.setText("Salvar");
        jButtonSalvar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSalvar);
        jButtonSalvar.setBounds(410, 450, 90, 40);

        jButtonExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jButtonExcluir.setText("Excluir");
        jButtonExcluir.setToolTipText("Excluir Fornecedor Cadastrado");
        jButtonExcluir.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonExcluir);
        jButtonExcluir.setBounds(320, 450, 90, 40);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(500, 450, 90, 40);

        setBounds(0, 0, 602, 525);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
        
        if (a_form_ex==true){
            try {
                jifr.setIcon(false);
            } catch (PropertyVetoException ex) {

            }
        } 
        dispose();

    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAbrirActionPerformed
        FormPesqFornecedor FrmPqFornec = new FormPesqFornecedor();
        FrmPqFornec.a_form_ex = true; 
        FrmPqFornec.jifr = this;
        FormPrincipal.AbreNovaJanelaS(FrmPqFornec);
        dispose();
    }//GEN-LAST:event_jButtonAbrirActionPerformed

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed

        ModFornecedor.setNome(jTextFieldNome.getText());
        ModFornecedor.setEndereco(jTextFieldEndereco.getText());
        ModFornecedor.setBairro(jTextFieldBairro.getText());
        ModFornecedor.setCidade(jTextFieldCidade.getText());
        ModFornecedor.setEstado(String.valueOf(jComboBoxEstado.getSelectedItem()));
        ModFornecedor.setCep(jFormattedTextFieldCEP.getText());
        ModFornecedor.setTel1(jFormattedTextFieldTel1.getText());
        ModFornecedor.setTel2(jFormattedTextFieldTel2.getText());
        ModFornecedor.setEmail(jTextFieldEmail.getText());
        ModFornecedor.setSite(jTextFieldSite.getText());
        ModFornecedor.setCpf(jFormattedTextFieldCPF.getText());
        ModFornecedor.setCnpj(jFormattedTextFieldCNPJ.getText());
        ModFornecedor.setObs(jTextAreaOBS.getText());
        ModFornecedor.setId(CodFornecedor);
        ControlFornecedor.SalvaDados(ModFornecedor);
        jButtonSalvar.setEnabled(false);
        jButtonEditar.setEnabled(false);
        jComboBoxEstado.setEnabled(false);
        LimpaItens();
        DesabilitaItens();
        DestivaEdicaoDeItens();
        
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed
        int i = JOptionPane.showConfirmDialog(rootPane, "Deseja excluir realmente\nos dados deste fornecedor?","Confirmando Exclusão", JOptionPane.YES_NO_OPTION);
        if(i == JOptionPane.YES_OPTION) {
            ModFornecedor.setId(CodFornecedor);
            ControlFornecedor.ExcluiDados(ModFornecedor);
            LimpaItens();
            DesabilitaItens();
            DestivaEdicaoDeItens();
            dispose();
            JOptionPane.showMessageDialog(rootPane, "Dados excluidos com sucesso!");
        }
        else if(i == JOptionPane.NO_OPTION) {
        }  

    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jButtonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditarActionPerformed
        AtivaEdicaoDeItens();
        jComboBoxEstado.setEnabled(true);
        jButtonEditar.setEnabled(false);
        jButtonSalvar.setEnabled(true);
    }//GEN-LAST:event_jButtonEditarActionPerformed

    private void jFormattedTextFieldTel1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFormattedTextFieldTel1FocusGained
        // TODO add your handling code here:
         jFormattedTextFieldTel1.setFormatterFactory(null);
    }//GEN-LAST:event_jFormattedTextFieldTel1FocusGained

    private void jFormattedTextFieldTel2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFormattedTextFieldTel2FocusGained
        // TODO add your handling code here:
         jFormattedTextFieldTel2.setFormatterFactory(null);
    }//GEN-LAST:event_jFormattedTextFieldTel2FocusGained

    private void jFormattedTextFieldTel1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFormattedTextFieldTel1FocusLost
        // TODO add your handling code here:
         mudaMascaraTelefone(jFormattedTextFieldTel1);
    }//GEN-LAST:event_jFormattedTextFieldTel1FocusLost

    private void jFormattedTextFieldTel2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFormattedTextFieldTel2FocusLost
        // TODO add your handling code here:
         mudaMascaraTelefone(jFormattedTextFieldTel2);
    }//GEN-LAST:event_jFormattedTextFieldTel2FocusLost

    public void DesabilitaItens (){
        
        jTextFieldCod.setEnabled(false);
        jTextFieldNome.setEnabled(false);
        jTextFieldEndereco.setEnabled(false);
        jTextFieldBairro.setEnabled(false);
        jTextFieldCidade.setEnabled(false);
        jComboBoxEstado.setEnabled(false);
        jFormattedTextFieldCEP.setEnabled(false);
        jFormattedTextFieldTel1.setEnabled(false);
        jFormattedTextFieldTel2.setEnabled(false);
        jTextFieldEmail.setEnabled(false);
        jTextFieldSite.setEnabled(false);
        jFormattedTextFieldCPF.setEnabled(false);
        jFormattedTextFieldCNPJ.setEnabled(false);
        jTextAreaOBS.setEnabled(false);
        
    }
    
    public void DestivaEdicaoDeItens(){
        
        jTextFieldCod.setEditable(false);
        jTextFieldNome.setEditable(false);
        jTextFieldEndereco.setEditable(false);
        jTextFieldBairro.setEditable(false);
        jTextFieldCidade.setEditable(false);
        jFormattedTextFieldCEP.setEditable(false);
        jFormattedTextFieldTel1.setEditable(false);
        jFormattedTextFieldTel2.setEditable(false);
        jTextFieldEmail.setEditable(false);
        jTextFieldSite.setEditable(false);
        jFormattedTextFieldCPF.setEditable(false);
        jFormattedTextFieldCNPJ.setEditable(false);
        jTextAreaOBS.setEditable(false);
               
    }
    
    public void AtivaEdicaoDeItens(){

        jTextFieldNome.setEditable(true);
        jTextFieldEndereco.setEditable(true);
        jTextFieldBairro.setEditable(true);
        jTextFieldCidade.setEditable(true);
        jFormattedTextFieldCEP.setEditable(true);
        jFormattedTextFieldTel1.setEditable(true);
        jFormattedTextFieldTel2.setEditable(true);
        jTextFieldEmail.setEditable(true);
        jTextFieldSite.setEditable(true);
        jFormattedTextFieldCPF.setEditable(true);
        jFormattedTextFieldCNPJ.setEditable(true);
        jTextAreaOBS.setEditable(true);
        
    }
    
    public void AbilitaItens (){
        
        jTextFieldCod.setEnabled(true);
        jTextFieldNome.setEnabled(true);
        jTextFieldEndereco.setEnabled(true);
        jTextFieldBairro.setEnabled(true);
        jTextFieldCidade.setEnabled(true);
        jComboBoxEstado.setEnabled(true);
        jFormattedTextFieldCEP.setEnabled(true);
        jFormattedTextFieldTel1.setEnabled(true);
        jFormattedTextFieldTel2.setEnabled(true);
        jTextFieldEmail.setEnabled(true);
        jTextFieldSite.setEnabled(true);
        jFormattedTextFieldCPF.setEnabled(true);
        jFormattedTextFieldCNPJ.setEnabled(true);
        jTextAreaOBS.setEnabled(true);
        
    }
    
    public void LimpaItens (){
        
        jTextFieldCod.setText("");
        jTextFieldNome.setText("");
        jTextFieldEndereco.setText("");
        jTextFieldBairro.setText("");
        jTextFieldCidade.setText("");
        jComboBoxEstado.setSelectedItem("BA");
        jFormattedTextFieldCEP.setText("");
        jFormattedTextFieldTel1.setText("");
        jFormattedTextFieldTel2.setText("");
        jTextFieldEmail.setText("");
        jTextFieldSite.setText("");
        jFormattedTextFieldCPF.setText("");
        jFormattedTextFieldCNPJ.setText("");
        jTextAreaOBS.setText("");
        
    }
    
    public class FilePreviewer extends JComponent implements
            PropertyChangeListener {

        ImageIcon thumbnail = null;

        @SuppressWarnings("LeakingThisInConstructor")
        public FilePreviewer(JFileChooser fc) {
            setPreferredSize(new Dimension(100, 50));
            fc.addPropertyChangeListener(this);
        }

        public void loadImage(File f) {
            if (f == null) {
                thumbnail = null;
            } else {
                ImageIcon tmpIcon = new ImageIcon(f.getPath());
                if (tmpIcon.getIconWidth() > 90) {
                    thumbnail = new ImageIcon(
                            tmpIcon.getImage().getScaledInstance(90, -1,
                            Image.SCALE_DEFAULT));
                } else {
                    thumbnail = tmpIcon;
                }
            }
        }

        public void propertyChange(PropertyChangeEvent e) {
            String prop = e.getPropertyName();
            if (SELECTED_FILE_CHANGED_PROPERTY.equals(prop)) {
                if (isShowing()) {
                    loadImage((File) e.getNewValue());
                    repaint();
                }
            }
        }

        @Override
        public void paint(Graphics g) {
            if (thumbnail != null) {
                int x = getWidth() / 2 - thumbnail.getIconWidth() / 2;
                int y = getHeight() / 2 - thumbnail.getIconHeight() / 2;
                if (y < 0) {
                    y = 0;
                }

                if (x < 5) {
                    x = 5;
                }
                thumbnail.paintIcon(this, g, x, y);
            }
        }
        }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAbrir;
    private javax.swing.JButton jButtonEditar;
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JComboBox jComboBoxEstado;
    private javax.swing.JFormattedTextField jFormattedTextFieldCEP;
    private javax.swing.JFormattedTextField jFormattedTextFieldCNPJ;
    private javax.swing.JFormattedTextField jFormattedTextFieldCPF;
    private javax.swing.JFormattedTextField jFormattedTextFieldTel1;
    private javax.swing.JFormattedTextField jFormattedTextFieldTel2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextAreaOBS;
    private controle.ClassUpperField jTextFieldBairro;
    private controle.ClassUpperField jTextFieldCidade;
    private controle.ClassUpperField jTextFieldCod;
    private javax.swing.JTextField jTextFieldEmail;
    private controle.ClassUpperField jTextFieldEndereco;
    private controle.ClassUpperField jTextFieldNome;
    private javax.swing.JTextField jTextFieldSite;
    // End of variables declaration//GEN-END:variables
}
