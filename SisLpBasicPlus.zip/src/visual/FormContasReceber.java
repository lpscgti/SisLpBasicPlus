
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.ConnectionFactory2;
import controle.ControleEmpresa;
import controle.PlanodeFundoForms;
import controle.formata_janela_principal;
import modelo.ModeloTabela;
import java.awt.BorderLayout;
import java.awt.Image;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.ListSelectionModel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.text.MaskFormatter;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;
import static visual.FormPrincipal.AreaDeTrabalhoPrincipal;


/**
 *
 * @author Lindembergue
 */
public class FormContasReceber extends javax.swing.JInternalFrame {
    ConectaBanco conCR = new ConectaBanco();
    formata_janela_principal visual_form = new formata_janela_principal();
    ControleEmpresa ctrl_de = new ControleEmpresa();
    String Titular, DtVencimento, DtCobrarJuros, OrigemDebito, DataHoje, DataPag, MsgAtrasoPag, caminhoDb, DataFormatada, DataConvertidaString;
    int CodConta, Parcela, QtdParcela, idOrigem, DiasCorridos, TempoJuros, flag=0, CodHisCont=0;
    double ValorParcela, ValorParcelaAtualizado, JurosAoMes, JurosAoDia, MultaAtraso, ValorPago, Valor_A_Pagar, ValorRestante, ValorRestanteAtualizado, ValorConvertido, ValorTotaljuros;
    double JurosCalc = 0;
    DecimalFormat formatoNum = new DecimalFormat("#0.00");
    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
//    SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");
//    SimpleDateFormat df3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
//    String SQLp = "select contas_receber.codigo as codconta,  contas_receber.venda, contas_receber.dtlancamento, contas_receber.dtvencimento, contas_receber.nparcela, contas_receber.parcelan,  contas_receber.valor, contas_receber.valorcj,  contas_receber.valortotalvcj, contas_receber.valorrest, contas_receber.situacao, contas_receber.dtpg, clientes.codigo as codcliente, clientes.nome as cliente from ((contas_receber inner join vendas on vendas.codigo=contas_receber.venda) inner join clientes on clientes.codigo=vendas.cliente) where situacao='NP' order by cdate(format(contas_receber.dtvencimento, 'dd/mm/yyyy')), cdate(format(contas_receber.dtlancamento, 'dd/mm/yyyy')) desc";
    java.sql.Date DataConvertidaSQL;
    Date DataConvertidaJava;
    public static String NomeJIF = "FormContasReceber";
    String sql = "";
    String dt_form_pesq = "";
    Date hoje;
    int JurusRemovido=0;
    boolean RetornoParcelaBatida=false;
    PreparedStatement pst;
    
    /**
     * Creates new form FormContasReceber
     */
    public FormContasReceber() {
        initComponents();
        ColocaImagemFundoFrame();
        hoje = new Date();
        DataHoje = (df.format(hoje));
        try {
//            MaskFormatter cep = new MaskFormatter("#####-###");
//            MaskFormatter tel = new MaskFormatter("(##) #####-####");
              //MaskFormatter Moeda = new MaskFormatter();
              MaskFormatter data = new MaskFormatter("##/##/####");
//            MaskFormatter rg = new MaskFormatter("########-##");
//            MaskFormatter cpf = new MaskFormatter("###.###.###-##");
//            MaskFormatter cnpj = new MaskFormatter("##.###.###/####-##");
            //jFormattedTextFieldValorPago.setFormatterFactory(new DefaultFormatterFactory(Moeda));
        } catch (ParseException ex) {
            Logger.getLogger(FormCadClientes.class.getName()).log(Level.SEVERE, null, ex);
        }
        jFormattedTextFieldValorPago.setEnabled(false);
        
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
        Obtemdadosiniciais();
        jbtPrint.setEnabled(false);
    }
    
    public void Obtemdadosiniciais(){
        preencherjTablejTablePesquisa("select clientes.codigo as codcliente, clientes.nome as cliente, contas_receber.codigo as codconta,  contas_receber.dtlancamento, contas_receber.dtvencimento, contas_receber.nparcela, contas_receber.parcelan,  contas_receber.valor, contas_receber.valorcj,  contas_receber.valortotalvcj, contas_receber.valorrest, contas_receber.situacao, contas_receber.dtpg, contas_receber.origem, contas_receber.codorigem from (contas_receber inner join clientes on clientes.codigo=contas_receber.codcliente) where situacao='NP' order by contas_receber.dtvencimento, contas_receber.dtlancamento",jTablePesquisa);
    }
    
    public void ConvertDataParaString(java.sql.Date Data){
        
        DataConvertidaString = df.format(Data);
       
    }
    
    public void ConverteStringparaData(String Data){
        
        String dia = "" + Data.charAt(0) + Data.charAt(1);
        String mes = "" + Data.charAt(3) + Data.charAt(4);
        String ano = "" + Data.charAt(6) + Data.charAt(7) + Data.charAt(8) + Data.charAt(9);
        String dtfSQLData = ano+"-"+mes+"-"+dia;
        DataConvertidaSQL = java.sql.Date.valueOf(dtfSQLData);
        
    }
    
    public void QuebraData(String data){
        
        String dia = "" + data.charAt(0) + data.charAt(1);
        String mes = "" + data.charAt(3) + data.charAt(4);
        String ano = "" + data.charAt(6) + data.charAt(7) + data.charAt(8) + data.charAt(9);
    
        DataFormatada = ano+"-"+mes+"-"+dia;
        
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
    public void Converte_Valor_Jtf_Para_Double(String ValorEntrada){
        
        if (ValorEntrada.equals("")){
            ValorEntrada = "0";
        }else{
          
        }
        ValorConvertido = Double.parseDouble(ValorEntrada.replace(',', '.'));
    }
    
    public void AbreNovaJanela(JInternalFrame jif){
        visual_form.AbreNovaJanela(jif, AreaDeTrabalhoPrincipal);
    }
    
    public void preencherjTablejTablePesquisa(String SQL, JTable jtb){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Cód.","Dt. Vencimento","Nome do Cliente"};
        conCR.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conCR.executaSQL(SQL);
        try {
            conCR.rs.first();
            do{
                dados.add(new Object[]{conCR.rs.getString("codconta"), df.format(conCR.rs.getDate("dtvencimento")), conCR.rs.getString("cliente")});
        }while(conCR.rs.next());
        } catch (SQLException ex) {
            //JOptionPane.showMessageDialog(rootPane,"Erro ao Preencher ArrayList"+ex);
        }
        
        DefaultTableCellRenderer cellRenderC = new DefaultTableCellRenderer();
	cellRenderC.setHorizontalAlignment(SwingConstants.CENTER);
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jtb.setModel(modelo);
        jtb.getColumnModel().getColumn(0).setPreferredWidth(73);
        jtb.getColumnModel().getColumn(0).setCellRenderer(cellRenderC);
        jtb.getColumnModel().getColumn(0).setResizable(false);
        jtb.getColumnModel().getColumn(1).setPreferredWidth(95);
        jtb.getColumnModel().getColumn(1).setCellRenderer(cellRenderC);
        jtb.getColumnModel().getColumn(1).setResizable(false);
        jtb.getColumnModel().getColumn(2).setPreferredWidth(280);
        jtb.getColumnModel().getColumn(2).setResizable(false);
        jtb.setAutoResizeMode(jtb.AUTO_RESIZE_OFF);
        jtb.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conCR.desconecta();
              
    }
    
   public void PrintComprovante(int CodHisCont){
        int i = JOptionPane.showConfirmDialog(rootPane, "Deseja realizar a impressão do comprovante?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
            if(i == JOptionPane.YES_OPTION) {
                ctrl_de.Obtem_Dados_da_Empresa();
                try {
                    Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                    Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                    Map<String, Object> parametros = new HashMap<String, Object>();
                    Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                    //dados empresa
                    parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                    parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                    parametros.put( "cnpj", ctrl_de.de_cnpj );
                    parametros.put( "de_ie", ctrl_de.de_ie );
                    parametros.put( "endereco", ctrl_de.de_endereco );
                    parametros.put( "bairro", ctrl_de.de_bairro );
                    parametros.put( "cidade", ctrl_de.de_cidade );
                    parametros.put( "estado", ctrl_de.de_estado );
                    parametros.put( "cep", ctrl_de.de_cep );
                    parametros.put( "telefone1", ctrl_de.de_fone1 );
                    parametros.put( "telefone2", ctrl_de.de_fone2 );
                    parametros.put( "de_site", ctrl_de.de_site );
                    parametros.put( "email", ctrl_de.de_email );
                    parametros.put("logoimg",imagePath);
                    parametros.put( "idconta", CodHisCont );
                    JasperPrint jpPrint = null;
                if (OrigemDebito.equals("SERVIÇO")){
                    jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteContaReceberOS.jasper", parametros, ConnectionFactory2.getSlpConnection());
                }else{
                    jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteContaReceber.jasper", parametros, ConnectionFactory2.getSlpConnection());
                }
                    JRViewer viewer = new JRViewer(jpPrint);
                    viewer.setZoomRatio((float) 0.5);
                    JFrame frameRelatorio = new JFrame();
                    frameRelatorio.add( viewer, BorderLayout.CENTER );
                    frameRelatorio.setTitle("Comprovante de Pagamento");
                    frameRelatorio.setSize( 500, 500 );
                    frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                    frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                    frameRelatorio.setVisible( true );
                    } catch (JRException ex) {
                    JOptionPane.showMessageDialog(null, "Erro ao Gerar Comprovante de Pagamento para Impressão!/nErro: "+ex);
                    } catch (SQLException ex) {
                    Logger.getLogger(FormVendas.class.getName()).log(Level.SEVERE, null, ex);
                }
             //conOs.desconecta();
            }
   }
   
    
    
    public void PrintComprovanteHistoricoPag(){
        ctrl_de.Obtem_Dados_da_Empresa();
        try {
                Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                Map<String, Object> parametros = new HashMap<String, Object>();
                Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                //dados empresa
                parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                parametros.put( "cnpj", ctrl_de.de_cnpj );
                parametros.put( "de_ie", ctrl_de.de_ie );
                parametros.put( "endereco", ctrl_de.de_endereco );
                parametros.put( "bairro", ctrl_de.de_bairro );
                parametros.put( "cidade", ctrl_de.de_cidade );
                parametros.put( "estado", ctrl_de.de_estado );
                parametros.put( "cep", ctrl_de.de_cep );
                parametros.put( "telefone1", ctrl_de.de_fone1 );
                parametros.put( "telefone2", ctrl_de.de_fone2 );
                parametros.put( "de_site", ctrl_de.de_site );
                parametros.put( "email", ctrl_de.de_email );
                parametros.put("logoimg",imagePath);
                parametros.put( "idConta", CodConta );
                JasperPrint jpPrint = null;
                if (OrigemDebito.equals("SERVIÇO")){
                    jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteContaReceber_historico_pag_conta_os.jasper", parametros, ConnectionFactory2.getSlpConnection());
                }else{
                    jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteContaReceber_historico_pag_conta.jasper", parametros, ConnectionFactory2.getSlpConnection());
                }
                JRViewer viewer = new JRViewer(jpPrint);
                viewer.setZoomRatio((float) 0.5);
                JFrame frameRelatorio = new JFrame();
                frameRelatorio.add( viewer, BorderLayout.CENTER );
                frameRelatorio.setTitle("Histórico de Pagamentos");
                frameRelatorio.setSize( 500, 500 );
                frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                frameRelatorio.setVisible( true );
            } catch (JRException ex) {
                JOptionPane.showMessageDialog(null, "Erro ao Gerar Conta para Impressão!/nErro: "+ex);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Erro ao Gerar Conta para Impressão!/nErro: "+ex);
            }
    }
           
    public void PreencherTabelaPesquisa(){
            
            preencherjTablejTablePesquisa("select clientes.codigo as codcliente, clientes.nome as cliente, contas_receber.codigo as codconta,  contas_receber.dtlancamento, contas_receber.dtvencimento, contas_receber.nparcela, contas_receber.parcelan,  contas_receber.valor, contas_receber.valorcj,  contas_receber.valortotalvcj, contas_receber.valorrest, contas_receber.situacao, contas_receber.dtpg, contas_receber.origem, contas_receber.codorigem from (contas_receber inner join clientes on clientes.codigo=contas_receber.codcliente) where situacao='NP' order by contas_receber.dtvencimento, contas_receber.dtlancamento", jTablePesquisa);
        
    }
    
    public void Pesquisar(){
    //Codigo              0
    //nome do cliente     1
    //data                2
    //todas               3
    
        sql = "select clientes.codigo as codcliente, clientes.nome as cliente, contas_receber.codigo as codconta,  contas_receber.dtlancamento, contas_receber.dtvencimento, contas_receber.nparcela, contas_receber.parcelan,  contas_receber.valor, contas_receber.valorcj,  contas_receber.valortotalvcj, contas_receber.valorrest, contas_receber.situacao, contas_receber.dtpg, contas_receber.origem, contas_receber.codorigem from (contas_receber inner join clientes on clientes.codigo=contas_receber.codcliente) where situacao='NP' ";
        String DadosParaPesquisar = jTextFieldPesquisa.getText();
        String CampoPesquisa = "";
        int CampoEscolhido = (jComboBoxPesquisa.getSelectedIndex());
        if (CampoEscolhido == 0){
            if ("".equals(jTextFieldPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite um número para a pesquisa.");
            }else{
                int codpesq = Integer.parseInt(DadosParaPesquisar);

                CampoPesquisa = "and contas_receber.codigo='"+codpesq+"'";
            }
        }
        else if (CampoEscolhido == 1){CampoPesquisa = "and clientes.nome like '"+DadosParaPesquisar+"%' order by contas_receber.dtvencimento, contas_receber.dtlancamento";}
        else if (CampoEscolhido == 2){
            if (validaData(DadosParaPesquisar)){
                obtemformatodata(DadosParaPesquisar);
                CampoPesquisa = "and contas_receber.dtvencimento <= #"+dt_form_pesq+"# order by contas_receber.dtvencimento, contas_receber.dtlancamento";
            }
        }
        else if (CampoEscolhido == 3){CampoPesquisa = "order by contas_receber.dtvencimento, contas_receber.dtlancamento";}        
        else if (CampoEscolhido == 4){CampoPesquisa = "where autorizado_por like '"+DadosParaPesquisar+"%'";}
        preencherjTablejTablePesquisa(sql+CampoPesquisa, jTablePesquisa);
        jTextFieldPesquisa.requestFocus();
        
    }
    
    public void obtemformatodata (String Data){
        String dia = "" + Data.charAt(0) + Data.charAt(1);
        String mes = "" + Data.charAt(3) + Data.charAt(4);
        String ano = "" + Data.charAt(6) + Data.charAt(7) + Data.charAt(8) + Data.charAt(9);
        dt_form_pesq = ano+"-"+mes+"-"+dia;//+" 00:00:00"
    }
    
    public boolean validaData(String Data){
        String dateFormat = "dd/MM/uuuu";
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter
        .ofPattern(dateFormat)
        .withResolverStyle(ResolverStyle.STRICT);
        try {
            LocalDate date = LocalDate.parse(Data, dateTimeFormatter);
//            JOptionPane.showMessageDialog(rootPane, "Data valida");
            return true;
        } catch (DateTimeParseException e) {
//            JOptionPane.showMessageDialog(rootPane, "Data invalida, erro: "+e);
            return false;
        } 
    }
    
    public void ObtemDados(int cod){
       
        conCR.conecta();
        CodConta = cod;
        DataPag = null;
        OrigemDebito = "";
        idOrigem = 0;
        Titular = "";
        DtVencimento = null;
        DtCobrarJuros = null;
        Parcela = 0;
        QtdParcela = 0;
        ValorParcela = 0;
        ValorRestante = 0;
        String Origem = "";
        
        try {
            conCR.executaSQL("select clientes.codigo as codcliente, clientes.nome as cliente, contas_receber.codigo as codconta,  contas_receber.dtlancamento, contas_receber.dtvencimento, contas_receber.nparcela, contas_receber.parcelan,  contas_receber.valor, contas_receber.valorcj,  contas_receber.valortotalvcj, contas_receber.valorrest, contas_receber.situacao, contas_receber.dtpg, contas_receber.origem, contas_receber.codorigem from (contas_receber inner join clientes on clientes.codigo=contas_receber.codcliente) where situacao='NP' and contas_receber.codigo='"+cod+"'"); 
             
            if(conCR.rs.first()){
                
                    OrigemDebito = conCR.rs.getString("origem");
                    idOrigem = conCR.rs.getInt("codorigem");
                    Titular = conCR.rs.getString("cliente");
                    ConvertDataParaString(conCR.rs.getDate("dtvencimento"));
                    DtVencimento = DataConvertidaString;
                    if (conCR.rs.getDate("dtpg")!=null){
                    ConvertDataParaString(conCR.rs.getDate("dtpg"));
                    DtCobrarJuros = DataConvertidaString;
                    }else{
                        DtCobrarJuros = "";
                    }
//                    JOptionPane.showMessageDialog(null, DtCobrarJuros);
//                    Valor = conCR.rs.getDouble("valortotalvcj");
                    Parcela = conCR.rs.getInt("parcelan");
                    QtdParcela = conCR.rs.getInt("nparcela");
                    ValorParcela = conCR.rs.getDouble("valor");
                    ValorRestante = conCR.rs.getDouble("valorrest");
                    jTextFieldTitular.setText(Titular);
                    jFormattedTextFieldDtVenc.setText(DtVencimento);
                    if (OrigemDebito.equals("SERVIÇO")){
                        Origem = "ORDEM DE SERVIÇO";
                        jTextFieldOrigem.setText(Origem);
                    } else {
                        Origem = "VENDA";
                        jTextFieldOrigem.setText(Origem);
                    }
                    jTextFieldValor.setText(String.valueOf(formatoNum.format(ValorParcela)));
                    jTextFieldParcelaStatus.setText(String.valueOf(Parcela)+" de "+String.valueOf(QtdParcela));
                    jTextFieldResumoCodOrigem.setText("Código da "+Origem+":  "+idOrigem+"");
                    jdt_dt_pag.setDate(hoje);
                    jdt_dt_pag.setEnabled(true);
                    CalculaJurus();
        
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(FormContasReceber.class.getName()).log(Level.SEVERE, null, ex);
        }
        conCR.desconecta();
    }
    
    public void CalculaJurus(){
            conCR.conecta();
            JurosAoMes = 0;
            JurosAoDia = 0;
            TempoJuros = 0;
            MultaAtraso = 0;
            DiasCorridos = 0;
            MsgAtrasoPag = "";
            ValorTotaljuros = 0;
            
            GregorianCalendar DataVencimentoTMP = new GregorianCalendar();  //data de vencimento;
            GregorianCalendar DataAtualTMP = new GregorianCalendar(); //data atual ou data selecionada;
            GregorianCalendar DataPagamentoTMP = new GregorianCalendar(); //data de pagamento;
            SimpleDateFormat FormataDataDDMMYYYY = new SimpleDateFormat ("dd/MM/yyyy"); //formato de data;
            try {
                
                conCR.executaSQL("select * from config where codigo=1");
                if (conCR.rs.first()){
                    JurosAoMes = (conCR.rs.getDouble("jurosmes"));//obtem o vlaor do juros;
                    JurosAoDia = (conCR.rs.getDouble("jurosdia"));//obtem o valor do juros ao dia;
                    TempoJuros = (conCR.rs.getInt("cobrarjuros"));//obtem o numero inicia de dias em atraso para iniciar cobrança de juros;
                    MultaAtraso = (conCR.rs.getDouble("multaatraso"));
                }

                DataAtualTMP.setTime(jdt_dt_pag.getDate());
                long DataAtualNLongo = DataAtualTMP.getTimeInMillis(); //Converte Data Atual para Numero Longo;
                long DiasCorridosNLongo = 0; //define nº de dias corridos;
                JurosCalc = 0; //define valor do juros calculado;
                
                if (DtCobrarJuros.equals("")){//verifica se a daata de pagamento na conta está em branco;
                    DataVencimentoTMP.setTime(FormataDataDDMMYYYY.parse(DtVencimento)); //se a data de pagamento da conta estiver em branco é considerado a data de vencimento original;
                }else{
                    DataVencimentoTMP.setTime(FormataDataDDMMYYYY.parse(DtCobrarJuros));// se a data de pagamento estiver preenchida será considerada no calculo do juros, substituindo a data de vencimento;
                }                
                long DataVencimentoNLongo = DataVencimentoTMP.getTimeInMillis();// Converte data de Vencimento em Numero longo, facilitando o calculo de comparação entre datas;
                DiasCorridosNLongo =  (DataAtualNLongo-DataVencimentoNLongo) / 86400000; // Dias Corridos
//                      JOptionPane.showMessageDialog(rootPane, "Dias Corridos: "+DiasCorridosNLongo+"  TempoJuros: "+TempoJuros);
                        if (DiasCorridosNLongo>=TempoJuros){
                            DiasCorridos = (int) (DiasCorridosNLongo);
                            JurosCalc = ((ValorRestante*JurosAoMes)/TempoJuros)+(((ValorRestante*JurosAoDia)/TempoJuros)*MultaAtraso);
                            ValorTotaljuros = JurosCalc;
                            ValorRestanteAtualizado = (ValorRestante+(JurosCalc));
                            jTextFieldValorParcelaCJ.setText(String.valueOf(formatoNum.format(ValorRestanteAtualizado)));
                            MsgAtrasoPag = "Parcela em atraso por "+String.valueOf(DiasCorridos)+" dia(s).";
                            jTextFieldAtraso.setText(MsgAtrasoPag);
                        }else{
                            ValorRestanteAtualizado = (ValorRestante);
                            MsgAtrasoPag = "Parcela não está em atraso.";
                            jTextFieldValorParcelaCJ.setText(String.valueOf(formatoNum.format(ValorParcela)));
                            jTextFieldAtraso.setText(MsgAtrasoPag);
                        }
                        
                        conCR.executaSQL("select * from contas_receber_historico where conta='"+CodConta+"'");
                        if (conCR.rs.first()){
                                jTextFieldStatusParcela.setText("Essa conta já teve abatimento de valor, verifique o histórico.");
                            }else{
                                jTextFieldStatusParcela.setText("");
                            }
                        jTextFieldValorApagar.setText(String.valueOf(formatoNum.format(ValorRestanteAtualizado)));
                        jFormattedTextFieldValorPago.setEnabled(true);
                        jFormattedTextFieldValorPago.setText(jTextFieldValorApagar.getText());
            } catch (ParseException ex) {
                Logger.getLogger(FormContasReceber.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
            Logger.getLogger(FormContasReceber.class.getName()).log(Level.SEVERE, null, ex);
            }
            conCR.desconecta();
        
    }
    
    public void RemoveJurus(){
        
                        double ValorARemover = 0;
                        ValorARemover = ValorRestanteAtualizado-ValorTotaljuros;
                        ValorRestanteAtualizado = ValorARemover;
                        jTextFieldValorParcelaCJ.setText(String.valueOf(formatoNum.format(ValorRestanteAtualizado)));
                        jTextFieldValorApagar.setText(String.valueOf(formatoNum.format(ValorRestanteAtualizado)));
            
    }
    
    public void VerificaSeContaAbatida(int CodTMP){
        conCR.conecta();
        sql = "select contas_receber.codigo as codconta, contas_receber.codcliente, contas_receber.cliente, "
                + "contas_receber.dtlancamento, contas_receber.dtvencimento,contas_receber.nparcela, "
                + "contas_receber.parcelan, contas_receber.valor, contas_receber.valorcj, "
                + "contas_receber.valortotalvcj, contas_receber.entrada, contas_receber.situacao, "
                + "contas_receber.dtpg, contas_receber.origem, contas_receber.codorigem, "
                + "contas_receber_historico.codigo as codhisconta, contas_receber_historico.datapg, "
                + "contas_receber_historico.valorapg, contas_receber_historico.valorpago from "
                + "(contas_receber inner join contas_receber_historico on contas_receber_historico.conta=contas_receber.codigo) "
                + "where contas_receber.situacao='NP' and contas_receber.codigo='"+CodTMP+"'";
        conCR.executaSQL(sql);
        try {
            if (conCR.rs.first()){
                RetornoParcelaBatida = true;
            }else{
                RetornoParcelaBatida = false;
            }
        } catch (SQLException ex) {
            Logger.getLogger(FormContasReceber.class.getName()).log(Level.SEVERE, null, ex);
        }
        conCR.desconecta();
    }
    
    public boolean AtualizaConta(){
        conCR.conecta();
            int n; //variavel de referencia de erro no Statement boolen
//          verificando a diferença entre o valor pago e o valor a pagar através da variável  ValorRestanteAtualizado 
            double v_ref = 0.10; //até 0,10 será considerado como PG qualquer conta;
//          ********************************************************************            
            ValorConvertido = 0;
            Converte_Valor_Jtf_Para_Double(jFormattedTextFieldValorPago.getText());
            ValorPago = ValorConvertido;
//          *****************************************************************************************************            
            ValorConvertido = 0;
            Converte_Valor_Jtf_Para_Double(jTextFieldValorApagar.getText());
            Valor_A_Pagar = ValorConvertido;
            ValorRestanteAtualizado = Valor_A_Pagar-ValorPago;
            
//          ****************************************************************************************************            
            ValorConvertido = 0;
//          ****************************************************************************************************
//          Verificando se existe um valor digitado no campo Valor Pago:
        if (ValorRestanteAtualizado<=v_ref){
            
                try {
                        pst = conCR.conn.prepareStatement("update contas_receber set situacao=?, dtpg=?, valorrest=?, valorcj=?, valortotalvcj=? where codigo=?");
                        pst.setString(1, "PG");
                        pst.setDate(2, new java.sql.Date(jdt_dt_pag.getDate().getTime()));
                        pst.setDouble(3, 0);
                        pst.setDouble(4, Valor_A_Pagar);
                        pst.setDouble(5, Valor_A_Pagar);
                        pst.setInt(6, CodConta);
                        int v01 = pst.executeUpdate();
                        if (v01 > 0){
                            pst = conCR.conn.prepareStatement("insert into contas_receber_historico (conta, datapg, valorapg, valorpago) values (?,?,?,?)");
                            pst.setInt(1, CodConta);
                            pst.setDate(2, new java.sql.Date(jdt_dt_pag.getDate().getTime()));
                            pst.setDouble(3, Valor_A_Pagar);                    
                            pst.setDouble(4, Valor_A_Pagar);
                            int v02 = pst.executeUpdate();
                            if (v02 > 0){
                                conCR.executaSQL("select * from contas_receber_historico where conta='"+CodConta+"'");
                                if (conCR.rs.last()){
                                    CodHisCont = conCR.rs.getInt("codigo");
                                    PergutaImpressaoComprovante(CodHisCont);
                                    return true;
                                }else{
                                    return false;
                                }
                            }else{
                                return false;
                            }

                        }else{
                            return false;
                        }   
                } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(rootPane, ex);
                }
            
        }else{
            
                try {
                        pst = conCR.conn.prepareStatement("update contas_receber set dtpg=?, valorrest=?, valorcj=?, valortotalvcj=? where codigo=?");
                        pst.setDate(1, new java.sql.Date(jdt_dt_pag.getDate().getTime()));
                        pst.setDouble(2, ValorRestanteAtualizado);
                        pst.setDouble(3, Valor_A_Pagar);
                        pst.setDouble(4, Valor_A_Pagar);
                        pst.setInt(5, CodConta);
                        int f01 = pst.executeUpdate();
                        if (f01 > 0){
                                pst = conCR.conn.prepareStatement("insert into contas_receber_historico (conta, datapg, valorapg, valorpago) values (?,?,?,?)");
                                pst.setInt(1, CodConta);
                                pst.setDate(2, new java.sql.Date(jdt_dt_pag.getDate().getTime()));
                                pst.setDouble(3, Valor_A_Pagar);                    
                                pst.setDouble(4, ValorPago);
                                int f02 = pst.executeUpdate();
                                if (f02 >0){
                                    conCR.executaSQL("select * from contas_receber_historico where conta='"+CodConta+"'");
                                    if (conCR.rs.last()){
                                        CodHisCont = conCR.rs.getInt("codigo");
                                        PergutaImpressaoComprovante(CodHisCont);
                                        return true;
                                    }else{
                                        return false;
                                    }
                                }else{
                                   return false; 
                                }
                        }else{
                            return false;
                        }
                } catch (SQLException ex) {
                        JOptionPane.showMessageDialog(rootPane, ex);
                }
        }
        conCR.desconecta();
        return false;
    }
    
    public void PergutaImpressaoComprovante(int codigotmp){
         
        int i = JOptionPane.showConfirmDialog(null, "Pagamento efetuado com sucesso!","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
        if(i == JOptionPane.YES_OPTION) {
            PrintComprovante(codigotmp);
        }
        
    }
    
    public boolean AtualizaContaJurosHis(){
        conCR.conecta();
        int n;
        PreparedStatement pst;
            try {
                    pst = conCR.conn.prepareStatement("insert into contas_receber_juros_his (conta, datapg, valor_juros, obs) values (?,?,?,?)");
                    pst.setInt(1, CodConta);
                    pst.setDate(2, new java.sql.Date(jdt_dt_pag.getDate().getTime()));                  
                    pst.setDouble(3, ValorTotaljuros);
                    pst.setString(4, "Jurus dispensado para esta conta. Usuário logado: "+FormPrincipal.UsuarioLogado);
                    n=pst.executeUpdate();
                        if (n!=0){
                            return true;
                        }else{
                            return false;
                        }
                } catch (SQLException ex) {
                
                }
        conCR.desconecta();
        JurusRemovido = 0;
        return false;
    } 
    
    public void s_senha_ao_dispensar_juros (){
        if (FormPrincipal.UsuarioPermissao.equals("2")){
                DialogConfSenha DPSenha = new DialogConfSenha();
                DPSenha.setModal(true);
                DPSenha.setVisible(true);
                String SenhaDig = DPSenha.Senha;
                if (FormPrincipal.SenhaULogado.equals(SenhaDig)){
                    mensagem_rem_juros_edita_conta();
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Senha não confere!");
                }
        }else{
            JOptionPane.showMessageDialog(rootPane, "Você não possui permissão suficiente\n para executar esta ação.");
        }
    }
    
    public void mensagem_rem_juros_edita_conta(){
        JLabel labelM = new JLabel("<HTML>Escolha uma opção <br>campo e confirme no botão 'OK'.<br /></HTML>");
        JComboBox jcb_opcao = new JComboBox();
        jcb_opcao.removeAllItems();
        jcb_opcao.addItem("Remover Juros");
        jcb_opcao.addItem("Editar Manualmente");
        
        int pi = JOptionPane.showConfirmDialog(this,new Object[]{labelM, jcb_opcao},"Editar Conta", JOptionPane.OK_CANCEL_OPTION);
        
        if(pi == JOptionPane.OK_OPTION) {
            if (jcb_opcao.getSelectedItem().equals("Remover Juros")){
                RemoveJurus();
                JurusRemovido = 1;
            }if (jcb_opcao.getSelectedItem().equals("Editar Manualmente")) {
                FormAtualizaContasReceberManual form_acr = new FormAtualizaContasReceberManual();
                form_acr.ObtemDados(CodConta);
                AbreNovaJanela(form_acr);
                Obtemdadosiniciais();
            }
        }
    }
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisa = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jFormattedTextFieldDtVenc = new javax.swing.JFormattedTextField();
        jTextFieldOrigem = new javax.swing.JTextField();
        jTextFieldValor = new javax.swing.JTextField();
        jTextFieldParcelaStatus = new javax.swing.JTextField();
        jTextFieldValorParcelaCJ = new javax.swing.JTextField();
        jTextFieldValorApagar = new javax.swing.JTextField();
        jTextFieldResumoCodOrigem = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jFormattedTextFieldValorPago = new javax.swing.JFormattedTextField();
        jTextFieldAtraso = new javax.swing.JTextField();
        jButtonEfetuarPG = new javax.swing.JButton();
        jdt_dt_pag = new com.toedter.calendar.JDateChooser();
        jButton2 = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextFieldStatusParcela = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextFieldTitular = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jComboBoxPesquisa = new javax.swing.JComboBox();
        jTextFieldPesquisa = new controle.ClassUpperField();
        jButtonPesq = new javax.swing.JButton();
        jButtonSair = new javax.swing.JButton();
        jbtPrint = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setTitle("Contas a Receber");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jTablePesquisa.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTablePesquisa.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePesquisaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablePesquisa);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 70, 450, 400);

        jPanel2.setBackground(java.awt.Color.white);
        jPanel2.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(51, 102, 255));
        jLabel2.setText("Titular:");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(10, 10, 50, 20);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(51, 102, 255));
        jLabel3.setText("Data de Vencimento:");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(10, 50, 130, 20);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(51, 102, 255));
        jLabel4.setText("Origem do Débito:");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(10, 70, 120, 20);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 102, 255));
        jLabel5.setText("Valor Original R$:");
        jPanel2.add(jLabel5);
        jLabel5.setBounds(10, 90, 110, 20);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(51, 102, 255));
        jLabel6.setText("Parcela:");
        jPanel2.add(jLabel6);
        jLabel6.setBounds(10, 110, 60, 20);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(51, 102, 255));
        jLabel10.setText("Valor da Parcela C/Juros R$:");
        jPanel2.add(jLabel10);
        jLabel10.setBounds(10, 130, 180, 20);

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(51, 102, 255));
        jLabel12.setText("Valor à Pagar R$:");
        jPanel2.add(jLabel12);
        jLabel12.setBounds(10, 150, 110, 20);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(51, 102, 255));
        jLabel9.setText("Data de Pagamento:");
        jPanel2.add(jLabel9);
        jLabel9.setBounds(10, 290, 140, 25);

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(51, 102, 255));
        jLabel11.setText("Valor Pago:");
        jPanel2.add(jLabel11);
        jLabel11.setBounds(160, 290, 140, 25);

        jFormattedTextFieldDtVenc.setEditable(false);
        jFormattedTextFieldDtVenc.setBackground(java.awt.Color.white);
        jFormattedTextFieldDtVenc.setBorder(null);
        jFormattedTextFieldDtVenc.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jFormattedTextFieldDtVenc.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jFormattedTextFieldDtVenc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFormattedTextFieldDtVencActionPerformed(evt);
            }
        });
        jPanel2.add(jFormattedTextFieldDtVenc);
        jFormattedTextFieldDtVenc.setBounds(140, 50, 150, 20);

        jTextFieldOrigem.setEditable(false);
        jTextFieldOrigem.setBackground(new java.awt.Color(255, 255, 255));
        jTextFieldOrigem.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jTextFieldOrigem.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jTextFieldOrigem.setBorder(null);
        jPanel2.add(jTextFieldOrigem);
        jTextFieldOrigem.setBounds(130, 70, 160, 20);

        jTextFieldValor.setEditable(false);
        jTextFieldValor.setBackground(new java.awt.Color(255, 255, 255));
        jTextFieldValor.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jTextFieldValor.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jTextFieldValor.setBorder(null);
        jTextFieldValor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldValorActionPerformed(evt);
            }
        });
        jPanel2.add(jTextFieldValor);
        jTextFieldValor.setBounds(130, 90, 110, 20);

        jTextFieldParcelaStatus.setEditable(false);
        jTextFieldParcelaStatus.setBackground(new java.awt.Color(255, 255, 255));
        jTextFieldParcelaStatus.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jTextFieldParcelaStatus.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jTextFieldParcelaStatus.setBorder(null);
        jTextFieldParcelaStatus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldParcelaStatusActionPerformed(evt);
            }
        });
        jPanel2.add(jTextFieldParcelaStatus);
        jTextFieldParcelaStatus.setBounds(70, 110, 110, 20);

        jTextFieldValorParcelaCJ.setEditable(false);
        jTextFieldValorParcelaCJ.setBackground(java.awt.Color.white);
        jTextFieldValorParcelaCJ.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jTextFieldValorParcelaCJ.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jTextFieldValorParcelaCJ.setBorder(null);
        jPanel2.add(jTextFieldValorParcelaCJ);
        jTextFieldValorParcelaCJ.setBounds(190, 130, 110, 20);

        jTextFieldValorApagar.setEditable(false);
        jTextFieldValorApagar.setBackground(java.awt.Color.white);
        jTextFieldValorApagar.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jTextFieldValorApagar.setHorizontalAlignment(javax.swing.JTextField.LEFT);
        jTextFieldValorApagar.setBorder(null);
        jPanel2.add(jTextFieldValorApagar);
        jTextFieldValorApagar.setBounds(120, 150, 180, 20);

        jTextFieldResumoCodOrigem.setEditable(false);
        jTextFieldResumoCodOrigem.setBackground(new java.awt.Color(255, 255, 255));
        jTextFieldResumoCodOrigem.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jTextFieldResumoCodOrigem.setForeground(new java.awt.Color(51, 102, 255));
        jTextFieldResumoCodOrigem.setBorder(null);
        jTextFieldResumoCodOrigem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldResumoCodOrigemActionPerformed(evt);
            }
        });
        jPanel2.add(jTextFieldResumoCodOrigem);
        jTextFieldResumoCodOrigem.setBounds(10, 250, 290, 25);
        jPanel2.add(jSeparator1);
        jSeparator1.setBounds(10, 280, 290, 10);

        jFormattedTextFieldValorPago.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jFormattedTextFieldValorPago.setForeground(new java.awt.Color(0, 102, 102));
        jFormattedTextFieldValorPago.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jFormattedTextFieldValorPago.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jFormattedTextFieldValorPagoKeyTyped(evt);
            }
        });
        jPanel2.add(jFormattedTextFieldValorPago);
        jFormattedTextFieldValorPago.setBounds(160, 320, 144, 25);

        jTextFieldAtraso.setEditable(false);
        jTextFieldAtraso.setBackground(new java.awt.Color(255, 255, 255));
        jTextFieldAtraso.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jTextFieldAtraso.setBorder(null);
        jPanel2.add(jTextFieldAtraso);
        jTextFieldAtraso.setBounds(10, 170, 290, 25);

        jButtonEfetuarPG.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButtonEfetuarPG.setForeground(new java.awt.Color(51, 102, 255));
        jButtonEfetuarPG.setText("Efetuar Pag.");
        jButtonEfetuarPG.setToolTipText("Confirmar Pagamento");
        jButtonEfetuarPG.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEfetuarPGActionPerformed(evt);
            }
        });
        jPanel2.add(jButtonEfetuarPG);
        jButtonEfetuarPG.setBounds(200, 360, 105, 30);

        jdt_dt_pag.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.add(jdt_dt_pag);
        jdt_dt_pag.setBounds(10, 320, 140, 25);
        jdt_dt_pag.getDateEditor().addPropertyChangeListener( new PropertyChangeListener() {
            public void propertyChange(PropertyChangeEvent e){

                if ("date".equals(e.getPropertyName())) {
                    CalculaJurus();
                }
            }
        });

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jButton2.setForeground(new java.awt.Color(51, 102, 255));
        jButton2.setText("Atualizar Manualmente");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel2.add(jButton2);
        jButton2.setBounds(10, 360, 180, 30);

        jScrollPane2.setBorder(null);

        jTextFieldStatusParcela.setEditable(false);
        jTextFieldStatusParcela.setBackground(java.awt.Color.white);
        jTextFieldStatusParcela.setColumns(20);
        jTextFieldStatusParcela.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTextFieldStatusParcela.setLineWrap(true);
        jTextFieldStatusParcela.setRows(2);
        jTextFieldStatusParcela.setWrapStyleWord(true);
        jTextFieldStatusParcela.setAutoscrolls(false);
        jTextFieldStatusParcela.setBorder(null);
        jScrollPane2.setViewportView(jTextFieldStatusParcela);

        jPanel2.add(jScrollPane2);
        jScrollPane2.setBounds(10, 200, 290, 35);

        jScrollPane3.setBorder(null);

        jTextFieldTitular.setEditable(false);
        jTextFieldTitular.setBackground(java.awt.Color.white);
        jTextFieldTitular.setColumns(20);
        jTextFieldTitular.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTextFieldTitular.setLineWrap(true);
        jTextFieldTitular.setRows(2);
        jTextFieldTitular.setWrapStyleWord(true);
        jTextFieldTitular.setAutoscrolls(false);
        jTextFieldTitular.setBorder(null);
        jScrollPane3.setViewportView(jTextFieldTitular);

        jPanel2.add(jScrollPane3);
        jScrollPane3.setBounds(60, 10, 240, 35);

        jPanelFundo.add(jPanel2);
        jPanel2.setBounds(470, 70, 310, 400);

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Método de Pesquisa:");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 4, 770, 30);

        jComboBoxPesquisa.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Código", "Nome do Cliente", "Data Vencimento", "Todas" }));
        jComboBoxPesquisa.setSelectedItem("Nome do Cliente");
        jComboBoxPesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxPesquisaActionPerformed(evt);
            }
        });
        jPanelFundo.add(jComboBoxPesquisa);
        jComboBoxPesquisa.setBounds(10, 30, 160, 30);

        jTextFieldPesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldPesquisaActionPerformed(evt);
            }
        });
        jTextFieldPesquisa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jTextFieldPesquisaKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldPesquisaKeyReleased(evt);
            }
        });
        jPanelFundo.add(jTextFieldPesquisa);
        jTextFieldPesquisa.setBounds(170, 30, 570, 30);

        jButtonPesq.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/btn_pesq_15.png"))); // NOI18N
        jButtonPesq.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonPesq.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesqActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesq);
        jButtonPesq.setBounds(740, 30, 40, 30);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 10, 790, 480);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(700, 500, 100, 40);

        jbtPrint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/printer.png"))); // NOI18N
        jbtPrint.setText("Imprimir");
        jbtPrint.setToolTipText("Imprimir Histórico de Pagamento da Conta");
        jbtPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtPrintActionPerformed(evt);
            }
        });
        getContentPane().add(jbtPrint);
        jbtPrint.setBounds(590, 500, 100, 40);

        setBounds(0, 0, 808, 575);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
        
        dispose();

    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonPesqActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesqActionPerformed
     
        Pesquisar();
        
    }//GEN-LAST:event_jButtonPesqActionPerformed

    private void jFormattedTextFieldDtVencActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFormattedTextFieldDtVencActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFormattedTextFieldDtVencActionPerformed

    private void jTextFieldValorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldValorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldValorActionPerformed

    private void jTextFieldResumoCodOrigemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldResumoCodOrigemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldResumoCodOrigemActionPerformed

    private void jTablePesquisaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePesquisaMouseClicked

        int line_sel = jTablePesquisa.getSelectedRow();
        if (line_sel>0){
            CodConta = Integer.parseInt(jTablePesquisa.getValueAt(line_sel, 0).toString());
            ObtemDados(CodConta);
            VerificaSeContaAbatida(CodConta);
                if (RetornoParcelaBatida==true){
                    jbtPrint.setEnabled(true);
                }else{
                    jbtPrint.setEnabled(false);
                }
        }
        
    }//GEN-LAST:event_jTablePesquisaMouseClicked

    private void jTextFieldParcelaStatusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldParcelaStatusActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldParcelaStatusActionPerformed

    private void jButtonEfetuarPGActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEfetuarPGActionPerformed


            String ivpg = jFormattedTextFieldValorPago.getText();
            if (ivpg.equals("")||ivpg==null){
                JOptionPane.showMessageDialog(rootPane, "Não é permitido que o campo valor pago fique em branco.");
                jFormattedTextFieldValorPago.grabFocus();
            }else{
                AtualizaConta();
                PreencherTabelaPesquisa();
                LimpaItens();
            }
            if (JurusRemovido==1){
                AtualizaContaJurosHis();
            }
                        
    }//GEN-LAST:event_jButtonEfetuarPGActionPerformed

    private void jTextFieldPesquisaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldPesquisaKeyTyped
        
       
        
    }//GEN-LAST:event_jTextFieldPesquisaKeyTyped

    private void jTextFieldPesquisaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldPesquisaKeyPressed
        
        
        
    }//GEN-LAST:event_jTextFieldPesquisaKeyPressed

    private void jTextFieldPesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldPesquisaKeyReleased
        
        Pesquisar();
        
    }//GEN-LAST:event_jTextFieldPesquisaKeyReleased

    private void jFormattedTextFieldValorPagoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jFormattedTextFieldValorPagoKeyTyped
        String caracteres="0987654321,.";
        if(!caracteres.contains(evt.getKeyChar()+"")){
        evt.consume();
       
        }
    }//GEN-LAST:event_jFormattedTextFieldValorPagoKeyTyped

    private void jComboBoxPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxPesquisaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxPesquisaActionPerformed

    private void jTextFieldPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldPesquisaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldPesquisaActionPerformed

    private void jbtPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtPrintActionPerformed
        // TODO add your handling code here:
        int linha = jTablePesquisa.getSelectedRow();
        
        if (linha>0){
            PrintComprovanteHistoricoPag();            
        }else{
            JOptionPane.showMessageDialog(null, "Selecione uma conta.");
            linha = jTablePesquisa.getSelectedRow();
        }
        
    }//GEN-LAST:event_jbtPrintActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // TODO add your handling code here:
        s_senha_ao_dispensar_juros();
    }//GEN-LAST:event_jButton2ActionPerformed

    public void LimpaItens(){
        jTextFieldTitular.setText("");
            jFormattedTextFieldDtVenc.setText("");
            jTextFieldOrigem.setText("");
            jTextFieldValor.setText("");
            jTextFieldParcelaStatus.setText("");
            jTextFieldValorParcelaCJ.setText("");
            jTextFieldValorApagar.setText("");
//            jdt_dt_pag.setDate(null);
            jdt_dt_pag.setDate(hoje);
            jFormattedTextFieldValorPago.setText("");
            jTextFieldResumoCodOrigem.setText("");
            jFormattedTextFieldValorPago.setEnabled(false);
            jTextFieldAtraso.setText("");
            
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButtonEfetuarPG;
    private javax.swing.JButton jButtonPesq;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JComboBox jComboBoxPesquisa;
    private javax.swing.JFormattedTextField jFormattedTextFieldDtVenc;
    private javax.swing.JFormattedTextField jFormattedTextFieldValorPago;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTablePesquisa;
    private javax.swing.JTextField jTextFieldAtraso;
    private javax.swing.JTextField jTextFieldOrigem;
    private javax.swing.JTextField jTextFieldParcelaStatus;
    private controle.ClassUpperField jTextFieldPesquisa;
    private javax.swing.JTextField jTextFieldResumoCodOrigem;
    private javax.swing.JTextArea jTextFieldStatusParcela;
    private javax.swing.JTextArea jTextFieldTitular;
    private javax.swing.JTextField jTextFieldValor;
    private javax.swing.JTextField jTextFieldValorApagar;
    private javax.swing.JTextField jTextFieldValorParcelaCJ;
    private javax.swing.JButton jbtPrint;
    private com.toedter.calendar.JDateChooser jdt_dt_pag;
    // End of variables declaration//GEN-END:variables
}
