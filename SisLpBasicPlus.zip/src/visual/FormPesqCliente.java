/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.PlanodeFundoForms;
import java.beans.PropertyVetoException;
import modelo.ModeloTabela;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

/**
 *
 * @author Lindembergue
 */
public class FormPesqCliente extends javax.swing.JInternalFrame {
ConectaBanco conPesCli = new ConectaBanco();
String Usuario, UsuTipo;
public static String NomeJIF = "FormPesqCliente";
public boolean a_form_ex = false; //identifica se o jormulario foi aberto a partir de outro formulario.
public JInternalFrame jifr; //declara classe jif para permitir que o codigo consiga restaurar a janela do formulario de origem.

    /**
     * Creates new form FormPesquisaCliente
     */
    public FormPesqCliente() {
        initComponents();
        ColocaImagemFundoFrame();
        VerificaSeClientesCadastrados();
        jComboBoxTipoPesquisa.setSelectedIndex(1);
        preencherTablePesquisaOS("select * from clientes order by Codigo desc");
        jTextFieldCampoPesquisa.grabFocus();
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
    }
    
    public void VerificaSeClientesCadastrados(){
        
        conPesCli.conecta();
        conPesCli.executaSQL("select * from clientes");
    try {
        if (conPesCli.rs.first()){
            
        }else{
            JOptionPane.showMessageDialog(rootPane, "Não Existem Clientes Cadastrados");
            dispose();
        }
    } catch (SQLException ex) {
        Logger.getLogger(FormPesqCliente.class.getName()).log(Level.SEVERE, null, ex);
    }
        conPesCli.desconecta();
        
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    

    public void preencherTablePesquisaOS(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Còdigo","Cliente","Endereço","Bairro","Cidade", "Fone", "Fone", "CPF", "CNPJ", "Dt. Cadastro"};
        conPesCli.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conPesCli.executaSQL(SQL);
        
        try {
            conPesCli.rs.first();
            //JOptionPane.showMessageDialog(rootPane, conOsPesquisa.rs.getString("id"));
            do{
                dados.add(new Object[]{conPesCli.rs.getString("Codigo"), conPesCli.rs.getString("Nome"), conPesCli.rs.getString("Endereco"), conPesCli.rs.getString("Bairro"), conPesCli.rs.getString("Cidade"), conPesCli.rs.getString("FONE1"), conPesCli.rs.getString("FONE2"), conPesCli.rs.getString("CPF"), conPesCli.rs.getString("CNPJ"), conPesCli.rs.getString("dt_cadastro")});
            }while(conPesCli.rs.next());
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane,"Erro ao Obter Dados. \n Informação digitada não encontrada.");
        }
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTablePesquisaOS.setModel(modelo);
        jTablePesquisaOS.getColumnModel().getColumn(0).setPreferredWidth(60);
        jTablePesquisaOS.getColumnModel().getColumn(0).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(1).setPreferredWidth(240);
        jTablePesquisaOS.getColumnModel().getColumn(1).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(2).setPreferredWidth(250);
        jTablePesquisaOS.getColumnModel().getColumn(2).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(3).setPreferredWidth(180);
        jTablePesquisaOS.getColumnModel().getColumn(3).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(4).setPreferredWidth(150);
        jTablePesquisaOS.getColumnModel().getColumn(4).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(5).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(5).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(6).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(6).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(7).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(7).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(8).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(8).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(9).setPreferredWidth(80);
        jTablePesquisaOS.getColumnModel().getColumn(9).setResizable(false);
//        jTablePesquisaOS.getColumnModel().getColumn(10).setPreferredWidth(100);
//        jTablePesquisaOS.getColumnModel().getColumn(10).setResizable(false);
        jTablePesquisaOS.getTableHeader().setReorderingAllowed(false);
        jTablePesquisaOS.setAutoResizeMode(jTablePesquisaOS.AUTO_RESIZE_OFF);
        jTablePesquisaOS.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conPesCli.desconecta();
        
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBoxTipoPesquisa = new javax.swing.JComboBox();
        jButtonPesquisar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisaOS = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldCampoPesquisa = new controle.ClassUpperField();
        jButtonSair = new javax.swing.JButton();
        jButtonAbrir = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setIconifiable(true);
        setTitle("Clientes Cadastrados");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Pesquisar por:");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 10, 200, 16);

        jComboBoxTipoPesquisa.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Cód. Cliente", "Nome Cliente", "Data Cadastro", "Todas" }));
        jComboBoxTipoPesquisa.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBoxTipoPesquisaItemStateChanged(evt);
            }
        });
        jComboBoxTipoPesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoPesquisaActionPerformed(evt);
            }
        });
        jPanelFundo.add(jComboBoxTipoPesquisa);
        jComboBoxTipoPesquisa.setBounds(10, 30, 200, 30);

        jButtonPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/Search44Resultado.png"))); // NOI18N
        jButtonPesquisar.setToolTipText("");
        jButtonPesquisar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesquisar);
        jButtonPesquisar.setBounds(660, 30, 40, 30);

        jTablePesquisaOS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTablePesquisaOS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePesquisaOSMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablePesquisaOS);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 70, 690, 400);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Digite aqui os dados a pesquisar:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(210, 10, 390, 16);

        jTextFieldCampoPesquisa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldCampoPesquisaKeyReleased(evt);
            }
        });
        jPanelFundo.add(jTextFieldCampoPesquisa);
        jTextFieldCampoPesquisa.setBounds(210, 30, 450, 30);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 11, 710, 480);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(630, 500, 90, 40);

        jButtonAbrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/open folderResultado.png"))); // NOI18N
        jButtonAbrir.setText("Abrir");
        jButtonAbrir.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAbrirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAbrir);
        jButtonAbrir.setBounds(540, 500, 90, 40);

        setBounds(0, 0, 734, 575);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarActionPerformed
//        Cód. Cliente  = 0
//        Nome Cliente  = 1
//        Data Cadastro = 2
//        Todas         = 3
        
        int CampoEscolhido = (jComboBoxTipoPesquisa.getSelectedIndex());

        String DadosParaPesquisar = jTextFieldCampoPesquisa.getText();

        //preencherTablePesquisaOS("select os.id, clientes.nome_cliente, os.dt_abertura, funcionarios.nome_funcionario, os.status, os.total_os from os join clientes on clientes.id_cliente=os.id_cliente  join funcionarios on funcionarios.id_funcionario=os.id_funcionario where nome_cliente='%"+DadosParaPesquisar+"%'");

        if (CampoEscolhido == 0 ){
            if ("".equals(jTextFieldCampoPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite o codigo do Cliente para pesquisar.");
            } else {
                int idCliente = Integer.parseInt(DadosParaPesquisar);
                preencherTablePesquisaOS("select * from clientes where Codigo='"+idCliente+"'");
            }
        }

        if (CampoEscolhido == 1){
            preencherTablePesquisaOS("select * from clientes where nome like '"+DadosParaPesquisar+"%'");
        }

        if (CampoEscolhido == 2){
            preencherTablePesquisaOS("select * from clientes where dt_cadastro like '"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 3){
            preencherTablePesquisaOS("select * from clientes order by Codigo desc");
        }
        else{
            //JOptionPane.showMessageDialog(rootPane, "Erro ao Pesquisar dados!");
        }

    }//GEN-LAST:event_jButtonPesquisarActionPerformed

    private void jTablePesquisaOSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePesquisaOSMouseClicked
    if (evt.getClickCount()==2){
        int codClienteSel = jTablePesquisaOS.getSelectedRow();
            if (codClienteSel==(-1)){
            JOptionPane.showMessageDialog(rootPane, "Por favor, selecione um Cliente cadastrado.");
            } else {String codClientex = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
            int cdCli = Integer.parseInt(codClientex);
            FormAbreEditaClientes FrmAEClientes = new FormAbreEditaClientes();
            FrmAEClientes.AbreCadCliente(cdCli);
            FormPrincipal.AbreNovaJanelaS(FrmAEClientes);
            dispose();
            }
    }
    }//GEN-LAST:event_jTablePesquisaOSMouseClicked

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
        dispose();
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAbrirActionPerformed
        int codClienteSel = jTablePesquisaOS.getSelectedRow();
        if (codClienteSel==(-1)){
        JOptionPane.showMessageDialog(rootPane, "Por favor, selecione um Cliente cadastrado.");
        } else {String codClientex = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
        int cdCli = Integer.parseInt(codClientex);
        
            FormAbreEditaClientes FrmAEClientes = new FormAbreEditaClientes();
            FrmAEClientes.a_form_ex = true;
            FrmAEClientes.jifr = this;
            FrmAEClientes.AbreCadCliente(cdCli);
            FormPrincipal.AbreNovaJanelaS(FrmAEClientes);
            try {
                this.setIcon(true);
            } catch (PropertyVetoException ex) {

            }
            
        }
    }//GEN-LAST:event_jButtonAbrirActionPerformed

    private void jComboBoxTipoPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoPesquisaActionPerformed
        jTextFieldCampoPesquisa.grabFocus();
    }//GEN-LAST:event_jComboBoxTipoPesquisaActionPerformed

    private void jTextFieldCampoPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldCampoPesquisaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldCampoPesquisaActionPerformed

    private void jTextFieldCampoPesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldCampoPesquisaKeyReleased
        
        //        Cód. Cliente  = 0
//        Nome Cliente  = 1
//        Data Cadastro = 2
//        Todas         = 3
        
        int CampoEscolhido = (jComboBoxTipoPesquisa.getSelectedIndex());

        String DadosParaPesquisar = jTextFieldCampoPesquisa.getText();

        //preencherTablePesquisaOS("select os.id, clientes.nome_cliente, os.dt_abertura, funcionarios.nome_funcionario, os.status, os.total_os from os join clientes on clientes.id_cliente=os.id_cliente  join funcionarios on funcionarios.id_funcionario=os.id_funcionario where nome_cliente='%"+DadosParaPesquisar+"%'");

        if (CampoEscolhido == 0 ){
            if ("".equals(jTextFieldCampoPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite o codigo do Cliente para pesquisar.");
            } else {
                int idCliente = Integer.parseInt(DadosParaPesquisar);
                preencherTablePesquisaOS("select * from clientes where Codigo='"+idCliente+"'");
            }
        }

        if (CampoEscolhido == 1){
            preencherTablePesquisaOS("select * from clientes where nome like '"+DadosParaPesquisar+"%'");
        }

        if (CampoEscolhido == 2){
            preencherTablePesquisaOS("select * from clientes where dt_cadastro like '"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 3){
            preencherTablePesquisaOS("select * from clientes order by Codigo desc");
        }
        else{
            //JOptionPane.showMessageDialog(rootPane, "Erro ao Pesquisar dados!");
        }
        
    }//GEN-LAST:event_jTextFieldCampoPesquisaKeyReleased

    private void jComboBoxTipoPesquisaItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBoxTipoPesquisaItemStateChanged
    jTextFieldCampoPesquisa.grabFocus();
    }//GEN-LAST:event_jComboBoxTipoPesquisaItemStateChanged

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAbrir;
    private javax.swing.JButton jButtonPesquisar;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JComboBox jComboBoxTipoPesquisa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisaOS;
    private controle.ClassUpperField jTextFieldCampoPesquisa;
    // End of variables declaration//GEN-END:variables
}
