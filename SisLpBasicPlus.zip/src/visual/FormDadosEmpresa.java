/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.ControleEmpresa;
import controle.ManipularImagem;
import controle.FilePreviewer;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import modelo.ModeloDadosEmpresa;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.imageio.IIOException;
import javax.imageio.ImageIO;
import javax.swing.filechooser.FileNameExtensionFilter;


/**
 *
 * @author ProgXBERGUE
 */
public class FormDadosEmpresa extends javax.swing.JInternalFrame {
    ConectaBanco conDE = new ConectaBanco();
    ModeloDadosEmpresa modDE = new ModeloDadosEmpresa();
    ControleEmpresa ctrDE = new ControleEmpresa();
    int Editando = 0;
    public static String NomeJIF = "FormDadosEmpresa";
    BufferedImage imagem;
    BufferedImage imagem2;
    FilePreviewer previewer;
    /**
     * Creates new form FormDadosEmpresa
     */
    public FormDadosEmpresa() {
        initComponents();
        aplicavisual();
        Desativaitens();
        CarregaDados();
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
    }
    
    public static void aplicavisual(){
    try {
            UIManager.setLookAndFeel("com.jtattoo.plaf.fast.FastLookAndFeel");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FormDadosEmpresa.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(FormDadosEmpresa.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(FormDadosEmpresa.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(FormDadosEmpresa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void Ativaitens(){
        jBairro.setEnabled(true);
        jCep.setEnabled(true);
        jCidade.setEnabled(true);
        jCnpj.setEnabled(true);
        jEnd.setEnabled(true);
        jFone1.setEnabled(true);
        jFone2.setEnabled(true);
        jIE.setEnabled(true);
        jNFantasia.setEnabled(true);
        jRSocial.setEnabled(true);
        jSite.setEnabled(true);
        jemail.setEnabled(true);
        jcbEstado.setEnabled(true);
        jbt_logo.setEnabled(true);
    }
    
    public void Desativaitens(){
        jBairro.setEnabled(false);
        jCep.setEnabled(false);
        jCidade.setEnabled(false);
        jCnpj.setEnabled(false);
        jEnd.setEnabled(false);
        jFone1.setEnabled(false);
        jFone2.setEnabled(false);
        jIE.setEnabled(false);
        jNFantasia.setEnabled(false);
        jRSocial.setEnabled(false);
        jSite.setEnabled(false);
        jemail.setEnabled(false);
        jcbEstado.setEnabled(false);
        jbt_logo.setEnabled(false);
    }
    
    public void CarregaDados(){
        conDE.conecta();
        conDE.executaSQL("select * from dados_empresa where codigo=1");
        Path local_logo = Paths.get(System.getProperty("user.dir")+"/Base/logo.jpg");
        File arquivo = null;
        try {
            if (conDE.rs.first()){
                jBairro.setText(conDE.rs.getString("bairro"));
                jCep.setText(conDE.rs.getString("cep"));
                jCidade.setText(conDE.rs.getString("cidade"));
                jCnpj.setText(conDE.rs.getString("cnpj"));
                jEnd.setText(conDE.rs.getString("endereco"));
                jFone1.setText(conDE.rs.getString("fone1"));
                jFone2.setText(conDE.rs.getString("fone2"));
                jIE.setText(conDE.rs.getString("ie"));
                jNFantasia.setText(conDE.rs.getString("nomefantasia"));
                jRSocial.setText(conDE.rs.getString("razaosocial"));
                jSite.setText(conDE.rs.getString("site"));
                jemail.setText(conDE.rs.getString("email"));
                jcbEstado.setSelectedItem(conDE.rs.getString("estado"));
                
                arquivo = local_logo.toFile();
                if (arquivo.exists()){
                    imagem2 = ManipularImagem.setIamegemDimensao(arquivo.getAbsolutePath(), 126, 126);
                    jlb_logo.setIcon(new ImageIcon(imagem2));
                }
                    
                
                
               
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao obter dados.");
        }
        conDE.desconecta();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTextField1 = new javax.swing.JTextField();
        jbtEdit = new javax.swing.JButton();
        jbtSalvarSair = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jemail = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        jFone1 = new javax.swing.JFormattedTextField();
        jFone2 = new javax.swing.JFormattedTextField();
        jSite = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jNFantasia = new controle.ClassUpperField();
        jLabel2 = new javax.swing.JLabel();
        jRSocial = new controle.ClassUpperField();
        jLabel3 = new javax.swing.JLabel();
        jCnpj = new javax.swing.JFormattedTextField();
        jLabel4 = new javax.swing.JLabel();
        jIE = new javax.swing.JFormattedTextField();
        jLabel5 = new javax.swing.JLabel();
        jEnd = new controle.ClassUpperField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jBairro = new controle.ClassUpperField();
        jCidade = new controle.ClassUpperField();
        jcbEstado = new javax.swing.JComboBox<>();
        jCep = new javax.swing.JFormattedTextField();
        jPanel2 = new javax.swing.JPanel();
        jLabel14 = new javax.swing.JLabel();
        jbt_logo = new javax.swing.JButton();
        jlb_logo = new javax.swing.JLabel();

        jTextField1.setText("jTextField1");

        getContentPane().setLayout(null);

        jbtEdit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/editResultado.png"))); // NOI18N
        jbtEdit.setText("Editar");
        jbtEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtEditActionPerformed(evt);
            }
        });
        getContentPane().add(jbtEdit);
        jbtEdit.setBounds(370, 400, 100, 50);

        jbtSalvarSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/cleanResultado.png"))); // NOI18N
        jbtSalvarSair.setText("Salvar");
        jbtSalvarSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtSalvarSairActionPerformed(evt);
            }
        });
        getContentPane().add(jbtSalvarSair);
        jbtSalvarSair.setBounds(470, 400, 100, 50);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButton1.setText("Sair");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(570, 400, 100, 50);

        jPanel1.setBackground(java.awt.Color.white);
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jLabel12.setText("E-mail:");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(10, 320, 370, 16);
        jPanel1.add(jemail);
        jemail.setBounds(10, 340, 330, 25);

        jLabel10.setText("Telefone / Fax / Celular:");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(10, 210, 280, 16);
        jPanel1.add(jFone1);
        jFone1.setBounds(10, 230, 170, 25);
        jPanel1.add(jFone2);
        jFone2.setBounds(180, 230, 160, 25);
        jPanel1.add(jSite);
        jSite.setBounds(10, 280, 330, 25);

        jLabel11.setText("Site:");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(10, 260, 360, 16);

        jLabel1.setText("Nome Fantasia:");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(10, 10, 580, 16);
        jPanel1.add(jNFantasia);
        jNFantasia.setBounds(10, 30, 640, 25);

        jLabel2.setText("Razão Social:");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(10, 60, 640, 16);
        jPanel1.add(jRSocial);
        jRSocial.setBounds(10, 80, 640, 25);

        jLabel3.setText("CNPJ:");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(10, 110, 130, 16);
        jPanel1.add(jCnpj);
        jCnpj.setBounds(10, 130, 130, 25);

        jLabel4.setText("Inscrição Estadual:");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(140, 110, 130, 16);
        jPanel1.add(jIE);
        jIE.setBounds(140, 130, 130, 25);

        jLabel5.setText("Endereço:");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(270, 110, 320, 16);
        jPanel1.add(jEnd);
        jEnd.setBounds(270, 130, 380, 25);

        jLabel6.setText("Bairro:");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(10, 160, 160, 16);

        jLabel7.setText("Cidade:");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(170, 160, 280, 16);

        jLabel8.setText("Estado:");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(450, 160, 80, 16);

        jLabel9.setText("Cep:");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(530, 160, 120, 16);
        jPanel1.add(jBairro);
        jBairro.setBounds(10, 180, 160, 25);
        jPanel1.add(jCidade);
        jCidade.setBounds(170, 180, 280, 25);

        jcbEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR", "SC", "SE", "SP", "TO" }));
        jcbEstado.setSelectedIndex(4);
        jPanel1.add(jcbEstado);
        jcbEstado.setBounds(450, 180, 80, 25);
        jPanel1.add(jCep);
        jCep.setBounds(530, 180, 120, 25);

        jPanel2.setBackground(java.awt.Color.white);
        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.setLayout(null);

        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel14.setText("<html><justing>Adicione sua Logo, ela<br>será visualizada nos<br>relatórios. Utilize aquivo<br>.jpg ou .jpeg<html\\>");
        jPanel2.add(jLabel14);
        jLabel14.setBounds(10, 10, 130, 90);

        jbt_logo.setText("<html><center>Adicionar<br>Logo<html\\>");
        jbt_logo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_logoActionPerformed(evt);
            }
        });
        jPanel2.add(jbt_logo);
        jbt_logo.setBounds(10, 102, 130, 40);

        jlb_logo.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel2.add(jlb_logo);
        jlb_logo.setBounds(150, 10, 130, 130);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(360, 220, 290, 150);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 10, 660, 380);

        setBounds(0, 0, 690, 503);
    }// </editor-fold>//GEN-END:initComponents

    private void jbtEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtEditActionPerformed
    
        
        if (Editando == 0){
            Ativaitens();
            Editando = 1;
        }else{
            Desativaitens();
            Editando = 0;
        }
            
        
    }//GEN-LAST:event_jbtEditActionPerformed

    private void jbtSalvarSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtSalvarSairActionPerformed

        
        modDE.setBai(jBairro.getText());
        modDE.setCNPJ(jCnpj.getText());
        modDE.setCep(jCep.getText());
        modDE.setCid(jCidade.getText());
        modDE.setCod(1);
        modDE.setEmail(jemail.getText());
        modDE.setEnd(jEnd.getText());
        modDE.setEst(String.valueOf(jcbEstado.getSelectedItem()));
        modDE.setF1(jFone1.getText());
        modDE.setF2(jFone2.getText());
        modDE.setIE(jIE.getText());
        modDE.setNF(jNFantasia.getText());
        modDE.setRS(jRSocial.getText());
        modDE.setSite(jSite.getText());
        ctrDE.AlteraDados(modDE);
        Desativaitens();
        
        


    }//GEN-LAST:event_jbtSalvarSairActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        
        dispose();
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jbt_logoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_logoActionPerformed
        // TODO add your handling code here:
        File arquivo;
        JFileChooser fc = new JFileChooser();
        previewer = new FilePreviewer(fc);
        fc.setAccessory(previewer);
        fc.setFileFilter(new FileNameExtensionFilter("Archivos de Imagem", "jpg", "jpeg"));
        int respuesta = fc.showOpenDialog(null);
        if (respuesta == JFileChooser.APPROVE_OPTION) {
            arquivo = fc.getSelectedFile();
            imagem = ManipularImagem.setIamegemDimensao(arquivo.getAbsolutePath(), 76, 76);
            imagem2 = ManipularImagem.setIamegemDimensao(arquivo.getAbsolutePath(), 126, 126);
        jlb_logo.setIcon(new ImageIcon(imagem2)); 
        }
        Path local_logo = Paths.get(System.getProperty("user.dir")+"/Base/");
        try {
            ImageIO.write((imagem), "PNG", new File(local_logo+"/"+"logo.jpg"));
//        ModCliente.setFotoUrl(ManipularImagemFoto.getImgBytes(imagem));
        } catch (IOException ex) {
            Logger.getLogger(FormDadosEmpresa.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jbt_logoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private controle.ClassUpperField jBairro;
    private javax.swing.JButton jButton1;
    private javax.swing.JFormattedTextField jCep;
    private controle.ClassUpperField jCidade;
    private javax.swing.JFormattedTextField jCnpj;
    private controle.ClassUpperField jEnd;
    private javax.swing.JFormattedTextField jFone1;
    private javax.swing.JFormattedTextField jFone2;
    private javax.swing.JFormattedTextField jIE;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private controle.ClassUpperField jNFantasia;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private controle.ClassUpperField jRSocial;
    private javax.swing.JTextField jSite;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton jbtEdit;
    private javax.swing.JButton jbtSalvarSair;
    private javax.swing.JButton jbt_logo;
    private javax.swing.JComboBox<String> jcbEstado;
    private javax.swing.JTextField jemail;
    private javax.swing.JLabel jlb_logo;
    // End of variables declaration//GEN-END:variables
}
