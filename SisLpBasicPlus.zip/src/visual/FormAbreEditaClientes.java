/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.ControleCliente;
import controle.PlanodeFundoForms;
import modelo.ModeloCliente;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyVetoException;
import java.io.File;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import static javax.swing.JFileChooser.SELECTED_FILE_CHANGED_PROPERTY;
import javax.swing.JFormattedTextField;
import javax.swing.JInternalFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;

/**
 *
 * @author Lindembergue
 */
public class FormAbreEditaClientes extends javax.swing.JInternalFrame {
ModeloCliente ModCliente = new ModeloCliente();
ConectaBanco ConCliente = new ConectaBanco();
ControleCliente ControlCliente = new ControleCliente();
BufferedImage imagem;
FilePreviewer previewer;
int CodCliente;
String DataHoje, Usuario, UsuTipo;
public static String NomeJIF = "FormAbreEditaClientes";
public boolean a_form_ex = false; //identifica se o jormulario foi aberto a partir de outro formulario.
public JInternalFrame jifr; //declara classe jif para permitir que o codigo consiga restaurar a janela do formulario de origem.

    /**
     * Creates new form FormCadClientes
     */
    public FormAbreEditaClientes() {
        initComponents();
        ColocaImagemFundoFrame();
//        DesabilitaItens();
          DestivaEdicaoDeItens();
          jComboBoxEstado.setEnabled(false);
//        jComboBoxEstado.setSelectedItem("BA");
        
//        FormPrincipal.RetornoAbreEditaClientes = 1;
        
        try {
            MaskFormatter cep = new MaskFormatter("#####-###");
            MaskFormatter tel = new MaskFormatter("(##) #####-####");
            MaskFormatter data = new MaskFormatter("##/##/####");
//            MaskFormatter rg = new MaskFormatter("########-##");
            MaskFormatter cpf = new MaskFormatter("###.###.###-##");
            MaskFormatter cnpj = new MaskFormatter("##.###.###/####-##");
            jFormattedTextFieldCep.setFormatterFactory(new DefaultFormatterFactory(cep));
            jFormattedTextFieldDtNasc.setFormatterFactory(new DefaultFormatterFactory(data));
//            jFormattedTextFieldRG.setFormatterFactory(new DefaultFormatterFactory(rg));
            jFormattedTextFieldCPF.setFormatterFactory(new DefaultFormatterFactory(cpf));
            jFormattedTextFieldCNPJ.setFormatterFactory(new DefaultFormatterFactory(cnpj));
        } catch (ParseException ex) {
            Logger.getLogger(FormAbreEditaClientes.class.getName()).log(Level.SEVERE, null, ex);
        }
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
    }
    
    public void toUpperCase(String texto, java.awt.event.KeyEvent evento){
        evento.setKeyChar(texto.toUpperCase().charAt(0));
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
    private void mudaMascaraTelefone(JFormattedTextField format) {
        try {
            format.setValue(null);
            String nome = format.getText().replaceAll("-", "").replaceAll("\\(", "").replaceAll("\\)", "");
            final MaskFormatter mask = new MaskFormatter();
            switch (nome.length()) {
                case 8:
                    mask.setMask("####-####");
                    format.setFormatterFactory(new DefaultFormatterFactory(mask));
                    break;
                case 9:
                    mask.setMask("#####-####");
                    format.setFormatterFactory(new DefaultFormatterFactory(mask));
                    break;
                case 10:
                    mask.setMask("(##)####-####");
                    format.setFormatterFactory(new DefaultFormatterFactory(mask));
                    break;
                case 11:
                    mask.setMask("(##)#####-####");
                    format.setFormatterFactory(new DefaultFormatterFactory(mask));
                    break;
                default:
                    break;
            }
            format.setText(nome);
        } catch (Exception asd) {
            System.out.println(asd);
        }
    }
     
        public void AbreCadCliente(int CodClient){
        CodCliente = CodClient;
        ConCliente.conecta();
        
        try {
            ConCliente.executaSQL("select * from clientes where codigo='"+CodClient+"'");
            ConCliente.rs.first();
            jTextFieldCod.setText(String.valueOf(ConCliente.rs.getInt("codigo")));
            jTextFieldNome.setText(ConCliente.rs.getString("nome"));
            jTextFieldEndereco.setText(ConCliente.rs.getString("endereco"));
            jTextFieldBairro.setText(ConCliente.rs.getString("bairro"));
            jTextFieldCidade.setText(ConCliente.rs.getString("cidade"));
            jComboBoxEstado.setSelectedItem(ConCliente.rs.getString("estado"));
            jFormattedTextFieldCep.setText(ConCliente.rs.getString("cep"));
            jFormattedTextFieldFone1.setText(ConCliente.rs.getString("fone1"));
            jFormattedTextFieldFone2.setText(ConCliente.rs.getString("fone2"));
            jFormattedTextFieldDtNasc.setText(ConCliente.rs.getString("dt_cadastro"));
            if (ConCliente.rs.getString("PessoaJuridica")!=null){
                if(ConCliente.rs.getString("PessoaJuridica").equals("S")){
                    jCheckBoxPJ.setSelected(true);
                    jFormattedTextFieldCNPJ.setEnabled(true);
                    jFormattedTextFieldCPF.setEnabled(false);
                }else{
                    jCheckBoxPJ.setSelected(false);
                    jFormattedTextFieldCNPJ.setEnabled(false);
                    jFormattedTextFieldCPF.setEnabled(true);
                }
            }
            jFormattedTextFieldRG.setText(ConCliente.rs.getString("rg"));
            jFormattedTextFieldCPF.setText(ConCliente.rs.getString("cpf"));
            jFormattedTextFieldCNPJ.setText(ConCliente.rs.getString("cnpj"));
            jTextAreaOBS.setText(ConCliente.rs.getString("obs"));
            
            } catch (SQLException ex) {
            Logger.getLogger(FormAbreEditaClientes.class.getName()).log(Level.SEVERE, null, ex);
            } 
                        
            ConCliente.desconecta();
            
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jTextFieldCod = new controle.ClassUpperField();
        jTextFieldNome = new controle.ClassUpperField();
        jTextFieldEndereco = new controle.ClassUpperField();
        jTextFieldBairro = new controle.ClassUpperField();
        jTextFieldCidade = new controle.ClassUpperField();
        jComboBoxEstado = new javax.swing.JComboBox<>();
        jFormattedTextFieldCep = new javax.swing.JFormattedTextField();
        jFormattedTextFieldFone1 = new javax.swing.JFormattedTextField();
        jFormattedTextFieldFone2 = new javax.swing.JFormattedTextField();
        jCheckBoxPJ = new javax.swing.JCheckBox();
        jFormattedTextFieldDtNasc = new javax.swing.JFormattedTextField();
        jFormattedTextFieldRG = new javax.swing.JFormattedTextField();
        jFormattedTextFieldCPF = new javax.swing.JFormattedTextField();
        jFormattedTextFieldCNPJ = new javax.swing.JFormattedTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextAreaOBS = new controle.ClassUpperFieldText();
        jButtonAbrir = new javax.swing.JButton();
        jButtonEditar = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jButtonSair = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setIconifiable(true);
        setTitle("Cadastro de Clientes");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Código");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 10, 70, 16);

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nome/Razão:");
        jPanelFundo.add(jLabel3);
        jLabel3.setBounds(90, 10, 530, 16);

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Endereço:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(10, 60, 610, 16);

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Bairro:");
        jPanelFundo.add(jLabel4);
        jLabel4.setBounds(10, 110, 200, 16);

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Cidade:");
        jPanelFundo.add(jLabel5);
        jLabel5.setBounds(220, 110, 200, 16);

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Estado:");
        jPanelFundo.add(jLabel6);
        jLabel6.setBounds(430, 110, 70, 16);

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Cep:");
        jPanelFundo.add(jLabel7);
        jLabel7.setBounds(510, 110, 110, 16);

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Telefone, Celular, Contato, Fax...");
        jPanelFundo.add(jLabel11);
        jLabel11.setBounds(10, 160, 470, 16);

        jLabel14.setForeground(new java.awt.Color(255, 255, 255));
        jLabel14.setText("Dt. Nasc.");
        jPanelFundo.add(jLabel14);
        jLabel14.setBounds(490, 160, 130, 16);

        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("RG:");
        jPanelFundo.add(jLabel15);
        jLabel15.setBounds(10, 210, 140, 16);

        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("CPF:");
        jPanelFundo.add(jLabel16);
        jLabel16.setBounds(160, 210, 130, 16);

        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setText("CNPJ:");
        jPanelFundo.add(jLabel17);
        jLabel17.setBounds(300, 210, 140, 16);

        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("OBS:");
        jPanelFundo.add(jLabel18);
        jLabel18.setBounds(10, 270, 610, 16);
        jPanelFundo.add(jTextFieldCod);
        jTextFieldCod.setBounds(10, 30, 70, 25);
        jPanelFundo.add(jTextFieldNome);
        jTextFieldNome.setBounds(90, 30, 530, 25);
        jPanelFundo.add(jTextFieldEndereco);
        jTextFieldEndereco.setBounds(10, 80, 610, 25);
        jPanelFundo.add(jTextFieldBairro);
        jTextFieldBairro.setBounds(10, 130, 200, 25);
        jPanelFundo.add(jTextFieldCidade);
        jTextFieldCidade.setBounds(220, 130, 200, 25);

        jComboBoxEstado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "AC", "AL", "AM", "AP", "BA", "CE", "DF", "ES", "GO", "MA", "MG", "MS", "MT", "PA", "PB", "PE", "PI", "PR", "RJ", "RN", "RO", "RR", "SC", "SE", "SP", "TO" }));
        jPanelFundo.add(jComboBoxEstado);
        jComboBoxEstado.setBounds(430, 130, 72, 25);

        jFormattedTextFieldCep.setBorder(null);
        jPanelFundo.add(jFormattedTextFieldCep);
        jFormattedTextFieldCep.setBounds(510, 130, 110, 25);

        jFormattedTextFieldFone1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jFormattedTextFieldFone1FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jFormattedTextFieldFone1FocusLost(evt);
            }
        });
        jFormattedTextFieldFone1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jFormattedTextFieldFone1ActionPerformed(evt);
            }
        });
        jPanelFundo.add(jFormattedTextFieldFone1);
        jFormattedTextFieldFone1.setBounds(10, 180, 110, 25);

        jFormattedTextFieldFone2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jFormattedTextFieldFone2FocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jFormattedTextFieldFone2FocusLost(evt);
            }
        });
        jPanelFundo.add(jFormattedTextFieldFone2);
        jFormattedTextFieldFone2.setBounds(130, 180, 110, 25);

        jCheckBoxPJ.setForeground(java.awt.Color.white);
        jCheckBoxPJ.setText("Pessoal Jurídica");
        jPanelFundo.add(jCheckBoxPJ);
        jCheckBoxPJ.setBounds(250, 180, 230, 25);

        jFormattedTextFieldDtNasc.setBorder(null);
        jPanelFundo.add(jFormattedTextFieldDtNasc);
        jFormattedTextFieldDtNasc.setBounds(490, 180, 130, 25);

        jFormattedTextFieldRG.setBorder(null);
        jPanelFundo.add(jFormattedTextFieldRG);
        jFormattedTextFieldRG.setBounds(10, 230, 139, 25);

        jFormattedTextFieldCPF.setBorder(null);
        jPanelFundo.add(jFormattedTextFieldCPF);
        jFormattedTextFieldCPF.setBounds(160, 230, 130, 25);

        jFormattedTextFieldCNPJ.setBorder(null);
        jPanelFundo.add(jFormattedTextFieldCNPJ);
        jFormattedTextFieldCNPJ.setBounds(300, 230, 139, 25);
        jPanelFundo.add(jSeparator1);
        jSeparator1.setBounds(0, 260, 620, 10);

        jTextAreaOBS.setColumns(20);
        jTextAreaOBS.setRows(5);
        jScrollPane1.setViewportView(jTextAreaOBS);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 290, 610, 100);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 10, 630, 400);

        jButtonAbrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/open folderResultado.png"))); // NOI18N
        jButtonAbrir.setText("Abrir");
        jButtonAbrir.setToolTipText("Abrir Cadastro de Clientes");
        jButtonAbrir.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAbrirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAbrir);
        jButtonAbrir.setBounds(190, 420, 90, 40);

        jButtonEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/editResultado.png"))); // NOI18N
        jButtonEditar.setText("Editar");
        jButtonEditar.setToolTipText("Ativar edição de Itens");
        jButtonEditar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonEditar);
        jButtonEditar.setBounds(280, 420, 90, 40);

        jButtonExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jButtonExcluir.setText("Excluir");
        jButtonExcluir.setToolTipText("Excluir Cliente do Cadastro");
        jButtonExcluir.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonExcluir);
        jButtonExcluir.setBounds(370, 420, 90, 40);

        jButtonSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/accept.png"))); // NOI18N
        jButtonSalvar.setText("Salvar");
        jButtonSalvar.setToolTipText("Salvar Dados");
        jButtonSalvar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSalvar);
        jButtonSalvar.setBounds(460, 420, 90, 40);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.setToolTipText("");
        jButtonSair.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(550, 420, 90, 40);

        setBounds(0, 0, 653, 490);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed

       if (a_form_ex==true){
            try {
                jifr.setIcon(false);
            } catch (PropertyVetoException ex) {

            }
        } 
       dispose();
       FormPrincipal.AreaDeTrabalhoPrincipal.remove(this);
        

    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed

        ModCliente.setNome(jTextFieldNome.getText());
        ModCliente.setEndereco(jTextFieldEndereco.getText());
        ModCliente.setBairro(jTextFieldBairro.getText());
        ModCliente.setCidade(jTextFieldCidade.getText());
        ModCliente.setEstado(String.valueOf(jComboBoxEstado.getSelectedItem()));
        ModCliente.setCep(jFormattedTextFieldCep.getText());
        ModCliente.setTel1(jFormattedTextFieldFone1.getText());
        ModCliente.setTel2(jFormattedTextFieldFone2.getText());
        if (jCheckBoxPJ.isSelected()==true){
            ModCliente.setPj("S");
        }else{
            ModCliente.setPj("N");
        }
        ModCliente.setDtNascimento(jFormattedTextFieldDtNasc.getText());
        ModCliente.setRg(jFormattedTextFieldRG.getText());
        ModCliente.setCpf(jFormattedTextFieldCPF.getText());
        ModCliente.setCnpj(jFormattedTextFieldCNPJ.getText());
        ModCliente.setObs(jTextAreaOBS.getText());
        ModCliente.setId(CodCliente);
        ControlCliente.SalvaDados(ModCliente);
        jComboBoxEstado.setEnabled(false);
        LimpaItens();
        DesabilitaItens();
        DestivaEdicaoDeItens();
        
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed

        
        int i = JOptionPane.showConfirmDialog(rootPane, "Deseja excluir realmente\nos dados deste cliente?","Confirmando Exclusão", JOptionPane.YES_NO_OPTION);
        if(i == JOptionPane.YES_OPTION) {
            ModCliente.setId(CodCliente);
            ControlCliente.ExcluiDados(ModCliente);
            LimpaItens();
            DesabilitaItens();
            DestivaEdicaoDeItens();
            dispose();
            JOptionPane.showMessageDialog(rootPane, "Dados excluidos com sucesso!");
        }
        else if(i == JOptionPane.NO_OPTION) {
        }   
        
        
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jButtonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditarActionPerformed
        
        AtivaEdicaoDeItens();
        jComboBoxEstado.setEnabled(true);
        jButtonEditar.setEnabled(false);
        
    }//GEN-LAST:event_jButtonEditarActionPerformed

    private void jButtonAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAbrirActionPerformed
        
        FormPesqCliente FrmPqCliente = new FormPesqCliente();
        FormPrincipal.AbreNovaJanelaS(FrmPqCliente);
        dispose();
        
    }//GEN-LAST:event_jButtonAbrirActionPerformed

    private void jFormattedTextFieldFone1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jFormattedTextFieldFone1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jFormattedTextFieldFone1ActionPerformed

    private void jFormattedTextFieldFone1FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFormattedTextFieldFone1FocusLost
        // TODO add your handling code here:
        mudaMascaraTelefone(jFormattedTextFieldFone1);
        
    }//GEN-LAST:event_jFormattedTextFieldFone1FocusLost

    private void jFormattedTextFieldFone1FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFormattedTextFieldFone1FocusGained
        // TODO add your handling code here:
        jFormattedTextFieldFone1.setFormatterFactory(null);
    }//GEN-LAST:event_jFormattedTextFieldFone1FocusGained

    private void jFormattedTextFieldFone2FocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFormattedTextFieldFone2FocusGained
        // TODO add your handling code here:
        jFormattedTextFieldFone2.setFormatterFactory(null);
    }//GEN-LAST:event_jFormattedTextFieldFone2FocusGained

    private void jFormattedTextFieldFone2FocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jFormattedTextFieldFone2FocusLost
        // TODO add your handling code here:
        mudaMascaraTelefone(jFormattedTextFieldFone2);
    }//GEN-LAST:event_jFormattedTextFieldFone2FocusLost

    public void DesabilitaItens (){
        
        jTextFieldCod.setEnabled(false);
        jTextFieldNome.setEnabled(false);
        jTextFieldEndereco.setEnabled(false);
        jTextFieldBairro.setEnabled(false);
        jTextFieldCidade.setEnabled(false);
        jComboBoxEstado.setEnabled(false);
        jFormattedTextFieldCep.setEnabled(false);
        jFormattedTextFieldFone1.setEnabled(false);
        jFormattedTextFieldFone2.setEnabled(false);
        jFormattedTextFieldDtNasc.setEnabled(false);
        jFormattedTextFieldRG.setEnabled(false);
        jFormattedTextFieldCPF.setEnabled(false);
        jFormattedTextFieldCNPJ.setEnabled(false);
        jTextAreaOBS.setEnabled(false);
        jCheckBoxPJ.setEnabled(false);
        
    }
    
    public void DestivaEdicaoDeItens(){
       
        jTextFieldCod.setEditable(false);
        jTextFieldNome.setEditable(false);
        jTextFieldEndereco.setEditable(false);
        jTextFieldBairro.setEditable(false);
        jTextFieldCidade.setEditable(false);
        jFormattedTextFieldCep.setEditable(false);
        jFormattedTextFieldFone1.setEditable(false);
        jFormattedTextFieldFone2.setEditable(false);
        jFormattedTextFieldDtNasc.setEditable(false);
        jFormattedTextFieldRG.setEditable(false);
        jFormattedTextFieldCPF.setEditable(false);
        jFormattedTextFieldCNPJ.setEditable(false);
        jTextAreaOBS.setEditable(false);
               
    }
    
    public void AtivaEdicaoDeItens(){

        jTextFieldNome.setEditable(true);
        jTextFieldEndereco.setEditable(true);
        jTextFieldBairro.setEditable(true);
        jTextFieldCidade.setEditable(true);
        jFormattedTextFieldCep.setEditable(true);
        jFormattedTextFieldFone1.setEditable(true);
        jFormattedTextFieldFone2.setEditable(true);
        jFormattedTextFieldDtNasc.setEditable(true);
        jFormattedTextFieldRG.setEditable(true);
        jFormattedTextFieldCPF.setEditable(true);
        jFormattedTextFieldCNPJ.setEditable(true);
        jTextAreaOBS.setEditable(true);
        
    }
    
    public void AbilitaItens (){
        
        jTextFieldCod.setEnabled(true);
        jTextFieldNome.setEnabled(true);
        jTextFieldEndereco.setEnabled(true);
        jTextFieldBairro.setEnabled(true);
        jTextFieldCidade.setEnabled(true);
        jComboBoxEstado.setEnabled(true);
        jFormattedTextFieldCep.setEnabled(true);
        jFormattedTextFieldFone1.setEnabled(true);
        jFormattedTextFieldFone2.setEnabled(true);
        jFormattedTextFieldDtNasc.setEnabled(true);
        jFormattedTextFieldRG.setEnabled(true);
        jFormattedTextFieldCPF.setEnabled(true);
        jFormattedTextFieldCNPJ.setEnabled(true);
        jTextAreaOBS.setEnabled(true);
        jCheckBoxPJ.setEnabled(true);
        
    }
    
    
    public void LimpaItens (){
        
        jTextFieldCod.setText("");
        jTextFieldNome.setText("");
        jTextFieldEndereco.setText("");
        jTextFieldBairro.setText("");
        jTextFieldCidade.setText("");
        jComboBoxEstado.setSelectedItem("BA");
        jFormattedTextFieldCep.setText("");
        jFormattedTextFieldFone1.setText("");
        jFormattedTextFieldFone2.setText("");
        jFormattedTextFieldDtNasc.setText("");
        jFormattedTextFieldRG.setText("");
        jFormattedTextFieldCPF.setText("");
        jFormattedTextFieldCNPJ.setText("");
        jTextAreaOBS.setText("");
        jCheckBoxPJ.setSelected(false);
        
    }
        
    public class FilePreviewer extends JComponent implements
        
        PropertyChangeListener {
        ImageIcon thumbnail = null;
        @SuppressWarnings("LeakingThisInConstructor")
        public FilePreviewer(JFileChooser fc) {
            setPreferredSize(new Dimension(100, 50));
            fc.addPropertyChangeListener(this);
        }

        public void loadImage(File f) {
            if (f == null) {
                thumbnail = null;
            } else {
                ImageIcon tmpIcon = new ImageIcon(f.getPath());
                if (tmpIcon.getIconWidth() > 90) {
                    thumbnail = new ImageIcon(
                            tmpIcon.getImage().getScaledInstance(90, -1,
                            Image.SCALE_DEFAULT));
                } else {
                    thumbnail = tmpIcon;
                }
            }
        }

        public void propertyChange(PropertyChangeEvent e) {
            String prop = e.getPropertyName();
            if (SELECTED_FILE_CHANGED_PROPERTY.equals(prop)) {
                if (isShowing()) {
                    loadImage((File) e.getNewValue());
                    repaint();
                }
            }
        }

        @Override
        public void paint(Graphics g) {
            if (thumbnail != null) {
                int x = getWidth() / 2 - thumbnail.getIconWidth() / 2;
                int y = getHeight() / 2 - thumbnail.getIconHeight() / 2;
                if (y < 0) {
                    y = 0;
                }

                if (x < 5) {
                    x = 5;
                }
                thumbnail.paintIcon(this, g, x, y);
            }
        }
        }
        
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAbrir;
    private javax.swing.JButton jButtonEditar;
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JCheckBox jCheckBoxPJ;
    private javax.swing.JComboBox<String> jComboBoxEstado;
    private javax.swing.JFormattedTextField jFormattedTextFieldCNPJ;
    private javax.swing.JFormattedTextField jFormattedTextFieldCPF;
    private javax.swing.JFormattedTextField jFormattedTextFieldCep;
    private javax.swing.JFormattedTextField jFormattedTextFieldDtNasc;
    private javax.swing.JFormattedTextField jFormattedTextFieldFone1;
    private javax.swing.JFormattedTextField jFormattedTextFieldFone2;
    private javax.swing.JFormattedTextField jFormattedTextFieldRG;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private controle.ClassUpperFieldText jTextAreaOBS;
    private controle.ClassUpperField jTextFieldBairro;
    private controle.ClassUpperField jTextFieldCidade;
    private controle.ClassUpperField jTextFieldCod;
    private controle.ClassUpperField jTextFieldEndereco;
    private controle.ClassUpperField jTextFieldNome;
    // End of variables declaration//GEN-END:variables
}
