
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.Conf;
import controle.ConnectionFactory2;
import controle.ControleEmpresa;
import controle.PlanodeFundoForms;
import modelo.ModeloTabela;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyEvent;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JPopupMenu;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;

/**
 *
 * @author Lindembergue
 */
public class FormControleCaixa extends javax.swing.JInternalFrame {
    
    ConectaBanco conCX = new ConectaBanco();
    ConectaBanco conCXT = new ConectaBanco();
    ControleEmpresa ctrl_de = new ControleEmpresa();
    int CodCX, CodCXAnt;
    int UltimoDiadoMes;
    String DataHoje, DataQ, dia, mes, ano, Usuario, UsuTipo, UsuSenha, caminhoDb, DataConvertidaString;
    private String DataInicial, DataFinal;
    DecimalFormat Format;
    double TotalEntrada, TotalSaida, SaldoDia, SaldoTotal, AberturaCX;
    double TotalHsEntrada, TotalHsSaida, SaldoHsTotal;
    double Valor;
    DecimalFormat formatoNum;
    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat df3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    Date hoje = new Date();
    Date DataIni = new Date();
    Date DataFin = new Date();
    java.sql.Date DataConvertidaSQL;
    public static String NomeJIF = "FormControleCaixa";
    
    /**
     * Creates new form FormControleCaixa
     */
    public FormControleCaixa() throws SQLException {
        
        initComponents();
        formatoNum = new DecimalFormat("#0.00");
        ColocaImagemFundoFrame();
        jbtVoltarDadosTabelaCX.setVisible(false);
        Format = new DecimalFormat("#0.00");
        DataHoje = (df.format(hoje));
        PreencheListaReferencias();
        VerificaSeCaixaEstaAberto();
        jComboBoxOrigem.setSelectedIndex(0);
        jComboBoxRefOrigem.setSelectedIndex(0);
        jTextFieldDescrRef.setText("");
        jTextFieldValor.setText("0");
        
        try {
//              MaskFormatter cep = new MaskFormatter("#####-###");
//              MaskFormatter tel = new MaskFormatter("(##) #####-####");
                MaskFormatter data = new MaskFormatter("##/##/####");
//              MaskFormatter rg = new MaskFormatter("########-##");
//              MaskFormatter cpf = new MaskFormatter("###.###.###-##");
//              MaskFormatter cnpj = new MaskFormatter("##.###.###/####-##");
                jFormattedTextFieldData.setFormatterFactory(new DefaultFormatterFactory(data));
        } catch (ParseException ex) {
            
        }  
        jFormattedTextFieldData.setText(DataHoje);
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));

    }
    
    public void VerCapsLock(JPasswordField jtxt, JLabel jlab){
        
    Toolkit tk = Toolkit.getDefaultToolkit();    
    
    if(tk.getLockingKeyState(KeyEvent.VK_CAPS_LOCK)){
        
        jlab.setText("Caps Lock está ativada");
        jlab.setVisible(true);
        
    }else{
        jlab.setText("");
        jlab.setVisible(false);
    }
        
    }
    
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }

    public void VerificaSeCaixaEstaAberto() throws SQLException{
        conCX.conecta();
        try {
            conCX.executaSQL("select * from caixa where status='Aberto'");
            if (conCX.rs.last()){
                CodCX = conCX.rs.getInt("id_caixa");
                ConvertDataParaString(conCX.rs.getDate("dt_abertura"));
                jLabelDataCXAberto.setText("ABERTO EM: "+DataConvertidaString);
                jLabelCX.setText("CX Nº:   "+CodCX);
                jButtonAbrir.setEnabled(false);
                preencherTabelaCX("select * from caixa_descricao where id_caixa='"+CodCX+"'");
                //preencherTabelaHS("select * from caixa where status='Fechado'");
            }else{
                int i = JOptionPane.showConfirmDialog(rootPane, "Não Existe Caixa Aberto,\ndeseja Abrir Novo Caixa?","Caixa Fechado", JOptionPane.YES_NO_OPTION);
                if(i == JOptionPane.YES_OPTION) {
                    
                    PreparedStatement pst = conCX.conn.prepareStatement("insert into caixa (dt_abertura, status)values(?,?)");
                    ConverteStringparaData(DataHoje);
                    pst.setDate(1, DataConvertidaSQL);
                    pst.setString(2, "Aberto");
                    pst.execute();
                    conCX.executaSQL("select * from caixa");
                    conCX.rs.last();
                    CodCX = conCX.rs.getInt("id_caixa");
                    jLabelCX.setText("CX Nº:   "+CodCX);
                    jLabelDataCXAberto.setText("Caixa aberto em: "+conCX.rs.getString("dt_abertura"));
                    jButtonAbrir.setEnabled(false);
                    preencherTabelaCX("select * from caixa_descricao where id_caixa='"+CodCX+"'");
                    //preencherTabelaHS("select * from caixa where status='Fechado'");
                }else{
                    jButtonAbrir.setEnabled(true);
                    jButtonFechar.setEnabled(false);
                }
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(FormControleCaixa.class.getName()).log(Level.SEVERE, null, ex);
        }
        jFormattedTextFieldData.setText(DataHoje);
        conCX.desconecta();
        
        DataQ=DataHoje;
        QuebraData();
        
//        preencherTabelaHS("select * from caixa where  dt_f_mes='"+mes+"' and dt_f_ano='"+ano+"' and status='Fechado'");
        obterdadosTabelaHS();
        obterdadosTabelaHSAnt();
////        preencherTabelaHSAnt("select * from caixa where  dt_f_mes!='"+mes+"' and dt_f_ano='"+ano+"' and status='Fechado'");
        preencherTabelaHSResumo("select * from caixa_historico");
        //preencherTabelaHS("select * from caixa where status='Fechado'");
    }
    
    public void obterUltimoDiaMes(int mes, int ano){
    
        Calendar Calendario = Calendar.getInstance();
        Calendario.set(Calendar.MONTH, mes);
        Calendario.set(Calendar.DAY_OF_MONTH, 1);
        Calendario.set(Calendar.YEAR, ano);
        Calendario.set(Calendar.DATE,-1);
        UltimoDiadoMes = Calendario.getActualMaximum(Calendar.DAY_OF_MONTH);
        
    }
    
    public void obterdadosTabelaHS() throws SQLException{
        
        obterUltimoDiaMes(Integer.parseInt(mes), Integer.parseInt(ano));//            JOptionPane.showMessageDialog(rootPane, ex);
        DataInicial = ano+"-"+mes+"-01";
        DataFinal = ano+"-"+mes+"-"+String.valueOf(UltimoDiadoMes);
        java.sql.Date DtI = java.sql.Date.valueOf(DataInicial);
        java.sql.Date DtF = java.sql.Date.valueOf(DataFinal);
        
        preencherTabelaHS("select * from caixa where status='Fechado' and dt_fechamento between #"+DtI+" 22:50:00# and #"+DtF+" 22:50:00#");
        
//        preencherTabelaHS("select * from caixa where cdate(format(dt_fechamento, 'dd/mm/yyyy') between '"+DataIni+"' and '"+DataFin+"') and status='Fechado'");
//        preencherTabelaHS("select * from (caixa) where status='Fechado' and (cdate(format(dt_fechamento, 'dd/MM/YYYY'))) between '"+DataInicial+"' and '"+DataInicial+"'");
        
        }
     
    public void obterdadosTabelaHSAnt(){
        int mesAnt = 0;
        if (Integer.parseInt(mes)==1){
           mesAnt = 12; 
        }else{
        mesAnt = Integer.parseInt(mes)-1;
        }
        obterUltimoDiaMes(mesAnt, Integer.parseInt(ano));
        String dtref1 = "1901-01-01";
        String dtref2 = ano+"-"+mesAnt+"-"+String.valueOf(UltimoDiadoMes);
//        JOptionPane.showMessageDialog(rootPane, "D1 = "+dtref1+"D2 = "+dtref2);
        java.sql.Date Dtr1 = java.sql.Date.valueOf(dtref1);
        java.sql.Date Dtr2 = java.sql.Date.valueOf(dtref2);
        
        preencherTabelaHSAnt("select id_caixa, dt_abertura, total_entrada, total_saida, status, dt_f_dia, dt_f_mes, dt_f_ano, dt_fechamento, saldo_total, abertura_cx from caixa where dt_fechamento between #"+Dtr1+" 22:50:00# and #"+Dtr2+" 22:50:00# and status='Fechado' order by id_caixa desc");
        
    }
    
    public void QuebraData(){
        
        dia = "" + DataQ.charAt(0) + DataQ.charAt(1);
        mes = "" + DataQ.charAt(3) + DataQ.charAt(4);
        ano = "" + DataQ.charAt(6) + DataQ.charAt(7) + DataQ.charAt(8) + DataQ.charAt(9);
    }
    
    public void PreencheListaReferencias(){
        conCX.conecta();
        
        conCX.executaSQL("select * from referencias_fluxo_caixa order by ref");
        try {
            if (conCX.rs.first()){
            jComboBoxRefOrigem.removeAllItems();
            do{
                jComboBoxRefOrigem.addItem(conCX.rs.getString("ref"));
            } while (conCX.rs.next());
            }else{
                JOptionPane.showMessageDialog(rootPane, "Cadastre Referências de Caixa");
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(FormControleCaixa.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        conCX.desconecta();
    }
    
    public void PermUsuario(String User){
        Usuario = User;
        conCX.conecta();
        try {
           // JOptionPane.showMessageDialog(rootPane, "Usuario = "+Usuario);
        conCX.executaSQL("select * from usuarios where nome='"+Usuario+"'");
        conCX.rs.first();
        UsuTipo = conCX.rs.getString("permissao");
        UsuSenha = conCX.rs.getString("senha");
        //JOptionPane.showMessageDialog(rootPane, "Usuario = "+UsuTipo);
        } catch (SQLException ex) {
        }
        conCX.desconecta();
        }
    
    public void limpatabelaFC(){
            
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{};
        dados.removeAll(dados);
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableFC.setModel(modelo);
        
    }
    
    public void Lerarquivo(){

        Conf cfg = new Conf();
            try {
                cfg.ConfigLido();
                String c = "jdbc:postgresql://"+cfg.host+":"+cfg.porta+"/slp";
                caminhoDb = c;
            } catch (IOException ex) {
//                Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
        
    }
        
    public void PrintCaixa(){
        int i = JOptionPane.showConfirmDialog(rootPane, "Deseja Realizar a impressão do Caixa selecionado?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
                                if(i == JOptionPane.YES_OPTION) {
                                    
                                    ctrl_de.Obtem_Dados_da_Empresa();
                                    Lerarquivo();
                                    try {
                                        try {
                                        Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                                        Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                                        Map<String, Object> parametros = new HashMap<String, Object>();
                                        Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                                        //dados empresa
                                        parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                                        parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                                        parametros.put( "cnpj", ctrl_de.de_cnpj );
                                        parametros.put( "de_ie", ctrl_de.de_ie );
                                        parametros.put( "endereco", ctrl_de.de_endereco );
                                        parametros.put( "bairro", ctrl_de.de_bairro );
                                        parametros.put( "cidade", ctrl_de.de_cidade );
                                        parametros.put( "estado", ctrl_de.de_estado );
                                        parametros.put( "cep", ctrl_de.de_cep );
                                        parametros.put( "telefone1", ctrl_de.de_fone1 );
                                        parametros.put( "telefone2", ctrl_de.de_fone2 );
                                        parametros.put( "de_site", ctrl_de.de_site );
                                        parametros.put( "email", ctrl_de.de_email );
                                        parametros.put("logoimg",imagePath);
                                        parametros.put("codCaixa",CodCXAnt);
                                        JasperPrint jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"Caixa.jasper", parametros, ConnectionFactory2.getSlpConnection());
                                        JRViewer viewer = new JRViewer(jpPrint);
                                        viewer.setZoomRatio((float) 0.5);
                                        JFrame frameRelatorio = new JFrame();
                                        frameRelatorio.add( viewer, BorderLayout.CENTER );
                                        frameRelatorio.setTitle("Relatório de CAIXA");
                                        frameRelatorio.setSize( 500, 500 );
                                        frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                                        frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                                        frameRelatorio.setVisible( true );
                                        } catch (SQLException ex) {
                                            JOptionPane.showMessageDialog(rootPane, "Erro: "+ex);
                                        }
                                    } catch (JRException ex) {
                                        JOptionPane.showMessageDialog(rootPane, "Erro: "+ex);
                                    }
                                        
                                  
                                }                           
    }
    
    public void convertValorVirgula(String ValorEntrada){
          
        Valor = Double.parseDouble(ValorEntrada.replace(',', '.'));  
        
    }
    
    public void ConvertDataParaString(java.sql.Date Data){
        
        DataConvertidaString = df.format(Data);
        
    }
    
    public void ConverteStringparaData(String Data){
        
        String dia = "" + Data.charAt(0) + Data.charAt(1);
        String mes = "" + Data.charAt(3) + Data.charAt(4);
        String ano = "" + Data.charAt(6) + Data.charAt(7) + Data.charAt(8) + Data.charAt(9);
        String dtfSQLData = ano+"-"+mes+"-"+dia;
        DataConvertidaSQL = java.sql.Date.valueOf(dtfSQLData);
        
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableFC = new javax.swing.JTable();
        jLabel_info_titulo_descricao_cx = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableHistorico = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        jTableHistoricoAnt = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane5 = new javax.swing.JScrollPane();
        jTableHistoricoResumo = new javax.swing.JTable();
        jbtVoltarDadosTabelaCX = new javax.swing.JButton();
        jLabelDataCXAberto = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabelCX = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jTextFieldTotalEnt = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jTextFieldTotalSaida = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jTextFieldSaldoTotal = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        jTextFieldAberturaCX = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jTextFieldSaldoDia = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jButtonFechar = new javax.swing.JButton();
        jButtonAbrir = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jComboBoxOrigem = new javax.swing.JComboBox();
        jComboBoxRefOrigem = new javax.swing.JComboBox();
        jTextFieldDescrRef = new controle.ClassUpperField();
        jTextFieldValor = new javax.swing.JTextField();
        jFormattedTextFieldData = new javax.swing.JFormattedTextField();
        jButtonAddMovimento = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jButtonSair = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(null);
        setTitle("Controle de Caixa");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(51, 153, 255));
        jPanelFundo.setLayout(null);

        jTableFC.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTableFC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableFCMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableFC);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(440, 40, 560, 320);

        jLabel_info_titulo_descricao_cx.setForeground(new java.awt.Color(255, 255, 255));
        jLabel_info_titulo_descricao_cx.setText("  Exibindo dados do Caixa Atual");
        jLabel_info_titulo_descricao_cx.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanelFundo.add(jLabel_info_titulo_descricao_cx);
        jLabel_info_titulo_descricao_cx.setBounds(440, 5, 560, 30);

        jPanel3.setToolTipText("");

        jTableHistorico.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTableHistorico.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableHistoricoMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTableHistorico);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 415, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jTabbedPane1.addTab("Caixas", jPanel3);

        jPanel1.setLayout(null);

        jTableHistoricoAnt.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTableHistoricoAnt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableHistoricoAntAntMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(jTableHistoricoAnt);

        jPanel1.add(jScrollPane4);
        jScrollPane4.setBounds(0, 0, 420, 340);

        jTabbedPane1.addTab("Histórico", jPanel1);

        jPanel2.setLayout(null);

        jTableHistoricoResumo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTableHistoricoResumo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableHistoricoResumoMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(jTableHistoricoResumo);

        jPanel2.add(jScrollPane5);
        jScrollPane5.setBounds(0, 0, 420, 340);

        jTabbedPane1.addTab("Resumo", jPanel2);

        jPanelFundo.add(jTabbedPane1);
        jTabbedPane1.setBounds(10, 10, 420, 350);

        jbtVoltarDadosTabelaCX.setText("Mostrar Caixa Atual");
        jbtVoltarDadosTabelaCX.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtVoltarDadosTabelaCXActionPerformed(evt);
            }
        });
        jPanelFundo.add(jbtVoltarDadosTabelaCX);
        jbtVoltarDadosTabelaCX.setBounds(820, 5, 180, 30);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 40, 1010, 370);

        jLabelDataCXAberto.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabelDataCXAberto.setForeground(new java.awt.Color(51, 153, 255));
        jLabelDataCXAberto.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabelDataCXAberto.setText("Aberto em:");
        getContentPane().add(jLabelDataCXAberto);
        jLabelDataCXAberto.setBounds(710, 5, 310, 30);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(51, 153, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel1.setText("CONTROLE DE CAIXA");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(300, 5, 410, 30);

        jLabelCX.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabelCX.setForeground(new java.awt.Color(51, 153, 255));
        jLabelCX.setText("CAIXA Nº:");
        getContentPane().add(jLabelCX);
        jLabelCX.setBounds(10, 5, 290, 30);
        getContentPane().add(jSeparator1);
        jSeparator1.setBounds(10, 470, 1010, 10);

        jTextFieldTotalEnt.setEditable(false);
        jTextFieldTotalEnt.setBackground(java.awt.Color.white);
        jTextFieldTotalEnt.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldTotalEnt.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));
        getContentPane().add(jTextFieldTotalEnt);
        jTextFieldTotalEnt.setBounds(320, 440, 110, 25);

        jLabel8.setText("Total Entra R$:");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(320, 420, 110, 16);

        jLabel9.setText("Total Saida R$:");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(440, 420, 110, 16);

        jTextFieldTotalSaida.setEditable(false);
        jTextFieldTotalSaida.setBackground(java.awt.Color.white);
        jTextFieldTotalSaida.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldTotalSaida.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));
        getContentPane().add(jTextFieldTotalSaida);
        jTextFieldTotalSaida.setBounds(440, 440, 110, 25);

        jLabel11.setText("Saldo Total R$:");
        getContentPane().add(jLabel11);
        jLabel11.setBounds(680, 420, 110, 16);

        jTextFieldSaldoTotal.setEditable(false);
        jTextFieldSaldoTotal.setBackground(java.awt.Color.white);
        jTextFieldSaldoTotal.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldSaldoTotal.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));
        getContentPane().add(jTextFieldSaldoTotal);
        jTextFieldSaldoTotal.setBounds(680, 440, 110, 25);

        jLabel12.setText("Abertura de CX R$:");
        getContentPane().add(jLabel12);
        jLabel12.setBounds(200, 420, 110, 16);

        jTextFieldAberturaCX.setEditable(false);
        jTextFieldAberturaCX.setBackground(java.awt.Color.white);
        jTextFieldAberturaCX.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldAberturaCX.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));
        getContentPane().add(jTextFieldAberturaCX);
        jTextFieldAberturaCX.setBounds(200, 440, 110, 25);

        jLabel13.setText("Saldo do Dia R$:");
        getContentPane().add(jLabel13);
        jLabel13.setBounds(560, 420, 110, 16);

        jTextFieldSaldoDia.setEditable(false);
        jTextFieldSaldoDia.setBackground(java.awt.Color.white);
        jTextFieldSaldoDia.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldSaldoDia.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));
        getContentPane().add(jTextFieldSaldoDia);
        jTextFieldSaldoDia.setBounds(560, 440, 110, 25);

        jPanel4.setBackground(java.awt.Color.white);
        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel4.setLayout(null);

        jButtonFechar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/32x32/cadeado2_32x32.png"))); // NOI18N
        jButtonFechar.setToolTipText("Fechar Caixa Atual");
        jButtonFechar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonFechar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFecharActionPerformed(evt);
            }
        });
        jPanel4.add(jButtonFechar);
        jButtonFechar.setBounds(50, 30, 40, 35);

        jButtonAbrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/32x32/cadeado1_32x32.png"))); // NOI18N
        jButtonAbrir.setToolTipText("Abrir Novo Caixa");
        jButtonAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAbrirActionPerformed(evt);
            }
        });
        jPanel4.add(jButtonAbrir);
        jButtonAbrir.setBounds(10, 30, 40, 35);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("Abrir e Fechar:");
        jLabel2.setToolTipText("");
        jPanel4.add(jLabel2);
        jLabel2.setBounds(0, 0, 100, 30);

        getContentPane().add(jPanel4);
        jPanel4.setBounds(10, 480, 100, 70);

        jPanel5.setBackground(java.awt.Color.white);
        jPanel5.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel5.setLayout(null);

        jLabel10.setText("Origem Fluxo:");
        jPanel5.add(jLabel10);
        jLabel10.setBounds(10, 0, 90, 30);

        jLabel4.setText("Referência ao Fluxo:");
        jPanel5.add(jLabel4);
        jLabel4.setBounds(100, 0, 190, 30);

        jLabel5.setText("Descrição da Referência:");
        jPanel5.add(jLabel5);
        jLabel5.setBounds(290, 0, 300, 30);

        jLabel6.setText("Valor R$:");
        jPanel5.add(jLabel6);
        jLabel6.setBounds(570, 0, 100, 30);

        jLabel7.setText("Data:");
        jPanel5.add(jLabel7);
        jLabel7.setBounds(670, 0, 130, 30);

        jComboBoxOrigem.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Entrada", "Saída", "Abertura CX" }));
        jComboBoxOrigem.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jComboBoxOrigemItemStateChanged(evt);
            }
        });
        jComboBoxOrigem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxOrigemActionPerformed(evt);
            }
        });
        jPanel5.add(jComboBoxOrigem);
        jComboBoxOrigem.setBounds(10, 30, 90, 30);

        jComboBoxRefOrigem.setEditable(true);
        jComboBoxRefOrigem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxRefOrigemActionPerformed(evt);
            }
        });
        jPanel5.add(jComboBoxRefOrigem);
        jComboBoxRefOrigem.setBounds(100, 30, 190, 30);
        jPanel5.add(jTextFieldDescrRef);
        jTextFieldDescrRef.setBounds(290, 30, 300, 30);
        jPanel5.add(jTextFieldValor);
        jTextFieldValor.setBounds(590, 30, 90, 30);
        jPanel5.add(jFormattedTextFieldData);
        jFormattedTextFieldData.setBounds(680, 30, 80, 30);

        jButtonAddMovimento.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jButtonAddMovimento.setForeground(new java.awt.Color(0, 153, 255));
        jButtonAddMovimento.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/add.png"))); // NOI18N
        jButtonAddMovimento.setToolTipText("Adicionar Movimentação");
        jButtonAddMovimento.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonAddMovimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddMovimentoActionPerformed(evt);
            }
        });
        jPanel5.add(jButtonAddMovimento);
        jButtonAddMovimento.setBounds(760, 30, 40, 30);

        getContentPane().add(jPanel5);
        jPanel5.setBounds(110, 480, 810, 70);

        jPanel6.setBackground(java.awt.Color.white);
        jPanel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel6.setLayout(null);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        jPanel6.add(jButtonSair);
        jButtonSair.setBounds(10, 10, 80, 50);

        getContentPane().add(jPanel6);
        jPanel6.setBounds(920, 480, 100, 70);

        setBounds(0, 0, 1028, 581);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAbrirActionPerformed
        conCX.conecta();
        try {
            PreparedStatement pst = conCX.conn.prepareStatement("insert into caixa (dt_abertura, status)values(?,?)");
            ConverteStringparaData(DataHoje);
            pst.setDate(1, DataConvertidaSQL);
            pst.setString(2, "Aberto");
            pst.execute();
            conCX.executaSQL("select * from caixa");
            conCX.rs.last();
            CodCX = conCX.rs.getInt("id_caixa");
            jLabelCX.setText("CX Nº:   "+CodCX);
            ConvertDataParaString(conCX.rs.getDate("dt_abertura"));
            jLabelDataCXAberto.setText("Caixa aberto em: "+DataConvertidaString);
        } catch (SQLException ex) {
            Logger.getLogger(FormControleCaixa.class.getName()).log(Level.SEVERE, null, ex);
        }conCX.desconecta();
        jButtonAbrir.setEnabled(false);
        jButtonFechar.setEnabled(true);
    }//GEN-LAST:event_jButtonAbrirActionPerformed

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
    dispose();
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonAddMovimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddMovimentoActionPerformed
    conCX.conecta();
    
        convertValorVirgula(jTextFieldValor.getText());
        try {
            PreparedStatement pst = conCX.conn.prepareStatement("insert into caixa_descricao (id_caixa, origem, ref_origem, desc_origem, valor, data)values(?,?,?,?,?,?)");
            pst.setInt(1, CodCX);
            pst.setString(2, String.valueOf(jComboBoxOrigem.getSelectedItem()));
            pst.setString(3, String.valueOf(jComboBoxRefOrigem.getSelectedItem()));
            pst.setString(4, jTextFieldDescrRef.getText());
            pst.setDouble(5, Valor);
            ConverteStringparaData(jFormattedTextFieldData.getText());
            pst.setDate(6, DataConvertidaSQL);
            pst.execute();
            preencherTabelaCX("select * from caixa_descricao where id_caixa='"+CodCX+"'");
            jComboBoxOrigem.setSelectedIndex(0);
            jComboBoxRefOrigem.setSelectedIndex(0);
            jTextFieldDescrRef.setText("");
            jTextFieldValor.setText("0");
            jFormattedTextFieldData.setText(DataHoje);
        } catch (SQLException ex) {
            Logger.getLogger(FormControleCaixa.class.getName()).log(Level.SEVERE, null, ex);
        }
    conCX.desconecta();
    }//GEN-LAST:event_jButtonAddMovimentoActionPerformed

    private void jButtonFecharActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFecharActionPerformed
        
        int i = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente Fechar o Caixa Aberto?","Confirmando Fechamento", JOptionPane.YES_NO_OPTION);
        if(i == JOptionPane.YES_OPTION) {           

        JLabel labelM = new JLabel("Digite a senha:");
        final JLabel labelC = new JLabel ("");
        final JPasswordField jpfS = new JPasswordField();
         
       
        jpfS.addFocusListener(new FocusAdapter() {
            public void focusga(FocusEvent e) {
                //adicionar sua verificação aqui
                VerCapsLock(jpfS, labelC);
            }
        });
        
        
        DialogConfSenha DPSenha = new DialogConfSenha();
        DPSenha.setModal(true);
        DPSenha.setVisible(true);
        String SenhaDig = DPSenha.Senha;
        
        if (FormPrincipal.SenhaULogado.equals(SenhaDig)){
        conCX.conecta();
        DataQ = DataHoje;
        String DataAgora = df2.format(hoje);
        java.sql.Date Dtr1 = java.sql.Date.valueOf(DataAgora);
        QuebraData();
        
        try {
            
            PreparedStatement pst = conCX.conn.prepareStatement("update caixa set dt_f_dia=?, dt_f_mes=?, dt_f_ano=?, dt_fechamento=?, total_entrada=?, total_saida=?, status=?, saldo_total=?, abertura_cx=?  where id_caixa=?");
            pst.setString(1, dia);
            pst.setString(2, mes);
            pst.setString(3, ano);
            pst.setDate(4, Dtr1);
            pst.setDouble(5, TotalEntrada);
            pst.setDouble(6, TotalSaida);
            pst.setString(7, "Fechado");
            pst.setDouble(8, SaldoTotal);
            pst.setDouble(9, AberturaCX);
            pst.setInt(10, CodCX);
            pst.execute();
            JOptionPane.showMessageDialog(rootPane, "Caixa do Dia Fechado com Sucesso!");
            obterdadosTabelaHS();
            limpatabelaFC();
        
        } catch (SQLException ex) {
            
            Logger.getLogger(FormControleCaixa.class.getName()).log(Level.SEVERE, null, ex);
            }conCX.desconecta();
            dispose();
        
        }else{
            JOptionPane.showMessageDialog(rootPane, "Senha incorreta!");
        }
        
        AtualizaResumoHistorico();
        preencherTabelaHSResumo("select * from caixa_historico");
        
        }else if(i == JOptionPane.NO_OPTION) {

        }
         
    }//GEN-LAST:event_jButtonFecharActionPerformed

    private void jTableFCMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableFCMouseClicked
    if (evt.getClickCount()==2){
    int i = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente Remover este Item","Confirmando Exclusão", JOptionPane.YES_NO_OPTION);
    if(i == JOptionPane.YES_OPTION){
        
        int CodCXDescTemp = Integer.parseInt(""+ jTableFC.getValueAt(jTableFC.getSelectedRow(), 0));
        
        conCX.conecta();

        try {
            conCX.executaSQL("select * from caixa_descricao where id_caixa_desc='"+CodCXDescTemp+"'");
            conCX.rs.first();
            int CodCXTemp = conCX.rs.getInt("id_caixa");
            conCX.executaSQL("select * from caixa where id_caixa='"+CodCXTemp+"'");
            conCX.rs.first();
            if (conCX.rs.getString("status").equals("Aberto")){
                PreparedStatement pst = conCX.conn.prepareStatement("delete from caixa_descricao where id_caixa_desc=?");
                pst.setInt(1, CodCXDescTemp);
                pst.execute();
                JOptionPane.showMessageDialog(rootPane, "Item Removido com sucesso!");
                preencherTabelaCX("select * from caixa_descricao where id_caixa='"+CodCX+"'");
            } else{
                JLabel labelM = new JLabel("Digite a senha:");
                JPasswordField jpfS = new JPasswordField();
                JOptionPane.showConfirmDialog(rootPane,new Object[]{labelM, jpfS},"Senha:", JOptionPane.OK_CANCEL_OPTION);
                String SenhaDig = new String(jpfS.getPassword());
                if (UsuSenha.equals(SenhaDig)){
                    PreparedStatement pst = conCX.conn.prepareStatement("delete from caixa_descricao where id_caixa_desc=?");
                    pst.setInt(1, CodCXDescTemp);
                    pst.execute();
                    JOptionPane.showMessageDialog(rootPane, "Item Removido com sucesso!");
                    preencherTabelaCX("select * from caixa_descricao where id_caixa='"+CodCX+"'");
                } else{
                    JOptionPane.showMessageDialog(rootPane, "Senha não confere!");
                }
            }
        } catch (SQLException ex) {
            //Logger.getLogger(FormControleCaixa.class.getName()).log(Level.SEVERE, null, ex);
        }
        conCX.desconecta();
        SomaOrigem();
    }
}


    }//GEN-LAST:event_jTableFCMouseClicked

    private void jComboBoxRefOrigemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxRefOrigemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxRefOrigemActionPerformed

    private void jComboBoxOrigemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxOrigemActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxOrigemActionPerformed

    private void jComboBoxOrigemItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_jComboBoxOrigemItemStateChanged
    
        if (jComboBoxOrigem.getSelectedItem().equals("Abertura CX")){
            jComboBoxRefOrigem.setSelectedItem("Dia Anterior");
            jTextFieldDescrRef.setText("Saldo Total do dia Anterior.");
            jTextFieldValor.grabFocus();
        }
    }//GEN-LAST:event_jComboBoxOrigemItemStateChanged

    private void jTableHistoricoAntAntMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableHistoricoAntAntMouseClicked
        CodCXAnt =  Integer.parseInt(""+ jTableHistoricoAnt.getValueAt(jTableHistoricoAnt.getSelectedRow(), 0));
        preencherTabelaCX("select * from caixa_descricao where id_caixa='"+CodCXAnt+"'");
        SomaOrigemCXFechado(CodCXAnt);
        jLabel_info_titulo_descricao_cx.setText("  Exibindo dados do Caixa Nº: "+CodCXAnt+".");
        jbtVoltarDadosTabelaCX.setVisible(true);
        
        if (evt.getButton() == MouseEvent.BUTTON3) { // Clique com botao direito do mouse. 
              MenuControleCaixaHistoricoAnt();
        }
    }//GEN-LAST:event_jTableHistoricoAntAntMouseClicked

    private void jTableHistoricoResumoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableHistoricoResumoMouseClicked
        String mesAno =  (""+ jTableHistoricoResumo.getValueAt(jTableHistoricoResumo.getSelectedRow(), 0));
        String mesHsR = "" + mesAno.charAt(0) + mesAno.charAt(1);
        String anoHsR = "" + mesAno.charAt(3) + mesAno.charAt(4) + mesAno.charAt(5) + mesAno.charAt(6);
        String DtInicial = "01"+"/"+mesHsR+"/"+anoHsR;
//        String UltimoDiadoMes = "";
//
//        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
//        Date dt = formatter.parse(DtInicial);
//        Calendar calendar = Calendar.getInstance();
//        calendar.setTime(dt);
//        calendar.add(Calendar.MONTH, 1);
//        calendar.set(Calendar.DAY_OF_MONTH, 1);
//        calendar.add(Calendar.DATE, -1);
//        Date lastDay = calendar.getTime();  
//        UltimoDiadoMes = formatter.format(lastDay);
//        String diaUM = ""+UltimoDiadoMes.charAt(0)+UltimoDiadoMes.charAt(1);
obterUltimoDiaMes(Integer.parseInt(mesHsR), Integer.parseInt(anoHsR));//            JOptionPane.showMessageDialog(rootPane, ex);
String DI = anoHsR+"-"+mesHsR+"-01";
String DF = anoHsR+"-"+mesHsR+"-"+UltimoDiadoMes;
java.sql.Date DtI = java.sql.Date.valueOf(DI);
java.sql.Date DtF = java.sql.Date.valueOf(DF);
preencherTabelaCX("select * from caixa_descricao where data between #"+DtI+" 00:00:01# and #"+DtF+" 23:59:00# order by data");
jLabel_info_titulo_descricao_cx.setText("  Exibindo Resumo entre 01/"+mesHsR+"/"+anoHsR+" e "+UltimoDiadoMes+"/"+mesHsR+"/"+anoHsR+".");
jbtVoltarDadosTabelaCX.setVisible(true);

    }//GEN-LAST:event_jTableHistoricoResumoMouseClicked

    private void jTableHistoricoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableHistoricoMouseClicked
        CodCXAnt =  Integer.parseInt(""+ jTableHistorico.getValueAt(jTableHistorico.getSelectedRow(), 0));
        preencherTabelaCX("select * from caixa_descricao where id_caixa='"+CodCXAnt+"'");
        SomaOrigemCXFechado(CodCXAnt);
        jbtVoltarDadosTabelaCX.setVisible(true);
        jLabel_info_titulo_descricao_cx.setText("  Exibindo dados do Caixa Nº: "+CodCXAnt+".");
        
        if (evt.getButton() == MouseEvent.BUTTON3) { // Clique com botao direito do mouse. 
              MenuControleCaixaHistorico();
        }
    }//GEN-LAST:event_jTableHistoricoMouseClicked

    private void jbtVoltarDadosTabelaCXActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtVoltarDadosTabelaCXActionPerformed
        // TODO add your handling code here:
        preencherTabelaCX("select * from caixa_descricao where id_caixa='"+CodCX+"'");
        jLabel_info_titulo_descricao_cx.setText("  Exibindo dados do Caixa Atual");
        jbtVoltarDadosTabelaCX.setVisible(false);
        
    }//GEN-LAST:event_jbtVoltarDadosTabelaCXActionPerformed

        public void preencherTabelaCX(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Cod.","Origem","Referência","Descrição","Valor R$", "Data"};
        conCX.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conCX.executaSQL(SQL);
        
        try {
            conCX.rs.first();
            do{
                
                dados.add(new Object[]{conCX.rs.getInt("id_caixa_desc"), conCX.rs.getString("origem"), conCX.rs.getString("ref_origem"), conCX.rs.getString("desc_origem"), String.valueOf(formatoNum.format(conCX.rs.getDouble("valor"))), df.format(conCX.rs.getDate("data"))});
                
            }while(conCX.rs.next());
        } catch (SQLException ex) {
            //JOptionPane.showMessageDialog(rootPane,"Erro ao Preencher ArrayList"+ex);
        }
        SomaOrigem();
        
        DefaultTableCellRenderer cellRenderD = new DefaultTableCellRenderer();
	cellRenderD.setHorizontalAlignment(SwingConstants.RIGHT);
        
        DefaultTableCellRenderer cellRenderC = new DefaultTableCellRenderer();
	cellRenderC.setHorizontalAlignment(SwingConstants.CENTER);
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableFC.setModel(modelo);
        jTableFC.getColumnModel().getColumn(0).setPreferredWidth(45);
        jTableFC.getColumnModel().getColumn(0).setCellRenderer(cellRenderD);
        jTableFC.getColumnModel().getColumn(0).setResizable(false);
        jTableFC.getColumnModel().getColumn(1).setPreferredWidth(85);
        jTableFC.getColumnModel().getColumn(1).setResizable(false);
        jTableFC.getColumnModel().getColumn(2).setPreferredWidth(85);
        jTableFC.getColumnModel().getColumn(2).setResizable(false);
        jTableFC.getColumnModel().getColumn(3).setPreferredWidth(200);
        jTableFC.getColumnModel().getColumn(3).setResizable(false);
        jTableFC.getColumnModel().getColumn(4).setPreferredWidth(65);
        jTableFC.getColumnModel().getColumn(4).setCellRenderer(cellRenderD);
        jTableFC.getColumnModel().getColumn(4).setResizable(false);
        jTableFC.getColumnModel().getColumn(5).setPreferredWidth(78);
        jTableFC.getColumnModel().getColumn(5).setCellRenderer(cellRenderC);
        jTableFC.getColumnModel().getColumn(5).setResizable(false);
//        jTableFC.getColumnModel().getColumn(6).setPreferredWidth(100);
//        jTableFC.getColumnModel().getColumn(6).setResizable(false);
//        jTableFC.getColumnModel().getColumn(7).setPreferredWidth(100);
//        jTableFC.getColumnModel().getColumn(7).setResizable(false);
//        jTableFC.getColumnModel().getColumn(8).setPreferredWidth(100);
//        jTableFC.getColumnModel().getColumn(8).setResizable(false);
        jTableFC.getTableHeader().setReorderingAllowed(false);
        jTableFC.setAutoResizeMode(jTableFC.AUTO_RESIZE_OFF);
        jTableFC.setSelectionMode(ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        
        conCX.desconecta();
              
    }
    
        public void SomaOrigem(){
        TotalEntrada = 0;
        AberturaCX = 0;
        SaldoTotal = 0;
        SaldoDia = 0;
        TotalSaida = 0;
        conCX.conecta();
        
        try {
            conCX.executaSQL("select * from caixa_descricao where origem='Abertura CX' and id_caixa='"+CodCX+"'");
            while (conCX.rs.next()){
            AberturaCX = AberturaCX+conCX.rs.getDouble("valor");
            }
            jTextFieldAberturaCX.setText(String.valueOf(formatoNum.format(AberturaCX)));
            
            conCX.executaSQL("select * from caixa_descricao where origem='Entrada' and id_caixa='"+CodCX+"'");
            //connVendaPsq.rs.first();
            while (conCX.rs.next()){
                TotalEntrada = TotalEntrada+conCX.rs.getDouble("valor");
            }
            jTextFieldTotalEnt.setText(String.valueOf(formatoNum.format(TotalEntrada)));
            
            conCX.executaSQL("select * from caixa_descricao where origem='Saída' and id_caixa='"+CodCX+"'");
            //connVendaPsq.rs.first();
            while (conCX.rs.next()){
                TotalSaida = TotalSaida+conCX.rs.getDouble("valor");
            }
            jTextFieldTotalSaida.setText(String.valueOf(formatoNum.format(TotalSaida)));
            
//            double t_ent = Double.parseDouble(jTextFieldTotalEnt.getText());
//            double t_sai = Double.parseDouble(jTextFieldTotalSaida.getText());
            SaldoDia = TotalEntrada-TotalSaida;
            //Double dT_saldo = Double.parseDouble(t_saldo);
            //JOptionPane.showMessageDialog(rootPane, t_saldo);
            jTextFieldSaldoDia.setText(String.valueOf(formatoNum.format(SaldoDia)));
            
            SaldoTotal = (AberturaCX+TotalEntrada)-TotalSaida;
            jTextFieldSaldoTotal.setText(String.valueOf(formatoNum.format(SaldoTotal)));
           
            if (SaldoDia<=0){
                jTextFieldSaldoDia.setForeground(Color.RED);
            }else{
                jTextFieldSaldoDia.setForeground(Color.BLUE);
            }
            if (SaldoTotal<=0){
                jTextFieldSaldoTotal.setForeground(Color.RED);
            }else{
                jTextFieldSaldoTotal.setForeground(Color.BLUE);
            }
        
        } catch (SQLException ex) {
            Logger.getLogger(FormVendas.class.getName()).log(Level.SEVERE, null, ex);
        }conCX.desconecta();
            
        
    }
    
        public void SomaOrigemCXFechado(int CdCXFechado){
        TotalEntrada = 0;
        SaldoDia = 0;
        SaldoTotal = 0;
        TotalSaida = 0;
        AberturaCX = 0;
        conCX.conecta();
        
        try {
            
            conCX.executaSQL("select * from caixa_descricao where origem='Abertura CX' and id_caixa='"+CdCXFechado+"'");
            while (conCX.rs.next()){
            AberturaCX = AberturaCX+conCX.rs.getDouble("valor");
            }
            jTextFieldAberturaCX.setText(String.valueOf(formatoNum.format(AberturaCX)));
            
            conCX.executaSQL("select * from caixa_descricao where origem='Entrada' and id_caixa='"+CdCXFechado+"'");
            //connVendaPsq.rs.first();
            while (conCX.rs.next()){
                TotalEntrada = TotalEntrada+conCX.rs.getDouble("valor");
            }
            jTextFieldTotalEnt.setText(String.valueOf(formatoNum.format(TotalEntrada)));
            
            conCX.executaSQL("select * from caixa_descricao where origem='Saída' and id_caixa='"+CdCXFechado+"'");
            //connVendaPsq.rs.first();
            while (conCX.rs.next()){
                TotalSaida = TotalSaida+conCX.rs.getDouble("valor");
            }
            jTextFieldTotalSaida.setText(String.valueOf(formatoNum.format(TotalSaida)));
//            double t_ent = Double.parseDouble(jTextFieldTotalEnt.getText());
//            double t_sai = Double.parseDouble(jTextFieldTotalSaida.getText());
//            double t_saldo = t_ent-t_sai;
            
            SaldoDia = TotalEntrada-TotalSaida;
            jTextFieldSaldoDia.setText(String.valueOf(formatoNum.format(SaldoDia)));
            
            SaldoTotal = (AberturaCX+TotalEntrada)-TotalSaida;
            jTextFieldSaldoTotal.setText(String.valueOf(formatoNum.format(SaldoTotal)));
            
            if (SaldoDia<=0){
                jTextFieldSaldoDia.setForeground(Color.RED);
            }else{
                jTextFieldSaldoDia.setForeground(Color.BLUE);
            }
            if (SaldoTotal<=0){
                jTextFieldSaldoTotal.setForeground(Color.RED);
            }else{
                jTextFieldSaldoTotal.setForeground(Color.BLUE);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(FormVendas.class.getName()).log(Level.SEVERE, null, ex);
        }conCX.desconecta();
        
    }
    
        public void preencherTabelaHS(String SQL) throws SQLException{
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Cód","Dt. Fechamento","Abertura Caixa","Total Entrada","Total Saída"};
        conCX.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conCX.executaSQL(SQL);
        
//        
//        PreparedStatement preparedStatement = conCX.conn.prepareStatement(SQL);
//        preparedStatement.setString(1, Status);
//        preparedStatement.setDate(2, (java.sql.Date) dataI);
//        preparedStatement.setDate(3, (java.sql.Date) dataF);
//        preparedStatement.execute();
//        conCX.rs = preparedStatement.executeQuery();
        
        try {
            if (conCX.rs.first()){
            do{
                
                dados.add(new Object[]{conCX.rs.getInt("id_caixa"), conCX.rs.getString("dt_f_dia")+"/"+conCX.rs.getString("dt_f_mes")+"/"+conCX.rs.getString("dt_f_ano"), String.valueOf(formatoNum.format(conCX.rs.getDouble("abertura_cx"))), String.valueOf(formatoNum.format(conCX.rs.getDouble("total_entrada"))), String.valueOf(formatoNum.format(conCX.rs.getDouble("total_saida")))});
                
            }while(conCX.rs.next());
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane,"Erro ao Preencher ArrayList"+ex);
        }
        
        DefaultTableCellRenderer cellRenderD = new DefaultTableCellRenderer();
	cellRenderD.setHorizontalAlignment(SwingConstants.RIGHT);
        
        DefaultTableCellRenderer cellRenderC = new DefaultTableCellRenderer();
	cellRenderC.setHorizontalAlignment(SwingConstants.CENTER);
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableHistorico.setModel(modelo);
        jTableHistorico.getColumnModel().getColumn(0).setPreferredWidth(42);
        jTableHistorico.getColumnModel().getColumn(0).setCellRenderer(cellRenderD);
        jTableHistorico.getColumnModel().getColumn(0).setResizable(false);
        jTableHistorico.getColumnModel().getColumn(1).setPreferredWidth(106);
        jTableHistorico.getColumnModel().getColumn(1).setCellRenderer(cellRenderC);
        jTableHistorico.getColumnModel().getColumn(1).setResizable(false);
        jTableHistorico.getColumnModel().getColumn(2).setPreferredWidth(94);
        jTableHistorico.getColumnModel().getColumn(2).setCellRenderer(cellRenderD);
        jTableHistorico.getColumnModel().getColumn(2).setResizable(false);
        jTableHistorico.getColumnModel().getColumn(3).setPreferredWidth(88);
        jTableHistorico.getColumnModel().getColumn(3).setCellRenderer(cellRenderD);
        jTableHistorico.getColumnModel().getColumn(3).setResizable(false);
        jTableHistorico.getColumnModel().getColumn(4).setPreferredWidth(86);
        jTableHistorico.getColumnModel().getColumn(4).setCellRenderer(cellRenderD);
        jTableHistorico.getColumnModel().getColumn(4).setResizable(false);
        jTableHistorico.getTableHeader().setReorderingAllowed(false);
        jTableHistorico.setAutoResizeMode(jTableHistorico.AUTO_RESIZE_OFF);
        jTableHistorico.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conCX.desconecta();
    
        }
        
        public void preencherTabelaHSAnt(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Cód","Dt. Fechamento","Abertura Caixa","Total Entrada","Total Saída"};
        conCX.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conCX.executaSQL(SQL);
        
        try {
            conCX.rs.first();
            do{
                
                dados.add(new Object[]{conCX.rs.getInt("id_caixa"), conCX.rs.getString("dt_f_dia")+"/"+conCX.rs.getString("dt_f_mes")+"/"+conCX.rs.getString("dt_f_ano"), String.valueOf(formatoNum.format(conCX.rs.getDouble("abertura_CX"))), String.valueOf(formatoNum.format(conCX.rs.getDouble("total_entrada"))), String.valueOf(formatoNum.format(conCX.rs.getDouble("total_saida")))});
                
            }while(conCX.rs.next());
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane,"Erro ao Preencher ArrayList"+ex);
        }
        DefaultTableCellRenderer cellRenderD = new DefaultTableCellRenderer();
	cellRenderD.setHorizontalAlignment(SwingConstants.RIGHT);
        
        DefaultTableCellRenderer cellRenderC = new DefaultTableCellRenderer();
	cellRenderC.setHorizontalAlignment(SwingConstants.CENTER);
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableHistoricoAnt.setModel(modelo);
        jTableHistoricoAnt.getColumnModel().getColumn(0).setPreferredWidth(42);
        jTableHistoricoAnt.getColumnModel().getColumn(0).setCellRenderer(cellRenderD);
        jTableHistoricoAnt.getColumnModel().getColumn(0).setResizable(false);
        jTableHistoricoAnt.getColumnModel().getColumn(1).setPreferredWidth(106);
        jTableHistoricoAnt.getColumnModel().getColumn(1).setCellRenderer(cellRenderC);
        jTableHistoricoAnt.getColumnModel().getColumn(1).setResizable(false);
        jTableHistoricoAnt.getColumnModel().getColumn(2).setPreferredWidth(94);
        jTableHistoricoAnt.getColumnModel().getColumn(2).setCellRenderer(cellRenderD);
        jTableHistoricoAnt.getColumnModel().getColumn(2).setResizable(false);
        jTableHistoricoAnt.getColumnModel().getColumn(3).setPreferredWidth(88);
        jTableHistoricoAnt.getColumnModel().getColumn(3).setCellRenderer(cellRenderD);
        jTableHistoricoAnt.getColumnModel().getColumn(3).setResizable(false);
        jTableHistoricoAnt.getColumnModel().getColumn(4).setPreferredWidth(86);
        jTableHistoricoAnt.getColumnModel().getColumn(4).setCellRenderer(cellRenderD);
        jTableHistoricoAnt.getColumnModel().getColumn(4).setResizable(false);
        jTableHistoricoAnt.getTableHeader().setReorderingAllowed(false);
        jTableHistoricoAnt.setAutoResizeMode(jTableHistoricoAnt.AUTO_RESIZE_OFF);
        jTableHistoricoAnt.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        conCX.desconecta();
              
    }
              
        public void AtualizaResumoHistorico(){
//            obterUltimoDiaMes(Integer.parseInt(mes), Integer.parseInt(ano));
//            DataInicial = "01/"+mes+"/"+ano;
//            DataFinal = String.valueOf(UltimoDiadoMes)+"/"+mes+"/"+ano;
            
            obterUltimoDiaMes(Integer.parseInt(mes), Integer.parseInt(ano));//            JOptionPane.showMessageDialog(rootPane, ex);
            String DI = ano+"-"+mes+"-01";
            String DF = ano+"-"+mes+"-"+String.valueOf(UltimoDiadoMes);
            java.sql.Date DtI = java.sql.Date.valueOf(DI);
            java.sql.Date DtF = java.sql.Date.valueOf(DF);
//            JOptionPane.showMessageDialog(rootPane, DI+" e "+DF);
//            JOptionPane.showMessageDialog(rootPane, DtI+" e "+DtF);
            conCX.conecta();
            
        try {
//            conCX.executaSQL("select * from caixa where status='Fechado' and dt_fechamento between #"+DtI+" 00:00:00# and #"+DtF+" 23:59:59#");
//            conCX.rs.first();
//            JOptionPane.showMessageDialog(rootPane, conCX.rs.getDouble("total_entrada"));
            conCX.executaSQL("select * from caixa_historico where mes='"+mes+"' and ano='"+ano+"'");
            if (conCX.rs.first()){
                    
                    conCX.executaSQL("select * from caixa where status='Fechado' and dt_fechamento between #"+DtI+" 00:00:00# and #"+DtF+" 23:59:59#");
                    conCX.rs.first();
                    do{
                        TotalHsEntrada = TotalHsEntrada+conCX.rs.getDouble("total_entrada");
                        TotalHsSaida = TotalHsSaida+conCX.rs.getDouble("total_saida");
                        SaldoHsTotal = TotalHsEntrada-TotalHsSaida;
                        JOptionPane.showMessageDialog(rootPane, conCX.rs.getDouble("total_entrada"));
                    }while(conCX.rs.next());
                    
                    try {
                        
                        PreparedStatement pst = conCX.conn.prepareStatement("update caixa_historico set total_entrada=?, total_saida=?, saldo_total=? where mes=? and ano=?");
                        pst.setDouble(1, TotalHsEntrada);
                        pst.setDouble(2, TotalHsSaida);
                        pst.setDouble(3, SaldoHsTotal);
                        pst.setString(4, mes);
                        pst.setString(5, ano);
                        pst.execute();
                    
                    } catch (SQLException ex) {
                    
                        JOptionPane.showMessageDialog(rootPane, ex);
                    
                    }
            }else{
                
                        conCX.executaSQL("select * from caixa where status='Fechado' and dt_fechamento between #"+DtI+" 22:50:00# and #"+DtF+" 22:50:00#");
                        conCX.rs.first();
//                      
                        
                    do{
                    
                        TotalHsEntrada = TotalHsEntrada+conCX.rs.getDouble("total_entrada");
                        TotalHsSaida = TotalHsSaida+conCX.rs.getDouble("total_saida");
                        SaldoHsTotal = TotalHsEntrada-TotalHsSaida;
                    
                    }while(conCX.rs.next());
                    
                    try {
                        PreparedStatement pst = conCX.conn.prepareStatement("insert into caixa_historico (mes, ano, total_entrada, total_saida, saldo_total) values (?,?,?,?,?)");
                        pst.setString(1, mes);
                        pst.setString(2, ano);
                        pst.setDouble(3, TotalHsEntrada);
                        pst.setDouble(4, TotalHsSaida);
                        pst.setDouble(5, SaldoHsTotal);
                        pst.execute();
                    } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(rootPane, ex);
                    }
                    
            }
        } catch (SQLException ex) {
            Logger.getLogger(FormControleCaixa.class.getName()).log(Level.SEVERE, null, ex);
        }
            conCX.desconecta();
        }
        
        
        public void preencherTabelaHSResumo(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Mês/Ano","Total Entrada","Total Saída","Saldo Total"};
        conCX.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conCX.executaSQL(SQL);
        
        try {
            conCX.rs.first();
            do{
                
                dados.add(new Object[]{conCX.rs.getString("mes")+"/"+conCX.rs.getString("ano"), String.valueOf(formatoNum.format(conCX.rs.getDouble("total_entrada"))), String.valueOf(formatoNum.format(conCX.rs.getDouble("total_saida"))), String.valueOf(formatoNum.format(conCX.rs.getDouble("saldo_total")))});
                
            }while(conCX.rs.next());
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane,"Erro ao Preencher ArrayList"+ex);
        }
        
        if (SaldoDia<=0){
                jTextFieldSaldoDia.setForeground(Color.RED);
            }else{
                jTextFieldSaldoDia.setForeground(Color.BLUE);
            }
            if (SaldoTotal<=0){
                jTextFieldSaldoTotal.setForeground(Color.RED);
            }else{
                jTextFieldSaldoTotal.setForeground(Color.BLUE);
            }
        
        DefaultTableCellRenderer cellRenderD = new DefaultTableCellRenderer();
        cellRenderD.setHorizontalAlignment(SwingConstants.RIGHT);
        
        
        
        DefaultTableCellRenderer cellRenderC = new DefaultTableCellRenderer();
	cellRenderC.setHorizontalAlignment(SwingConstants.CENTER);
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableHistoricoResumo.setModel(modelo);
        jTableHistoricoResumo.getColumnModel().getColumn(0).setPreferredWidth(101);
        jTableHistoricoResumo.getColumnModel().getColumn(0).setCellRenderer(cellRenderC);
        jTableHistoricoResumo.getColumnModel().getColumn(0).setResizable(false);
        jTableHistoricoResumo.getColumnModel().getColumn(1).setPreferredWidth(105);
        jTableHistoricoResumo.getColumnModel().getColumn(1).setCellRenderer(cellRenderD);
        jTableHistoricoResumo.getColumnModel().getColumn(1).setResizable(false);
        jTableHistoricoResumo.getColumnModel().getColumn(2).setPreferredWidth(105);
        jTableHistoricoResumo.getColumnModel().getColumn(2).setCellRenderer(cellRenderD);
        jTableHistoricoResumo.getColumnModel().getColumn(2).setResizable(false);
        jTableHistoricoResumo.getColumnModel().getColumn(3).setPreferredWidth(105);
        jTableHistoricoResumo.getColumnModel().getColumn(3).setCellRenderer(cellRenderD);
        jTableHistoricoResumo.getColumnModel().getColumn(3).setResizable(false);
        
        jTableHistoricoResumo.getTableHeader().setReorderingAllowed(false);
        jTableHistoricoResumo.setAutoResizeMode(jTableHistoricoResumo.AUTO_RESIZE_OFF);
        jTableHistoricoResumo.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conCX.desconecta();
              
    }
        
        
        
    public void MenuControleCaixaHistorico(){
    
    JMenuItem item1 = new JMenuItem("Imprimir Caixa Selecionado.");
    item1.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        
            PrintCaixa();
            
        }
    });
     
    //cria o menu popup e adiciona os 3 itens
    JPopupMenu popup = new JPopupMenu();
    popup.setPreferredSize(new Dimension(200,60));
    popup.setBackground(Color.WHITE);
    item1.setBackground(Color.WHITE);
    popup.add(item1);
        
    //mostra na tela
       popup.show(jTableHistorico, 55, 0);
    
    }
    
    public void MenuControleCaixaHistoricoAnt(){
    
    JMenuItem item1 = new JMenuItem("Imprimir Caixa Selecionado.");
    item1.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        
            PrintCaixa();
            
        }
    });
     
    //cria o menu popup e adiciona os 3 itens
    JPopupMenu popup = new JPopupMenu();
    popup.setPreferredSize(new Dimension(200,60));
    popup.setBackground(Color.WHITE);
    item1.setBackground(Color.WHITE);
    popup.add(item1);
        
    //mostra na tela
    popup.show(jTableHistoricoAnt, 55, 0);
    
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAbrir;
    private javax.swing.JButton jButtonAddMovimento;
    private javax.swing.JButton jButtonFechar;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JComboBox jComboBoxOrigem;
    private javax.swing.JComboBox jComboBoxRefOrigem;
    private javax.swing.JFormattedTextField jFormattedTextFieldData;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelCX;
    private javax.swing.JLabel jLabelDataCXAberto;
    private javax.swing.JLabel jLabel_info_titulo_descricao_cx;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JTable jTableFC;
    private javax.swing.JTable jTableHistorico;
    private javax.swing.JTable jTableHistoricoAnt;
    private javax.swing.JTable jTableHistoricoResumo;
    private javax.swing.JTextField jTextFieldAberturaCX;
    private controle.ClassUpperField jTextFieldDescrRef;
    private javax.swing.JTextField jTextFieldSaldoDia;
    private javax.swing.JTextField jTextFieldSaldoTotal;
    private javax.swing.JTextField jTextFieldTotalEnt;
    private javax.swing.JTextField jTextFieldTotalSaida;
    private javax.swing.JTextField jTextFieldValor;
    private javax.swing.JButton jbtVoltarDadosTabelaCX;
    // End of variables declaration//GEN-END:variables
}
