/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.PlanodeFundoForms;
import java.beans.PropertyVetoException;
import modelo.ModeloTabela;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author Lindembergue
 */
public class FormPesqProduto extends javax.swing.JInternalFrame {
ConectaBanco conPesProd = new ConectaBanco();
String Usuario, UsuTipo;
DecimalFormat formatoNum;
public static String NomeJIF = "FormPesqProduto";

    /**
     * Creates new form FormPesqProduto
     */
    public FormPesqProduto() {
        initComponents();
        ColocaImagemFundoFrame();
        jTextFieldCampoPesquisa.grabFocus();
        formatoNum = new DecimalFormat("#0.00");
        VerificaSeProdutosCadastrados();
        jComboBoxTipoPesquisa.setSelectedIndex(1);
        preencherTablePesquisaOS("select produtos.codigo, produtos.codigobarras, produtos.produto, produtos.prvenda, produtos.quantidade, fabricantes.fabricante, fornecedores.nome as fornecedor, produtos.data_atual from ((produtos inner join fabricantes on fabricantes.codigo=produtos.fabricante) inner join fornecedores on fornecedores.codigo=produtos.fornecedor) order by produtos.Codigo desc");
        jTextFieldCampoPesquisa.grabFocus();
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
    }
    
    public void VerificaSeProdutosCadastrados(){
        conPesProd.conecta();
        conPesProd.executaSQL("select * from produtos");
    try {
        if (conPesProd.rs.first()){
            
        }else{
            JOptionPane.showMessageDialog(rootPane, "Não existe Produtos Cadastrados.");
            dispose();
        }
    } catch (SQLException ex) {
        Logger.getLogger(FormPesqProduto.class.getName()).log(Level.SEVERE, null, ex);
    }
        conPesProd.desconecta();
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
        
    public void toUpperCase(String texto, java.awt.event.KeyEvent evento){
        evento.setKeyChar(texto.toUpperCase().charAt(0));
    }
    
    public void preencherTablePesquisaOS(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Código","Cód. Barras", "Produto","Preço","Estoque","Fabricante", "Fornecedor", "Dt. Cadastro"};
        conPesProd.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conPesProd.executaSQL(SQL);
        
        try {
            conPesProd.rs.first();
            //JOptionPane.showMessageDialog(rootPane, conOsPesquisa.rs.getString("id"));
            do{
                dados.add(new Object[]{conPesProd.rs.getString("Codigo"),  conPesProd.rs.getString("codigobarras"), conPesProd.rs.getString("produto"), String.valueOf(formatoNum.format(conPesProd.rs.getDouble("prvenda"))), conPesProd.rs.getString("quantidade"), conPesProd.rs.getString("fabricante"), conPesProd.rs.getString("fornecedor"), conPesProd.rs.getString("data_atual")});
            }while(conPesProd.rs.next());
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane,"Erro ao Obter Dados. \n Informação digitada não encontrada."+ex);
        }
        
        DefaultTableCellRenderer cellRenderD = new DefaultTableCellRenderer();
        cellRenderD.setHorizontalAlignment(SwingConstants.RIGHT);
        
        
        
        DefaultTableCellRenderer cellRenderC = new DefaultTableCellRenderer();
	cellRenderC.setHorizontalAlignment(SwingConstants.CENTER);
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTablePesquisaOS.setModel(modelo);
        jTablePesquisaOS.getColumnModel().getColumn(0).setPreferredWidth(60);
        jTablePesquisaOS.getColumnModel().getColumn(0).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(1).setPreferredWidth(80);
        jTablePesquisaOS.getColumnModel().getColumn(1).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(2).setPreferredWidth(250);
        jTablePesquisaOS.getColumnModel().getColumn(2).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(3).setCellRenderer(cellRenderD);
        jTablePesquisaOS.getColumnModel().getColumn(3).setPreferredWidth(70);
        jTablePesquisaOS.getColumnModel().getColumn(3).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(4).setCellRenderer(cellRenderC);
        jTablePesquisaOS.getColumnModel().getColumn(4).setPreferredWidth(60);
        jTablePesquisaOS.getColumnModel().getColumn(4).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(5).setPreferredWidth(160);
        jTablePesquisaOS.getColumnModel().getColumn(5).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(5).setPreferredWidth(150);
        jTablePesquisaOS.getColumnModel().getColumn(6).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(6).setPreferredWidth(80);
        jTablePesquisaOS.getColumnModel().getColumn(6).setResizable(false);
        jTablePesquisaOS.getTableHeader().setReorderingAllowed(false);
        jTablePesquisaOS.setAutoResizeMode(jTablePesquisaOS.AUTO_RESIZE_OFF);
        jTablePesquisaOS.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conPesProd.desconecta();
              
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBoxTipoPesquisa = new javax.swing.JComboBox();
        jButtonPesquisar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisaOS = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldCampoPesquisa = new controle.ClassUpperField();
        jButtonSair = new javax.swing.JButton();
        jButtonAbrir = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setTitle("Produtos  Cadastrados");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Pesquisar por:");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 10, 200, 16);

        jComboBoxTipoPesquisa.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Cód. Produto", "Nome Produto", "Categoria", "Data Cadastro", "Cód Barras" }));
        jComboBoxTipoPesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoPesquisaActionPerformed(evt);
            }
        });
        jPanelFundo.add(jComboBoxTipoPesquisa);
        jComboBoxTipoPesquisa.setBounds(10, 30, 200, 30);

        jButtonPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/Search44Resultado.png"))); // NOI18N
        jButtonPesquisar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesquisar);
        jButtonPesquisar.setBounds(680, 30, 40, 30);

        jTablePesquisaOS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTablePesquisaOS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePesquisaOSMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablePesquisaOS);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 70, 710, 370);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Digite aqui os dados a pesquisar:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(210, 10, 390, 16);

        jTextFieldCampoPesquisa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldCampoPesquisaKeyReleased(evt);
            }
        });
        jPanelFundo.add(jTextFieldCampoPesquisa);
        jTextFieldCampoPesquisa.setBounds(210, 30, 470, 30);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(6, 6, 730, 449);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(640, 470, 100, 40);

        jButtonAbrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/open folderResultado.png"))); // NOI18N
        jButtonAbrir.setText("Abrir");
        jButtonAbrir.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAbrirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAbrir);
        jButtonAbrir.setBounds(540, 470, 100, 40);

        setBounds(0, 0, 748, 545);
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxTipoPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoPesquisaActionPerformed
        jTextFieldCampoPesquisa.grabFocus();
    }//GEN-LAST:event_jComboBoxTipoPesquisaActionPerformed

    private void jButtonPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarActionPerformed
        //        Cód. Cliente  = 0
        //        Nome Cliente  = 1
        //        Categoria     = 2
        //        Data Cadastro = 3
        //        Todas         = 4

        int CampoEscolhido = (jComboBoxTipoPesquisa.getSelectedIndex());

        String DadosParaPesquisar = jTextFieldCampoPesquisa.getText();

        //preencherTablePesquisaOS("select os.id, clientes.nome_cliente, os.dt_abertura, funcionarios.nome_funcionario, os.status, os.total_os from os join clientes on clientes.id_cliente=os.id_cliente  join funcionarios on funcionarios.id_funcionario=os.id_funcionario where nome_cliente='%"+DadosParaPesquisar+"%'");

        if (CampoEscolhido == 0 ){
            if ("".equals(jTextFieldCampoPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite o codigo do Produto para pesquisar.");
            } else {
                int idCliente = Integer.parseInt(DadosParaPesquisar);
                preencherTablePesquisaOS("select produtos.codigo, produtos.codigobarras, produtos.produto, produtos.prvenda, produtos.quantidade, fabricantes.fabricante, fornecedores.nome as fornecedor, produtos.data_atual from ((produtos inner join fabricantes on fabricantes.codigo=produtos.fabricante) inner join fornecedores on fornecedores.codigo=produtos.fornecedor) where produtos.Codigo='"+idCliente+"'");
            }
        }

        if (CampoEscolhido == 1){
            preencherTablePesquisaOS("select produtos.codigo, produtos.codigobarras, produtos.produto, produtos.prvenda, produtos.quantidade, fabricantes.fabricante, fornecedores.nome as fornecedor, produtos.data_atual from ((produtos inner join fabricantes on fabricantes.codigo=produtos.fabricante) inner join fornecedores on fornecedores.codigo=produtos.fornecedor) where produtos.produto like '%"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 2){
            preencherTablePesquisaOS("select produtos.codigo, produtos.codigobarras, produtos.produto, produtos.prvenda, produtos.quantidade, fabricantes.fabricante, fornecedores.nome as fornecedor, produtos.data_atual from ((produtos inner join fabricantes on fabricantes.codigo=produtos.fabricante) inner join fornecedores on fornecedores.codigo=produtos.fornecedor) where fabricantes.fabricante like '%"+DadosParaPesquisar+"%'");
        }

        if (CampoEscolhido == 3){
            preencherTablePesquisaOS("select produtos.codigo, produtos.codigobarras, produtos.produto, produtos.prvenda, produtos.quantidade, fabricantes.fabricante, fornecedores.nome as fornecedor, produtos.data_atual from ((produtos inner join fabricantes on fabricantes.codigo=produtos.fabricante) inner join fornecedores on fornecedores.codigo=produtos.fornecedor) where data_atual like '%"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 4){
            preencherTablePesquisaOS("select produtos.codigo, produtos.codigobarras, produtos.produto, produtos.prvenda, produtos.quantidade, fabricantes.fabricante, fornecedores.nome as fornecedor, produtos.data_atual from ((produtos inner join fabricantes on fabricantes.codigo=produtos.fabricante) inner join fornecedores on fornecedores.codigo=produtos.fornecedor) where produtos.codigobarras like '%"+DadosParaPesquisar+"%'");
        }
        else{
            //JOptionPane.showMessageDialog(rootPane, "Erro ao Pesquisar dados!");
        }
    }//GEN-LAST:event_jButtonPesquisarActionPerformed

    private void jTablePesquisaOSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePesquisaOSMouseClicked
        if (evt.getClickCount()==2){
            String codProdx = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
            int cdCli = Integer.parseInt(codProdx);
            FormAbreEditaProduto FrmAbreProd = new FormAbreEditaProduto();
            FrmAbreProd.AbreEditaProd(cdCli);
            FormPrincipal.AbreNovaJanelaS(FrmAbreProd);
            dispose();
        }
    }//GEN-LAST:event_jTablePesquisaOSMouseClicked

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
        dispose();
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAbrirActionPerformed
        int codProdSel = jTablePesquisaOS.getSelectedRow();
        if (codProdSel==(-1)){
            JOptionPane.showMessageDialog(rootPane, "Por favor, selecione um Produto cadastrado.");
        } else {String codProdx = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
            int cdCli = Integer.parseInt(codProdx);
            FormAbreEditaProduto FrmAbreProd = new FormAbreEditaProduto();
            FrmAbreProd.a_form_ex = true; 
            FrmAbreProd.jifr = this;
            FrmAbreProd.AbreEditaProd(cdCli);
            FormPrincipal.AbreNovaJanelaS(FrmAbreProd);
            try {
            this.setIcon(true);
            } catch (PropertyVetoException ex) {

            }

//            dispose();
        }
    }//GEN-LAST:event_jButtonAbrirActionPerformed

    private void jTextFieldCampoPesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldCampoPesquisaKeyReleased
        
        //        Cód. Cliente  = 0
        //        Nome Cliente  = 1
        //        Categoria     = 2
        //        Data Cadastro = 3
        //        Todas         = 4

        int CampoEscolhido = (jComboBoxTipoPesquisa.getSelectedIndex());

        String DadosParaPesquisar = jTextFieldCampoPesquisa.getText();

        //preencherTablePesquisaOS("select os.id, clientes.nome_cliente, os.dt_abertura, funcionarios.nome_funcionario, os.status, os.total_os from os join clientes on clientes.id_cliente=os.id_cliente  join funcionarios on funcionarios.id_funcionario=os.id_funcionario where nome_cliente='%"+DadosParaPesquisar+"%'");

        if (CampoEscolhido == 0 ){
            if ("".equals(jTextFieldCampoPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite o codigo do Produto para pesquisar.");
            } else {
                int idCliente = Integer.parseInt(DadosParaPesquisar);
               preencherTablePesquisaOS("select produtos.codigo, produtos.codigobarras, produtos.produto, produtos.prvenda, produtos.quantidade, fabricantes.fabricante, fornecedores.nome as fornecedor, produtos.data_atual from ((produtos inner join fabricantes on fabricantes.codigo=produtos.fabricante) inner join fornecedores on fornecedores.codigo=produtos.fornecedor) where produtos.Codigo='"+idCliente+"'");
            }
        }

        if (CampoEscolhido == 1){
            preencherTablePesquisaOS("select produtos.codigo, produtos.codigobarras, produtos.produto, produtos.prvenda, produtos.quantidade, fabricantes.fabricante, fornecedores.nome as fornecedor, produtos.data_atual from ((produtos inner join fabricantes on fabricantes.codigo=produtos.fabricante) inner join fornecedores on fornecedores.codigo=produtos.fornecedor) where produtos.produto like '%"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 2){
            preencherTablePesquisaOS("select produtos.codigo, produtos.codigobarras, produtos.produto, produtos.prvenda, produtos.quantidade, fabricantes.fabricante, fornecedores.nome as fornecedor, produtos.data_atual from ((produtos inner join fabricantes on fabricantes.codigo=produtos.fabricante) inner join fornecedores on fornecedores.codigo=produtos.fornecedor) where fabricantes.fabricante like '%"+DadosParaPesquisar+"%'");
        }

        if (CampoEscolhido == 3){
            preencherTablePesquisaOS("select produtos.codigo, produtos.codigobarras, produtos.produto, produtos.prvenda, produtos.quantidade, fabricantes.fabricante, fornecedores.nome as fornecedor, produtos.data_atual from ((produtos inner join fabricantes on fabricantes.codigo=produtos.fabricante) inner join fornecedores on fornecedores.codigo=produtos.fornecedor) where data_atual like '%"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 4){
            preencherTablePesquisaOS("select produtos.codigo, produtos.codigobarras, produtos.produto, produtos.prvenda, produtos.quantidade, fabricantes.fabricante, fornecedores.nome as fornecedor, produtos.data_atual from ((produtos inner join fabricantes on fabricantes.codigo=produtos.fabricante) inner join fornecedores on fornecedores.codigo=produtos.fornecedor) where produtos.codigobarras like '%"+DadosParaPesquisar+"%'");
        }
        else{
            //JOptionPane.showMessageDialog(rootPane, "Erro ao Pesquisar dados!");
        }
        
    }//GEN-LAST:event_jTextFieldCampoPesquisaKeyReleased
    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAbrir;
    private javax.swing.JButton jButtonPesquisar;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JComboBox jComboBoxTipoPesquisa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisaOS;
    private controle.ClassUpperField jTextFieldCampoPesquisa;
    // End of variables declaration//GEN-END:variables
}
