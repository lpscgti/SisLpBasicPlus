/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.PlanodeFundoForms;
import modelo.ModeloTabela;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

/**
 *
 * @author Lindembergue
 */
    public class DialogPesqFornecedor extends javax.swing.JDialog {
    ConectaBanco conPesCli = new ConectaBanco();
    public int CodFornecedor = 0;
    public String NomeFornecedor = null;
    public static String NomeJIF = "DialogPesqFornecedor";
    /**
     * Creates new form DialogPesqCliente
     */
    public DialogPesqFornecedor() {
        
        initComponents();
        preencherTablePesquisaOS("select * from fornecedores");
        ColocaImagemFundoFrame();
        ImageIcon img = new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png"));
        this.setIconImage(img.getImage());
        
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }

    private DialogPesqFornecedor(JFrame jFrame, boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public int GetCodigoCliente (){
            
        CodFornecedor = Integer.parseInt("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
        
        return CodFornecedor;
         
    }

    
    public String GetNomeFornecedor (){
            
        NomeFornecedor = "" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 1);
        
        return NomeFornecedor;
    }
    
    
    public void preencherTablePesquisaOS(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Còdigo","Fornecedor","Endereço","Bairro","Cidade", "Fone", "Fone", "CNPJ", "CPF"};
        conPesCli.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conPesCli.executaSQL(SQL);
        
        try {
            conPesCli.rs.first();
            //JOptionPane.showMessageDialog(rootPane, conOsPesquisa.rs.getString("id"));
            do{
                dados.add(new Object[]{conPesCli.rs.getString("codigo"), conPesCli.rs.getString("nome"), conPesCli.rs.getString("endereco"), conPesCli.rs.getString("bairro"), conPesCli.rs.getString("cidade"), conPesCli.rs.getString("tel1"), conPesCli.rs.getString("tel2"), conPesCli.rs.getString("cnpj"), conPesCli.rs.getString("cpf")});
            }while(conPesCli.rs.next());
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane,"Erro ao Obter Dados. \n Informação digitada não encontrada."+ex);
        }
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTablePesquisaOS.setModel(modelo);
        jTablePesquisaOS.getColumnModel().getColumn(0).setPreferredWidth(60);
        jTablePesquisaOS.getColumnModel().getColumn(0).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(1).setPreferredWidth(240);
        jTablePesquisaOS.getColumnModel().getColumn(1).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(2).setPreferredWidth(250);
        jTablePesquisaOS.getColumnModel().getColumn(2).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(3).setPreferredWidth(180);
        jTablePesquisaOS.getColumnModel().getColumn(3).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(4).setPreferredWidth(150);
        jTablePesquisaOS.getColumnModel().getColumn(4).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(5).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(5).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(6).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(6).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(7).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(7).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(8).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(8).setResizable(false);
//        jTablePesquisaOS.getColumnModel().getColumn(10).setPreferredWidth(100);
//        jTablePesquisaOS.getColumnModel().getColumn(10).setResizable(false);
        jTablePesquisaOS.getTableHeader().setReorderingAllowed(false);
        jTablePesquisaOS.setAutoResizeMode(jTablePesquisaOS.AUTO_RESIZE_OFF);
        jTablePesquisaOS.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conPesCli.desconecta();
              
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldCampoPesquisa = new controle.ClassUpperField();
        jButtonPesquisar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisaOS = new javax.swing.JTable();
        jButtonAbrir = new javax.swing.JButton();
        jButtonSair = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Pesquisando Fornecedor...");
        setBackground(new java.awt.Color(255, 255, 255));
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Digite aqui os dados a pesquisar:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(10, 6, 690, 20);

        jTextFieldCampoPesquisa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldCampoPesquisaKeyReleased(evt);
            }
        });
        jPanelFundo.add(jTextFieldCampoPesquisa);
        jTextFieldCampoPesquisa.setBounds(10, 30, 650, 25);

        jButtonPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/btn_pesq_15.png"))); // NOI18N
        jButtonPesquisar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesquisar);
        jButtonPesquisar.setBounds(660, 30, 40, 25);

        jTablePesquisaOS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTablePesquisaOS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePesquisaOSMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablePesquisaOS);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 70, 690, 370);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 10, 710, 450);

        jButtonAbrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/applyResultado.png"))); // NOI18N
        jButtonAbrir.setText("OK");
        jButtonAbrir.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAbrirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAbrir);
        jButtonAbrir.setBounds(540, 470, 90, 40);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(630, 470, 90, 40);

        setSize(new java.awt.Dimension(746, 558));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarActionPerformed
      
        preencherTablePesquisaOS("select * from fornecedores where nome like '"+jTextFieldCampoPesquisa.getText()+"%'");
        
    }//GEN-LAST:event_jButtonPesquisarActionPerformed

    private void jTablePesquisaOSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePesquisaOSMouseClicked
        if (evt.getClickCount()==2){
            
            CodFornecedor = Integer.parseInt("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
            NomeFornecedor = "" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 1);
            
            dispose();
        }

    }//GEN-LAST:event_jTablePesquisaOSMouseClicked

    private void jTextFieldCampoPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldCampoPesquisaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldCampoPesquisaActionPerformed

    private void jTextFieldCampoPesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldCampoPesquisaKeyReleased

        preencherTablePesquisaOS("select * from fornecedores where nome like '"+jTextFieldCampoPesquisa.getText()+"%'");

    }//GEN-LAST:event_jTextFieldCampoPesquisaKeyReleased

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
        dispose();
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAbrirActionPerformed

        CodFornecedor = Integer.parseInt("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
        NomeFornecedor = "" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 1);
        
        dispose();

    }//GEN-LAST:event_jButtonAbrirActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DialogPesqFornecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DialogPesqFornecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DialogPesqFornecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DialogPesqFornecedor.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                DialogPesqFornecedor dialog = new DialogPesqFornecedor(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAbrir;
    private javax.swing.JButton jButtonPesquisar;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisaOS;
    private controle.ClassUpperField jTextFieldCampoPesquisa;
    // End of variables declaration//GEN-END:variables
}
