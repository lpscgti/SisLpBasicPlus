/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ControleProduto;
import modelo.ModeloProduto;
import controle.ConectaBanco;
import controle.PlanodeFundoForms;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyVetoException;
import java.io.File;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import static javax.swing.JFileChooser.SELECTED_FILE_CHANGED_PROPERTY;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;


/**
 *
 * @author Lindembergue
 */
public class FormAbreEditaProduto extends javax.swing.JInternalFrame {
ConectaBanco conProduto = new ConectaBanco();
ModeloProduto ModProduto = new ModeloProduto();
ControleProduto ControlProd = new ControleProduto();
BufferedImage imagem;
FilePreviewer previewer;
int CodCategoria, CodFornecedor, CodProduto, CodMedida;
String DataHoje, Usuario, UsuTipo;
double MargLucro,PrCusto, PrVenda, Valor, ConverteValor; 
DecimalFormat formatoNumP = new DecimalFormat("#0.0");
DecimalFormat formatoNum = new DecimalFormat("#0.00");
public static String NomeJIF = "FormAbreEditaProduto";
public boolean a_form_ex = false; //identifica se o jormulario foi aberto a partir de outro formulario.
public JInternalFrame jifr; //declara classe jif para permitir que o codigo consiga restaurar a janela do formulario de origem.

    /**
     * Creates new form FormAbreEditaProduto
     */
    public FormAbreEditaProduto() {
        initComponents();
        ColocaImagemFundoFrame();
        preencheCategoria();
        preencheFornecedor();
        preencheUnidadeMedida();
        DesativaEdicaoItens();
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
    }
    
    public void convertValorVirgula(String ValorEntrada){
        if (ValorEntrada.equals("")){
            ValorEntrada = "0";
        }else{
        Valor = Double.parseDouble(ValorEntrada.replace(',', '.'));  
        }
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
    public void toUpperCase(String texto, java.awt.event.KeyEvent evento){
        evento.setKeyChar(texto.toUpperCase().charAt(0));
    }
    
     public void preencheCategoria(){
    
        conProduto.conecta();
        
        try {
            conProduto.executaSQL("select * from fabricantes order by fabricante");
            if (conProduto.rs.first()){
            jComboBoxCate.removeAllItems();
            jComboBoxCate.addItem("Selecione um Fabricante/Marca");
            do{
                jComboBoxCate.addItem(conProduto.rs.getString("fabricante"));
            } while (conProduto.rs.next());
            }else{
                jComboBoxCate.removeAllItems();
                jComboBoxCate.addItem("Cadastre Fabricantes/Marcas");
                dispose();
                JOptionPane.showMessageDialog(rootPane, "Não existe Fabricante ou Marca cadastrados.\nCadastre Fabricantes ou Marcas de Produtos em 'Cadastros / Fabricantes/Marcas'");
                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao Obter lista de Fabricante/Marca. "+ex);
            //Logger.getLogger(FormCadProdutos.class.getName()).log(Level.SEVERE, null, ex);
        }
        conProduto.desconecta();
    
}
    
    public void preencheFornecedor(){
    
        conProduto.conecta();
        
        try {
            conProduto.executaSQL("select * from fornecedores order by nome");
            if (conProduto.rs.first()){
            jComboBoxFornc.removeAllItems();
            jComboBoxFornc.addItem("Selecione um Fornecedor");
            do{
                jComboBoxFornc.addItem(conProduto.rs.getString("nome"));
            } while (conProduto.rs.next());
            }else{
                jComboBoxFornc.removeAllItems();
            jComboBoxFornc.addItem("Cadastre Fornecedores");
                dispose();
                JOptionPane.showMessageDialog(rootPane, "Não existe Fornecedores cadastrados.\nCadastre Fornecedores em 'Cadastros / Fornecedores'");
                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao Obter lista de Fornecedores. "+ex);
            //Logger.getLogger(FormCadProdutos.class.getName()).log(Level.SEVERE, null, ex);
        }
        conProduto.desconecta();
    
}
    
    public void preencheUnidadeMedida(){
        conProduto.conecta();
        try {
            conProduto.executaSQL("select * from medidas order by medida");
            conProduto.rs.first();
            jComboBoxU_medida.removeAllItems();
            do{
                jComboBoxU_medida.addItem(conProduto.rs.getString("medida"));
            } while (conProduto.rs.next());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao Obter lista de unidade de medidas. "+ex);
            //Logger.getLogger(FormCadProdutos.class.getName()).log(Level.SEVERE, null, ex);
        }
        conProduto.desconecta();
    }
    
    public void DesativaItens(){
        
        jTextFieldCOD.setEnabled(false);
        jTextFieldProd.setEnabled(false);
        jComboBoxCate.setEnabled(false);
        jComboBoxFornc.setEnabled(false);
        jComboBoxU_medida.setEnabled(false);
        jTextFieldPrCusto.setEnabled(false);
        jTextFieldPrVenda.setEnabled(false);
        jTextFieldMLucro.setEnabled(false);
        jTextFieldQuant.setEnabled(false);
        jTextArea1.setEnabled(false);
        jButtonSalvar.setEnabled(false);
        jFormattedTextFieldDtAtual.setEnabled(false);
        jTextFieldCodBarras.setEnabled(false);
        
    }
    
    public void DesativaEdicaoItens(){
       
        jTextFieldCOD.setEditable(false);
        jTextFieldProd.setEditable(false);
        jTextFieldPrCusto.setEditable(false);
        jTextFieldPrVenda.setEditable(false);
        jTextFieldMLucro.setEditable(false);
        jTextFieldQuant.setEditable(false);
        jTextArea1.setEditable(false);
        jFormattedTextFieldDtAtual.setEditable(false);
        jComboBoxCate.setEnabled(false);
        jComboBoxFornc.setEnabled(false);
        jComboBoxU_medida.setEnabled(false);
        jTextFieldCodBarras.setEditable(false);
        
    }
    
    public void AtivaEdicaoItens(){

        jTextFieldCOD.setEditable(true);
        jTextFieldProd.setEditable(true);
        jTextFieldPrCusto.setEditable(true);
        jTextFieldPrVenda.setEditable(true);
        jTextFieldMLucro.setEditable(true);
        jTextFieldQuant.setEditable(true);
        jTextArea1.setEditable(true);
        jFormattedTextFieldDtAtual.setEditable(true);
        jComboBoxCate.setEnabled(true);
        jComboBoxFornc.setEnabled(true);
        jComboBoxU_medida.setEnabled(true);
        jTextFieldCodBarras.setEditable(true);
        
    }
    
    public void AtivaItens(){
        
        jTextFieldCOD.setEnabled(true);
        jTextFieldProd.setEnabled(true);
        jComboBoxCate.setEnabled(true);
        jComboBoxFornc.setEnabled(true);
        jComboBoxU_medida.setEnabled(true);
        jTextFieldPrCusto.setEnabled(true);
        jTextFieldPrVenda.setEnabled(true);
        jTextFieldMLucro.setEnabled(true);
        jTextFieldQuant.setEnabled(true);
        jTextArea1.setEnabled(true);
        jButtonSalvar.setEnabled(true);
        jFormattedTextFieldDtAtual.setEnabled(true);
        jTextFieldCodBarras.setEnabled(true);
        
    }
    
    public void LimpaItens(){
        
        jTextFieldCOD.setText("");
        jTextFieldProd.setText("");
        jComboBoxCate.setSelectedIndex(0);
        jComboBoxFornc.setSelectedIndex(0);
        jComboBoxU_medida.setSelectedItem("UN");
        jTextFieldPrCusto.setText("0");
        jTextFieldPrVenda.setText("0");
        jTextFieldMLucro.setText("0");
        jTextFieldQuant.setText("");
        jTextArea1.setText("");
        jFormattedTextFieldDtAtual.setText("");
        jTextFieldCodBarras.setText("");
        
    }
    
    
    
    public void AbreEditaProd(int CdProd){
        
        CodProduto = CdProd;
        conProduto.conecta();
        try {
            conProduto.executaSQL("select produtos.codigo, produtos.produto, fabricantes.fabricante, fornecedores.nome as fornecedor, produtos.prcusto, produtos.prvenda, produtos.margemlucro, produtos.quantidade, fornecedores.nome, produtos.obs, produtos.data_atual, produtos.unidademedida from ((produtos inner join  fabricantes on fabricantes.codigo=produtos.fabricante) inner join fornecedores on fornecedores.codigo=produtos.fornecedor) where produtos.codigo='"+CdProd+"'");
            conProduto.rs.first();
            jTextFieldCOD.setText(String.valueOf(CodProduto));
            jTextFieldProd.setText(conProduto.rs.getString("produto"));
            jComboBoxCate.setSelectedItem(conProduto.rs.getString("fabricante"));
            jComboBoxFornc.setSelectedItem(conProduto.rs.getString("fornecedor"));
            jTextFieldPrCusto.setText(String.valueOf(formatoNum.format(conProduto.rs.getDouble("prcusto"))));
            jTextFieldPrVenda.setText(String.valueOf(formatoNum.format(conProduto.rs.getDouble("prvenda"))));
            jTextFieldMLucro.setText(String.valueOf(formatoNumP.format(conProduto.rs.getInt("margemlucro"))));
            jTextFieldQuant.setText(String.valueOf(conProduto.rs.getInt("quantidade")));
            jFormattedTextFieldDtAtual.setText(conProduto.rs.getString("data_atual"));
            jTextArea1.setText(conProduto.rs.getString("obs"));
            jComboBoxU_medida.setSelectedItem(conProduto.rs.getString("unidademedida"));
        } catch (SQLException ex) {
            Logger.getLogger(FormAbreEditaProduto.class.getName()).log(Level.SEVERE, null, ex);
        }
        conProduto.desconecta();
        jButtonEditar.setEnabled(true);
        jButtonSalvar.setEnabled(false);
        jButtonExcluir.setEnabled(true);
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jTextFieldCOD = new controle.ClassUpperField();
        jTextFieldProd = new controle.ClassUpperField();
        jTextFieldCodBarras = new javax.swing.JTextField();
        jComboBoxCate = new javax.swing.JComboBox();
        jComboBoxFornc = new javax.swing.JComboBox();
        jTextFieldPrCusto = new javax.swing.JTextField();
        jTextFieldPrVenda = new javax.swing.JTextField();
        jTextFieldMLucro = new javax.swing.JTextField();
        jTextFieldQuant = new javax.swing.JTextField();
        jFormattedTextFieldDtAtual = new javax.swing.JFormattedTextField();
        jComboBoxU_medida = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButtonAbrir = new javax.swing.JButton();
        jButtonEditar = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jButtonSair = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(null);
        setTitle("Cadastro de Produtos");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Código");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 11, 90, 16);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Produto:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(110, 10, 500, 16);

        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Código de Barras:");
        jPanelFundo.add(jLabel12);
        jLabel12.setBounds(10, 60, 280, 16);

        jLabel3.setForeground(java.awt.Color.white);
        jLabel3.setText("Categoria:");
        jPanelFundo.add(jLabel3);
        jLabel3.setBounds(300, 60, 310, 16);

        jLabel4.setForeground(java.awt.Color.white);
        jLabel4.setText("Fornecedor:");
        jPanelFundo.add(jLabel4);
        jLabel4.setBounds(10, 110, 280, 16);

        jLabel5.setForeground(java.awt.Color.white);
        jLabel5.setText("Preço de Custo R$:");
        jPanelFundo.add(jLabel5);
        jLabel5.setBounds(300, 110, 150, 16);

        jLabel6.setForeground(java.awt.Color.white);
        jLabel6.setText("Preço de Venda R$:");
        jPanelFundo.add(jLabel6);
        jLabel6.setBounds(460, 110, 150, 16);

        jLabel7.setForeground(java.awt.Color.white);
        jLabel7.setText("Marg. de Luco %");
        jPanelFundo.add(jLabel7);
        jLabel7.setBounds(10, 160, 100, 16);

        jLabel8.setForeground(java.awt.Color.white);
        jLabel8.setText("Quantidade/ Estoque");
        jPanelFundo.add(jLabel8);
        jLabel8.setBounds(180, 160, 120, 16);

        jLabel11.setForeground(java.awt.Color.white);
        jLabel11.setText("Data de Atualização:");
        jPanelFundo.add(jLabel11);
        jLabel11.setBounds(350, 160, 120, 16);

        jLabel14.setForeground(java.awt.Color.white);
        jLabel14.setText("Tipo de Unidade/Med:");
        jPanelFundo.add(jLabel14);
        jLabel14.setBounds(480, 160, 130, 16);

        jLabel9.setForeground(java.awt.Color.white);
        jLabel9.setText("Obs:");
        jPanelFundo.add(jLabel9);
        jLabel9.setBounds(10, 210, 600, 16);
        jPanelFundo.add(jTextFieldCOD);
        jTextFieldCOD.setBounds(10, 30, 90, 25);
        jPanelFundo.add(jTextFieldProd);
        jTextFieldProd.setBounds(110, 30, 500, 25);

        jTextFieldCodBarras.setBorder(null);
        jPanelFundo.add(jTextFieldCodBarras);
        jTextFieldCodBarras.setBounds(10, 80, 280, 25);

        jComboBoxCate.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBoxCate.setBorder(null);
        jPanelFundo.add(jComboBoxCate);
        jComboBoxCate.setBounds(300, 80, 310, 25);

        jComboBoxFornc.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBoxFornc.setBorder(null);
        jPanelFundo.add(jComboBoxFornc);
        jComboBoxFornc.setBounds(10, 130, 280, 25);

        jTextFieldPrCusto.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldPrCusto.setBorder(null);
        jPanelFundo.add(jTextFieldPrCusto);
        jTextFieldPrCusto.setBounds(300, 130, 150, 25);

        jTextFieldPrVenda.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldPrVenda.setBorder(null);
        jTextFieldPrVenda.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextFieldPrVendaFocusLost(evt);
            }
        });
        jPanelFundo.add(jTextFieldPrVenda);
        jTextFieldPrVenda.setBounds(460, 130, 150, 25);

        jTextFieldMLucro.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldMLucro.setBorder(null);
        jTextFieldMLucro.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextFieldMLucroFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextFieldMLucroFocusLost(evt);
            }
        });
        jTextFieldMLucro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldMLucroKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldMLucroKeyTyped(evt);
            }
        });
        jPanelFundo.add(jTextFieldMLucro);
        jTextFieldMLucro.setBounds(10, 180, 160, 25);

        jTextFieldQuant.setBorder(null);
        jPanelFundo.add(jTextFieldQuant);
        jTextFieldQuant.setBounds(180, 180, 160, 25);

        jFormattedTextFieldDtAtual.setBorder(null);
        jPanelFundo.add(jFormattedTextFieldDtAtual);
        jFormattedTextFieldDtAtual.setBounds(350, 180, 120, 25);

        jComboBoxU_medida.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBoxU_medida.setBorder(null);
        jPanelFundo.add(jComboBoxU_medida);
        jComboBoxU_medida.setBounds(480, 180, 130, 25);

        jTextArea1.setColumns(20);
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setWrapStyleWord(true);
        jTextArea1.setBorder(null);
        jTextArea1.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextArea1KeyTyped(evt);
            }
        });
        jScrollPane1.setViewportView(jTextArea1);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 230, 600, 70);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 10, 620, 310);

        jButtonAbrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/open folderResultado.png"))); // NOI18N
        jButtonAbrir.setText("Abrir");
        jButtonAbrir.setToolTipText("Abrir Cadastro de Produtos");
        jButtonAbrir.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAbrirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAbrir);
        jButtonAbrir.setBounds(180, 330, 90, 40);

        jButtonEditar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/editResultado.png"))); // NOI18N
        jButtonEditar.setText("Editar");
        jButtonEditar.setToolTipText("Ativar Edição de Itens");
        jButtonEditar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonEditar);
        jButtonEditar.setBounds(270, 330, 90, 40);

        jButtonExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jButtonExcluir.setText("Excluir");
        jButtonExcluir.setToolTipText("Excluir Produto");
        jButtonExcluir.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonExcluir);
        jButtonExcluir.setBounds(360, 330, 90, 40);

        jButtonSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/accept.png"))); // NOI18N
        jButtonSalvar.setText("Salvar");
        jButtonSalvar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSalvar);
        jButtonSalvar.setBounds(450, 330, 90, 40);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(540, 330, 90, 40);

        setBounds(0, 0, 641, 401);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldMLucroFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldMLucroFocusGained

    }//GEN-LAST:event_jTextFieldMLucroFocusGained

    private void jTextFieldMLucroFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldMLucroFocusLost
        
        String marLucroc;
        marLucroc = jTextFieldMLucro.getText();

        if (marLucroc == "" ){
            JOptionPane.showMessageDialog(rootPane, "Margem de Lucro nao pode ser igual a 0");
        }

        if (marLucroc == "0") {
            JOptionPane.showMessageDialog(rootPane, "Margem de Lucro nao pode ser igual a 0");
        } else{
            Valor = 0;
            convertValorVirgula(jTextFieldPrCusto.getText());
            PrCusto = Valor;
            Valor = 0;
            convertValorVirgula(jTextFieldMLucro.getText());
            MargLucro = Valor;
            PrVenda = (MargLucro*(PrCusto/100))+PrCusto;
            jTextFieldPrVenda.setText(String.valueOf(formatoNum.format(PrVenda)));
        }
        
    }//GEN-LAST:event_jTextFieldMLucroFocusLost

    private void jTextFieldMLucroKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldMLucroKeyTyped

    }//GEN-LAST:event_jTextFieldMLucroKeyTyped

    private void jTextFieldMLucroKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldMLucroKeyReleased

    }//GEN-LAST:event_jTextFieldMLucroKeyReleased

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
        if (a_form_ex==true){
            try {
                jifr.setIcon(false);
            } catch (PropertyVetoException ex) {

            }
        } 
        dispose();
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
        
        String NomeCategoriaSel = String.valueOf(jComboBoxCate.getSelectedItem());
        String NomeFornecedorSel = String.valueOf(jComboBoxFornc.getSelectedItem());
        String NomeUnidadeMedida = String.valueOf(jComboBoxU_medida.getSelectedItem());
        int IndexCategoria = jComboBoxCate.getSelectedIndex();
        int IndexFornecedor = jComboBoxFornc.getSelectedIndex();

        if (IndexCategoria == 0){
            JOptionPane.showMessageDialog(rootPane, "Selecione uma fabricante de Produto.");
        }

        if (IndexFornecedor == 0) {
            JOptionPane.showMessageDialog(rootPane, "Selecione um Forncedor para esse Produto.");
        } else {

            conProduto.conecta();

            try {
                conProduto.executaSQL("select * from fabricantes where fabricante='"+NomeCategoriaSel+"'");
                conProduto.rs.first();
                CodCategoria = conProduto.rs.getInt("codigo");
                //JOptionPane.showMessageDialog(rootPane, "Categoria: "+CodCategoria);
                conProduto.executaSQL("select * from fornecedores where nome='"+NomeFornecedorSel+"'");
                conProduto.rs.first();
                CodFornecedor = conProduto.rs.getInt("codigo");
                //JOptionPane.showMessageDialog(rootPane, "Fornecedor: "+CodFornecedor);
                conProduto.executaSQL("select * from medidas where medida='"+NomeUnidadeMedida+"'");
                conProduto.rs.first();
                CodMedida = conProduto.rs.getInt("codigo");

            } catch (SQLException ex) {
                Logger.getLogger(FormCadProdutos.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            
            ModProduto.setNome(jTextFieldProd.getText());
            ModProduto.setCat_id(CodCategoria);
            ModProduto.setForn_id(CodFornecedor);
            
            Valor = 0;
            convertValorVirgula(jTextFieldPrCusto.getText());
            ModProduto.setPr_custo(Valor);
            
            Valor=0;
            convertValorVirgula(jTextFieldPrVenda.getText());
            ModProduto.setPr_venda(Valor);
            
            Valor=0;
            convertValorVirgula(jTextFieldMLucro.getText());
            ModProduto.setM_lucro(Valor);
            
            ModProduto.setEstoque(Integer.parseInt(jTextFieldQuant.getText()));
            ModProduto.setObs(jTextArea1.getText());
            ModProduto.setDt_atual(jFormattedTextFieldDtAtual.getText());
            ModProduto.setId(CodProduto);
            ModProduto.setU_medida(CodMedida);
            ModProduto.setCodBarras(jTextFieldCodBarras.getText());
            ControlProd.SalvaDados(ModProduto);
            LimpaItens();
            DesativaItens();
            DesativaEdicaoItens();
            jButtonAbrir.setEnabled(true);
            jButtonSalvar.setEnabled(false);
            jButtonEditar.setEnabled(false);
        }

    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jButtonAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAbrirActionPerformed
        FormPesqProduto FrmPesqProd = new FormPesqProduto();
        FormPrincipal.AbreNovaJanelaS(FrmPesqProd);
        dispose();
    }//GEN-LAST:event_jButtonAbrirActionPerformed

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed
        
        int i = JOptionPane.showConfirmDialog(rootPane, "Deseja excluir realmente\nos dados deste produto?","Confirmando Exclusão", JOptionPane.YES_NO_OPTION);
        if(i == JOptionPane.YES_OPTION) {
            ModProduto.setId(CodProduto);
            ControlProd.ExcluiDados(ModProduto);
            LimpaItens();
            DesativaItens();
            DesativaEdicaoItens();
            dispose();
            JOptionPane.showMessageDialog(rootPane, "Dados excluidos com sucesso!");
        }
        else if(i == JOptionPane.NO_OPTION) {
        }   
    
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jButtonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditarActionPerformed
        
        AtivaEdicaoItens();
        jButtonSalvar.setEnabled(true);
        jButtonEditar.setEnabled(false);

    }//GEN-LAST:event_jButtonEditarActionPerformed

    private void jTextArea1KeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextArea1KeyTyped
        
        toUpperCase(evt.getKeyChar() + "",  evt);
        
    }//GEN-LAST:event_jTextArea1KeyTyped

    private void jTextFieldPrVendaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldPrVendaFocusLost

    Valor = 0;
    convertValorVirgula(jTextFieldPrVenda.getText());
    PrVenda = Valor;

        if (PrVenda == 0){
                JOptionPane.showMessageDialog(rootPane, "Preco de Venda nao pode ser igual a 0");
        } else{
                Valor = 0;
                convertValorVirgula(jTextFieldPrCusto.getText());
                PrCusto = Valor;

                double MargLucroCalc1 = (PrVenda-PrCusto)/PrCusto;
                double MargLucroCalc2 = ((MargLucroCalc1)*100);
                MargLucro = (MargLucroCalc2);
                jTextFieldMLucro.setText(String.valueOf(formatoNumP.format(MargLucro)));

        } 
        
    }//GEN-LAST:event_jTextFieldPrVendaFocusLost

    public class FilePreviewer extends JComponent implements
            PropertyChangeListener {

        ImageIcon thumbnail = null;

        @SuppressWarnings("LeakingThisInConstructor")
        public FilePreviewer(JFileChooser fc) {
            setPreferredSize(new Dimension(100, 50));
            fc.addPropertyChangeListener(this);
        }

        public void loadImage(File f) {
            if (f == null) {
                thumbnail = null;
            } else {
                ImageIcon tmpIcon = new ImageIcon(f.getPath());
                if (tmpIcon.getIconWidth() > 90) {
                    thumbnail = new ImageIcon(
                            tmpIcon.getImage().getScaledInstance(90, -1,
                            Image.SCALE_DEFAULT));
                } else {
                    thumbnail = tmpIcon;
                }
            }
        }

        public void propertyChange(PropertyChangeEvent e) {
            String prop = e.getPropertyName();
            if (SELECTED_FILE_CHANGED_PROPERTY.equals(prop)) {
                if (isShowing()) {
                    loadImage((File) e.getNewValue());
                    repaint();
                }
            }
        }

        @Override
        public void paint(Graphics g) {
            if (thumbnail != null) {
                int x = getWidth() / 2 - thumbnail.getIconWidth() / 2;
                int y = getHeight() / 2 - thumbnail.getIconHeight() / 2;
                if (y < 0) {
                    y = 0;
                }

                if (x < 5) {
                    x = 5;
                }
                thumbnail.paintIcon(this, g, x, y);
            }
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAbrir;
    private javax.swing.JButton jButtonEditar;
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JComboBox jComboBoxCate;
    private javax.swing.JComboBox jComboBoxFornc;
    private javax.swing.JComboBox jComboBoxU_medida;
    private javax.swing.JFormattedTextField jFormattedTextFieldDtAtual;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private controle.ClassUpperField jTextFieldCOD;
    private javax.swing.JTextField jTextFieldCodBarras;
    private javax.swing.JTextField jTextFieldMLucro;
    private javax.swing.JTextField jTextFieldPrCusto;
    private javax.swing.JTextField jTextFieldPrVenda;
    private controle.ClassUpperField jTextFieldProd;
    private javax.swing.JTextField jTextFieldQuant;
    // End of variables declaration//GEN-END:variables
}
