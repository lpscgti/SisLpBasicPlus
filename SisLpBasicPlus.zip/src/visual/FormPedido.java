/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.Conf;
import controle.ConnectionFactory2;
import controle.ControleEmpresa;
import controle.ControlePedido;
import controle.PlanodeFundoForms;
import modelo.ModeloTabela;
import modelo.ModeloPedido;
import java.awt.BorderLayout;
import java.awt.Image;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;

/**
 *
 * @author Lindembergue
 */
public class FormPedido extends javax.swing.JInternalFrame {
    
    ConectaBanco conPedido = new ConectaBanco();
    ModeloPedido modPedido = new ModeloPedido();
    ControlePedido controlPedido = new ControlePedido();
    ControleEmpresa ctrl_de = new ControleEmpresa();
    int CodPedido, CodCliente, CodProduto, CodFuncionario, QtdVend, TipoPag, flag = 1, IdConta = 0, NovaPedido = 0, ClienteSel=0;
    String DataHoje, NomeCliente, NomeProduto, NomeFuncionario, caminho, caminhoDb;
    double TotalPedido, PrUnit, TotalProdVend, Desconto, DesconcoCalc, ConverteValor;
    DecimalFormat formatoNum;
    
    public static String NomeJIF = "FormPedido";

    /**
     * Creates new form FormPedidos
     */
    
    public FormPedido() {
        initComponents();
        formatoNum = new DecimalFormat("#0.00");
        ColocaImagemFundoFrame();
        Lerarquivo();
        desativaitens();
        jtfCodPedido.setEditable(false);
        jtfCodFornecedor.setEditable(false);
        jtfCodProd.setEditable(false);
        try {
            MaskFormatter data = new MaskFormatter("##/##/####");
            jtfDataPedido.setFormatterFactory(new DefaultFormatterFactory(data));
        } catch (ParseException ex) {
            Logger.getLogger(FormCadClientes.class.getName()).log(Level.SEVERE, null, ex);
        }
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date hoje = new Date();
        DataHoje = (df.format(hoje));
        jtfDataPedido.setText(DataHoje);
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
     public void Lerarquivo(){

        Conf cfg = new Conf();
        Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
        caminho = String.valueOf(caminhoTXT+"\\");
        
            try {
                cfg.ConfigLido();
                String c = "jdbc:ucanaccess://"+caminho+"sislpbasicdb.mdb";
                caminhoDb = c;
            } catch (IOException ex) {
//                Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
        
    }
    
     public void convertValorVirgula(String ValorEntrada){
          
        
        if (ValorEntrada.equals("")){
            ValorEntrada = "0";
        }else{
        ConverteValor = Double.parseDouble(ValorEntrada.replace(',', '.'));  
        }
    }
     

     public void preencherTabelaItensPedidos(String SQL){
        
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Produto","Quantidade"};
        conPedido.conecta();
        conPedido.executaSQL(SQL);
        try {
            conPedido.rs.first();
            do{
                dados.add(new Object[]{conPedido.rs.getString("produto"),conPedido.rs.getInt("quantidade")});
            }while(conPedido.rs.next());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane,"Erro ao Preencher ArrayList"+ex);
        }
        DefaultTableCellRenderer cellRenderD = new DefaultTableCellRenderer();
	cellRenderD.setHorizontalAlignment(SwingConstants.RIGHT);
        DefaultTableCellRenderer cellRenderC = new DefaultTableCellRenderer();
	cellRenderC.setHorizontalAlignment(SwingConstants.CENTER);
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableItensPedido.setModel(modelo);
        jTableItensPedido.getColumnModel().getColumn(0).setPreferredWidth(590);
        jTableItensPedido.getColumnModel().getColumn(0).setResizable(false);
        jTableItensPedido.getColumnModel().getColumn(1).setPreferredWidth(98);
        jTableItensPedido.getColumnModel().getColumn(1).setCellRenderer(cellRenderD);
        jTableItensPedido.getColumnModel().getColumn(1).setResizable(false);
        jTableItensPedido.getTableHeader().setReorderingAllowed(false);
        jTableItensPedido.setAutoResizeMode(jTableItensPedido.AUTO_RESIZE_OFF);
        jTableItensPedido.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        conPedido.desconecta();
           
    }
     
     
    
    
     
     public void desativaitens(){
         jtfCodPedido.setEnabled(false);
         jtfCodFornecedor.setEnabled(false);
         jtfNomeFornecedor.setEnabled(false);
         jtfDataPedido.setEnabled(false);
         jtfCodProd.setEnabled(false);
         jtfNomeProd.setEnabled(false);
         QTD.setEnabled(false);
         jButtonPesqCliente.setEnabled(false);
         jButtonPesqProd.setEnabled(false);
         jButtonAdd.setEnabled(false);
         jButtonRem.setEnabled(false);
         jTableItensPedido.setEnabled(false);
     }
     
     public void ativaitens(){
         jtfCodPedido.setEnabled(true);
         jtfCodFornecedor.setEnabled(true);
         jtfNomeFornecedor.setEnabled(true);
         jtfDataPedido.setEnabled(true);
         jtfCodProd.setEnabled(true);
         jtfNomeProd.setEnabled(true);
         QTD.setEnabled(true);
         jButtonPesqCliente.setEnabled(true);
         jButtonPesqProd.setEnabled(true);
         jButtonAdd.setEnabled(true);
         jButtonRem.setEnabled(true);
         jTableItensPedido.setEnabled(true);
     }
     
    public void Limpaitens(){
         jtfCodPedido.setText("");
         jtfCodFornecedor.setText("");
         jtfNomeFornecedor.setText("");
         jtfDataPedido.setText("");
         jtfCodProd.setText("");
         jtfNomeProd.setText("");
         QTD.setValue(1);
    }
     
    public void limpatabelaPesquisa(){
            
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{};
        dados.removeAll(dados);
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        
    }
    
    public void limpatabelaItensPedidos(){
        
      ArrayList dados = new ArrayList();
      String[] Colunas = new String[]{};
      dados.removeAll(dados);
      ModeloTabela modelo = new ModeloTabela(dados, Colunas);
      jTableItensPedido.setModel(modelo);
      
    }
    
   public void PrintPedidoAVista(){
       ctrl_de.Obtem_Dados_da_Empresa();
        int i = JOptionPane.showConfirmDialog(rootPane, "Pedido Gerado com Sucesso.\nDeseja realizar a impressão?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
                                if(i == JOptionPane.YES_OPTION) {
                               
                                try {
                                    Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                                    Map<String, Object> parametros = new HashMap<String, Object>();
                                    Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                                    //dados empresa
                                    parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                                    parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                                    parametros.put( "cnpj", ctrl_de.de_cnpj );
                                    parametros.put( "de_ie", ctrl_de.de_ie );
                                    parametros.put( "endereco", ctrl_de.de_endereco );
                                    parametros.put( "bairro", ctrl_de.de_bairro );
                                    parametros.put( "cidade", ctrl_de.de_cidade );
                                    parametros.put( "estado", ctrl_de.de_estado );
                                    parametros.put( "cep", ctrl_de.de_cep );
                                    parametros.put( "telefone1", ctrl_de.de_fone1 );
                                    parametros.put( "telefone2", ctrl_de.de_fone2 );
                                    parametros.put( "de_site", ctrl_de.de_site );
                                    parametros.put( "email", ctrl_de.de_email );
                                    parametros.put("logoimg",imagePath);
                                    parametros.put( "CodPedido", CodPedido );
                                    JasperPrint jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraListaPedido.jasper", parametros, ConnectionFactory2.getSlpConnection());
                                    JRViewer viewer = new JRViewer(jpPrint);
                                    viewer.setZoomRatio((float) 0.5);
                                    JFrame frameRelatorio = new JFrame();
                                    frameRelatorio.add( viewer, BorderLayout.CENTER );
                                    frameRelatorio.setTitle("Novo Pedido Gerado");
                                    frameRelatorio.setSize( 500, 500 );
                                    frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                                    frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                                    frameRelatorio.setVisible( true );
                                    }catch (JRException ex) {
                                    JOptionPane.showMessageDialog(null, "Erro ao Gerar Pedido para Impressão!/nErro: "+ex);
//                                    } catch (SQLException ex) {
//                                    Logger.getLogger(FormPedidos.class.getName()).log(Level.SEVERE, null, ex);
                                }   catch (SQLException ex) {
                                        Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                    //conOs.desconecta(); //conOs.desconecta();
                                     //conOs.desconecta(); //conOs.desconecta();
                                
                                }
    
                                
    }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jtfCodPedido = new javax.swing.JTextField();
        jtfCodFornecedor = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButtonPesqCliente = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        jtfDataPedido = new javax.swing.JFormattedTextField();
        jLabel5 = new javax.swing.JLabel();
        jtfCodProd = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableItensPedido = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jButtonRem = new javax.swing.JButton();
        jButtonPesqProd = new javax.swing.JButton();
        jButtonAdd = new javax.swing.JButton();
        QTD = new javax.swing.JSpinner();
        jtfNomeFornecedor = new controle.ClassUpperField();
        jtfNomeProd = new controle.ClassUpperField();
        jButtonSair = new javax.swing.JButton();
        jButtonNovo = new javax.swing.JButton();
        jButtonFinalizar = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setTitle("Efetuar Pedidos");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Cód. Pedido:");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 10, 90, 16);

        jtfCodPedido.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jtfCodPedido.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jPanelFundo.add(jtfCodPedido);
        jtfCodPedido.setBounds(10, 30, 90, 30);

        jtfCodFornecedor.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jPanelFundo.add(jtfCodFornecedor);
        jtfCodFornecedor.setBounds(100, 30, 90, 30);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Cód. Fornecedor:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(100, 10, 90, 16);

        jLabel3.setForeground(java.awt.Color.white);
        jLabel3.setText("Nome do Fornecedor:");
        jPanelFundo.add(jLabel3);
        jLabel3.setBounds(190, 10, 370, 16);

        jButtonPesqCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/btn_pesq_15.png"))); // NOI18N
        jButtonPesqCliente.setToolTipText("Pesquisar Cliente");
        jButtonPesqCliente.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonPesqCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesqClienteActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesqCliente);
        jButtonPesqCliente.setBounds(562, 30, 40, 30);

        jLabel4.setForeground(java.awt.Color.white);
        jLabel4.setText("Data:");
        jPanelFundo.add(jLabel4);
        jLabel4.setBounds(610, 10, 90, 16);

        jtfDataPedido.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter()));
        jPanelFundo.add(jtfDataPedido);
        jtfDataPedido.setBounds(610, 30, 90, 30);

        jLabel5.setForeground(java.awt.Color.white);
        jLabel5.setText("Cód. Produto:");
        jPanelFundo.add(jLabel5);
        jLabel5.setBounds(10, 70, 90, 16);

        jtfCodProd.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jPanelFundo.add(jtfCodProd);
        jtfCodProd.setBounds(10, 90, 90, 30);

        jLabel6.setForeground(java.awt.Color.white);
        jLabel6.setText("Produto:");
        jPanelFundo.add(jLabel6);
        jLabel6.setBounds(100, 70, 300, 16);

        jLabel7.setForeground(java.awt.Color.white);
        jLabel7.setText("Quant. Prod.");
        jPanelFundo.add(jLabel7);
        jLabel7.setBounds(550, 70, 90, 16);

        jTableItensPedido.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTableItensPedido);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 160, 690, 340);

        jLabel9.setForeground(java.awt.Color.white);
        jLabel9.setText("Descrição dos Itens:");
        jPanelFundo.add(jLabel9);
        jLabel9.setBounds(10, 130, 690, 30);

        jButtonRem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jButtonRem.setToolTipText("Remover Produto");
        jButtonRem.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonRem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRemActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonRem);
        jButtonRem.setBounds(670, 90, 30, 30);

        jButtonPesqProd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/btn_pesq_15.png"))); // NOI18N
        jButtonPesqProd.setToolTipText("Pesquisar Produto");
        jButtonPesqProd.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonPesqProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesqProdActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesqProd);
        jButtonPesqProd.setBounds(510, 90, 40, 30);

        jButtonAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/add.png"))); // NOI18N
        jButtonAdd.setToolTipText("Adicionar Produto");
        jButtonAdd.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonAdd);
        jButtonAdd.setBounds(640, 90, 30, 30);

        QTD.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanelFundo.add(QTD);
        QTD.setBounds(550, 90, 90, 30);
        jPanelFundo.add(jtfNomeFornecedor);
        jtfNomeFornecedor.setBounds(190, 30, 370, 30);
        jPanelFundo.add(jtfNomeProd);
        jtfNomeProd.setBounds(100, 90, 410, 30);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 10, 710, 510);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Cancelar");
        jButtonSair.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(630, 530, 90, 40);

        jButtonNovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/add.png"))); // NOI18N
        jButtonNovo.setText("Novo Pedido");
        jButtonNovo.setToolTipText("");
        jButtonNovo.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonNovo);
        jButtonNovo.setBounds(450, 530, 90, 40);

        jButtonFinalizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/applyResultado.png"))); // NOI18N
        jButtonFinalizar.setText("Finalizar");
        jButtonFinalizar.setToolTipText("");
        jButtonFinalizar.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFinalizarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonFinalizar);
        jButtonFinalizar.setBounds(540, 530, 90, 40);

        setBounds(0, 0, 728, 601);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
    
    if (NovaPedido == 0){
        dispose();
    }else{
    controlPedido.CancelaPedido();
    dispose();
    }    


    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonPesqClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesqClienteActionPerformed
    
        DialogPesqFornecedor DPFor = new DialogPesqFornecedor();
        DPFor.setModal(true);
        DPFor.setVisible(true);
        CodCliente = DPFor.CodFornecedor;
        NomeCliente = DPFor.NomeFornecedor;
        jtfCodFornecedor.setText(String.valueOf(CodCliente));
        jtfNomeFornecedor.setText(NomeCliente);
        
        jtfNomeFornecedor.setEditable(false);
        jtfNomeProd.setEnabled(true);
        jButtonPesqProd.setEnabled(true);
        ClienteSel = 1;
        
    }//GEN-LAST:event_jButtonPesqClienteActionPerformed

    private void jButtonRemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRemActionPerformed
       
       int CodRemProduto;
       int QtdVend;
       int qtdEstoque;
       int qtdEstoqueAtual;
       CodRemProduto = Integer.parseInt("" + jTableItensPedido.getValueAt(jTableItensPedido.getSelectedRow(), 0));
       QtdVend = Integer.parseInt("" + jTableItensPedido.getValueAt(jTableItensPedido.getSelectedRow(), 3));
       conPedido.conecta();
        try {
            PreparedStatement pst;
            pst = conPedido.conn.prepareStatement("delete from pedidos_desc where pedido=? and produto=?");
            pst.setInt(1, CodPedido);
            pst.setInt(2, CodRemProduto);
            pst.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao escluir produto da lista.\nErro Código: "+ex);
        }
            jtfCodProd.setText("");
            jtfNomeProd.setText("");
            QTD.setValue(1);
            
       preencherTabelaItensPedidos("select pedidos_desc.pedido, produtos.produto, pedidos_desc.quantidade from (pedidos_desc inner join produtos on produtos.codigo=pedidos_desc.produto) where pedidos_desc.pedido="+CodPedido);
           
    }//GEN-LAST:event_jButtonRemActionPerformed

    private void jButtonPesqProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesqProdActionPerformed
   
        DialogPesqProdutos DPProd = new DialogPesqProdutos();
        DPProd.setModal(true);
        DPProd.setVisible(true);
        CodProduto = DPProd.CodProduto;
        NomeProduto = DPProd.NomeProduto;
        PrUnit = DPProd.PrecoProduto;
        jtfCodProd.setText(String.valueOf(CodProduto));
        jtfNomeProd.setText(String.valueOf(NomeProduto));
        QTD.setValue(1);
        
        jtfCodProd.setEnabled(true);
        jtfNomeProd.setEnabled(true);
        QTD.setEnabled(true);
        jButtonAdd.setEnabled(true);
        jButtonRem.setEnabled(true);
        
    }//GEN-LAST:event_jButtonPesqProdActionPerformed

    private void jButtonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddActionPerformed
        int qtdDisponivel=0;
        try {
            conPedido.conecta();
            conPedido.executaSQL("select * from pedidos_desc where pedido='"+CodPedido+"' and produto='"+CodProduto+"'");
            
            if (conPedido.rs.first()){
                JOptionPane.showMessageDialog(rootPane, "O Produto já foi adicionado\nRemova-o para readicionar com alterações.");
            }else{
            
            
            QtdVend = (int) QTD.getValue();
            modPedido.setIdPedido(CodPedido);
            modPedido.setIdProduto(CodProduto);
            modPedido.setNomeProduto(NomeProduto);
            modPedido.setQtd_produto((int) QTD.getValue());
            controlPedido.AddItem(modPedido);
            
            
            jtfCodProd.setText("");
            jtfNomeProd.setText("");
            QTD.setValue(1);
            }
        } catch (SQLException ex) {
           //JOptionPane.showMessageDialog(rootPane, "erro ao verificar a quantidade! "+ex);
        }
        QTD.setValue(1);
        
        //total = total+Double.parseDouble(jTextFieldPrUnit.getText())*Integer.parseInt(jTextFieldQuantidade.getText());
        //jTextFieldTotalPedido.setText(String.valueOf(total));
        preencherTabelaItensPedidos("select pedidos_desc.pedido, produtos.produto, pedidos_desc.quantidade from (pedidos_desc inner join produtos on produtos.codigo=pedidos_desc.produto) where pedidos_desc.pedido="+CodPedido);

        //preencherTabelaItensPedidos();
    }//GEN-LAST:event_jButtonAddActionPerformed

    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed
        
        NovaPedido = 1;        
        conPedido.conecta();
        try {
            PreparedStatement pst = conPedido.conn.prepareStatement("insert into pedidos (valortotal) values (?)");
            pst.setDouble(1, 0);
            pst.execute();
            conPedido.executaSQL("select * from pedidos order by id_pedido");
            conPedido.rs.last();
            CodPedido = conPedido.rs.getInt("id_pedido");
            jtfCodPedido.setText(String.valueOf(CodPedido));            
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao Gerar Novo Pedido no Banco de Dados!"+ex);
        }
        ativaitens();
        jButtonNovo.setEnabled(false);
        
    }//GEN-LAST:event_jButtonNovoActionPerformed

    private void jButtonFinalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFinalizarActionPerformed
        conPedido.conecta();
    
                modPedido.setIdPedido(CodPedido);
                modPedido.setIdFornecedor(CodCliente);
                modPedido.setDtPedido(jtfDataPedido.getText());
                controlPedido.FechaPedido(modPedido);
                controlPedido.FechaPedido(modPedido);
                JOptionPane.showMessageDialog(null, "Pedido finalizada com sucesso!");
                PrintPedidoAVista();
                dispose();
                
        conPedido.desconecta();
        
    }//GEN-LAST:event_jButtonFinalizarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSpinner QTD;
    private javax.swing.JButton jButtonAdd;
    private javax.swing.JButton jButtonFinalizar;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonPesqCliente;
    private javax.swing.JButton jButtonPesqProd;
    private javax.swing.JButton jButtonRem;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableItensPedido;
    private javax.swing.JTextField jtfCodFornecedor;
    private javax.swing.JTextField jtfCodPedido;
    private javax.swing.JTextField jtfCodProd;
    private javax.swing.JFormattedTextField jtfDataPedido;
    private controle.ClassUpperField jtfNomeFornecedor;
    private controle.ClassUpperField jtfNomeProd;
    // End of variables declaration//GEN-END:variables
}
