/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.PlanodeFundoForms;
import modelo.ModeloTabela;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author Lindembergue
 */
public class FormPesqVendas extends javax.swing.JInternalFrame {
ConectaBanco conPesProd = new ConectaBanco();
String Usuario, UsuTipo;
DecimalFormat formatoNum;
SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat df2 = new SimpleDateFormat("yyyy-MM-dd");
    SimpleDateFormat df3 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public static String NomeJIF = "FormPesqVendas";

    /**
     * Creates new form FormPesqProduto
     */
    public FormPesqVendas() {
       
        initComponents();
        formatoNum = new DecimalFormat("#0.00");
        ColocaImagemFundoFrame();
        jTextFieldCampoPesquisa.grabFocus();
        jComboBoxTipoPesquisa.setSelectedIndex(1);
        preencherTablePesquisaOS("select vendas.codigo, vendas.valorvenda, clientes.nome as cliente, vendas.tipo, vendas.data from (vendas inner join clientes on clientes.codigo=vendas.cliente) order by vendas.data desc");
    
        jTextFieldCampoPesquisa.grabFocus();
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
     
    
    public void toUpperCase(String texto, java.awt.event.KeyEvent evento){
        evento.setKeyChar(texto.toUpperCase().charAt(0));
    }
    
    public void preencherTablePesquisaOS(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Código","Cliente","Tipo","Valor R$","Data"};
        conPesProd.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conPesProd.executaSQL(SQL);
        
        try {
            conPesProd.rs.first();
           
            //JOptionPane.showMessageDialog(rootPane, conOsPesquisa.rs.getString("id"));
            do{
                dados.add(new Object[]{conPesProd.rs.getInt("codigo"), conPesProd.rs.getString("cliente"), conPesProd.rs.getString("tipo"),String.valueOf(formatoNum.format(conPesProd.rs.getDouble("valorvenda"))), df.format(conPesProd.rs.getDate("data"))});
            }while(conPesProd.rs.next());
            
        } catch (SQLException ex) {
            //JOptionPane.showMessageDialog(rootPane,"Erro ao Obter Dados. \n Informação digitada não encontrada.");
        }
        
        DefaultTableCellRenderer cellRenderD = new DefaultTableCellRenderer();
	cellRenderD.setHorizontalAlignment(SwingConstants.RIGHT);
        
        DefaultTableCellRenderer cellRenderC = new DefaultTableCellRenderer();
	cellRenderC.setHorizontalAlignment(SwingConstants.CENTER);
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTablePesquisaOS.setModel(modelo);
        jTablePesquisaOS.getColumnModel().getColumn(0).setPreferredWidth(60);
        jTablePesquisaOS.getColumnModel().getColumn(0).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(0).setCellRenderer(cellRenderC);
        jTablePesquisaOS.getColumnModel().getColumn(1).setPreferredWidth(360);
        jTablePesquisaOS.getColumnModel().getColumn(1).setResizable(false);
        
        jTablePesquisaOS.getColumnModel().getColumn(2).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(2).setPreferredWidth(78);
        jTablePesquisaOS.getColumnModel().getColumn(2).setCellRenderer(cellRenderC);
        
        jTablePesquisaOS.getColumnModel().getColumn(3).setPreferredWidth(95);
        jTablePesquisaOS.getColumnModel().getColumn(3).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(3).setCellRenderer(cellRenderD);
        jTablePesquisaOS.getColumnModel().getColumn(4).setPreferredWidth(80);
        jTablePesquisaOS.getColumnModel().getColumn(4).setCellRenderer(cellRenderC);
        jTablePesquisaOS.getColumnModel().getColumn(4).setResizable(false);
        jTablePesquisaOS.getTableHeader().setReorderingAllowed(false);
        jTablePesquisaOS.setAutoResizeMode(jTablePesquisaOS.AUTO_RESIZE_OFF);
        jTablePesquisaOS.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conPesProd.desconecta();
              
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBoxTipoPesquisa = new javax.swing.JComboBox();
        jButtonPesquisar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisaOS = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldCampoPesquisa = new controle.ClassUpperField();
        jButtonSair = new javax.swing.JButton();
        jButtonNovaVenda = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setTitle("Vendas Efetuadas");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Pesquisar por:");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 10, 200, 16);

        jComboBoxTipoPesquisa.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Código", "Cliente", "Data", "Todas" }));
        jComboBoxTipoPesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoPesquisaActionPerformed(evt);
            }
        });
        jPanelFundo.add(jComboBoxTipoPesquisa);
        jComboBoxTipoPesquisa.setBounds(10, 30, 200, 30);

        jButtonPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/Search44Resultado.png"))); // NOI18N
        jButtonPesquisar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));
        jButtonPesquisar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesquisar);
        jButtonPesquisar.setBounds(660, 30, 40, 30);

        jTablePesquisaOS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTablePesquisaOS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePesquisaOSMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablePesquisaOS);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 70, 690, 370);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Digite aqui os dados a pesquisar:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(210, 10, 390, 16);

        jTextFieldCampoPesquisa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldCampoPesquisaKeyReleased(evt);
            }
        });
        jPanelFundo.add(jTextFieldCampoPesquisa);
        jTextFieldCampoPesquisa.setBounds(210, 30, 450, 30);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(6, 6, 710, 449);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(630, 470, 90, 40);

        jButtonNovaVenda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/add.png"))); // NOI18N
        jButtonNovaVenda.setText("Novo");
        jButtonNovaVenda.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonNovaVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovaVendaActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonNovaVenda);
        jButtonNovaVenda.setBounds(450, 470, 90, 40);

        jButtonExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jButtonExcluir.setText("Excluir");
        jButtonExcluir.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonExcluir);
        jButtonExcluir.setBounds(540, 470, 90, 40);

        setBounds(0, 0, 729, 548);
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxTipoPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoPesquisaActionPerformed
        jTextFieldCampoPesquisa.grabFocus();
    }//GEN-LAST:event_jComboBoxTipoPesquisaActionPerformed

    private void jButtonPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarActionPerformed
        //        Cód.          = 0 Código, Cliente, Data, Todas
        //        Cliente       = 1
        //        Data          = 2
        //        Funcionario   = 3
        //        Todas         = 4

        int CampoEscolhido = (jComboBoxTipoPesquisa.getSelectedIndex());

        String DadosParaPesquisar = jTextFieldCampoPesquisa.getText();

        //preencherTablePesquisaOS("select os.id, clientes.nome_cliente, os.dt_abertura, funcionarios.nome_funcionario, os.status, os.total_os from os join clientes on clientes.id_cliente=os.id_cliente  join funcionarios on funcionarios.id_funcionario=os.id_funcionario where nome_cliente='%"+DadosParaPesquisar+"%'");

        if (CampoEscolhido == 0 ){
            if ("".equals(jTextFieldCampoPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite o codigo da Venda para pesquisar.");
            } else {
                int idCliente = Integer.parseInt(DadosParaPesquisar);
                preencherTablePesquisaOS("select vendas.codigo, vendas.valorvenda, clientes.nome as cliente, vendas.tipo, vendas.data from (vendas inner join clientes on clientes.codigo=vendas.cliente) where vendas.codigo='"+idCliente+"'");
            }
        }

        if (CampoEscolhido == 1){
            preencherTablePesquisaOS("select vendas.codigo, vendas.valorvenda, clientes.nome as cliente, vendas.tipo, vendas.data from (vendas inner join clientes on clientes.codigo=vendas.cliente) where clientes.nome like '"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 2){
            preencherTablePesquisaOS("select vendas.codigo, vendas.valorvenda, clientes.nome as cliente, vendas.tipo, vendas.data from (vendas inner join clientes on clientes.codigo=vendas.cliente) where vendas.data like '"+DadosParaPesquisar+"%'");
        }
        
        if (CampoEscolhido == 3){
            preencherTablePesquisaOS("select vendas.codigo, vendas.valorvenda, clientes.nome as cliente, vendas.tipo, vendas.data from (vendas inner join clientes on clientes.codigo=vendas.cliente) order by vendas.data desc");
        }
        else{
            //JOptionPane.showMessageDialog(rootPane, "Erro ao Pesquisar dados!");
        }
    }//GEN-LAST:event_jButtonPesquisarActionPerformed

    private void jTablePesquisaOSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePesquisaOSMouseClicked

    }//GEN-LAST:event_jTablePesquisaOSMouseClicked

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
        dispose();
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonNovaVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovaVendaActionPerformed
    FormVendas FrmVendas = new FormVendas();
    FormPrincipal.AbreNovaJanelaS(FrmVendas);
    FrmVendas.setVisible(true);
    dispose();
    }//GEN-LAST:event_jButtonNovaVendaActionPerformed

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed

    if (FormPrincipal.UsuarioPermissao.equals("2")){
        ExcluiVenda();
    }else{
        JOptionPane.showMessageDialog(rootPane, "Você não possui permissão suficiente para executar essa ação.");
    }
       
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jTextFieldCampoPesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldCampoPesquisaKeyReleased
        
        
        int CampoEscolhido = (jComboBoxTipoPesquisa.getSelectedIndex());

        String DadosParaPesquisar = jTextFieldCampoPesquisa.getText();

        //preencherTablePesquisaOS("select os.id, clientes.nome_cliente, os.dt_abertura, funcionarios.nome_funcionario, os.status, os.total_os from os join clientes on clientes.id_cliente=os.id_cliente  join funcionarios on funcionarios.id_funcionario=os.id_funcionario where nome_cliente='%"+DadosParaPesquisar+"%'");

        if (CampoEscolhido == 0 ){
            if ("".equals(jTextFieldCampoPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite o codigo da Venda para pesquisar.");
            } else {
                int idCliente = Integer.parseInt(DadosParaPesquisar);
                preencherTablePesquisaOS("select vendas.codigo, vendas.valorvenda, clientes.nome as cliente, vendas.tipo, vendas.data from (vendas inner join clientes on clientes.codigo=vendas.cliente) where vendas.codigo='"+idCliente+"'");
            }
        }

        if (CampoEscolhido == 1){
            preencherTablePesquisaOS("select vendas.codigo, vendas.valorvenda, clientes.nome as cliente, vendas.tipo, vendas.data from (vendas inner join clientes on clientes.codigo=vendas.cliente) where clientes.nome like '"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 2){
            preencherTablePesquisaOS("select vendas.codigo, vendas.valorvenda, clientes.nome as cliente, vendas.tipo, vendas.data from (vendas inner join clientes on clientes.codigo=vendas.cliente) where vendas.data like '"+DadosParaPesquisar+"%'");
        }
        
        if (CampoEscolhido == 3){
            preencherTablePesquisaOS("select vendas.codigo, vendas.valorvenda, clientes.nome as cliente, vendas.tipo, vendas.data from (vendas inner join clientes on clientes.codigo=vendas.cliente) order by vendas.data desc");
        }
        else{
            //JOptionPane.showMessageDialog(rootPane, "Erro ao Pesquisar dados!");
        }
        
    }//GEN-LAST:event_jTextFieldCampoPesquisaKeyReleased
    
    public void ExcluiVenda(){
        int is = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente Excluir?","Confirmando Exclusão", JOptionPane.YES_NO_OPTION);
        if(is == JOptionPane.YES_OPTION) {
        
        conPesProd.conecta();
        
        int codVendaSel = jTablePesquisaOS.getSelectedRow();
        
        if (codVendaSel==(-1)){
            
            JOptionPane.showMessageDialog(rootPane, "Por favor, selecione um Item cadastrado.");
        
        } else {String codProdx = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
            
            int cdVenda = Integer.parseInt(codProdx);
            
            try {
//                JOptionPane.showMessageDialog(rootPane, cdVenda);
                conPesProd.executaSQL("select * from contas_receber where origem='VENDA' and codorigem='"+cdVenda+"'");
                if (conPesProd.rs.first()){
                do{
                    int CodConta = conPesProd.rs.getInt("codigo");
                    PreparedStatement pst = conPesProd.conn.prepareStatement("delete  from contas_receber_historico where conta=?");
                    pst.setInt(1, CodConta);
                    pst.execute();
                
                }while(conPesProd.rs.next());
                }
                
            try {
            PreparedStatement pst = conPesProd.conn.prepareStatement("delete  from contas_receber where origem='VENDA' and codorigem=?");
            pst.setInt(1, cdVenda);
            pst.execute();
            pst = conPesProd.conn.prepareStatement("delete  from vendas_desc where venda=?");
            pst.setInt(1, cdVenda);
            pst.execute();
            pst = conPesProd.conn.prepareStatement("delete  from vendas where codigo=?");
            pst.setInt(1, cdVenda);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Erro ao Excluir dados\n Erro código: "+ex);
            }
            } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Erro ao Excluir dados\n Erro código: "+ex);
            }
            
        }
        preencherTablePesquisaOS("select vendas.codigo, vendas.valorvenda, clientes.nome as cliente, vendas.tipo, vendas.data from (vendas inner join clientes on clientes.codigo=vendas.cliente) order by vendas.data desc");
        } 
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonNovaVenda;
    private javax.swing.JButton jButtonPesquisar;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JComboBox jComboBoxTipoPesquisa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisaOS;
    private controle.ClassUpperField jTextFieldCampoPesquisa;
    // End of variables declaration//GEN-END:variables
}
