/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.Conf;
import controle.ControleAbreForms;
import controle.ControleRelatorios;
import controle.ControleTarefas;
import controle.ExecutaTarefaAgendaAt;
import controle.formata_janela_principal;
import controle.obter_arquivo_conf;
import static java.awt.Frame.MAXIMIZED_BOTH;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author ProgXBERGUE
 */
public class FormPrincipal extends javax.swing.JFrame {
        
        ConectaBanco conPrc = new ConectaBanco();
        ExecutaTarefaAgendaAt ExeTA = new ExecutaTarefaAgendaAt();
        ControleAbreForms ctrlAForm = new ControleAbreForms();
        ControleRelatorios ctrlRel = new ControleRelatorios();
        ControleTarefas     ctrlTask = new ControleTarefas();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        int TamTelaAltura, TamTelaLargura;
        String Usuario, UsuTipo, caminhoDb, caminho;
        String DataHoje, AgoraHora;
        long ChaveBloqueio, ChaveDesBloqueio;
        public static String User, UserType;
        public static String NomePesqCliente, NomePesqProdutos;
        public static int CodigoPesqCliente, CodigoPesqProdutos;
        public static String UsuarioLogado, SenhaULogado, UsuarioPermissao;
        public static String NomeEmpresa;
        public static int RetornoNotAgenda = 0;
        
        //Informar dados para abertura de Clientes e Produtos quando pesquisados para adicionar aos forms
        public String NomeCliente, NomeProduto;
        public int CodCliente, CodProduto, Estoque;
        public double PrecoUnit; 
        public  int RetornoCadClintes = 0;
        
        Date DataInicial = null;
        Date DataFinal = null;
       
        formata_janela_principal visual_jp = new formata_janela_principal();
        obter_arquivo_conf o_ac = new obter_arquivo_conf();
       
        
        
    
    /**
     * Creates new form FormPrincipal
     */
    public FormPrincipal() {
        visual_jp.aplicavisual();
        initComponents();
        this.setExtendedState(MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        visual_jp.RedimensionaAreaTrabalho(AreaDeTrabalhoPrincipal);
        visual_jp.RedimensionaBarraFerramentas(BarraFerramentas);
        RodaTarefa1M();
        try {
        VerificaDadosEmpresa();
        } catch (IOException ex) {
                Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void RodaTarefa1M(){
        conPrc.conecta();
        int TimerG = 0;
        try {
            conPrc.executaSQL("select * from config_agenda where codigo=1");
            conPrc.rs.first();
            TimerG = conPrc.rs.getInt("internot");
        } catch (SQLException ex) {
            Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        conPrc.desconecta();
        long TEMPO = TimerG; // chama o método a cada tempo definido na configuração da agenda;
        Timer timer = null;
        if (timer == null) {
            timer = new Timer();
            TimerTask tarefa = new TimerTask() {
                public void run() {
                    try {
                       //JOptionPane.showMessageDialog(null, "Verifique a Agenda!!!");
                        ExeTA.Iniciar();
                        if(ExeTA.FlagAgenda == 1){
                            FormNotificacaoAgenda FrmNotAg = new FormNotificacaoAgenda();
                            FrmNotAg.oClip.stop();
                            AbreNotificacaoAgenda(FrmNotAg, 1);
                        }else {
//                            RemoveAgendadaTela();
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            };
            timer.scheduleAtFixedRate(tarefa, TEMPO, TEMPO);
        }
    }
    
    public static void AbreNotificacaoAgenda(JInternalFrame jif, Integer Vji){
                if (RetornoNotAgenda == 0){
                int lDesk = AreaDeTrabalhoPrincipal.getWidth();  
                int aDesk = AreaDeTrabalhoPrincipal.getHeight();  
                int lIFrame = jif.getWidth();  
                int aIFrame = jif.getHeight();  
                jif.setLocation((lDesk - 10) - lIFrame , 10);
                AreaDeTrabalhoPrincipal.add(jif); //adiciona na tela
                jif.setVisible(true); // seta visivel
                }else{
//                   JOptionPane.showMessageDialog(null, "Notificação da agenda já está aberta!");
                }
    }
    
    public void ObterUsuarioSenha(String Nome, String Senha, String Permissao){
        UsuarioLogado = Nome;
        SenhaULogado = Senha;
        UsuarioPermissao = Permissao;
        visual_jp.StatusBar(this, Nome, NomeEmpresa);//chama a StatusBar e atrinui o nome de usuário e nome da empresa.
    }
    
    public void VerificaDadosEmpresa() throws IOException{
        conPrc.conecta();
            try {
                //Verifica Nome Fantasia
                conPrc.executaSQL("select * from dados_empresa where codigo='1'");
                conPrc.rs.first();
                NomeEmpresa = conPrc.rs.getString("nomefantasia");
                String Endereco = conPrc.rs.getString("endereco");
                if (NomeEmpresa==null || Endereco==null){
                    
                FormDadosEmpresa FrmDE= new FormDadosEmpresa();
                }
            } catch (SQLException ex) {
            }
        conPrc.desconecta();
    }
    
    public static void AbreNovaJanelaS(JInternalFrame jif){
                JDesktopPane desktop = AreaDeTrabalhoPrincipal;
                int lDesk = desktop.getWidth();  
                int aDesk = desktop.getHeight();  
                int lIFrame = jif.getWidth();  
                int aIFrame = jif.getHeight();  
                jif.setLocation(lDesk / 2 - lIFrame / 2, aDesk / 2 - (aIFrame / 2));
                desktop.add(jif); //adiciona na tela
                jif.setVisible(true); // seta visivel
    }
    
    public void AbreNovaJanela(JInternalFrame jif){
        visual_jp.AbreNovaJanela(jif, AreaDeTrabalhoPrincipal);
    }
    
    public void Lerarquivo(){

        Conf cfg = new Conf();
        Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
        caminho = String.valueOf(caminhoTXT+"\\");
        
            try {
                cfg.ConfigLido();
                String c = "jdbc:ucanaccess://"+caminho+"sislpbasicdb.mdb";
                caminhoDb = c;
            } catch (IOException ex) {
//                Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
        
    }
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jSeparator2 = new javax.swing.JSeparator();
        BarraFerramentas = new javax.swing.JToolBar();
        jbtbfclientes = new javax.swing.JButton();
        jbtbffornecedores = new javax.swing.JButton();
        jbtbfprodutos = new javax.swing.JButton();
        jbtbfvendas = new javax.swing.JButton();
        jbtbfrecibo = new javax.swing.JButton();
        jbtbfcontasreceber = new javax.swing.JButton();
        jbtbfcontrolecaixa = new javax.swing.JButton();
        jbtbfcontasrecebidas = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jbtbfcalculadora = new javax.swing.JButton();
        jSeparator4 = new javax.swing.JToolBar.Separator();
        AreaDeTrabalhoPrincipal = new javax.swing.JDesktopPane();
        BarraMenu = new javax.swing.JMenuBar();
        Cadastros = new javax.swing.JMenu();
        Cadastros_Clientes = new javax.swing.JMenuItem();
        Cadastros_Fornecedores = new javax.swing.JMenuItem();
        jMenuItem6 = new javax.swing.JMenuItem();
        Cadastros_Produtos = new javax.swing.JMenuItem();
        jMenuItem3 = new javax.swing.JMenuItem();
        jMenuItem13 = new javax.swing.JMenuItem();
        Movimentos = new javax.swing.JMenu();
        Movimentos_Cadastros = new javax.swing.JMenu();
        Movimentos_Cadastros_Clientes = new javax.swing.JMenuItem();
        Movimentos_Cadastros_Fornecedores = new javax.swing.JMenuItem();
        Movimentos_Cadastros_Produtos = new javax.swing.JMenuItem();
        jMenu1 = new javax.swing.JMenu();
        jMenuItem7 = new javax.swing.JMenuItem();
        jMenuItem8 = new javax.swing.JMenuItem();
        Movimentos_Recibo = new javax.swing.JMenu();
        Movimentos_Recibo_Recibo = new javax.swing.JMenuItem();
        Movimentos_Recibo_Recibo_Emitidos = new javax.swing.JMenuItem();
        jMenuItem11 = new javax.swing.JMenuItem();
        jMenuItem2 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        jMenuItem4 = new javax.swing.JMenuItem();
        jMenuItem12 = new javax.swing.JMenuItem();
        jMenuItem9 = new javax.swing.JMenuItem();
        jMenuItem1 = new javax.swing.JMenuItem();
        Finaceiro = new javax.swing.JMenu();
        Financeiro_Vendas = new javax.swing.JMenu();
        jMenuItem10 = new javax.swing.JMenuItem();
        Financeiro_Vendas_GeraCarnes = new javax.swing.JMenuItem();
        Financeiro_Vendas_Vendas = new javax.swing.JMenuItem();
        Financeiro_Vendas_VendasCliente = new javax.swing.JMenuItem();
        Financeiro_Vendas_ClientesData = new javax.swing.JMenuItem();
        Financeiro_Vendas_Data = new javax.swing.JMenuItem();
        Financeiro_Fluxo_de_Caixa = new javax.swing.JMenu();
        Fluxo_de_Caixa_Periodo = new javax.swing.JMenuItem();
        Fluxo_de_Caixa_Periodo_Referencia = new javax.swing.JMenuItem();
        Financeiro_Relatorios = new javax.swing.JMenu();
        Financeiro_Relatorios_Clientes = new javax.swing.JMenu();
        Financeiro_Relatorios_Clientes_C = new javax.swing.JMenuItem();
        Financeiro_Relatorios_Clientes_CN = new javax.swing.JMenuItem();
        Financeiro_Produtos = new javax.swing.JMenu();
        Financeiro_Produtos_Todos = new javax.swing.JMenuItem();
        Financeiro_Produtos_Fabricantes = new javax.swing.JMenuItem();
        Financeiro_Produtos_Fornecedor = new javax.swing.JMenuItem();
        Financeiro_Produtos_Nome = new javax.swing.JMenuItem();
        Financeiro_Relatorios_Fornecedores = new javax.swing.JMenu();
        Financeiro_Relatorios_Fornecedores_FT = new javax.swing.JMenuItem();
        Financeiro_Relatorios_Fornecedores_FN = new javax.swing.JMenuItem();
        Financeiro_Relatorios_Fabricantes_Marcas = new javax.swing.JMenu();
        Financeiro_Relatorios_Fabricantes_Marcas_FT = new javax.swing.JMenuItem();
        Financeiro_Contas_a_Receber = new javax.swing.JMenu();
        Financeiro_Contas_a_Receber_Todas = new javax.swing.JMenuItem();
        Financeiro_Contas_a_Receber_Cliente = new javax.swing.JMenuItem();
        Financeiro_Contas_a_Receber_Data = new javax.swing.JMenuItem();
        Financeiro_Contas_Recebidas = new javax.swing.JMenu();
        Financeiro_Contas_Recebidas_Todas = new javax.swing.JMenuItem();
        Financeiro_Contas_Recebidas_Data = new javax.swing.JMenuItem();
        Financeiro_ReimprimirComprovantes = new javax.swing.JMenu();
        Financeiro_ReimprimirComprovantes_Orcmentos = new javax.swing.JMenuItem();
        Financeiro_ReimprimirComprovantes_OSAprazo = new javax.swing.JMenuItem();
        Financeiro_ReimprimirComprovantes_VAvista = new javax.swing.JMenuItem();
        Financeiro_ReimprimirComprovantes_APr = new javax.swing.JMenuItem();
        Financeiro_ReimprimirComprovantes_PagConta = new javax.swing.JMenuItem();
        SislpBasicMenu = new javax.swing.JMenu();
        SislpBasicMenu_Backup = new javax.swing.JMenuItem();
        SislpBasicMenu_Calc = new javax.swing.JMenuItem();
        SislpBasicMenu_Config = new javax.swing.JMenuItem();
        SislpBasicMenu_IE = new javax.swing.JMenuItem();
        SislpBasicMenu_Users = new javax.swing.JMenuItem();
        SislpBasicMenu_Sobre = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        SislpBasicMenu_Sair = new javax.swing.JMenuItem();
        jMenu2 = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("SisLpBasicPlus - Sistema de Cadastro e Vendas.");
        addWindowStateListener(new java.awt.event.WindowStateListener() {
            public void windowStateChanged(java.awt.event.WindowEvent evt) {
                formWindowStateChanged(evt);
            }
        });
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                ExecutarAoSair(evt);
            }
        });
        getContentPane().setLayout(null);

        BarraFerramentas.setOrientation(javax.swing.SwingConstants.VERTICAL);
        BarraFerramentas.setRollover(true);
        BarraFerramentas.setPreferredSize(new java.awt.Dimension(69, 500));

        jbtbfclientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/48x48/Community HelpResultado.png"))); // NOI18N
        jbtbfclientes.setToolTipText("Clientes Cadastrados");
        jbtbfclientes.setFocusable(false);
        jbtbfclientes.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jbtbfclientes.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbtbfclientes.setMaximumSize(new java.awt.Dimension(90, 90));
        jbtbfclientes.setPreferredSize(new java.awt.Dimension(65, 40));
        jbtbfclientes.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jbtbfclientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtbfclientesActionPerformed(evt);
            }
        });
        BarraFerramentas.add(jbtbfclientes);

        jbtbffornecedores.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/48x48/Client 3.png"))); // NOI18N
        jbtbffornecedores.setToolTipText("Fornecedores Cadastrados");
        jbtbffornecedores.setFocusable(false);
        jbtbffornecedores.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jbtbffornecedores.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbtbffornecedores.setMaximumSize(new java.awt.Dimension(90, 90));
        jbtbffornecedores.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jbtbffornecedores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtbffornecedoresActionPerformed(evt);
            }
        });
        BarraFerramentas.add(jbtbffornecedores);

        jbtbfprodutos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/48x48/blockdeviceResultado.png"))); // NOI18N
        jbtbfprodutos.setToolTipText("Produtos Cadastrados");
        jbtbfprodutos.setFocusable(false);
        jbtbfprodutos.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jbtbfprodutos.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbtbfprodutos.setMaximumSize(new java.awt.Dimension(90, 90));
        jbtbfprodutos.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jbtbfprodutos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtbfprodutosActionPerformed(evt);
            }
        });
        BarraFerramentas.add(jbtbfprodutos);

        jbtbfvendas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/48x48/shopping_cart_accept.png"))); // NOI18N
        jbtbfvendas.setToolTipText("Vendas");
        jbtbfvendas.setFocusable(false);
        jbtbfvendas.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jbtbfvendas.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbtbfvendas.setMaximumSize(new java.awt.Dimension(90, 90));
        jbtbfvendas.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jbtbfvendas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtbfvendasActionPerformed(evt);
            }
        });
        BarraFerramentas.add(jbtbfvendas);

        jbtbfrecibo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/48x48/Crystal_mimetypes_icon_document_1196.jpgResultado.png"))); // NOI18N
        jbtbfrecibo.setToolTipText("Recibos");
        jbtbfrecibo.setFocusable(false);
        jbtbfrecibo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jbtbfrecibo.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbtbfrecibo.setMaximumSize(new java.awt.Dimension(90, 90));
        jbtbfrecibo.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jbtbfrecibo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtbfreciboActionPerformed(evt);
            }
        });
        BarraFerramentas.add(jbtbfrecibo);

        jbtbfcontasreceber.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/48x48/PurseResultado.png"))); // NOI18N
        jbtbfcontasreceber.setToolTipText("Contas a Receber");
        jbtbfcontasreceber.setFocusable(false);
        jbtbfcontasreceber.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jbtbfcontasreceber.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbtbfcontasreceber.setMaximumSize(new java.awt.Dimension(90, 90));
        jbtbfcontasreceber.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jbtbfcontasreceber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtbfcontasreceberActionPerformed(evt);
            }
        });
        BarraFerramentas.add(jbtbfcontasreceber);

        jbtbfcontrolecaixa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/48x48/Money_CalculatorResultado.png"))); // NOI18N
        jbtbfcontrolecaixa.setToolTipText("Controle de Caixa");
        jbtbfcontrolecaixa.setFocusable(false);
        jbtbfcontrolecaixa.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jbtbfcontrolecaixa.setMaximumSize(new java.awt.Dimension(90, 90));
        jbtbfcontrolecaixa.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jbtbfcontrolecaixa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtbfcontrolecaixaActionPerformed(evt);
            }
        });
        BarraFerramentas.add(jbtbfcontrolecaixa);

        jbtbfcontasrecebidas.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/48x48/bundle-256x256x32bResultado.png"))); // NOI18N
        jbtbfcontasrecebidas.setToolTipText("Contas Recebidas");
        jbtbfcontasrecebidas.setFocusable(false);
        jbtbfcontasrecebidas.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jbtbfcontasrecebidas.setMaximumSize(new java.awt.Dimension(90, 90));
        jbtbfcontasrecebidas.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jbtbfcontasrecebidas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtbfcontasrecebidasActionPerformed(evt);
            }
        });
        BarraFerramentas.add(jbtbfcontasrecebidas);

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/48x48/calResultado.png"))); // NOI18N
        jButton1.setToolTipText("Agenda");
        jButton1.setFocusable(false);
        jButton1.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jButton1.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButton1.setMaximumSize(new java.awt.Dimension(90, 90));
        jButton1.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        BarraFerramentas.add(jButton1);

        jbtbfcalculadora.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/48x48/calculator8Resultado.png"))); // NOI18N
        jbtbfcalculadora.setToolTipText("Calculadora");
        jbtbfcalculadora.setFocusable(false);
        jbtbfcalculadora.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jbtbfcalculadora.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbtbfcalculadora.setMaximumSize(new java.awt.Dimension(90, 90));
        jbtbfcalculadora.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jbtbfcalculadora.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtbfcalculadoraActionPerformed(evt);
            }
        });
        BarraFerramentas.add(jbtbfcalculadora);
        BarraFerramentas.add(jSeparator4);

        getContentPane().add(BarraFerramentas);
        BarraFerramentas.setBounds(0, 0, 90, 650);

        javax.swing.GroupLayout AreaDeTrabalhoPrincipalLayout = new javax.swing.GroupLayout(AreaDeTrabalhoPrincipal);
        AreaDeTrabalhoPrincipal.setLayout(AreaDeTrabalhoPrincipalLayout);
        AreaDeTrabalhoPrincipalLayout.setHorizontalGroup(
            AreaDeTrabalhoPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 920, Short.MAX_VALUE)
        );
        AreaDeTrabalhoPrincipalLayout.setVerticalGroup(
            AreaDeTrabalhoPrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 650, Short.MAX_VALUE)
        );

        getContentPane().add(AreaDeTrabalhoPrincipal);
        AreaDeTrabalhoPrincipal.setBounds(90, 0, 920, 650);

        BarraMenu.setMaximumSize(new java.awt.Dimension(600, 32768));
        BarraMenu.setMinimumSize(new java.awt.Dimension(800, 39));
        BarraMenu.setPreferredSize(new java.awt.Dimension(500, 48));

        Cadastros.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/00_32.png"))); // NOI18N
        Cadastros.setText("Cadastros");

        Cadastros_Clientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/01_32.png"))); // NOI18N
        Cadastros_Clientes.setText("Clientes");
        Cadastros_Clientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cadastros_ClientesActionPerformed(evt);
            }
        });
        Cadastros.add(Cadastros_Clientes);

        Cadastros_Fornecedores.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/02_32.png"))); // NOI18N
        Cadastros_Fornecedores.setText("Fornecedores");
        Cadastros_Fornecedores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cadastros_FornecedoresActionPerformed(evt);
            }
        });
        Cadastros.add(Cadastros_Fornecedores);

        jMenuItem6.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/03_32.png"))); // NOI18N
        jMenuItem6.setText("Fabricantes");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        Cadastros.add(jMenuItem6);

        Cadastros_Produtos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/04_32.png"))); // NOI18N
        Cadastros_Produtos.setText("Produtos");
        Cadastros_Produtos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Cadastros_ProdutosActionPerformed(evt);
            }
        });
        Cadastros.add(Cadastros_Produtos);

        jMenuItem3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/06_32.png"))); // NOI18N
        jMenuItem3.setText("Referências do Fluxo de Caixa");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        Cadastros.add(jMenuItem3);

        jMenuItem13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/07_32.png"))); // NOI18N
        jMenuItem13.setText("Horários da Agenda");
        jMenuItem13.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem13ActionPerformed(evt);
            }
        });
        Cadastros.add(jMenuItem13);

        BarraMenu.add(Cadastros);

        Movimentos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/21_32.png"))); // NOI18N
        Movimentos.setText("Movimentos");

        Movimentos_Cadastros.setText("Cadastrados");

        Movimentos_Cadastros_Clientes.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F3, 0));
        Movimentos_Cadastros_Clientes.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/22_01_32_1.png"))); // NOI18N
        Movimentos_Cadastros_Clientes.setText("Clientes");
        Movimentos_Cadastros_Clientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Movimentos_Cadastros_ClientesActionPerformed(evt);
            }
        });
        Movimentos_Cadastros.add(Movimentos_Cadastros_Clientes);

        Movimentos_Cadastros_Fornecedores.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F4, 0));
        Movimentos_Cadastros_Fornecedores.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/22_02_32_1.png"))); // NOI18N
        Movimentos_Cadastros_Fornecedores.setText("Fornecedores");
        Movimentos_Cadastros_Fornecedores.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Movimentos_Cadastros_FornecedoresActionPerformed(evt);
            }
        });
        Movimentos_Cadastros.add(Movimentos_Cadastros_Fornecedores);

        Movimentos_Cadastros_Produtos.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F5, 0));
        Movimentos_Cadastros_Produtos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/22_03_32_1.png"))); // NOI18N
        Movimentos_Cadastros_Produtos.setText("Produtos");
        Movimentos_Cadastros_Produtos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Movimentos_Cadastros_ProdutosActionPerformed(evt);
            }
        });
        Movimentos_Cadastros.add(Movimentos_Cadastros_Produtos);

        Movimentos.add(Movimentos_Cadastros);

        jMenu1.setText("Pedidos");

        jMenuItem7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/40_32_25.png"))); // NOI18N
        jMenuItem7.setText("Lista de Pedidos Realizados");
        jMenuItem7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem7ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem7);

        jMenuItem8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/41_32_25.png"))); // NOI18N
        jMenuItem8.setText("Gerar Lista de Pedidos");
        jMenuItem8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem8ActionPerformed(evt);
            }
        });
        jMenu1.add(jMenuItem8);

        Movimentos.add(jMenu1);

        Movimentos_Recibo.setText("Recibo");

        Movimentos_Recibo_Recibo.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F7, 0));
        Movimentos_Recibo_Recibo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/24_02_32_25.png"))); // NOI18N
        Movimentos_Recibo_Recibo.setText("Gerar Recibo");
        Movimentos_Recibo_Recibo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Movimentos_Recibo_ReciboActionPerformed(evt);
            }
        });
        Movimentos_Recibo.add(Movimentos_Recibo_Recibo);

        Movimentos_Recibo_Recibo_Emitidos.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/24_32_25.png"))); // NOI18N
        Movimentos_Recibo_Recibo_Emitidos.setText("Recibos Emitidos");
        Movimentos_Recibo_Recibo_Emitidos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Movimentos_Recibo_Recibo_EmitidosActionPerformed(evt);
            }
        });
        Movimentos_Recibo.add(Movimentos_Recibo_Recibo_Emitidos);

        Movimentos.add(Movimentos_Recibo);

        jMenuItem11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/27_32.png"))); // NOI18N
        jMenuItem11.setText("Agenda");
        jMenuItem11.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem11ActionPerformed(evt);
            }
        });
        Movimentos.add(jMenuItem11);

        jMenuItem2.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F8, 0));
        jMenuItem2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/PurseResultado.png"))); // NOI18N
        jMenuItem2.setText("Contas à Receber");
        jMenuItem2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem2ActionPerformed(evt);
            }
        });
        Movimentos.add(jMenuItem2);

        jMenuItem5.setText("Contas Recebidas");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        Movimentos.add(jMenuItem5);

        jMenuItem4.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F9, 0));
        jMenuItem4.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/25_32.png"))); // NOI18N
        jMenuItem4.setText("Controle de Caixa");
        jMenuItem4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem4ActionPerformed(evt);
            }
        });
        Movimentos.add(jMenuItem4);

        jMenuItem12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/28_32.png"))); // NOI18N
        jMenuItem12.setText("Orçamento");
        jMenuItem12.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem12ActionPerformed(evt);
            }
        });
        Movimentos.add(jMenuItem12);

        jMenuItem9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/21_32.png"))); // NOI18N
        jMenuItem9.setText("Ordem de Serviço - OS");
        jMenuItem9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem9ActionPerformed(evt);
            }
        });
        Movimentos.add(jMenuItem9);

        jMenuItem1.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F6, 0));
        jMenuItem1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/23_32.png"))); // NOI18N
        jMenuItem1.setText("Venda");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        Movimentos.add(jMenuItem1);

        BarraMenu.add(Movimentos);

        Finaceiro.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/40_32.png"))); // NOI18N
        Finaceiro.setText("Financeiro");

        Financeiro_Vendas.setText("Vendas");

        jMenuItem10.setText("Contrato de Venda");
        jMenuItem10.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem10ActionPerformed(evt);
            }
        });
        Financeiro_Vendas.add(jMenuItem10);

        Financeiro_Vendas_GeraCarnes.setText("Gerar Carnês de Vendas");
        Financeiro_Vendas_GeraCarnes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Vendas_GeraCarnesActionPerformed(evt);
            }
        });
        Financeiro_Vendas.add(Financeiro_Vendas_GeraCarnes);

        Financeiro_Vendas_Vendas.setText("Vendas");
        Financeiro_Vendas_Vendas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Vendas_VendasActionPerformed(evt);
            }
        });
        Financeiro_Vendas.add(Financeiro_Vendas_Vendas);

        Financeiro_Vendas_VendasCliente.setText("Vendas por Cliente");
        Financeiro_Vendas_VendasCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Vendas_VendasClienteActionPerformed(evt);
            }
        });
        Financeiro_Vendas.add(Financeiro_Vendas_VendasCliente);

        Financeiro_Vendas_ClientesData.setText("Vendas por Cliente e Data");
        Financeiro_Vendas_ClientesData.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Vendas_ClientesDataActionPerformed(evt);
            }
        });
        Financeiro_Vendas.add(Financeiro_Vendas_ClientesData);

        Financeiro_Vendas_Data.setText("Vendas por Data");
        Financeiro_Vendas_Data.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Vendas_DataActionPerformed(evt);
            }
        });
        Financeiro_Vendas.add(Financeiro_Vendas_Data);

        Finaceiro.add(Financeiro_Vendas);

        Financeiro_Fluxo_de_Caixa.setText("Fluxo de Caixa");

        Fluxo_de_Caixa_Periodo.setText("Caixa por Período");
        Fluxo_de_Caixa_Periodo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Fluxo_de_Caixa_PeriodoActionPerformed(evt);
            }
        });
        Financeiro_Fluxo_de_Caixa.add(Fluxo_de_Caixa_Periodo);

        Fluxo_de_Caixa_Periodo_Referencia.setText("Caixa por Período e Referência");
        Fluxo_de_Caixa_Periodo_Referencia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Fluxo_de_Caixa_Periodo_ReferenciaActionPerformed(evt);
            }
        });
        Financeiro_Fluxo_de_Caixa.add(Fluxo_de_Caixa_Periodo_Referencia);

        Finaceiro.add(Financeiro_Fluxo_de_Caixa);

        Financeiro_Relatorios.setText("Relatorios");

        Financeiro_Relatorios_Clientes.setText("Clientes");

        Financeiro_Relatorios_Clientes_C.setText("Clientes");
        Financeiro_Relatorios_Clientes_C.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Relatorios_Clientes_CActionPerformed(evt);
            }
        });
        Financeiro_Relatorios_Clientes.add(Financeiro_Relatorios_Clientes_C);

        Financeiro_Relatorios_Clientes_CN.setText("Clientes por Nome");
        Financeiro_Relatorios_Clientes_CN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Relatorios_Clientes_CNActionPerformed(evt);
            }
        });
        Financeiro_Relatorios_Clientes.add(Financeiro_Relatorios_Clientes_CN);

        Financeiro_Relatorios.add(Financeiro_Relatorios_Clientes);

        Financeiro_Produtos.setText("Produtos");

        Financeiro_Produtos_Todos.setText("Produtos");
        Financeiro_Produtos_Todos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Produtos_TodosActionPerformed(evt);
            }
        });
        Financeiro_Produtos.add(Financeiro_Produtos_Todos);

        Financeiro_Produtos_Fabricantes.setText("Produtos por Fabricantes");
        Financeiro_Produtos_Fabricantes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Produtos_FabricantesActionPerformed(evt);
            }
        });
        Financeiro_Produtos.add(Financeiro_Produtos_Fabricantes);

        Financeiro_Produtos_Fornecedor.setText("Produtos por Fornecedor");
        Financeiro_Produtos_Fornecedor.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Produtos_FornecedorActionPerformed(evt);
            }
        });
        Financeiro_Produtos.add(Financeiro_Produtos_Fornecedor);

        Financeiro_Produtos_Nome.setText("Produtos por Nome");
        Financeiro_Produtos_Nome.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Produtos_NomeActionPerformed(evt);
            }
        });
        Financeiro_Produtos.add(Financeiro_Produtos_Nome);

        Financeiro_Relatorios.add(Financeiro_Produtos);

        Financeiro_Relatorios_Fornecedores.setText("Fornecedores");

        Financeiro_Relatorios_Fornecedores_FT.setText("Fornecedores - Todos");
        Financeiro_Relatorios_Fornecedores_FT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Relatorios_Fornecedores_FTActionPerformed(evt);
            }
        });
        Financeiro_Relatorios_Fornecedores.add(Financeiro_Relatorios_Fornecedores_FT);

        Financeiro_Relatorios_Fornecedores_FN.setText("Fornecedores por Nome");
        Financeiro_Relatorios_Fornecedores_FN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Relatorios_Fornecedores_FNActionPerformed(evt);
            }
        });
        Financeiro_Relatorios_Fornecedores.add(Financeiro_Relatorios_Fornecedores_FN);

        Financeiro_Relatorios.add(Financeiro_Relatorios_Fornecedores);

        Financeiro_Relatorios_Fabricantes_Marcas.setText("Fabricantes/Marcas");

        Financeiro_Relatorios_Fabricantes_Marcas_FT.setText("Fabricantes- Todos");
        Financeiro_Relatorios_Fabricantes_Marcas_FT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Relatorios_Fabricantes_Marcas_FTActionPerformed(evt);
            }
        });
        Financeiro_Relatorios_Fabricantes_Marcas.add(Financeiro_Relatorios_Fabricantes_Marcas_FT);

        Financeiro_Relatorios.add(Financeiro_Relatorios_Fabricantes_Marcas);

        Finaceiro.add(Financeiro_Relatorios);

        Financeiro_Contas_a_Receber.setText("Contas à Receber");

        Financeiro_Contas_a_Receber_Todas.setText("Contas à  Receber - Todas");
        Financeiro_Contas_a_Receber_Todas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Contas_a_Receber_TodasActionPerformed(evt);
            }
        });
        Financeiro_Contas_a_Receber.add(Financeiro_Contas_a_Receber_Todas);

        Financeiro_Contas_a_Receber_Cliente.setText("Contas à Receber por Cliente");
        Financeiro_Contas_a_Receber_Cliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Contas_a_Receber_ClienteActionPerformed(evt);
            }
        });
        Financeiro_Contas_a_Receber.add(Financeiro_Contas_a_Receber_Cliente);

        Financeiro_Contas_a_Receber_Data.setText("Contas à Receber por Data");
        Financeiro_Contas_a_Receber_Data.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Contas_a_Receber_DataActionPerformed(evt);
            }
        });
        Financeiro_Contas_a_Receber.add(Financeiro_Contas_a_Receber_Data);

        Finaceiro.add(Financeiro_Contas_a_Receber);

        Financeiro_Contas_Recebidas.setText("Contas Recebidas");

        Financeiro_Contas_Recebidas_Todas.setText("Contas Recebidas - Todas");
        Financeiro_Contas_Recebidas_Todas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Contas_Recebidas_TodasActionPerformed(evt);
            }
        });
        Financeiro_Contas_Recebidas.add(Financeiro_Contas_Recebidas_Todas);

        Financeiro_Contas_Recebidas_Data.setText("Contas Recebidas por Data");
        Financeiro_Contas_Recebidas_Data.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_Contas_Recebidas_DataActionPerformed(evt);
            }
        });
        Financeiro_Contas_Recebidas.add(Financeiro_Contas_Recebidas_Data);

        Finaceiro.add(Financeiro_Contas_Recebidas);

        Financeiro_ReimprimirComprovantes.setText("Reimprimir Comprovantes");

        Financeiro_ReimprimirComprovantes_Orcmentos.setText("Orcamento");
        Financeiro_ReimprimirComprovantes_Orcmentos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_ReimprimirComprovantes_OrcmentosActionPerformed(evt);
            }
        });
        Financeiro_ReimprimirComprovantes.add(Financeiro_ReimprimirComprovantes_Orcmentos);

        Financeiro_ReimprimirComprovantes_OSAprazo.setText("OS à Prazo");
        Financeiro_ReimprimirComprovantes_OSAprazo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_ReimprimirComprovantes_OSAprazoActionPerformed(evt);
            }
        });
        Financeiro_ReimprimirComprovantes.add(Financeiro_ReimprimirComprovantes_OSAprazo);

        Financeiro_ReimprimirComprovantes_VAvista.setText("Venda à Vista");
        Financeiro_ReimprimirComprovantes_VAvista.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_ReimprimirComprovantes_VAvistaActionPerformed(evt);
            }
        });
        Financeiro_ReimprimirComprovantes.add(Financeiro_ReimprimirComprovantes_VAvista);

        Financeiro_ReimprimirComprovantes_APr.setText("Venda à Prazo");
        Financeiro_ReimprimirComprovantes_APr.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_ReimprimirComprovantes_APrActionPerformed(evt);
            }
        });
        Financeiro_ReimprimirComprovantes.add(Financeiro_ReimprimirComprovantes_APr);

        Financeiro_ReimprimirComprovantes_PagConta.setText("Pagamento de Conta");
        Financeiro_ReimprimirComprovantes_PagConta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Financeiro_ReimprimirComprovantes_PagContaActionPerformed(evt);
            }
        });
        Financeiro_ReimprimirComprovantes.add(Financeiro_ReimprimirComprovantes_PagConta);

        Finaceiro.add(Financeiro_ReimprimirComprovantes);

        BarraMenu.add(Finaceiro);

        SislpBasicMenu.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/70_32.png"))); // NOI18N
        SislpBasicMenu.setText("SisLpBasic");

        SislpBasicMenu_Backup.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/37_32png.png"))); // NOI18N
        SislpBasicMenu_Backup.setText("Backup");
        SislpBasicMenu_Backup.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SislpBasicMenu_BackupActionPerformed(evt);
            }
        });
        SislpBasicMenu.add(SislpBasicMenu_Backup);

        SislpBasicMenu_Calc.setAccelerator(javax.swing.KeyStroke.getKeyStroke(java.awt.event.KeyEvent.VK_F11, 0));
        SislpBasicMenu_Calc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/60_32.png"))); // NOI18N
        SislpBasicMenu_Calc.setText("Calculadora");
        SislpBasicMenu_Calc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SislpBasicMenu_CalcActionPerformed(evt);
            }
        });
        SislpBasicMenu.add(SislpBasicMenu_Calc);

        SislpBasicMenu_Config.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/35_32.png"))); // NOI18N
        SislpBasicMenu_Config.setText("Configurações");
        SislpBasicMenu_Config.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SislpBasicMenu_ConfigActionPerformed(evt);
            }
        });
        SislpBasicMenu.add(SislpBasicMenu_Config);

        SislpBasicMenu_IE.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/20_32.png"))); // NOI18N
        SislpBasicMenu_IE.setText("Informações da Empresa");
        SislpBasicMenu_IE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SislpBasicMenu_IEActionPerformed(evt);
            }
        });
        SislpBasicMenu.add(SislpBasicMenu_IE);

        SislpBasicMenu_Users.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/32_32.png"))); // NOI18N
        SislpBasicMenu_Users.setText("Usuários");
        SislpBasicMenu_Users.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SislpBasicMenu_UsersActionPerformed(evt);
            }
        });
        SislpBasicMenu.add(SislpBasicMenu_Users);

        SislpBasicMenu_Sobre.setText("Sobre");
        SislpBasicMenu_Sobre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SislpBasicMenu_SobreActionPerformed(evt);
            }
        });
        SislpBasicMenu.add(SislpBasicMenu_Sobre);
        SislpBasicMenu.add(jSeparator1);

        SislpBasicMenu_Sair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/sair_02.png"))); // NOI18N
        SislpBasicMenu_Sair.setText("Sair");
        SislpBasicMenu_Sair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SislpBasicMenu_SairActionPerformed(evt);
            }
        });
        SislpBasicMenu.add(SislpBasicMenu_Sair);

        BarraMenu.add(SislpBasicMenu);

        jMenu2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/doe.png"))); // NOI18N
        jMenu2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jMenu2MouseClicked(evt);
            }
        });
        BarraMenu.add(jMenu2);

        setJMenuBar(BarraMenu);

        setSize(new java.awt.Dimension(1024, 768));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void SislpBasicMenu_SairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SislpBasicMenu_SairActionPerformed
        ctrlTask.ReparaRegistrosInvalidosCadastrados();
        
        if (JOptionPane.showConfirmDialog(null,"Deseja Finalizar o SisLp?")==JOptionPane.OK_OPTION){
            
            if (JOptionPane.showConfirmDialog(null,"É extremamente recomendado fazer o backup da base de dados.\nDeseja efetuar o backup agora?")==JOptionPane.OK_OPTION){
                AbreJaneladeBackup();
                
            }else{
                System.exit(0);
            }
            
        }
    }//GEN-LAST:event_SislpBasicMenu_SairActionPerformed

    private void Cadastros_ProdutosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Cadastros_ProdutosActionPerformed
        FormCadProdutos FrmcadProdutos = new FormCadProdutos();
        AbreNovaJanela(FrmcadProdutos);
    }//GEN-LAST:event_Cadastros_ProdutosActionPerformed

    private void Cadastros_ClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Cadastros_ClientesActionPerformed
        FormCadClientes FrmCadClientes = new FormCadClientes();
        AbreNovaJanela(FrmCadClientes);
    }//GEN-LAST:event_Cadastros_ClientesActionPerformed

    private void Cadastros_FornecedoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Cadastros_FornecedoresActionPerformed
        
        FormCadFornecedoresN FrmFornecedores = new FormCadFornecedoresN();
        AbreNovaJanela(FrmFornecedores);
        
    }//GEN-LAST:event_Cadastros_FornecedoresActionPerformed

    private void Movimentos_Cadastros_ClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Movimentos_Cadastros_ClientesActionPerformed
                
        FormPesqCliente FrmPesqCliente = new FormPesqCliente();
        AbreNovaJanela(FrmPesqCliente);
        
    }//GEN-LAST:event_Movimentos_Cadastros_ClientesActionPerformed

    private void Movimentos_Cadastros_FornecedoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Movimentos_Cadastros_FornecedoresActionPerformed

        FormPesqFornecedor FrmPesqForn = new FormPesqFornecedor();
        AbreNovaJanela(FrmPesqForn);
        
    }//GEN-LAST:event_Movimentos_Cadastros_FornecedoresActionPerformed

    private void Movimentos_Cadastros_ProdutosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Movimentos_Cadastros_ProdutosActionPerformed
        
        FormPesqProduto FrmPesqProd = new FormPesqProduto();
        AbreNovaJanela(FrmPesqProd);
        
    }//GEN-LAST:event_Movimentos_Cadastros_ProdutosActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        
        FormPesqVendas FrmPesqVendas = new FormPesqVendas();
        AbreNovaJanela(FrmPesqVendas);
        
    }//GEN-LAST:event_jMenuItem1ActionPerformed

    private void SislpBasicMenu_IEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SislpBasicMenu_IEActionPerformed
        
        FormDadosEmpresa FrmDE = new FormDadosEmpresa();
        AbreNovaJanela(FrmDE);
        
    }//GEN-LAST:event_SislpBasicMenu_IEActionPerformed

    private void jMenuItem2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem2ActionPerformed
        
        FormContasReceber FrmCR = new FormContasReceber();
        AbreNovaJanela(FrmCR);
        
    }//GEN-LAST:event_jMenuItem2ActionPerformed

    private void Financeiro_Vendas_GeraCarnesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Vendas_GeraCarnesActionPerformed
    
        ctrlRel.VendasGeraCarne(NomeEmpresa);
        
    }//GEN-LAST:event_Financeiro_Vendas_GeraCarnesActionPerformed

    private void Movimentos_Recibo_ReciboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Movimentos_Recibo_ReciboActionPerformed
        FormGeraRecibo FrmGRecibo = new FormGeraRecibo();
        AbreNovaJanela(FrmGRecibo);
    }//GEN-LAST:event_Movimentos_Recibo_ReciboActionPerformed

    private void Movimentos_Recibo_Recibo_EmitidosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Movimentos_Recibo_Recibo_EmitidosActionPerformed
        FormPesqRecibo FrmPesRecibo = new FormPesqRecibo();
        AbreNovaJanela(FrmPesRecibo);
    }//GEN-LAST:event_Movimentos_Recibo_Recibo_EmitidosActionPerformed

    private void SislpBasicMenu_ConfigActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SislpBasicMenu_ConfigActionPerformed
        FormConfig FrmConf = new FormConfig();
        AbreNovaJanela(FrmConf);
    }//GEN-LAST:event_SislpBasicMenu_ConfigActionPerformed

    private void Financeiro_Vendas_VendasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Vendas_VendasActionPerformed
         
        
        ctrlRel.Vendas();
     
    }//GEN-LAST:event_Financeiro_Vendas_VendasActionPerformed

    private void Financeiro_Vendas_DataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Vendas_DataActionPerformed
        
        ctrlRel.VendasData();
        
    }//GEN-LAST:event_Financeiro_Vendas_DataActionPerformed

    private void Financeiro_Vendas_ClientesDataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Vendas_ClientesDataActionPerformed
        
        ctrlRel.VendasClienteData();
        
    }//GEN-LAST:event_Financeiro_Vendas_ClientesDataActionPerformed

    private void Financeiro_Vendas_VendasClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Vendas_VendasClienteActionPerformed
        
        ctrlRel.VendasCliente();
        
    }//GEN-LAST:event_Financeiro_Vendas_VendasClienteActionPerformed

    private void jMenuItem4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem4ActionPerformed
        
        FormControleCaixa FrmCtrlCX;
            try {
                FrmCtrlCX = new FormControleCaixa();
                FrmCtrlCX.PermUsuario(User);
                AbreNovaJanela(FrmCtrlCX);
        } catch (SQLException ex) {
                Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_jMenuItem4ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed

        CadReferenciaDoFCX FrmCadRefFCX = new CadReferenciaDoFCX();
        AbreNovaJanela(FrmCadRefFCX);
        
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        CadFabricantes CadFabr = new CadFabricantes();
        AbreNovaJanela(CadFabr);
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void SislpBasicMenu_SobreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SislpBasicMenu_SobreActionPerformed
       FormSobre FrmSobre = new FormSobre();
        AbreNovaJanela(FrmSobre);
    }//GEN-LAST:event_SislpBasicMenu_SobreActionPerformed

    private void jMenuItem8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem8ActionPerformed
        FormPedido FrmPedido = new FormPedido();
        AbreNovaJanela(FrmPedido);
    }//GEN-LAST:event_jMenuItem8ActionPerformed

    private void jMenuItem7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem7ActionPerformed
        FormPesqPedidos FrmPesqPedido = new FormPesqPedidos();
        AbreNovaJanela(FrmPesqPedido);
    }//GEN-LAST:event_jMenuItem7ActionPerformed

    private void Financeiro_Produtos_TodosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Produtos_TodosActionPerformed
        ctrlRel.Produtos();
    }//GEN-LAST:event_Financeiro_Produtos_TodosActionPerformed

    private void Financeiro_Produtos_FabricantesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Produtos_FabricantesActionPerformed
        
        ctrlRel.ProdutosFabricantes();
        
    }//GEN-LAST:event_Financeiro_Produtos_FabricantesActionPerformed

    private void Financeiro_Produtos_FornecedorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Produtos_FornecedorActionPerformed
        
        ctrlRel.ProdutosFornecedor();
        
    }//GEN-LAST:event_Financeiro_Produtos_FornecedorActionPerformed

    private void Financeiro_Produtos_NomeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Produtos_NomeActionPerformed
        
        ctrlRel.ProdutosNome();
        
    }//GEN-LAST:event_Financeiro_Produtos_NomeActionPerformed

    private void SislpBasicMenu_CalcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SislpBasicMenu_CalcActionPerformed
        try{
           Runtime.getRuntime().exec("calc"); //assim
//           Runtime.getRuntime().exec("C:\Windows\System32\calc.exe"); //e assim
        }catch(Exception e){
//           System.err.println("Deu pau!");
        }
    }//GEN-LAST:event_SislpBasicMenu_CalcActionPerformed

    private void SislpBasicMenu_BackupActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SislpBasicMenu_BackupActionPerformed

        AbreJaneladeBackup();

    }//GEN-LAST:event_SislpBasicMenu_BackupActionPerformed

    private void ExecutarAoSair(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_ExecutarAoSair
        
        ctrlTask.ReparaRegistrosInvalidosCadastrados();
        
        if (JOptionPane.showConfirmDialog(null,"Deseja Finalizar o SisLp?")==JOptionPane.OK_OPTION){
            
            if (JOptionPane.showConfirmDialog(null,"É extremamente recomendado fazer o backup da base de dados.\nDeseja efetuar o backup agora?")==JOptionPane.OK_OPTION){
                AbreJaneladeBackup();
                System.exit(0);
            }else{
                System.exit(0);
            }
            
        }
    }//GEN-LAST:event_ExecutarAoSair

    private void SislpBasicMenu_UsersActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SislpBasicMenu_UsersActionPerformed
        FormUsuarios FrmUser = new FormUsuarios();
        AbreNovaJanela(FrmUser);
    }//GEN-LAST:event_SislpBasicMenu_UsersActionPerformed

    private void Fluxo_de_Caixa_PeriodoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Fluxo_de_Caixa_PeriodoActionPerformed
        ctrlRel.CaixaPorPeriodo();
    }//GEN-LAST:event_Fluxo_de_Caixa_PeriodoActionPerformed

    private void Fluxo_de_Caixa_Periodo_ReferenciaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Fluxo_de_Caixa_Periodo_ReferenciaActionPerformed
        ctrlRel.CaixaPorPeriodoReferencia();
    }//GEN-LAST:event_Fluxo_de_Caixa_Periodo_ReferenciaActionPerformed

    private void Financeiro_Relatorios_Clientes_CNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Relatorios_Clientes_CNActionPerformed
        ctrlRel.ClientesNome();
    }//GEN-LAST:event_Financeiro_Relatorios_Clientes_CNActionPerformed

    private void Financeiro_Relatorios_Clientes_CActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Relatorios_Clientes_CActionPerformed
        ctrlRel.ClientesTodos();
    }//GEN-LAST:event_Financeiro_Relatorios_Clientes_CActionPerformed

    private void Financeiro_Contas_a_Receber_TodasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Contas_a_Receber_TodasActionPerformed
        ctrlRel.ContasVencidas();
    }//GEN-LAST:event_Financeiro_Contas_a_Receber_TodasActionPerformed

    private void Financeiro_Contas_a_Receber_ClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Contas_a_Receber_ClienteActionPerformed
        ctrlRel.ContasVencidasCliente();
    }//GEN-LAST:event_Financeiro_Contas_a_Receber_ClienteActionPerformed

    private void Financeiro_Contas_a_Receber_DataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Contas_a_Receber_DataActionPerformed
         ctrlRel.ContasVencidasData();
    }//GEN-LAST:event_Financeiro_Contas_a_Receber_DataActionPerformed

    private void Financeiro_Contas_Recebidas_TodasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Contas_Recebidas_TodasActionPerformed
        ctrlRel.ContasPagas();
    }//GEN-LAST:event_Financeiro_Contas_Recebidas_TodasActionPerformed

    private void Financeiro_Contas_Recebidas_DataActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Contas_Recebidas_DataActionPerformed
        ctrlRel.ContasPagasData();
    }//GEN-LAST:event_Financeiro_Contas_Recebidas_DataActionPerformed

    private void Financeiro_Relatorios_Fornecedores_FTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Relatorios_Fornecedores_FTActionPerformed
        ctrlRel.Fornecedores();
    }//GEN-LAST:event_Financeiro_Relatorios_Fornecedores_FTActionPerformed

    private void Financeiro_Relatorios_Fornecedores_FNActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Relatorios_Fornecedores_FNActionPerformed
        ctrlRel.FornecedoresNome();
    }//GEN-LAST:event_Financeiro_Relatorios_Fornecedores_FNActionPerformed

    private void Financeiro_Relatorios_Fabricantes_Marcas_FTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_Relatorios_Fabricantes_Marcas_FTActionPerformed
        ctrlRel.Fabricantes();
    }//GEN-LAST:event_Financeiro_Relatorios_Fabricantes_Marcas_FTActionPerformed

    private void Financeiro_ReimprimirComprovantes_VAvistaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_ReimprimirComprovantes_VAvistaActionPerformed
        ctrlRel.VendaAVista();
    }//GEN-LAST:event_Financeiro_ReimprimirComprovantes_VAvistaActionPerformed

    private void Financeiro_ReimprimirComprovantes_APrActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_ReimprimirComprovantes_APrActionPerformed
        ctrlRel.VendaAPrazo();
    }//GEN-LAST:event_Financeiro_ReimprimirComprovantes_APrActionPerformed

    private void Financeiro_ReimprimirComprovantes_PagContaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_ReimprimirComprovantes_PagContaActionPerformed
        ctrlRel.ComprovantePagContaReceber();
    }//GEN-LAST:event_Financeiro_ReimprimirComprovantes_PagContaActionPerformed

    private void jMenuItem9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem9ActionPerformed
        FormPesqOS FrmPesqOSF = new FormPesqOS();
        AbreNovaJanela(FrmPesqOSF);
    }//GEN-LAST:event_jMenuItem9ActionPerformed

    private void jMenuItem10ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem10ActionPerformed
        ctrlRel.ContratoVendaAPrazo();    
    }//GEN-LAST:event_jMenuItem10ActionPerformed

    private void jMenuItem11ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem11ActionPerformed
        FormAgenda FrmAgenda = new FormAgenda();
        AbreNovaJanela(FrmAgenda);
    }//GEN-LAST:event_jMenuItem11ActionPerformed

    private void jMenuItem12ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem12ActionPerformed
        FormPesqOrcamento FrmPesqO = new FormPesqOrcamento();
        AbreNovaJanela(FrmPesqO);
    }//GEN-LAST:event_jMenuItem12ActionPerformed

    private void jMenuItem13ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem13ActionPerformed
        CadHoraAgenda CadHoraA = new CadHoraAgenda();
        AbreNovaJanela(CadHoraA);
    }//GEN-LAST:event_jMenuItem13ActionPerformed

    private void Financeiro_ReimprimirComprovantes_OSAprazoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_ReimprimirComprovantes_OSAprazoActionPerformed
        ctrlRel.PrintOSParcelada();
    }//GEN-LAST:event_Financeiro_ReimprimirComprovantes_OSAprazoActionPerformed

    private void Financeiro_ReimprimirComprovantes_OrcmentosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Financeiro_ReimprimirComprovantes_OrcmentosActionPerformed
        ctrlRel.PrintOrcamento();
    }//GEN-LAST:event_Financeiro_ReimprimirComprovantes_OrcmentosActionPerformed

    private void jbtbfcalculadoraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtbfcalculadoraActionPerformed

        try{
            Runtime.getRuntime().exec("calc"); //assim
            //           Runtime.getRuntime().exec("C:\Windows\System32\calc.exe"); //e assim
        }catch(Exception e){
            //           System.err.println("Deu pau!");
        }

    }//GEN-LAST:event_jbtbfcalculadoraActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        FormAgenda FrmAgenda = new FormAgenda();
        AbreNovaJanela(FrmAgenda);
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jbtbfcontasrecebidasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtbfcontasrecebidasActionPerformed
        FormContasRecebidas frmCRecb = new FormContasRecebidas();
        AbreNovaJanela(frmCRecb);
    }//GEN-LAST:event_jbtbfcontasrecebidasActionPerformed

    private void jbtbfcontrolecaixaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtbfcontrolecaixaActionPerformed
        FormControleCaixa FrmCtrlCX;
        try {
            FrmCtrlCX = new FormControleCaixa();
            FrmCtrlCX.PermUsuario(User);
            AbreNovaJanela(FrmCtrlCX);
        } catch (SQLException ex) {
            Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_jbtbfcontrolecaixaActionPerformed

    private void jbtbfcontasreceberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtbfcontasreceberActionPerformed
        FormContasReceber FrmCR = new FormContasReceber();
        AbreNovaJanela(FrmCR);
    }//GEN-LAST:event_jbtbfcontasreceberActionPerformed

    private void jbtbfreciboActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtbfreciboActionPerformed
        FormGeraRecibo FrmGRecibo = new FormGeraRecibo();
        AbreNovaJanela(FrmGRecibo);
    }//GEN-LAST:event_jbtbfreciboActionPerformed

    private void jbtbfvendasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtbfvendasActionPerformed
        FormPesqVendas FrmPesqVendas = new FormPesqVendas();
        AbreNovaJanela(FrmPesqVendas);
    }//GEN-LAST:event_jbtbfvendasActionPerformed

    private void jbtbfprodutosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtbfprodutosActionPerformed

        FormPesqProduto FrmPesqProdbf = new FormPesqProduto();
        AbreNovaJanela(FrmPesqProdbf);

    }//GEN-LAST:event_jbtbfprodutosActionPerformed

    private void jbtbffornecedoresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtbffornecedoresActionPerformed

        FormPesqFornecedor FrmPesqFornbf = new FormPesqFornecedor();
        AbreNovaJanela(FrmPesqFornbf);

    }//GEN-LAST:event_jbtbffornecedoresActionPerformed

    private void jbtbfclientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtbfclientesActionPerformed

        FormPesqCliente FrmPesqClientebf = new FormPesqCliente();
        AbreNovaJanela(FrmPesqClientebf);

    }//GEN-LAST:event_jbtbfclientesActionPerformed

    private void formWindowStateChanged(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowStateChanged
       
    }//GEN-LAST:event_formWindowStateChanged

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
        // TODO add your handling code here:
        FormContasRecebidas frmCRecb = new FormContasRecebidas();
        AbreNovaJanela(frmCRecb);
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenu2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jMenu2MouseClicked
        // TODO add your handling code here:
        FormDoacao frmDoe = new FormDoacao();
        AbreNovaJanela(frmDoe);
    }//GEN-LAST:event_jMenu2MouseClicked

    public void AbreJaneladeBackup(){
            FormBackup frmbkp = new FormBackup();
            frmbkp.setVisible(true);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JDesktopPane AreaDeTrabalhoPrincipal;
    private javax.swing.JToolBar BarraFerramentas;
    private javax.swing.JMenuBar BarraMenu;
    private javax.swing.JMenu Cadastros;
    private javax.swing.JMenuItem Cadastros_Clientes;
    private javax.swing.JMenuItem Cadastros_Fornecedores;
    private javax.swing.JMenuItem Cadastros_Produtos;
    private javax.swing.JMenu Finaceiro;
    private javax.swing.JMenu Financeiro_Contas_Recebidas;
    private javax.swing.JMenuItem Financeiro_Contas_Recebidas_Data;
    private javax.swing.JMenuItem Financeiro_Contas_Recebidas_Todas;
    private javax.swing.JMenu Financeiro_Contas_a_Receber;
    private javax.swing.JMenuItem Financeiro_Contas_a_Receber_Cliente;
    private javax.swing.JMenuItem Financeiro_Contas_a_Receber_Data;
    private javax.swing.JMenuItem Financeiro_Contas_a_Receber_Todas;
    private javax.swing.JMenu Financeiro_Fluxo_de_Caixa;
    private javax.swing.JMenu Financeiro_Produtos;
    private javax.swing.JMenuItem Financeiro_Produtos_Fabricantes;
    private javax.swing.JMenuItem Financeiro_Produtos_Fornecedor;
    private javax.swing.JMenuItem Financeiro_Produtos_Nome;
    private javax.swing.JMenuItem Financeiro_Produtos_Todos;
    private javax.swing.JMenu Financeiro_ReimprimirComprovantes;
    private javax.swing.JMenuItem Financeiro_ReimprimirComprovantes_APr;
    private javax.swing.JMenuItem Financeiro_ReimprimirComprovantes_OSAprazo;
    private javax.swing.JMenuItem Financeiro_ReimprimirComprovantes_Orcmentos;
    private javax.swing.JMenuItem Financeiro_ReimprimirComprovantes_PagConta;
    private javax.swing.JMenuItem Financeiro_ReimprimirComprovantes_VAvista;
    private javax.swing.JMenu Financeiro_Relatorios;
    private javax.swing.JMenu Financeiro_Relatorios_Clientes;
    private javax.swing.JMenuItem Financeiro_Relatorios_Clientes_C;
    private javax.swing.JMenuItem Financeiro_Relatorios_Clientes_CN;
    private javax.swing.JMenu Financeiro_Relatorios_Fabricantes_Marcas;
    private javax.swing.JMenuItem Financeiro_Relatorios_Fabricantes_Marcas_FT;
    private javax.swing.JMenu Financeiro_Relatorios_Fornecedores;
    private javax.swing.JMenuItem Financeiro_Relatorios_Fornecedores_FN;
    private javax.swing.JMenuItem Financeiro_Relatorios_Fornecedores_FT;
    private javax.swing.JMenu Financeiro_Vendas;
    private javax.swing.JMenuItem Financeiro_Vendas_ClientesData;
    private javax.swing.JMenuItem Financeiro_Vendas_Data;
    private javax.swing.JMenuItem Financeiro_Vendas_GeraCarnes;
    private javax.swing.JMenuItem Financeiro_Vendas_Vendas;
    private javax.swing.JMenuItem Financeiro_Vendas_VendasCliente;
    private javax.swing.JMenuItem Fluxo_de_Caixa_Periodo;
    private javax.swing.JMenuItem Fluxo_de_Caixa_Periodo_Referencia;
    private javax.swing.JMenu Movimentos;
    private javax.swing.JMenu Movimentos_Cadastros;
    private javax.swing.JMenuItem Movimentos_Cadastros_Clientes;
    private javax.swing.JMenuItem Movimentos_Cadastros_Fornecedores;
    private javax.swing.JMenuItem Movimentos_Cadastros_Produtos;
    private javax.swing.JMenu Movimentos_Recibo;
    private javax.swing.JMenuItem Movimentos_Recibo_Recibo;
    private javax.swing.JMenuItem Movimentos_Recibo_Recibo_Emitidos;
    private javax.swing.JMenu SislpBasicMenu;
    private javax.swing.JMenuItem SislpBasicMenu_Backup;
    private javax.swing.JMenuItem SislpBasicMenu_Calc;
    private javax.swing.JMenuItem SislpBasicMenu_Config;
    private javax.swing.JMenuItem SislpBasicMenu_IE;
    private javax.swing.JMenuItem SislpBasicMenu_Sair;
    private javax.swing.JMenuItem SislpBasicMenu_Sobre;
    private javax.swing.JMenuItem SislpBasicMenu_Users;
    private javax.swing.JButton jButton1;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem10;
    private javax.swing.JMenuItem jMenuItem11;
    private javax.swing.JMenuItem jMenuItem12;
    private javax.swing.JMenuItem jMenuItem13;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem4;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JMenuItem jMenuItem7;
    private javax.swing.JMenuItem jMenuItem8;
    private javax.swing.JMenuItem jMenuItem9;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JToolBar.Separator jSeparator4;
    private javax.swing.JButton jbtbfcalculadora;
    private javax.swing.JButton jbtbfclientes;
    private javax.swing.JButton jbtbfcontasreceber;
    private javax.swing.JButton jbtbfcontasrecebidas;
    private javax.swing.JButton jbtbfcontrolecaixa;
    private javax.swing.JButton jbtbffornecedores;
    private javax.swing.JButton jbtbfprodutos;
    private javax.swing.JButton jbtbfrecibo;
    private javax.swing.JButton jbtbfvendas;
    // End of variables declaration//GEN-END:variables
}
