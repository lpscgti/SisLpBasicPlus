/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import com.formdev.flatlaf.FlatDarculaLaf;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatIntelliJLaf;
import com.formdev.flatlaf.FlatLightLaf;
import controle.ConectaBanco;
import controle.formata_janela_principal;
import controle.obter_arquivo_conf;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author Lindembergue
 */
public class FormLogon extends javax.swing.JFrame {
    
    ConectaBanco conlp = new ConectaBanco();
    String Nome, tipoUser, Login, Senha;
    String Serial, SerialD, DataIni, DataVenc, DataTemp, DataRenova, DataConvertidaString, chavedesbloqueio,DataHoje, AgoraHora;
    int Licenciado, TempoTesteRestante;
    java.sql.Date DataAnteriorTeste, DataInicialTeste;
    private String login, senha, nome, permissao;
    Date vDataV, vDataR,vDataH;
    long ChaveBloqueio, ChaveDesBloqueio, dtB, dtH;
    public static String NomeJIF = "FormLogon";
    obter_arquivo_conf o_ac = new obter_arquivo_conf();
    formata_janela_principal visual_jp = new formata_janela_principal();
    
    
    /**
     * Creates new form FormLogar
     */
    public FormLogon() throws IOException {
        
        visual_jp.aplicavisual();
        initComponents();
        jLabelinfo.setVisible(false);
        getRootPane().setDefaultButton(jButtonLogar);
        BuscaUsuarios();
       
            Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
            this.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoTXT+"/"+"SisLpICO.png"));
            jPasswordFieldSenha.grabFocus();
     

        try {
                     
            UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
                            
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(FormLogon.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            Logger.getLogger(FormLogon.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            Logger.getLogger(FormLogon.class.getName()).log(Level.SEVERE, null, ex);
        } catch (UnsupportedLookAndFeelException ex) {
            Logger.getLogger(FormLogon.class.getName()).log(Level.SEVERE, null, ex);
        }
                          
    }    
    

    
    
public void BuscaUsuarios() throws IOException{
    
    conlp.conecta();
    try {
            conlp.executaSQL("select * from usuarios order by login");
            conlp.rs.first();
            jComboBoxUser.removeAllItems();
            //jComboBoxUser.addItem("Selecione uma Categoria");
            do{
                jComboBoxUser.addItem(conlp.rs.getString("login"));
            } while (conlp.rs.next());
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane, "Erro ao Obter lista de Usuários. "+ex);
            //Logger.getLogger(FormCadProdutos.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(rootPane, "Erro ao Obter lista de Usuários.");
        }
    conlp.desconecta();
    jPasswordFieldSenha.grabFocus();
}

    public void ObtemDadosLicenciamento(){
        conlp.conecta();
        conlp.executaSQL("select * from licenciamento where codigo=1");
        try {
            if (conlp.rs.first()){
                Serial = conlp.rs.getString("serial");
                DataIni = conlp.rs.getString("datainst");
                DataVenc = conlp.rs.getString("datavenc");
                DataRenova = conlp.rs.getString("datarenova");
                chavedesbloqueio = conlp.rs.getString("chavedesbloqueio");
                DataInicialTeste = conlp.rs.getDate("data_i_teste");
                Licenciado = conlp.rs.getInt("licenciado");
                TempoTesteRestante = conlp.rs.getInt("tempo_restante_teste");
                DataAnteriorTeste = conlp.rs.getDate("data_a_teste");
                ValidaLicenciamento();
            }
        } catch (SQLException ex) {
            Logger.getLogger(FormLicenciamento.class.getName()).log(Level.SEVERE, null, ex);
        }
        conlp.desconecta();
    }
    
    public void ValidaLicenciamento(){
        if (chavedesbloqueio==null||chavedesbloqueio.equals("")){
            FormLicenciamento FrmLic = new FormLicenciamento();
            FrmLic.nome = nome;
            FrmLic.senha = senha;
            FrmLic.permissao = permissao;
            FrmLic.setVisible(true);
            dispose();
        }else{
            
            AbreFormPrincipal();
            
        }
    }
    
    
    
    public void AbreFormPrincipal(){
                    FormPrincipal fp = new FormPrincipal();
                    fp.ObterUsuarioSenha(nome, senha, permissao);
                    Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
                    fp.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoTXT+"/"+"sislp.ico.png"));
                    fp.setVisible(true);
                    dispose();
                    
    }
    
     
     
            

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jComboBoxUser = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        jButtonLogar = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jLabelinfo = new javax.swing.JLabel();
        jPasswordFieldSenha = new javax.swing.JPasswordField();
        jLabelImg = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Logar");
        setAlwaysOnTop(true);
        setBackground(new java.awt.Color(255, 255, 255));
        setResizable(false);
        setType(java.awt.Window.Type.POPUP);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                saindo(evt);
            }
            public void windowOpened(java.awt.event.WindowEvent evt) {
                AoAbrir(evt);
            }
        });
        getContentPane().setLayout(null);

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel3.setText("Login:");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(220, 180, 60, 30);

        getContentPane().add(jComboBoxUser);
        jComboBoxUser.setBounds(280, 180, 200, 30);

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel1.setText("Senha:");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(220, 220, 60, 30);

        jButtonLogar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/applyResultado.png"))); // NOI18N
        jButtonLogar.setText("Logar");
        jButtonLogar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLogarActionPerformed(evt);
            }
        });
        jButtonLogar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                jButtonLogarKeyPressed(evt);
            }
        });
        getContentPane().add(jButtonLogar);
        jButtonLogar.setBounds(280, 300, 100, 40);

        jButtonCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonCancelar.setText("Sair");
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCancelar);
        jButtonCancelar.setBounds(380, 300, 100, 40);

        jLabelinfo.setForeground(new java.awt.Color(255, 255, 255));
        jLabelinfo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelinfo.setText("jLabel2");
        getContentPane().add(jLabelinfo);
        jLabelinfo.setBounds(200, 260, 280, 25);
        getContentPane().add(jPasswordFieldSenha);
        jPasswordFieldSenha.setBounds(280, 220, 200, 30);

        jLabelImg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/fundo_login2.png"))); // NOI18N
        getContentPane().add(jLabelImg);
        jLabelImg.setBounds(0, 0, 510, 370);

        setSize(new java.awt.Dimension(514, 398));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonLogarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLogarActionPerformed

        login = (String) jComboBoxUser.getSelectedItem();
        senha = jPasswordFieldSenha.getText();
        
        try {
            
            if (login.equals("")&&(senha.equals(""))) {
                JOptionPane.showMessageDialog(rootPane, "Campos em branco, não são aceitos.");
            } else {
                conlp.conecta();
                conlp.executaSQL("select * from usuarios where login='"+login+"'");
                                
                if (conlp.rs.first()){
                    
                    nome = conlp.rs.getString("nome");
                    permissao = conlp.rs.getString("permissao");
                
                }else{
                    
                    JOptionPane.showMessageDialog(rootPane, "Usuário inválido!");
                    jPasswordFieldSenha.setText("");
                    jComboBoxUser.grabFocus();
                }
                            
                if (conlp.rs.getString("senha").equals(senha)){
                    
//                    ObtemDadosLicenciamento();
                      AbreFormPrincipal();

                    
                } else{
                    
                    JOptionPane.showMessageDialog(rootPane, "Senha inválida!");
                    jComboBoxUser.grabFocus();
                    jPasswordFieldSenha.setText("");
                    
                }
                
                conlp.desconecta();
            }//                Logger.getLogger(Logar.class.getName()).log(Level.SEVERE, null, ex);
            
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane, "Erro: "+ex);
        }


    }//GEN-LAST:event_jButtonLogarActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jButtonLogarKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jButtonLogarKeyPressed

    }//GEN-LAST:event_jButtonLogarKeyPressed

    private void saindo(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_saindo
        System.exit(0);
    }//GEN-LAST:event_saindo

    private void AoAbrir(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_AoAbrir
        jPasswordFieldSenha.grabFocus();
    }//GEN-LAST:event_AoAbrir

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
     
    
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormLogon.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormLogon.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormLogon.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormLogon.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    new FormLogon().setVisible(true);
                } catch (IOException ex) {
                    Logger.getLogger(FormLogon.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonLogar;
    private javax.swing.JComboBox<String> jComboBoxUser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabelImg;
    private javax.swing.JLabel jLabelinfo;
    private javax.swing.JPasswordField jPasswordFieldSenha;
    // End of variables declaration//GEN-END:variables
}
