/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.Conf;
import controle.ConnectionFactory2;
import controle.ControleEmpresa;
import controle.ControleOrcamento;
import controle.PlanodeFundoForms;
import modelo.ModeloTabela;
import modelo.ModeloOrcamento;
import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;

/**
 *
 * @author Lindembergue
 */
public class FormOrcamento extends javax.swing.JInternalFrame {
    ConectaBanco conOrcamento = new ConectaBanco();
    ModeloOrcamento modOrcamento = new ModeloOrcamento();
    ControleOrcamento controlOrcamento = new ControleOrcamento();
    ControleEmpresa ctrl_de = new ControleEmpresa();
    
    int CodOrcamento, CodCliente, CodProduto, CodFuncionario, QtdVend, TipoPag, flag = 1, IdConta = 0, NovaOrcamento = 0, ClienteSel=0;
    String DataHoje, NomeCliente, NomeProduto, NomeFuncionario, caminhoDb;
    double TotalOrcamento, PrUnit, TotalProdVend, Desconto, DesconcoCalc, ConverteValor;
    DecimalFormat formatoNum;

    /**
     * Creates new form FormOrcamentos
     */
    
    
    
    public FormOrcamento() {
        initComponents();
        formatoNum = new DecimalFormat("#0.00");
        ColocaImagemFundoFrame();
        Lerarquivo();
        desativaitens();
        jTextFieldCodOrcamento.setEditable(false);
        jTextFieldTotalOrcamento.setEditable(false);
        jTextFieldCodCliente.setEditable(false);
        jTextFieldCodProd.setEditable(false);
        try {
            MaskFormatter data = new MaskFormatter("##/##/####");
            jFormattedTextFieldDtOrcamento.setFormatterFactory(new DefaultFormatterFactory(data));
        } catch (ParseException ex) {
            Logger.getLogger(FormCadClientes.class.getName()).log(Level.SEVERE, null, ex);
        }
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date hoje = new Date();
        //jFormattedTextFieldData.setText(df.format(hoje));
        DataHoje = (df.format(hoje));
        jFormattedTextFieldDtOrcamento.setText(DataHoje);
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
     public void Lerarquivo(){

        Conf cfg = new Conf();
            try {
                cfg.ConfigLido();
                String c = "jdbc:postgresql://"+cfg.host+":"+cfg.porta+"/slp";
                caminhoDb = c;
            } catch (IOException ex) {
//                Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
        
    }
    
     public void convertValorVirgula(String ValorEntrada){
          
        
        if (ValorEntrada.equals("")){
            ValorEntrada = "0";
        }else{
        ConverteValor = Double.parseDouble(ValorEntrada.replace(',', '.'));  
        }
    }
     
      
    

     public void preencherTabelaItensOrcamentos(String SQL){
        
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Cod. Prod.","Produto","Pr. Venda", "Desconto","Qtd. Orcamento","Total R$"};
        conOrcamento.conecta();
        conOrcamento.executaSQL(SQL);
        
        try {
            
            conOrcamento.rs.first();
            do{
                
                double PrProdutoOrcamento = conOrcamento.rs.getDouble("prvenda");
                int qtdVendida = conOrcamento.rs.getInt("qtd_produto");
                double vDescont = conOrcamento.rs.getInt("desconto");
                double ProdVend = (PrProdutoOrcamento*qtdVendida);
                double DescCalc = (ProdVend/100)*vDescont;
                double VtProdVend = (ProdVend-DescCalc);
                dados.add(new Object[]{conOrcamento.rs.getInt("id_produto"),conOrcamento.rs.getString("produto"), String.valueOf(formatoNum.format(conOrcamento.rs.getDouble("prvenda"))), String.valueOf(formatoNum.format(conOrcamento.rs.getDouble("desconto"))),conOrcamento.rs.getInt("qtd_produto"), String.valueOf(formatoNum.format(VtProdVend))});
                
            }while(conOrcamento.rs.next());
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane,"Erro ao Preencher ArrayList"+ex);
        }
        
        DefaultTableCellRenderer cellRenderD = new DefaultTableCellRenderer();
	cellRenderD.setHorizontalAlignment(SwingConstants.RIGHT);
        
        DefaultTableCellRenderer cellRenderC = new DefaultTableCellRenderer();
	cellRenderC.setHorizontalAlignment(SwingConstants.CENTER);
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableItensOrcamento.setModel(modelo);
        jTableItensOrcamento.getColumnModel().getColumn(0).setPreferredWidth(80);
        jTableItensOrcamento.getColumnModel().getColumn(0).setResizable(false);
        jTableItensOrcamento.getColumnModel().getColumn(0).setCellRenderer(cellRenderD);
        jTableItensOrcamento.getColumnModel().getColumn(1).setPreferredWidth(250);
        jTableItensOrcamento.getColumnModel().getColumn(1).setResizable(false);
        jTableItensOrcamento.getColumnModel().getColumn(2).setPreferredWidth(80);
        jTableItensOrcamento.getColumnModel().getColumn(2).setCellRenderer(cellRenderC);
        jTableItensOrcamento.getColumnModel().getColumn(2).setResizable(false);
        jTableItensOrcamento.getColumnModel().getColumn(3).setPreferredWidth(80);
        jTableItensOrcamento.getColumnModel().getColumn(3).setCellRenderer(cellRenderC);
        jTableItensOrcamento.getColumnModel().getColumn(3).setResizable(false);
        jTableItensOrcamento.getColumnModel().getColumn(4).setPreferredWidth(100);
        jTableItensOrcamento.getColumnModel().getColumn(4).setCellRenderer(cellRenderC);
        jTableItensOrcamento.getColumnModel().getColumn(4).setResizable(false);
        jTableItensOrcamento.getColumnModel().getColumn(5).setPreferredWidth(100);
        jTableItensOrcamento.getColumnModel().getColumn(5).setCellRenderer(cellRenderC);
        jTableItensOrcamento.getColumnModel().getColumn(5).setResizable(false);
        jTableItensOrcamento.getTableHeader().setReorderingAllowed(false);
        jTableItensOrcamento.setAutoResizeMode(jTableItensOrcamento.AUTO_RESIZE_OFF);
        jTableItensOrcamento.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        conOrcamento.desconecta();
        SomaProduto();      
    }
     
     
     public void SomaProduto(){
         
        TotalOrcamento = 0;
        
        conOrcamento.conecta();
        conOrcamento.executaSQL("select * from (orcamentos_descricao inner join produtos"
                +" on orcamentos_descricao.id_produto = produtos.codigo)"
                +" where id_orcamento='"+CodOrcamento+"'");
        try {
            //connOrcamentoPsq.rs.first();
            while (conOrcamento.rs.next()){
                TotalOrcamento = TotalOrcamento+conOrcamento.rs.getDouble("total_vendido");
            }
            jTextFieldTotalOrcamento.setText(String.valueOf(formatoNum.format(TotalOrcamento)));
        } catch (SQLException ex) {
            Logger.getLogger(FormOrcamento.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
     
     public void desativaitens(){
         jTextFieldCodOrcamento.setEnabled(false);
         jTextFieldCodCliente.setEnabled(false);
         jTextFieldNome.setEnabled(false);
         jFormattedTextFieldDtOrcamento.setEnabled(false);
         jTextFieldCodProd.setEnabled(false);
         jTextFieldNomeProd.setEnabled(false);
         jTextFieldPrecoProd.setEnabled(false);
         QTD.setEnabled(false);
         jTextFieldDesconto.setEnabled(false);
         jButtonPesqCliente.setEnabled(false);
         jButtonPesqProd.setEnabled(false);
         jButtonAdd.setEnabled(false);
         jButtonRem.setEnabled(false);
         jTableItensOrcamento.setEnabled(false);
     }
     
     public void ativaitens(){
         jTextFieldCodOrcamento.setEnabled(true);
         jTextFieldCodCliente.setEnabled(true);
         jTextFieldNome.setEnabled(true);
         jFormattedTextFieldDtOrcamento.setEnabled(true);
         jTextFieldCodProd.setEnabled(true);
         jTextFieldNomeProd.setEnabled(true);
         jTextFieldPrecoProd.setEnabled(true);
         QTD.setEnabled(true);
         jTextFieldDesconto.setEnabled(true);
         jButtonPesqCliente.setEnabled(true);
         jButtonPesqProd.setEnabled(true);
         jButtonAdd.setEnabled(true);
         jButtonRem.setEnabled(true);
         jTableItensOrcamento.setEnabled(true);
     }
     
     public void Limpaitens(){
         jTextFieldCodOrcamento.setText("");
         jTextFieldCodCliente.setText("");
         jTextFieldNome.setText("");
         jFormattedTextFieldDtOrcamento.setText("");
         jTextFieldCodProd.setText("");
         jTextFieldNomeProd.setText("");
         jTextFieldPrecoProd.setText("0.00");
         QTD.setValue(1);
         jTextFieldDesconto.setText("0");;
         }
     
     public void limpatabelaPesquisa(){
            
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{};
        dados.removeAll(dados);
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        
        
    }
    
   public void limpatabelaItensOrcamentos(){
        
      ArrayList dados = new ArrayList();
      String[] Colunas = new String[]{};
      dados.removeAll(dados);
      ModeloTabela modelo = new ModeloTabela(dados, Colunas);
      jTableItensOrcamento.setModel(modelo);
      
    }
    
   public void PrintOrcamentoAVista(){
       ctrl_de.Obtem_Dados_da_Empresa();
        int i = JOptionPane.showConfirmDialog(rootPane, "Orçamento gerado com sucesso.\nDeseja realizar a impressão?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
                                if(i == JOptionPane.YES_OPTION) {
                               
                                try {
                                    Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                                    Map<String, Object> parametros = new HashMap<String, Object>();
                                    Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                                    //dados empresa
                                    parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                                    parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                                    parametros.put( "cnpj", ctrl_de.de_cnpj );
                                    parametros.put( "de_ie", ctrl_de.de_ie );
                                    parametros.put( "endereco", ctrl_de.de_endereco );
                                    parametros.put( "bairro", ctrl_de.de_bairro );
                                    parametros.put( "cidade", ctrl_de.de_cidade );
                                    parametros.put( "estado", ctrl_de.de_estado );
                                    parametros.put( "cep", ctrl_de.de_cep );
                                    parametros.put( "telefone1", ctrl_de.de_fone1 );
                                    parametros.put( "telefone2", ctrl_de.de_fone2 );
                                    parametros.put( "de_site", ctrl_de.de_site );
                                    parametros.put( "email", ctrl_de.de_email );
                                    parametros.put("logoimg",imagePath);
                                    parametros.put( "CodOrc", CodOrcamento );
                                    JasperPrint jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraOrcamentoAVista.jasper", parametros, ConnectionFactory2.getConnection2());
                                    JRViewer viewer = new JRViewer(jpPrint);
                                    viewer.setZoomRatio((float) 0.5);
                                    JFrame frameRelatorio = new JFrame();
                                    frameRelatorio.add( viewer, BorderLayout.CENTER );
                                    frameRelatorio.setTitle("Novo Orcamento Gerado");
                                    frameRelatorio.setSize( 500, 500 );
                                    frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                                    frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                                    Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                                    frameRelatorio.setVisible( true );
                                    }catch (JRException ex) {
                                    JOptionPane.showMessageDialog(null, "Erro ao Gerar Orcamento para Impressão!/nErro: "+ex);
                                    } catch (SQLException ex) {
                Logger.getLogger(FormOrcamento.class.getName()).log(Level.SEVERE, null, ex);
            }
            //conOs.desconecta(); //conOs.desconecta(); //conOs.desconecta(); //conOs.desconecta();
             //conOs.desconecta(); //conOs.desconecta(); //conOs.desconecta(); //conOs.desconecta();
                                
                                }
    }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextFieldCodOrcamento = new javax.swing.JTextField();
        jTextFieldCodCliente = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButtonPesqCliente = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        jTextFieldCodProd = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextFieldPrecoProd = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableItensOrcamento = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jButtonRem = new javax.swing.JButton();
        jButtonPesqProd = new javax.swing.JButton();
        jButtonAdd = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jTextFieldDesconto = new javax.swing.JTextField();
        QTD = new javax.swing.JSpinner();
        jTextFieldNome = new controle.ClassUpperField();
        jTextFieldNomeProd = new controle.ClassUpperField();
        jFormattedTextFieldDtOrcamento = new javax.swing.JFormattedTextField();
        jButtonSair = new javax.swing.JButton();
        jButtonNovo = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jTextFieldTotalOrcamento = new javax.swing.JTextField();
        jButtonFinalizar = new javax.swing.JButton();
        jComboBoxTipoPag = new javax.swing.JComboBox();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setTitle("Efetuar Orçamentos");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Cód. Venda:");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 10, 90, 16);

        jTextFieldCodOrcamento.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldCodOrcamento.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jPanelFundo.add(jTextFieldCodOrcamento);
        jTextFieldCodOrcamento.setBounds(10, 30, 90, 30);

        jTextFieldCodCliente.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jPanelFundo.add(jTextFieldCodCliente);
        jTextFieldCodCliente.setBounds(100, 30, 90, 30);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Cód. Cliente:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(100, 10, 90, 16);

        jLabel3.setForeground(java.awt.Color.white);
        jLabel3.setText("Nome do Cliente:");
        jPanelFundo.add(jLabel3);
        jLabel3.setBounds(190, 10, 370, 16);

        jButtonPesqCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/btn_pesq_15.png"))); // NOI18N
        jButtonPesqCliente.setToolTipText("Pesquisar Cliente");
        jButtonPesqCliente.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonPesqCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesqClienteActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesqCliente);
        jButtonPesqCliente.setBounds(670, 30, 40, 30);

        jLabel5.setForeground(java.awt.Color.white);
        jLabel5.setText("Cód. Produto:");
        jPanelFundo.add(jLabel5);
        jLabel5.setBounds(10, 70, 90, 16);

        jTextFieldCodProd.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jPanelFundo.add(jTextFieldCodProd);
        jTextFieldCodProd.setBounds(10, 90, 90, 30);

        jLabel6.setForeground(java.awt.Color.white);
        jLabel6.setText("Produto:");
        jPanelFundo.add(jLabel6);
        jLabel6.setBounds(110, 70, 300, 16);

        jLabel7.setForeground(java.awt.Color.white);
        jLabel7.setText("Quant. Prod.");
        jPanelFundo.add(jLabel7);
        jLabel7.setBounds(550, 70, 80, 16);

        jTextFieldPrecoProd.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jPanelFundo.add(jTextFieldPrecoProd);
        jTextFieldPrecoProd.setBounds(410, 90, 70, 30);

        jLabel8.setForeground(java.awt.Color.white);
        jLabel8.setText("Preço:");
        jPanelFundo.add(jLabel8);
        jLabel8.setBounds(410, 70, 70, 16);

        jTableItensOrcamento.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTableItensOrcamento);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 150, 700, 350);

        jLabel9.setForeground(java.awt.Color.white);
        jLabel9.setText("Descrição dos Itens desta Venda:");
        jPanelFundo.add(jLabel9);
        jLabel9.setBounds(10, 130, 690, 20);

        jButtonRem.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jButtonRem.setToolTipText("Remover Produto");
        jButtonRem.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonRem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRemActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonRem);
        jButtonRem.setBounds(670, 90, 40, 30);

        jButtonPesqProd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/btn_pesq_15.png"))); // NOI18N
        jButtonPesqProd.setToolTipText("Pesquisar Produto");
        jButtonPesqProd.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonPesqProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesqProdActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesqProd);
        jButtonPesqProd.setBounds(370, 90, 40, 30);

        jButtonAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/add.png"))); // NOI18N
        jButtonAdd.setToolTipText("Adicionar Produto");
        jButtonAdd.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonAdd);
        jButtonAdd.setBounds(630, 90, 40, 30);

        jLabel12.setForeground(java.awt.Color.white);
        jLabel12.setText("Desconto %");
        jPanelFundo.add(jLabel12);
        jLabel12.setBounds(480, 70, 70, 16);

        jTextFieldDesconto.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jPanelFundo.add(jTextFieldDesconto);
        jTextFieldDesconto.setBounds(480, 90, 70, 30);

        QTD.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanelFundo.add(QTD);
        QTD.setBounds(550, 90, 80, 30);
        jPanelFundo.add(jTextFieldNome);
        jTextFieldNome.setBounds(190, 30, 480, 30);
        jPanelFundo.add(jTextFieldNomeProd);
        jTextFieldNomeProd.setBounds(100, 90, 270, 30);
        jPanelFundo.add(jFormattedTextFieldDtOrcamento);
        jFormattedTextFieldDtOrcamento.setBounds(580, 30, 4, 25);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 10, 720, 510);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Cancelar");
        jButtonSair.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(630, 530, 100, 40);

        jButtonNovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/add.png"))); // NOI18N
        jButtonNovo.setText("Novo");
        jButtonNovo.setToolTipText("");
        jButtonNovo.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonNovo);
        jButtonNovo.setBounds(430, 530, 100, 40);

        jLabel10.setText("Total do Orçamento R$:");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(10, 540, 140, 25);

        jTextFieldTotalOrcamento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldTotalOrcamentoActionPerformed(evt);
            }
        });
        getContentPane().add(jTextFieldTotalOrcamento);
        jTextFieldTotalOrcamento.setBounds(150, 540, 110, 25);

        jButtonFinalizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/applyResultado.png"))); // NOI18N
        jButtonFinalizar.setText("Finalizar");
        jButtonFinalizar.setToolTipText("");
        jButtonFinalizar.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFinalizarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonFinalizar);
        jButtonFinalizar.setBounds(530, 530, 100, 40);

        jComboBoxTipoPag.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "À Vista", "À Prazo" }));
        jComboBoxTipoPag.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoPagActionPerformed(evt);
            }
        });
        getContentPane().add(jComboBoxTipoPag);
        jComboBoxTipoPag.setBounds(260, 540, 110, 25);

        setBounds(0, 0, 741, 601);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
    
    if (NovaOrcamento == 0){
        dispose();
    }else{
    controlOrcamento.CancelaOrcamento();
    dispose();
    }    


    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonPesqClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesqClienteActionPerformed
    
        DialogPesqCliente DPCli = new DialogPesqCliente();
        DPCli.setModal(true);
        DPCli.setVisible(true);
        CodCliente = DPCli.CodCliente;
        NomeCliente = DPCli.NomeCliente;
        jTextFieldCodCliente.setText(String.valueOf(CodCliente));
        jTextFieldNome.setText(NomeCliente);
        
        jTextFieldNome.setEditable(false);
        jTextFieldNomeProd.setEnabled(true);
        jButtonPesqProd.setEnabled(true);
        ClienteSel = 1;
        
    }//GEN-LAST:event_jButtonPesqClienteActionPerformed

    private void jButtonRemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRemActionPerformed
       
       int CodRemProduto;
       int QtdVend;
       int qtdEstoque;
       int qtdEstoqueAtual;
       CodRemProduto = Integer.parseInt("" + jTableItensOrcamento.getValueAt(jTableItensOrcamento.getSelectedRow(), 0));
       QtdVend = Integer.parseInt("" + jTableItensOrcamento.getValueAt(jTableItensOrcamento.getSelectedRow(), 3));
       conOrcamento.conecta();
        try {
            conOrcamento.executaSQL("select * from produtos where id_produto='"+CodRemProduto+"'");
            conOrcamento.rs.first();
            qtdEstoque = conOrcamento.rs.getInt("estoque");
            qtdEstoqueAtual = qtdEstoque+QtdVend;
            PreparedStatement pst = conOrcamento.conn.prepareStatement("update produtos set estoque=? where id_produto=?");
            pst.setInt(1, qtdEstoqueAtual);
            pst.setInt(2, CodRemProduto);
            pst.execute();
            conOrcamento.executaSQL("select * from produtos where id_produto='"+CodRemProduto+"'");
            pst = conOrcamento.conn.prepareStatement("delete from vendas_descricao where id_venda=? and id_produto=?");
            pst.setInt(1, CodOrcamento);
            pst.setInt(2, CodRemProduto);
            pst.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao escluir produto da lista.\nErro Código: "+ex);
        }
            jTextFieldCodProd.setText("");
            jTextFieldNomeProd.setText("");
            jTextFieldPrecoProd.setText("0");
            jTextFieldDesconto.setText("0");
            QTD.setValue(1);
            
       preencherTabelaItensOrcamentos("select select orcamentos_descricao.id_orcamento, orcamentos_descricao.id_produto, produtos.produto, produtos.prvenda, orcamentos_descricao.desconto, orcamentos_descricao.qtd_produto, orcamentos_descricao.total_vendido from (orcamentos_descricao inner join produtos on produtos.codigo=orcamentos_descricao.id_produto) where orcamentos_descricao.id_orcamento='"+CodOrcamento+"'");
           
    }//GEN-LAST:event_jButtonRemActionPerformed

    private void jButtonPesqProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesqProdActionPerformed
   
        DialogPesqProdutos DPProd = new DialogPesqProdutos();
        DPProd.setModal(true);
        DPProd.setVisible(true);
        CodProduto = DPProd.CodProduto;
        NomeProduto = DPProd.NomeProduto;
        PrUnit = DPProd.PrecoProduto;
        jTextFieldPrecoProd.setText(String.valueOf(formatoNum.format(PrUnit)));
        jTextFieldCodProd.setText(String.valueOf(CodProduto));
        jTextFieldNomeProd.setText(String.valueOf(NomeProduto));
        QTD.setValue(1);
        jTextFieldDesconto.setText("0");
        
        jTextFieldCodProd.setEnabled(true);
        jTextFieldNomeProd.setEnabled(true);
        jTextFieldPrecoProd.setEnabled(true);
        QTD.setEnabled(true);
        jTextFieldDesconto.setEnabled(true);
        jButtonAdd.setEnabled(true);
        jButtonRem.setEnabled(true);
        
    }//GEN-LAST:event_jButtonPesqProdActionPerformed

    private void jButtonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddActionPerformed
        int qtdDisponivel=0;
        try {
            conOrcamento.conecta();
            conOrcamento.executaSQL("select * from orcamentos_descricao where id_orcamento='"+CodOrcamento+"' and id_produto='"+CodProduto+"'");
            
            if (conOrcamento.rs.first()){
                JOptionPane.showMessageDialog(rootPane, "O Produto já foi adicionado\nRemova-o para readicionar com alterações.");
            }else{
            
            conOrcamento.executaSQL("select * from produtos where codigo='"+jTextFieldCodProd.getText()+"'");
            conOrcamento.rs.first();
            qtdDisponivel = conOrcamento.rs.getInt("quantidade");
            QtdVend = (int) QTD.getValue();
            Desconto = Double.parseDouble(jTextFieldDesconto.getText());
            double ProdVend = (PrUnit*QtdVend); 
            DesconcoCalc = (ProdVend/100)*Desconto;
            TotalProdVend = (ProdVend-DesconcoCalc);
            if (qtdDisponivel >= (int) QTD.getValue()){
            modOrcamento.setIdOrcamento(CodOrcamento);
            modOrcamento.setIdProduto(CodProduto);
            modOrcamento.setNomeProduto(NomeProduto);
            modOrcamento.setPr_venda_prod(PrUnit);
            modOrcamento.setDesconto(Desconto);
            modOrcamento.setQtd_produto((int) QTD.getValue());
            modOrcamento.setTotal_vendido(TotalProdVend);
            controlOrcamento.AddItem(modOrcamento);
            
            } else {
                JOptionPane.showMessageDialog(rootPane, "Quantidade do Item indisponível!\n Quantidade Atual do Item = "+qtdDisponivel+".");
            }
            jTextFieldCodProd.setText("");
            jTextFieldNomeProd.setText("");
            jTextFieldPrecoProd.setText("0");
            jTextFieldDesconto.setText("0");
            QTD.setValue(1);
            }
        } catch (SQLException ex) {
           //JOptionPane.showMessageDialog(rootPane, "erro ao verificar a quantidade! "+ex);
        }
        jTextFieldDesconto.setText("0");
        QTD.setValue(1);
        
//total = total+Double.parseDouble(jTextFieldPrUnit.getText())*Integer.parseInt(jTextFieldQuantidade.getText());
//jTextFieldTotalOrcamento.setText(String.valueOf(total));
preencherTabelaItensOrcamentos("select orcamentos_descricao.id_orcamento, orcamentos_descricao.id_produto, produtos.produto, produtos.prvenda, orcamentos_descricao.desconto, orcamentos_descricao.qtd_produto, orcamentos_descricao.total_vendido from (orcamentos_descricao inner join produtos on produtos.codigo=orcamentos_descricao.id_produto) where orcamentos_descricao.id_orcamento='"+CodOrcamento+"'");

//preencherTabelaItensOrcamentos();
    }//GEN-LAST:event_jButtonAddActionPerformed

    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed
        
        NovaOrcamento = 1;        
        conOrcamento.conecta();
        try {
            PreparedStatement pst = conOrcamento.conn.prepareStatement("insert into orcamentos (valor_orcamento) values (?)");
            pst.setDouble(1, 0);
            pst.execute();
            conOrcamento.executaSQL("select * from orcamentos order by id_orcamento");
            conOrcamento.rs.last();
            CodOrcamento = conOrcamento.rs.getInt("id_orcamento");
            jTextFieldCodOrcamento.setText(String.valueOf(CodOrcamento));            
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao Gerar Novo Orçamento no Banco de Dados!");
        }
        ativaitens();
        
        jButtonNovo.setEnabled(false);
        
    }//GEN-LAST:event_jButtonNovoActionPerformed

    private void jButtonFinalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFinalizarActionPerformed

    if (jComboBoxTipoPag.getSelectedItem().equals("À Vista")){
                modOrcamento.setIdOrcamento(CodOrcamento);
                modOrcamento.setIdCliente(Integer.parseInt(jTextFieldCodCliente.getText()));
                modOrcamento.setDtOrcamento(jFormattedTextFieldDtOrcamento.getText());
                ConverteValor = 0;
                convertValorVirgula(jTextFieldTotalOrcamento.getText());
                modOrcamento.setValorOrcamento(ConverteValor);
                modOrcamento.setTipo_pag(String.valueOf(jComboBoxTipoPag.getSelectedItem()));
                controlOrcamento.FechaOrcamento(modOrcamento);
                PrintOrcamentoAVista();
                dispose();
    }else{
                modOrcamento.setIdOrcamento(CodOrcamento);
                modOrcamento.setIdCliente(Integer.parseInt(jTextFieldCodCliente.getText()));
                modOrcamento.setDtOrcamento(jFormattedTextFieldDtOrcamento.getText());
                ConverteValor = 0;
                convertValorVirgula(jTextFieldTotalOrcamento.getText());
                modOrcamento.setValorOrcamento(ConverteValor);
                modOrcamento.setTipo_pag(String.valueOf(jComboBoxTipoPag.getSelectedItem()));
                controlOrcamento.FechaOrcamento(modOrcamento);
                
                FormParcelaOrcamento frmParcOrc = new FormParcelaOrcamento(CodOrcamento);
                FormPrincipal.AbreNovaJanelaS(frmParcOrc);
                frmParcOrc.setVisible(true);
                dispose();
    }
                
        
        
    }//GEN-LAST:event_jButtonFinalizarActionPerformed

    private void jComboBoxTipoPagActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoPagActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxTipoPagActionPerformed

    private void jTextFieldTotalOrcamentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldTotalOrcamentoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldTotalOrcamentoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSpinner QTD;
    private javax.swing.JButton jButtonAdd;
    private javax.swing.JButton jButtonFinalizar;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonPesqCliente;
    private javax.swing.JButton jButtonPesqProd;
    private javax.swing.JButton jButtonRem;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JComboBox jComboBoxTipoPag;
    private javax.swing.JFormattedTextField jFormattedTextFieldDtOrcamento;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableItensOrcamento;
    private javax.swing.JTextField jTextFieldCodCliente;
    private javax.swing.JTextField jTextFieldCodOrcamento;
    private javax.swing.JTextField jTextFieldCodProd;
    private javax.swing.JTextField jTextFieldDesconto;
    private controle.ClassUpperField jTextFieldNome;
    private controle.ClassUpperField jTextFieldNomeProd;
    private javax.swing.JTextField jTextFieldPrecoProd;
    private javax.swing.JTextField jTextFieldTotalOrcamento;
    // End of variables declaration//GEN-END:variables
}
