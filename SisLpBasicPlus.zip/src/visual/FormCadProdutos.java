/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.ControleProduto;
import controle.PlanodeFundoForms;
import modelo.ModeloProduto;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.io.File;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import static javax.swing.JFileChooser.SELECTED_FILE_CHANGED_PROPERTY;
import javax.swing.JOptionPane;

/**
 *
 * @author Lindembergue
 */
public class FormCadProdutos extends javax.swing.JInternalFrame {
ConectaBanco conProduto = new ConectaBanco();
ModeloProduto ModProduto = new ModeloProduto();
ControleProduto ControlProd = new ControleProduto();
BufferedImage imagem;
FilePreviewer previewer;
int CodCategoria, CodFornecedor, CodProduto, CodMedida, ProdNaoSalvo=0;
String DataHoje;
double MargLucro,PrCusto, PrVenda, ConverteValor; 
DecimalFormat NumFormat = new DecimalFormat("#0.00");
DecimalFormat formatoNumP = new DecimalFormat("#0.0");
public static String NomeJIF = "CadProdutos";



    /**
     * Creates new form FormCadProdutos
     */
    public FormCadProdutos() {
        
        initComponents();
        ColocaImagemFundoFrame();
        jTextFieldCOD.setEditable(false);
        jComboBoxU_medida.setSelectedItem("UN");
        jTextFieldPrCusto.setText("0");
        jTextFieldPrVenda.setText("0");
        preencheCategoria();
        preencheFornecedor();
        preencheUnidadeMedida();
        DesativaItens();
        DesativaEdicaoItens();
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
              
    }

    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
    public void preencheCategoria(){
    
        conProduto.conecta();
        
        try {
            conProduto.executaSQL("select * from fabricantes order by fabricante");
            if (conProduto.rs.first()){
            jComboBoxCate.removeAllItems();
            jComboBoxCate.addItem("Selecione um Fabricante/Marca");
            do{
                jComboBoxCate.addItem(conProduto.rs.getString("fabricante"));
            } while (conProduto.rs.next());
            }else{
                jComboBoxCate.removeAllItems();
                jComboBoxCate.addItem("Cadastre Fabricantes/Marcas");
                JOptionPane.showMessageDialog(rootPane, "Não existe Fabricante ou Marca cadastrados.\nCadastre Fabricantes ou Marcas de Produtos em 'Cadastros / Fabricantes/Marcas'");
                dispose();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao Obter lista de Fabricante/Marca. "+ex);
            //Logger.getLogger(FormCadProdutos.class.getName()).log(Level.SEVERE, null, ex);
        }
        conProduto.desconecta();
    
}
    
    public void preencheFornecedor(){
    
        conProduto.conecta();
        
        try {
            conProduto.executaSQL("select * from fornecedores order by nome");
            if (conProduto.rs.first()){
            jComboBoxFornc.removeAllItems();
            jComboBoxFornc.addItem("Selecione um Fornecedor");
            do{
                jComboBoxFornc.addItem(conProduto.rs.getString("nome"));
            } while (conProduto.rs.next());
            }else{
                jComboBoxFornc.removeAllItems();
            jComboBoxFornc.addItem("Cadastre Fornecedores");
                JOptionPane.showMessageDialog(rootPane, "Não existe Fornecedores cadastrados.\nCadastre Fornecedores em 'Cadastros / Fornecedores'");
                 dispose();
                
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao Obter lista de Fornecedores. "+ex);
            //Logger.getLogger(FormCadProdutos.class.getName()).log(Level.SEVERE, null, ex);
        }
        conProduto.desconecta();
    
}
    
    public void preencheUnidadeMedida(){
        conProduto.conecta();
        try {
            conProduto.executaSQL("select * from medidas order by medida");
            conProduto.rs.first();
            jComboBoxU_medida.removeAllItems();
            do{
                jComboBoxU_medida.addItem(conProduto.rs.getString("medida"));
            } while (conProduto.rs.next());
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao Obter lista de unidade de medidas. "+ex);
            //Logger.getLogger(FormCadProdutos.class.getName()).log(Level.SEVERE, null, ex);
        }
        conProduto.desconecta();
    }
    
    public void convertValorVirgula(String ValorEntrada){
          
        
        if (ValorEntrada.equals("")){
            ValorEntrada = "0";
        }else{
        ConverteValor = Double.parseDouble(ValorEntrada.replace(',', '.'));  
        }
    }
    
    public void DesativaItens(){
        jTextFieldCOD.setEnabled(false);
        jTextFieldProd.setEnabled(false);
        jComboBoxCate.setEnabled(false);
        jComboBoxFornc.setEnabled(false);
        jComboBoxU_medida.setEnabled(false);
        jTextFieldPrCusto.setEnabled(false);
        jTextFieldPrVenda.setEnabled(false);
        jTextFieldMLucro.setEnabled(false);
        jTextFieldQuant.setEnabled(false);
        jTextArea1.setEnabled(false);
        jButtonSalvar.setEnabled(false);
        jTextFieldCodBarras.setEnabled(false);
        jFormattedTextFieldDtAtual.setEnabled(false);
    }
    
    public void DesativaEdicaoItens(){
        jTextFieldCOD.setEditable(false);
        jTextFieldProd.setEditable(false);
        jTextFieldPrCusto.setEditable(false);
        jTextFieldPrVenda.setEditable(false);
        jTextFieldMLucro.setEditable(false);
        jTextFieldQuant.setEditable(false);
        jTextArea1.setEditable(false);
        jFormattedTextFieldDtAtual.setEditable(false);
        jTextFieldCodBarras.setEditable(false);
    }
    
    public void AtivaEdicaoItens(){
        
        jTextFieldProd.setEditable(true);
        jTextFieldPrCusto.setEditable(true);
        jTextFieldPrVenda.setEditable(true);
        jTextFieldMLucro.setEditable(true);
        jTextFieldQuant.setEditable(true);
        jTextArea1.setEditable(true);
        jFormattedTextFieldDtAtual.setEditable(true);
        jTextFieldCodBarras.setEditable(true);
    }
    
    public void AtivaItens(){
        jTextFieldCOD.setEnabled(true);
        jTextFieldProd.setEnabled(true);
        jComboBoxCate.setEnabled(true);
        jComboBoxFornc.setEnabled(true);
        jComboBoxU_medida.setEnabled(true);
        jTextFieldPrCusto.setEnabled(true);
        jTextFieldPrVenda.setEnabled(true);
        jTextFieldMLucro.setEnabled(true);
        jTextFieldQuant.setEnabled(true);
        jTextArea1.setEnabled(true);
        jButtonSalvar.setEnabled(true);
        jTextFieldCodBarras.setEnabled(true);
        jFormattedTextFieldDtAtual.setEnabled(true);
    }
    
    public void LimpaItens(){
        jTextFieldCOD.setText("");
        jTextFieldProd.setText("");
        jComboBoxCate.setSelectedIndex(0);
        jComboBoxFornc.setSelectedIndex(0);
        jComboBoxU_medida.setSelectedItem("UN");
        jTextFieldPrCusto.setText("0");
        jTextFieldPrVenda.setText("0");
        jTextFieldMLucro.setText("0");
        jTextFieldQuant.setText("");
        jTextArea1.setText("");
        jFormattedTextFieldDtAtual.setText("");
        jTextFieldCodBarras.setText("");
    }
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBoxCate = new javax.swing.JComboBox();
        jComboBoxFornc = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextFieldQuant = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jFormattedTextFieldDtAtual = new javax.swing.JFormattedTextField();
        jTextFieldPrCusto = new javax.swing.JTextField();
        jTextFieldPrVenda = new javax.swing.JTextField();
        jTextFieldMLucro = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        jComboBoxU_medida = new javax.swing.JComboBox();
        jLabel15 = new javax.swing.JLabel();
        jTextFieldCodBarras = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jTextFieldProd = new controle.ClassUpperField();
        jTextFieldCOD = new controle.ClassUpperField();
        jButtonSair = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jButtonNovo = new javax.swing.JButton();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        setTitle("Cadastro de Produtos");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Código");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 11, 90, 16);

        jComboBoxCate.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBoxCate.setBorder(null);
        jPanelFundo.add(jComboBoxCate);
        jComboBoxCate.setBounds(310, 80, 290, 25);

        jComboBoxFornc.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBoxFornc.setBorder(null);
        jPanelFundo.add(jComboBoxFornc);
        jComboBoxFornc.setBounds(10, 130, 270, 25);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Produto:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(110, 10, 490, 16);

        jLabel3.setForeground(java.awt.Color.white);
        jLabel3.setText("Categoria:");
        jPanelFundo.add(jLabel3);
        jLabel3.setBounds(310, 60, 290, 16);

        jLabel4.setForeground(java.awt.Color.white);
        jLabel4.setText("Fornecedor:");
        jPanelFundo.add(jLabel4);
        jLabel4.setBounds(10, 110, 250, 16);

        jTextFieldQuant.setBorder(null);
        jPanelFundo.add(jTextFieldQuant);
        jTextFieldQuant.setBounds(170, 180, 140, 25);

        jLabel5.setForeground(java.awt.Color.white);
        jLabel5.setText("Preço de Custo R$:");
        jPanelFundo.add(jLabel5);
        jLabel5.setBounds(290, 110, 150, 16);

        jLabel6.setForeground(java.awt.Color.white);
        jLabel6.setText("Preço de Venda R$:");
        jPanelFundo.add(jLabel6);
        jLabel6.setBounds(450, 110, 150, 16);

        jLabel7.setForeground(java.awt.Color.white);
        jLabel7.setText("Marg. de Luco %");
        jPanelFundo.add(jLabel7);
        jLabel7.setBounds(10, 160, 150, 16);

        jLabel8.setForeground(java.awt.Color.white);
        jLabel8.setText("Quantidade/ Estoque");
        jPanelFundo.add(jLabel8);
        jLabel8.setBounds(170, 160, 140, 16);

        jTextArea1.setColumns(20);
        jTextArea1.setLineWrap(true);
        jTextArea1.setRows(5);
        jTextArea1.setWrapStyleWord(true);
        jTextArea1.setBorder(null);
        jScrollPane1.setViewportView(jTextArea1);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 230, 590, 70);

        jLabel9.setForeground(java.awt.Color.white);
        jLabel9.setText("Obs:");
        jPanelFundo.add(jLabel9);
        jLabel9.setBounds(10, 210, 590, 16);

        jLabel11.setForeground(java.awt.Color.white);
        jLabel11.setText("Data de Atualização:");
        jPanelFundo.add(jLabel11);
        jLabel11.setBounds(320, 160, 130, 16);

        jFormattedTextFieldDtAtual.setBorder(null);
        jPanelFundo.add(jFormattedTextFieldDtAtual);
        jFormattedTextFieldDtAtual.setBounds(320, 180, 130, 25);

        jTextFieldPrCusto.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldPrCusto.setBorder(null);
        jTextFieldPrCusto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldPrCustoKeyReleased(evt);
            }
        });
        jPanelFundo.add(jTextFieldPrCusto);
        jTextFieldPrCusto.setBounds(290, 130, 150, 25);

        jTextFieldPrVenda.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldPrVenda.setBorder(null);
        jTextFieldPrVenda.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextFieldPrVendaFocusLost(evt);
            }
        });
        jPanelFundo.add(jTextFieldPrVenda);
        jTextFieldPrVenda.setBounds(450, 130, 150, 25);

        jTextFieldMLucro.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldMLucro.setBorder(null);
        jTextFieldMLucro.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                jTextFieldMLucroFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                jTextFieldMLucroFocusLost(evt);
            }
        });
        jTextFieldMLucro.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldMLucroKeyReleased(evt);
            }
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldMLucroKeyTyped(evt);
            }
        });
        jPanelFundo.add(jTextFieldMLucro);
        jTextFieldMLucro.setBounds(10, 180, 150, 25);

        jLabel14.setForeground(java.awt.Color.white);
        jLabel14.setText("Tipo de Unidade/Med:");
        jPanelFundo.add(jLabel14);
        jLabel14.setBounds(460, 160, 140, 16);

        jComboBoxU_medida.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBoxU_medida.setBorder(null);
        jPanelFundo.add(jComboBoxU_medida);
        jComboBoxU_medida.setBounds(460, 180, 140, 25);

        jLabel15.setForeground(java.awt.Color.white);
        jLabel15.setText("Produto:");
        jPanelFundo.add(jLabel15);
        jLabel15.setBounds(110, 10, 260, 16);

        jTextFieldCodBarras.setBorder(null);
        jPanelFundo.add(jTextFieldCodBarras);
        jTextFieldCodBarras.setBounds(10, 80, 280, 25);

        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Código de Barras:");
        jPanelFundo.add(jLabel16);
        jLabel16.setBounds(10, 60, 280, 16);
        jPanelFundo.add(jTextFieldProd);
        jTextFieldProd.setBounds(110, 30, 490, 25);
        jPanelFundo.add(jTextFieldCOD);
        jTextFieldCOD.setBounds(10, 30, 90, 25);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 10, 610, 310);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(530, 330, 90, 40);

        jButtonSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/accept.png"))); // NOI18N
        jButtonSalvar.setText("Salvar");
        jButtonSalvar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSalvar);
        jButtonSalvar.setBounds(440, 330, 90, 40);

        jButtonNovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/add.png"))); // NOI18N
        jButtonNovo.setText("Novo");
        jButtonNovo.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonNovo);
        jButtonNovo.setBounds(350, 330, 90, 40);

        setBounds(300, 50, 635, 408);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
        if (ProdNaoSalvo==1){
            ModProduto.setId(CodProduto);
            ControlProd.ExcluiDados(ModProduto);
            dispose();
        }else{
            dispose();
        }
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed
        conProduto.conecta();
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date hoje = new Date();
        //jFormattedTextFieldData.setText(df.format(hoje));
        DataHoje = (df.format(hoje));
        jFormattedTextFieldDtAtual.setText(DataHoje);

                try {
                    PreparedStatement pst = conProduto.conn.prepareStatement("insert into produtos (produto,fornecedor,fabricante,data_atual) values (?,?,?,?)");
                    pst.setString(1, "nome");
                    pst.setInt(2, 1);
                    pst.setInt(3, 1);
                    pst.setString(4, DataHoje);
                    pst.execute();
                    conProduto.executaSQL("select * from produtos order by Codigo");
                    conProduto.rs.last();
                    CodProduto = conProduto.rs.getInt("Codigo");
                    ModProduto.setId(CodProduto);
                    ProdNaoSalvo=1;
                    jTextFieldCOD.setText(String.valueOf(CodProduto));
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(rootPane, ex);
                    Logger.getLogger(FormCadClientes.class.getName()).log(Level.SEVERE, null, ex);
                }
        conProduto.desconecta();
        ProdNaoSalvo=1;
        AtivaItens();
        AtivaEdicaoItens();
        jButtonNovo.setEnabled(false);
        jButtonSalvar.setEnabled(true);


    }//GEN-LAST:event_jButtonNovoActionPerformed

    private void jTextFieldMLucroKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldMLucroKeyTyped

    }//GEN-LAST:event_jTextFieldMLucroKeyTyped

    private void jTextFieldMLucroKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldMLucroKeyReleased

    }//GEN-LAST:event_jTextFieldMLucroKeyReleased

    private void jTextFieldMLucroFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldMLucroFocusGained
    
    }//GEN-LAST:event_jTextFieldMLucroFocusGained

    private void jTextFieldMLucroFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldMLucroFocusLost

       String marLucroc;
       marLucroc = jTextFieldMLucro.getText();

        if (marLucroc == "" ){
            JOptionPane.showMessageDialog(rootPane, "Margem de Lucro não foi preenchida.");
        }if (marLucroc == "0") {
            JOptionPane.showMessageDialog(rootPane, "Margem de Lucro não pode ser igual a 0");
        } else{
            ConverteValor = 0;
            convertValorVirgula(jTextFieldPrCusto.getText());
            PrCusto = ConverteValor;
            ConverteValor = 0;
            convertValorVirgula(jTextFieldMLucro.getText());
            MargLucro = ConverteValor;
            PrVenda = (MargLucro*(PrCusto/100))+PrCusto;
            jTextFieldPrVenda.setText(String.valueOf(NumFormat.format(PrVenda)));
        }  
      
    }//GEN-LAST:event_jTextFieldMLucroFocusLost

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed

    String NomeCategoriaSel = String.valueOf(jComboBoxCate.getSelectedItem());
    String NomeFornecedorSel = String.valueOf(jComboBoxFornc.getSelectedItem());
    String NomeUnidadeMedida = String.valueOf(jComboBoxU_medida.getSelectedItem());
    int IndexCategoria = jComboBoxCate.getSelectedIndex();
    int IndexFornecedor = jComboBoxFornc.getSelectedIndex();
    ProdNaoSalvo=0;



if (IndexCategoria == 0){
    JOptionPane.showMessageDialog(rootPane, "Selecione uma Fabricante/Marca.");
}

if (IndexFornecedor == 0) {
    JOptionPane.showMessageDialog(rootPane, "Selecione um Forncedor para esse Produto.");
} else {

        conProduto.conecta();
        try {
            conProduto.executaSQL("select * from fabricantes where fabricante='"+NomeCategoriaSel+"'");
            conProduto.rs.first();
            CodCategoria = conProduto.rs.getInt("codigo");
            //JOptionPane.showMessageDialog(rootPane, "Categoria: "+CodCategoria);
            conProduto.executaSQL("select * from fornecedores where nome='"+NomeFornecedorSel+"'");
            conProduto.rs.first();
            CodFornecedor = conProduto.rs.getInt("Codigo");
           //JOptionPane.showMessageDialog(rootPane, "Fornecedor: "+CodFornecedor);
            conProduto.executaSQL("select * from medidas where medida='"+NomeUnidadeMedida+"'");
            conProduto.rs.first();
            CodMedida = conProduto.rs.getInt("Codigo");
            
        } catch (SQLException ex) {
            Logger.getLogger(FormCadProdutos.class.getName()).log(Level.SEVERE, null, ex);
        }
        conProduto.desconecta();
        
        ModProduto.setNome(jTextFieldProd.getText());
        ModProduto.setCat_id(CodCategoria);
        ModProduto.setForn_id(CodFornecedor);
        ConverteValor = 0;
        convertValorVirgula(jTextFieldPrCusto.getText());
        ModProduto.setPr_custo(ConverteValor);
        
        ConverteValor = 0;
        convertValorVirgula(jTextFieldPrVenda.getText());
        ModProduto.setPr_venda(ConverteValor);
        
        ConverteValor = 0;
        convertValorVirgula(jTextFieldMLucro.getText());
        ModProduto.setM_lucro(ConverteValor);
        
        ModProduto.setEstoque(Integer.parseInt(jTextFieldQuant.getText()));
        ModProduto.setObs(jTextArea1.getText());
        ModProduto.setDt_atual(jFormattedTextFieldDtAtual.getText());
        ModProduto.setId(CodProduto);
        ModProduto.setU_medida(CodMedida);
        ModProduto.setCodBarras(jTextFieldCodBarras.getText());
        ControlProd.SalvaDados(ModProduto);
        LimpaItens();
        DesativaItens();
        DesativaEdicaoItens();
        jButtonNovo.setEnabled(true);
        jButtonSalvar.setEnabled(false);
}
    }
    
public class FilePreviewer extends JComponent implements
            PropertyChangeListener {

        ImageIcon thumbnail = null;

        @SuppressWarnings("LeakingThisInConstructor")
        public FilePreviewer(JFileChooser fc) {
            setPreferredSize(new Dimension(100, 50));
            fc.addPropertyChangeListener(this);
        }

        public void loadImage(File f) {
            if (f == null) {
                thumbnail = null;
            } else {
                ImageIcon tmpIcon = new ImageIcon(f.getPath());
                if (tmpIcon.getIconWidth() > 90) {
                    thumbnail = new ImageIcon(
                            tmpIcon.getImage().getScaledInstance(90, -1,
                            Image.SCALE_DEFAULT));
                } else {
                    thumbnail = tmpIcon;
                }
            }
        }

        public void propertyChange(PropertyChangeEvent e) {
            String prop = e.getPropertyName();
            if (SELECTED_FILE_CHANGED_PROPERTY.equals(prop)) {
                if (isShowing()) {
                    loadImage((File) e.getNewValue());
                    repaint();
                }
            }
        }

        @Override
        public void paint(Graphics g) {
            if (thumbnail != null) {
                int x = getWidth() / 2 - thumbnail.getIconWidth() / 2;
                int y = getHeight() / 2 - thumbnail.getIconHeight() / 2;
                if (y < 0) {
                    y = 0;
                }

                if (x < 5) {
                    x = 5;
                }
                thumbnail.paintIcon(this, g, x, y);
            }
        
        }
        
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jTextFieldPrVendaFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_jTextFieldPrVendaFocusLost
        ConverteValor = 0;
        convertValorVirgula(jTextFieldPrVenda.getText());
        PrVenda = ConverteValor;

        if (PrVenda == 0){
                JOptionPane.showMessageDialog(rootPane, "Preco de Venda nao pode ser igual a 0");
        } else{
                ConverteValor = 0;
                convertValorVirgula(jTextFieldPrCusto.getText());
                PrCusto = ConverteValor;

                double MargLucroCalc1 = (PrVenda-PrCusto)/PrCusto;
                double MargLucroCalc2 = ((MargLucroCalc1)*100);
                MargLucro = (MargLucroCalc2);
                jTextFieldMLucro.setText(String.valueOf(formatoNumP.format(MargLucroCalc2)));
        }   
// TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldPrVendaFocusLost

    private void jTextFieldPrCustoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldPrCustoKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldPrCustoKeyReleased

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JComboBox jComboBoxCate;
    private javax.swing.JComboBox jComboBoxFornc;
    private javax.swing.JComboBox jComboBoxU_medida;
    private javax.swing.JFormattedTextField jFormattedTextFieldDtAtual;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextArea1;
    private controle.ClassUpperField jTextFieldCOD;
    private javax.swing.JTextField jTextFieldCodBarras;
    private javax.swing.JTextField jTextFieldMLucro;
    private javax.swing.JTextField jTextFieldPrCusto;
    private javax.swing.JTextField jTextFieldPrVenda;
    private controle.ClassUpperField jTextFieldProd;
    private javax.swing.JTextField jTextFieldQuant;
    // End of variables declaration//GEN-END:variables
}
