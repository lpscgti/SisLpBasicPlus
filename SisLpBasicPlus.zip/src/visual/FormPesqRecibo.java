/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.ConnectionFactory2;
import controle.ControleEmpresa;
import controle.ControleRelatorios;
import controle.PlanodeFundoForms;
import modelo.ModeloTabela;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPopupMenu;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;

/**
 *
 * @author Lindembergue
 */
public class FormPesqRecibo extends javax.swing.JInternalFrame {
    ConectaBanco conPesProd = new ConectaBanco();
    ControleRelatorios ctrlRel = new ControleRelatorios();
    String Usuario, UsuTipo, caminhoDb;
    int CodRecibo;
    DecimalFormat formatoNum = new DecimalFormat("#,##0.00");
    public static String NomeJIF = "FormPesqRecibo";
    ControleEmpresa ctrl_de = new ControleEmpresa();
    
    /**
     * Creates new form FormPesqRecibo
     */
    public FormPesqRecibo() {  
        
        initComponents();
        ColocaImagemFundoFrame();
        jTextFieldCampoPesquisa.grabFocus();
        jComboBoxTipoPesquisa.setSelectedIndex(1);
        preencherTablePesquisaOS("select * from recibo order by codigo desc");
        jTextFieldCampoPesquisa.grabFocus();
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
        jbPrintRec.setEnabled(false);
        AcaoAoteclarEnter();
    }
    
    private void AcaoAoteclarEnter() {
        jTablePesquisaOS.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "Enter");
        jTablePesquisaOS.getActionMap().put("Enter", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                PrintRecibo();
            }
        });
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
    

    public void preencherTablePesquisaOS(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Código","Nome","Referência","Valor R$","Data"};
        conPesProd.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conPesProd.executaSQL(SQL);
        
        try {
            conPesProd.rs.first();
            //JOptionPane.showMessageDialog(rootPane, conOsPesquisa.rs.getString("id"));
            do{
                dados.add(new Object[]{conPesProd.rs.getString("codigo"), conPesProd.rs.getString("nome"), conPesProd.rs.getString("referencia"), String.valueOf(formatoNum.format(conPesProd.rs.getDouble("valor"))), conPesProd.rs.getString("data")});
            }while(conPesProd.rs.next());
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane,"Erro ao Obter Dados. \n Informação digitada não encontrada.");
        }
        
        DefaultTableCellRenderer cellRenderD = new DefaultTableCellRenderer();
        cellRenderD.setHorizontalAlignment(SwingConstants.RIGHT);
        
        DefaultTableCellRenderer cellRenderE = new DefaultTableCellRenderer();
        cellRenderD.setHorizontalAlignment(SwingConstants.CENTER);
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTablePesquisaOS.setModel(modelo);
        jTablePesquisaOS.getColumnModel().getColumn(0).setPreferredWidth(50);
        jTablePesquisaOS.getColumnModel().getColumn(0).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(1).setPreferredWidth(260);
        jTablePesquisaOS.getColumnModel().getColumn(1).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(2).setPreferredWidth(270);
        jTablePesquisaOS.getColumnModel().getColumn(2).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(3).setCellRenderer(cellRenderD);
        jTablePesquisaOS.getColumnModel().getColumn(3).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(3).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(3).setCellRenderer(cellRenderD);
        jTablePesquisaOS.getColumnModel().getColumn(4).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(4).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(3).setCellRenderer(cellRenderE);
        jTablePesquisaOS.getTableHeader().setReorderingAllowed(false);
        jTablePesquisaOS.setAutoResizeMode(jTablePesquisaOS.AUTO_RESIZE_OFF);
        jTablePesquisaOS.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conPesProd.desconecta();
              
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jComboBoxTipoPesquisa = new javax.swing.JComboBox();
        jButtonPesquisar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisaOS = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldCampoPesquisa = new controle.ClassUpperField();
        jButtonExcluir = new javax.swing.JButton();
        jButtonSair = new javax.swing.JButton();
        jbPrintRec = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setTitle("Recibos Gerados");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jComboBoxTipoPesquisa.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Cód. Recibo", "Nome", "Data", "Todas" }));
        jComboBoxTipoPesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoPesquisaActionPerformed(evt);
            }
        });
        jPanelFundo.add(jComboBoxTipoPesquisa);
        jComboBoxTipoPesquisa.setBounds(10, 30, 170, 30);

        jButtonPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/Search44Resultado.png"))); // NOI18N
        jButtonPesquisar.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesquisar);
        jButtonPesquisar.setBounds(750, 30, 40, 30);

        jTablePesquisaOS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTablePesquisaOS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePesquisaOSMouseClicked(evt);
            }
        });
        jTablePesquisaOS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTablePesquisaOSKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTablePesquisaOS);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 70, 780, 350);

        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Pesquisar por:");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 10, 170, 20);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Digite aqui os dados a pesquisar:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(180, 10, 610, 20);

        jTextFieldCampoPesquisa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldCampoPesquisaKeyReleased(evt);
            }
        });
        jPanelFundo.add(jTextFieldCampoPesquisa);
        jTextFieldCampoPesquisa.setBounds(180, 30, 570, 30);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 10, 800, 430);

        jButtonExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jButtonExcluir.setText("Excluir");
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonExcluir);
        jButtonExcluir.setBounds(630, 450, 90, 40);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(720, 450, 90, 40);

        jbPrintRec.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/printer.png"))); // NOI18N
        jbPrintRec.setText("Imprimir");
        jbPrintRec.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbPrintRecActionPerformed(evt);
            }
        });
        getContentPane().add(jbPrintRec);
        jbPrintRec.setBounds(530, 450, 100, 40);

        setBounds(0, 0, 823, 530);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarActionPerformed
        //        Cód. Cliente  = 0
        //        Nome Cliente  = 1
        //        Categoria     = 2
        //        Data Cadastro = 3
        //        Todas         = 4

        int CampoEscolhido = (jComboBoxTipoPesquisa.getSelectedIndex());

        String DadosParaPesquisar = jTextFieldCampoPesquisa.getText();

        //preencherTablePesquisaOS("select os.id, clientes.nome_cliente, os.dt_abertura, funcionarios.nome_funcionario, os.status, os.total_os from os join clientes on clientes.id_cliente=os.id_cliente  join funcionarios on funcionarios.id_funcionario=os.id_funcionario where nome_cliente='%"+DadosParaPesquisar+"%'");

        if (CampoEscolhido == 0 ){
            if ("".equals(jTextFieldCampoPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite o codigo do Recibo para pesquisar.");
            } else {
                int idCliente = Integer.parseInt(DadosParaPesquisar);
                preencherTablePesquisaOS("select * from recibo where codigo='"+idCliente+"'");
            }
        }

        if (CampoEscolhido == 1){
            preencherTablePesquisaOS("select * from recibo  where nome like '"+DadosParaPesquisar+"%'");
        }
        
        if (CampoEscolhido == 2){
            preencherTablePesquisaOS("select * from recibo where data like '"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 3){
            preencherTablePesquisaOS("select * from recibo order by cdate(format(data, 'dd/mm/yyyy')) desc");
        }
        else{
            //JOptionPane.showMessageDialog(rootPane, "Erro ao Pesquisar dados!");
        }
    }//GEN-LAST:event_jButtonPesquisarActionPerformed

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed
    
        int is = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente Excluir?","Confirmando Exclusão", JOptionPane.YES_NO_OPTION);
        if(is == JOptionPane.YES_OPTION) {
        conPesProd.conecta();
        int codProdSel = jTablePesquisaOS.getSelectedRow();
        if (codProdSel==(-1)){
            JOptionPane.showMessageDialog(rootPane, "Por favor, selecione um Item cadastrado.");
        } else {String codProdx = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
            int cdCli = Integer.parseInt(codProdx);
            try {
            PreparedStatement pst = conPesProd.conn.prepareStatement("delete  from recibo where codigo=?");
            pst.setInt(1, cdCli);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
            } catch (SQLException ex) {
           JOptionPane.showMessageDialog(null, "Erro ao Excluir dados\n Erro código: "+ex);
            }
        }preencherTablePesquisaOS("select * from recibo order by data desc");
        }
    
        
        
        
   
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
dispose();
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jTextFieldCampoPesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldCampoPesquisaKeyReleased
        
         //        Cód. Cliente  = 0
        //        Nome Cliente  = 1
        //        Categoria     = 2
        //        Data Cadastro = 3
        //        Todas         = 4

        int CampoEscolhido = (jComboBoxTipoPesquisa.getSelectedIndex());

        String DadosParaPesquisar = jTextFieldCampoPesquisa.getText();

        //preencherTablePesquisaOS("select os.id, clientes.nome_cliente, os.dt_abertura, funcionarios.nome_funcionario, os.status, os.total_os from os join clientes on clientes.id_cliente=os.id_cliente  join funcionarios on funcionarios.id_funcionario=os.id_funcionario where nome_cliente='%"+DadosParaPesquisar+"%'");

        if (CampoEscolhido == 0 ){
            if ("".equals(jTextFieldCampoPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite o codigo do Recibo para pesquisar.");
            } else {
                int idCliente = Integer.parseInt(DadosParaPesquisar);
                preencherTablePesquisaOS("select * from recibo where codigo='"+idCliente+"'");
            }
        }

        if (CampoEscolhido == 1){
            preencherTablePesquisaOS("select * from recibo  where nome like '"+DadosParaPesquisar+"%'");
        }
        
        if (CampoEscolhido == 2){
            preencherTablePesquisaOS("select * from recibo where data like '"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 3){
            preencherTablePesquisaOS("select * from recibo order by cdate(format(data, 'dd/mm/yyyy')) desc");
        }
        else{
            //JOptionPane.showMessageDialog(rootPane, "Erro ao Pesquisar dados!");
        }
        
    }//GEN-LAST:event_jTextFieldCampoPesquisaKeyReleased

    private void jComboBoxTipoPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoPesquisaActionPerformed
        jTextFieldCampoPesquisa.grabFocus();
    }//GEN-LAST:event_jComboBoxTipoPesquisaActionPerformed

    private void jTablePesquisaOSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePesquisaOSMouseClicked
        
        String codOStex = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
        CodRecibo = Integer.parseInt(codOStex);
        jbPrintRec.setText("Reimprimir Recibo: "+codOStex);
        jbPrintRec.setEnabled(true);
        
    }//GEN-LAST:event_jTablePesquisaOSMouseClicked

    private void jbPrintRecActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbPrintRecActionPerformed
        
        PrintRecibo();
        
    }//GEN-LAST:event_jbPrintRecActionPerformed

    private void jTablePesquisaOSKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTablePesquisaOSKeyReleased
        if (evt.getKeyCode()==KeyEvent.VK_UP || evt.getKeyCode()==KeyEvent.VK_DOWN){
            if (jbPrintRec.isEnabled()==false){
                jbPrintRec.setEnabled(true);
            }
            String codOStex = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
            CodRecibo = Integer.parseInt(codOStex);
            jbPrintRec.setText("Reimprimir Recibo: "+codOStex);
            
        }else if(evt.getKeyCode()==KeyEvent.VK_ENTER){
//            FormAbreEditaOSF FrmAbreOSF = new FormAbreEditaOSF();
//            FrmAbreOSF.AbreOS(cdOS);
//            FormPrincipal.AbreNovaJanela(FrmAbreOSF,1);
//            dispose();
        }
    }//GEN-LAST:event_jTablePesquisaOSKeyReleased

  
    
    public void MenuControlePrint(){
    
    JMenuItem item1 = new JMenuItem("Imprimir Recibo Selecionado.");
    item1.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent e) {
        
            
            PrintRecibo();
            
        }
    });
     
    //cria o menu popup e adiciona os 3 itens
    JPopupMenu popup = new JPopupMenu();
    popup.setPreferredSize(new Dimension(200,60));
    popup.setBackground(Color.WHITE);
    item1.setBackground(Color.WHITE);
    popup.add(item1);
        
    //mostra na tela
    popup.show(jTablePesquisaOS, 55, 0);
    
    }
    
    public  void PrintRecibo(){
        ctrl_de.Obtem_Dados_da_Empresa();
        int i = JOptionPane.showConfirmDialog(rootPane, "Reimpressão de Recibo, Continuar? ","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
                                if(i == JOptionPane.YES_OPTION) {
                                                                      
                                try {
                                    try {
                                        Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                                        Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                                        Map<String, Object> parametros = new HashMap<String, Object>();
                                        Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                                        //dados empresa
                                        parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                                        parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                                        parametros.put( "cnpj", ctrl_de.de_cnpj );
                                        parametros.put( "de_ie", ctrl_de.de_ie );
                                        parametros.put( "endereco", ctrl_de.de_endereco );
                                        parametros.put( "bairro", ctrl_de.de_bairro );
                                        parametros.put( "cidade", ctrl_de.de_cidade );
                                        parametros.put( "estado", ctrl_de.de_estado );
                                        parametros.put( "cep", ctrl_de.de_cep );
                                        parametros.put( "telefone1", ctrl_de.de_fone1 );
                                        parametros.put( "telefone2", ctrl_de.de_fone2 );
                                        parametros.put( "de_site", ctrl_de.de_site );
                                        parametros.put( "email", ctrl_de.de_email );
                                        parametros.put("logoimg",imagePath);
                                        parametros.put( "idrecibo", CodRecibo );
                                        JasperPrint jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraRecibo.jasper", parametros, ConnectionFactory2.getSlpConnection());
                                        JRViewer viewer = new JRViewer(jpPrint);
                                        viewer.setZoomRatio((float) 0.5);
                                        JFrame frameRelatorio = new JFrame();
                                        frameRelatorio.add( viewer, BorderLayout.CENTER );
                                        frameRelatorio.setTitle("Recibo Gerado");
                                        frameRelatorio.setSize( 500, 500 );
                                        frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                                        frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                                        frameRelatorio.setVisible( true );
                                    } catch (SQLException ex) {
                                        Logger.getLogger(FormPesqCliente.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                    } catch (JRException ex) {
                                    JOptionPane.showMessageDialog(null, "Erro ao Gerar Comprovante de Recibo para Impressão!\nErro: "+ex);
                                    }
                                jbPrintRec.setEnabled(false);
                                                                
                                }
                                
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonPesquisar;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JComboBox jComboBoxTipoPesquisa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisaOS;
    private controle.ClassUpperField jTextFieldCampoPesquisa;
    private javax.swing.JButton jbPrintRec;
    // End of variables declaration//GEN-END:variables
}
