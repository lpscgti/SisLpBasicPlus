/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.ConnectionFactory2;
import controle.ControleEmpresa;
import controle.ControleRelatorios;
import controle.PlanodeFundoForms;
import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import java.nio.file.Path;
import java.nio.file.Paths;
import modelo.ModeloTabela;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;

/**
 *
 * @author Lindembergue
 */
public class FormPesqOrcamento extends javax.swing.JInternalFrame {
ConectaBanco conPesProd = new ConectaBanco();
ControleRelatorios ctrlRel = new ControleRelatorios();
String Usuario, UsuTipo;
int cdOr, CodConta;
double TotalProd;
DecimalFormat formatoNum = new DecimalFormat("#0.00");
SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
ControleEmpresa ctrl_de = new ControleEmpresa();

    /**
     * Creates new form FormPesqProduto
     */
    public FormPesqOrcamento() {
       
        initComponents();
        ColocaImagemFundoFrame();
        jTextFieldCampoPesquisa.grabFocus();
        jComboBoxTipoPesquisa.setSelectedIndex(1);
        preencherTablePesquisaOS("select orcamentos.id_orcamento, orcamentos.valor_orcamento, clientes.nome, orcamentos.data_orcamento, orcamentos.tipo_pag from (orcamentos inner join clientes on clientes.codigo=orcamentos.id_cliente) order by data_orcamento desc");
        jTextFieldCampoPesquisa.grabFocus();
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
        jbPrintOrc.setEnabled(false);
        AcaoAoteclarEnter();
        
    }
    
    private void AcaoAoteclarEnter() {
        jTablePesquisaOS.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "Enter");
        jTablePesquisaOS.getActionMap().put("Enter", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                ctrlRel.RePrintOrcamento(cdOr);
            }
        });
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
    public void toUpperCase(String texto, java.awt.event.KeyEvent evento){
        evento.setKeyChar(texto.toUpperCase().charAt(0));
    }
    
    public void preencherTablePesquisaOS(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Código","Cliente","Data","Valor","Cond."};
        conPesProd.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conPesProd.executaSQL(SQL);
        try {
            conPesProd.rs.first();
           
            //JOptionPane.showMessageDialog(rootPane, conOsPesquisa.rs.getString("id"));
            do{
                dados.add(new Object[]{conPesProd.rs.getInt("id_orcamento"),  conPesProd.rs.getString("nome"), df.format(conPesProd.rs.getDate("data_orcamento")), String.valueOf(formatoNum.format(conPesProd.rs.getDouble("valor_orcamento"))), conPesProd.rs.getString("tipo_pag")});
            }while(conPesProd.rs.next());
            
        } catch (SQLException ex) {
            //JOptionPane.showMessageDialog(rootPane,"Erro ao Obter Dados. \n Informação digitada não encontrada.");
        }
        DefaultTableCellRenderer cellRenderD = new DefaultTableCellRenderer();
        cellRenderD.setHorizontalAlignment(SwingConstants.RIGHT);
        
        DefaultTableCellRenderer cellRenderC = new DefaultTableCellRenderer();
        cellRenderC.setHorizontalAlignment(SwingConstants.CENTER);
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTablePesquisaOS.setModel(modelo);
        jTablePesquisaOS.getColumnModel().getColumn(0).setPreferredWidth(80);
        jTablePesquisaOS.getColumnModel().getColumn(0).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(0).setCellRenderer(cellRenderD);
        jTablePesquisaOS.getColumnModel().getColumn(1).setPreferredWidth(308);
        jTablePesquisaOS.getColumnModel().getColumn(1).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(2).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(2).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(2).setCellRenderer(cellRenderC);
        jTablePesquisaOS.getColumnModel().getColumn(3).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(3).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(3).setCellRenderer(cellRenderD);
        jTablePesquisaOS.getColumnModel().getColumn(4).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(4).setResizable(false);
        jTablePesquisaOS.getTableHeader().setReorderingAllowed(false);
        jTablePesquisaOS.setAutoResizeMode(jTablePesquisaOS.AUTO_RESIZE_OFF);
        jTablePesquisaOS.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        conPesProd.desconecta();
    }
    
    
    public void PrintOSParce(){
        
        conPesProd.conecta();
        conPesProd.executaSQL("select * from orcamentos_descricao where id_orcamento='"+cdOr+"'");
        TotalProd = 0;
        try {
            if(conPesProd.rs.first()){
                do{
                    TotalProd = TotalProd+conPesProd.rs.getDouble("total_vendido");
                }while(conPesProd.rs.next());
            }
        } catch (SQLException ex) {
            Logger.getLogger(FormParcelaOrcamento.class.getName()).log(Level.SEVERE, null, ex);
        }
        conPesProd.desconecta();
        
        int i = JOptionPane.showConfirmDialog(rootPane, "Deseja realizar a impressão do Comprovante?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
                if(i == JOptionPane.YES_OPTION) {
                   
                    try {
                            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                            Map<String, Object> parametros = new HashMap<String, Object>();
                            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                            //dados empresa
                            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                            parametros.put( "cnpj", ctrl_de.de_cnpj );
                            parametros.put( "de_ie", ctrl_de.de_ie );
                            parametros.put( "endereco", ctrl_de.de_endereco );
                            parametros.put( "bairro", ctrl_de.de_bairro );
                            parametros.put( "cidade", ctrl_de.de_cidade );
                            parametros.put( "estado", ctrl_de.de_estado );
                            parametros.put( "cep", ctrl_de.de_cep );
                            parametros.put( "telefone1", ctrl_de.de_fone1 );
                            parametros.put( "telefone2", ctrl_de.de_fone2 );
                            parametros.put( "de_site", ctrl_de.de_site );
                            parametros.put( "email", ctrl_de.de_email );
                            parametros.put("logoimg",imagePath);
                            parametros.put( "CodConta", CodConta );
                            parametros.put("TotProds",TotalProd);
                            JasperPrint jpPrint;
                            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteOrcAP.jasper", parametros, ConnectionFactory2.getSlpConnection());
                            JRViewer viewer = new JRViewer(jpPrint);
                            viewer.setZoomRatio((float) 0.5);
                            JFrame frameRelatorio = new JFrame();
                            frameRelatorio.add( viewer, BorderLayout.CENTER );
                            frameRelatorio.setTitle("Comprovante de Parcelamento");
                            frameRelatorio.setSize( 500, 500 );
                            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                            frameRelatorio.setVisible( true );
                    }   catch (SQLException ex) {
                            Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
                    }   catch (JRException ex) {
                            Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
                    }
                   
            }
    }
    
    public void PrintOSParceEntrada(){
        
        conPesProd.conecta();
        conPesProd.executaSQL("select * from orcamentos_descricao where id_orcamento='"+cdOr+"'");
        TotalProd = 0;
        try {
            if(conPesProd.rs.first()){
                do{
                    TotalProd = TotalProd+conPesProd.rs.getDouble("total_vendido");
                }while(conPesProd.rs.next());
            }
        } catch (SQLException ex) {
            Logger.getLogger(FormParcelaOrcamento.class.getName()).log(Level.SEVERE, null, ex);
        }
        conPesProd.desconecta();
        
        int i = JOptionPane.showConfirmDialog(rootPane, "Deseja realizar a impressão do Comprovante?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
                if(i == JOptionPane.YES_OPTION) {
                   
                    try {
                            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                            Map<String, Object> parametros = new HashMap<String, Object>();
                            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                            //dados empresa
                            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                            parametros.put( "cnpj", ctrl_de.de_cnpj );
                            parametros.put( "de_ie", ctrl_de.de_ie );
                            parametros.put( "endereco", ctrl_de.de_endereco );
                            parametros.put( "bairro", ctrl_de.de_bairro );
                            parametros.put( "cidade", ctrl_de.de_cidade );
                            parametros.put( "estado", ctrl_de.de_estado );
                            parametros.put( "cep", ctrl_de.de_cep );
                            parametros.put( "telefone1", ctrl_de.de_fone1 );
                            parametros.put( "telefone2", ctrl_de.de_fone2 );
                            parametros.put( "de_site", ctrl_de.de_site );
                            parametros.put( "email", ctrl_de.de_email );
                            parametros.put("logoimg",imagePath);
                            parametros.put( "CodConta", CodConta );
                            parametros.put("TotProds",TotalProd);
                            JasperPrint jpPrint;
                            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteOrcAPEntrada.jasper", parametros, ConnectionFactory2.getSlpConnection());
                            JRViewer viewer = new JRViewer(jpPrint);
                            viewer.setZoomRatio((float) 0.5);
                            JFrame frameRelatorio = new JFrame();
                            frameRelatorio.add( viewer, BorderLayout.CENTER );
                            frameRelatorio.setTitle("Comprovante de Parcelamento");
                            frameRelatorio.setSize( 500, 500 );
                            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                            frameRelatorio.toFront();
                            frameRelatorio.setVisible( true );
                    }   catch (SQLException ex) {
                            Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
                    }   catch (JRException ex) {
                            Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
                    }
                   
            }
                                            
    }
    
    public void PrintOrcamentoAVista(){
        int i = JOptionPane.showConfirmDialog(rootPane, "Orçamento gerado com sucesso.\nDeseja realizar a impressão?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
                                if(i == JOptionPane.YES_OPTION) {
                               
                                try {
                                    Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                                    Map<String, Object> parametros = new HashMap<String, Object>();
                                    Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                                    //dados empresa
                                    parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                                    parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                                    parametros.put( "cnpj", ctrl_de.de_cnpj );
                                    parametros.put( "de_ie", ctrl_de.de_ie );
                                    parametros.put( "endereco", ctrl_de.de_endereco );
                                    parametros.put( "bairro", ctrl_de.de_bairro );
                                    parametros.put( "cidade", ctrl_de.de_cidade );
                                    parametros.put( "estado", ctrl_de.de_estado );
                                    parametros.put( "cep", ctrl_de.de_cep );
                                    parametros.put( "telefone1", ctrl_de.de_fone1 );
                                    parametros.put( "telefone2", ctrl_de.de_fone2 );
                                    parametros.put( "de_site", ctrl_de.de_site );
                                    parametros.put( "email", ctrl_de.de_email );
                                    parametros.put("logoimg",imagePath);
                                    parametros.put( "idvenda", cdOr );
                                    JasperPrint jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraOrcamentoAVista.jasper", parametros, ConnectionFactory2.getConnection2());
                                    JRViewer viewer = new JRViewer(jpPrint);
                                    viewer.setZoomRatio((float) 0.5);
                                    JFrame frameRelatorio = new JFrame();
                                    frameRelatorio.add( viewer, BorderLayout.CENTER );
                                    frameRelatorio.setTitle("Novo Orcamento Gerado");
                                    frameRelatorio.setSize( 500, 500 );
                                    frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                                    frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                                    Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                                    frameRelatorio.toFront();
                                    frameRelatorio.setVisible( true );
                                    }catch (JRException ex) {
                                    JOptionPane.showMessageDialog(null, "Erro ao Gerar Orcamento para Impressão!/nErro: "+ex);
                                    } catch (SQLException ex) {
                Logger.getLogger(FormOrcamento.class.getName()).log(Level.SEVERE, null, ex);
            }
            //conOs.desconecta(); //conOs.desconecta(); //conOs.desconecta(); //conOs.desconecta();
             //conOs.desconecta(); //conOs.desconecta(); //conOs.desconecta(); //conOs.desconecta();
                                
                                }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBoxTipoPesquisa = new javax.swing.JComboBox();
        jButtonPesquisar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisaOS = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldCampoPesquisa = new controle.ClassUpperField();
        jButtonSair = new javax.swing.JButton();
        jButtonNovaVenda = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jbPrintOrc = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setTitle("Orçamentos Efetuados");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Pesquisar por:");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 10, 190, 16);

        jComboBoxTipoPesquisa.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Código", "Cliente", "Data", "Funcionário", "Todas" }));
        jComboBoxTipoPesquisa.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));
        jComboBoxTipoPesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoPesquisaActionPerformed(evt);
            }
        });
        jPanelFundo.add(jComboBoxTipoPesquisa);
        jComboBoxTipoPesquisa.setBounds(10, 30, 190, 30);

        jButtonPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/Search44Resultado.png"))); // NOI18N
        jButtonPesquisar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));
        jButtonPesquisar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesquisar);
        jButtonPesquisar.setBounds(690, 30, 40, 30);

        jTablePesquisaOS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTablePesquisaOS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePesquisaOSMouseClicked(evt);
            }
        });
        jTablePesquisaOS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTablePesquisaOSKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTablePesquisaOS);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 70, 720, 370);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Digite aqui os dados a pesquisar:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(200, 10, 530, 16);

        jTextFieldCampoPesquisa.setBorder(null);
        jPanelFundo.add(jTextFieldCampoPesquisa);
        jTextFieldCampoPesquisa.setBounds(200, 30, 490, 30);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 11, 740, 449);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(650, 470, 100, 40);

        jButtonNovaVenda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/add.png"))); // NOI18N
        jButtonNovaVenda.setText("Novo");
        jButtonNovaVenda.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonNovaVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovaVendaActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonNovaVenda);
        jButtonNovaVenda.setBounds(450, 470, 100, 40);

        jButtonExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jButtonExcluir.setText("Excluir");
        jButtonExcluir.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonExcluir);
        jButtonExcluir.setBounds(550, 470, 100, 40);

        jbPrintOrc.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/printer.png"))); // NOI18N
        jbPrintOrc.setText("Imprimir");
        jbPrintOrc.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbPrintOrc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbPrintOrcActionPerformed(evt);
            }
        });
        getContentPane().add(jbPrintOrc);
        jbPrintOrc.setBounds(350, 470, 100, 40);

        setBounds(0, 0, 759, 541);
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxTipoPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoPesquisaActionPerformed
        jTextFieldCampoPesquisa.grabFocus();
    }//GEN-LAST:event_jComboBoxTipoPesquisaActionPerformed

    private void jButtonPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarActionPerformed
        

        int CampoEscolhido = (jComboBoxTipoPesquisa.getSelectedIndex());

        String DadosParaPesquisar = jTextFieldCampoPesquisa.getText();

        //preencherTablePesquisaOS("select os.id, clientes.nome_cliente, os.dt_abertura, funcionarios.nome_funcionario, os.status, os.total_os from os join clientes on clientes.id_cliente=os.id_cliente  join funcionarios on funcionarios.id_funcionario=os.id_funcionario where nome_cliente='%"+DadosParaPesquisar+"%'");

        if (CampoEscolhido == 0 ){
            if ("".equals(jTextFieldCampoPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite o codigo da Orçamento para pesquisar.");
            } else {
                int idCliente = Integer.parseInt(DadosParaPesquisar);
                preencherTablePesquisaOS("select orcamentos.id_orcamento, orcamentos.valor_orcamento, clientes.nome, orcamentos.data_orcamento from (orcamentos inner join clientes on clientes.codigo=orcamentos.id_cliente) where orcamentos.id_orcamento='"+idCliente+"'");
            }
        }

        if (CampoEscolhido == 1){
            preencherTablePesquisaOS("select orcamentos.id_orcamento, orcamentos.valor_orcamento, clientes.nome, orcamentos.data_orcamento from (orcamentos inner join clientes on clientes.codigo=orcamentos.id_cliente) where clientes.nome like '"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 2){
            preencherTablePesquisaOS("select orcamentos.id_orcamento, orcamentos.valor_orcamento, clientes.nome, orcamentos.data_orcamento from (orcamentos inner join clientes on clientes.codigo=orcamentos.id_cliente) where orcamentos.data_orcamento like '"+DadosParaPesquisar+"%'");
        }
        
        if (CampoEscolhido == 3){
            preencherTablePesquisaOS("select orcamentos.id_orcamento, orcamentos.valor_orcamento, clientes.nome, orcamentos.data_orcamento from (orcamentos inner join clientes on clientes.codigo=orcamentos.id_cliente) by orcamentos.data_orcamento desc");
        }
        else{
            //JOptionPane.showMessageDialog(rootPane, "Erro ao Pesquisar dados!");
        }
    }//GEN-LAST:event_jButtonPesquisarActionPerformed

    private void jTablePesquisaOSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePesquisaOSMouseClicked
        
        jbPrintOrc.setEnabled(true);
        String codOStex = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
        cdOr = Integer.parseInt(codOStex);
        jbPrintOrc.setText("Reimprimir Orçamento: "+codOStex);
        
            
        
    }//GEN-LAST:event_jTablePesquisaOSMouseClicked

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
        dispose();
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonNovaVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovaVendaActionPerformed
    FormOrcamento FrmOrc = new FormOrcamento();
    FormPrincipal.AbreNovaJanelaS(FrmOrc);
    dispose();
    }//GEN-LAST:event_jButtonNovaVendaActionPerformed

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed
if (FormPrincipal.UsuarioPermissao.equals("2")){
    
    int is = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente Excluir?","Confirmando Exclusão", JOptionPane.YES_NO_OPTION);
    if(is == JOptionPane.YES_OPTION) {
        conPesProd.conecta();
        int codVendaSel = jTablePesquisaOS.getSelectedRow();
        if (codVendaSel==(-1)){
            JOptionPane.showMessageDialog(rootPane, "Por favor, selecione um Item cadastrado.");
        } else {String codProdx = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
            int cdVenda = Integer.parseInt(codProdx);
            
               
            try {
            
            PreparedStatement pst = conPesProd.conn.prepareStatement("delete  from orcamentos_descricao where id_orcamento=?");
            pst.setInt(1, cdVenda);
            pst.execute();
            pst = conPesProd.conn.prepareStatement("delete  from orcamentos where id_orcamento=?");
            pst.setInt(1, cdVenda);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
            } catch (SQLException ex) {
                Logger.getLogger(FormPesqOrcamento.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        preencherTablePesquisaOS("select orcamentos.id_orcamento, orcamentos.valor_orcamento, clientes.nome, orcamentos.data_orcamento, orcamentos.tipo_pag from (orcamentos inner join clientes on clientes.codigo=orcamentos.id_cliente) order by data_orcamento desc");
        }   
}else{
    JOptionPane.showMessageDialog(null, "Você nao possui permissão\n para executar esta ação.");
}
        
    
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jTextFieldCampoPesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldCampoPesquisaKeyReleased

        int CampoEscolhido = (jComboBoxTipoPesquisa.getSelectedIndex());

        String DadosParaPesquisar = jTextFieldCampoPesquisa.getText();

        //preencherTablePesquisaOS("select os.id, clientes.nome_cliente, os.dt_abertura, funcionarios.nome_funcionario, os.status, os.total_os from os join clientes on clientes.id_cliente=os.id_cliente  join funcionarios on funcionarios.id_funcionario=os.id_funcionario where nome_cliente='%"+DadosParaPesquisar+"%'");

        if (CampoEscolhido == 0 ){
            if ("".equals(jTextFieldCampoPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite o codigo da Orçamento para pesquisar.");
            } else {
                int idCliente = Integer.parseInt(DadosParaPesquisar);
                preencherTablePesquisaOS("select orcamentos.id_orcamento, orcamentos.valor_orcamento, clientes.nome, orcamentos.data_orcamento from (orcamentos inner join clientes on clientes.codigo=orcamentos.id_cliente) where orcamentos.id_orcamento='"+idCliente+"'");
            }
        }

        if (CampoEscolhido == 1){
            preencherTablePesquisaOS("select orcamentos.id_orcamento, orcamentos.valor_orcamento, clientes.nome, orcamentos.data_orcamento from (orcamentos inner join clientes on clientes.codigo=orcamentos.id_cliente) where clientes.nome like '"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 2){
            preencherTablePesquisaOS("select orcamentos.id_orcamento, orcamentos.valor_orcamento, clientes.nome, orcamentos.data_orcamento from (orcamentos inner join clientes on clientes.codigo=orcamentos.id_cliente) where orcamentos.data_orcamento like '"+DadosParaPesquisar+"%'");
        }
        
        if (CampoEscolhido == 3){
            preencherTablePesquisaOS("select orcamentos.id_orcamento, orcamentos.valor_orcamento, clientes.nome, orcamentos.data_orcamento from (orcamentos inner join clientes on clientes.codigo=orcamentos.id_cliente) by orcamentos.data_orcamento desc");
        }
        else{
            //JOptionPane.showMessageDialog(rootPane, "Erro ao Pesquisar dados!");
        }
        
    }//GEN-LAST:event_jTextFieldCampoPesquisaKeyReleased

    private void jbPrintOrcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbPrintOrcActionPerformed
        
           ctrlRel.RePrintOrcamento(cdOr);
            
    }//GEN-LAST:event_jbPrintOrcActionPerformed

    private void jTablePesquisaOSKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTablePesquisaOSKeyReleased
        if (evt.getKeyCode()==KeyEvent.VK_UP || evt.getKeyCode()==KeyEvent.VK_DOWN){
            if (jbPrintOrc.isEnabled()==false){
                jbPrintOrc.setEnabled(true);
            }
            String codOStex = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
            cdOr = Integer.parseInt(codOStex);
            jbPrintOrc.setText("Reimprimir Orçamento: "+codOStex);
            
        }else if(evt.getKeyCode()==KeyEvent.VK_ENTER){
//            FormAbreEditaOSF FrmAbreOSF = new FormAbreEditaOSF();
//            FrmAbreOSF.AbreOS(cdOS);
//            FormPrincipal.AbreNovaJanela(FrmAbreOSF,1);
//            dispose();
        }
    }//GEN-LAST:event_jTablePesquisaOSKeyReleased
    
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonNovaVenda;
    private javax.swing.JButton jButtonPesquisar;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JComboBox jComboBoxTipoPesquisa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisaOS;
    private controle.ClassUpperField jTextFieldCampoPesquisa;
    private javax.swing.JButton jbPrintOrc;
    // End of variables declaration//GEN-END:variables
}
