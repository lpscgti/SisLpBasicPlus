/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import java.awt.Toolkit;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author ProgXBERGUE
 */
public class FormLicenciamento extends javax.swing.JFrame {
    ConectaBanco conLic = new ConectaBanco();
    String Serial, SerialD, DataIni, DataVenc, DataRenova, DataConvertidaString, chavedesbloqueio,DataHoje,   DataFormatada;
    java.sql.Date DataInicialTeste, DataAnteriorTeste, DtHoje;
    int Licenciado, TempoTesteRestante;
    long DataTempoMili;
    public String login, senha, nome, permissao;
    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    java.sql.Date DataConvertidaSQL;
    Date hoje0 = new Date();
    PreparedStatement pst;
    public static String NomeJIF = "FormLicenciamento";
    
    /**
     * Creates new form FormLicenciamento
     */
    public FormLicenciamento() {
        initComponents();
        DataHoje = (df.format(hoje0));
        ObtemDados();
        ObtemChaveDesbloqueio();
        Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
        this.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoTXT+"/"+"SisLpICO.png"));
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
    }
    
    public void ObtemDados(){
        conLic.conecta();
        conLic.executaSQL("select * from licenciamento where codigo=1");
        try {
            
            if (conLic.rs.first()){
                
                Serial = conLic.rs.getString("serial");
                DataIni = conLic.rs.getString("datainst");
                DataVenc = conLic.rs.getString("datavenc");
                DataRenova = conLic.rs.getString("datarenova");
                chavedesbloqueio = conLic.rs.getString("chavedesbloqueio");
                DataInicialTeste = conLic.rs.getDate("data_i_teste");
                Licenciado = conLic.rs.getInt("licenciado");
                TempoTesteRestante = conLic.rs.getInt("tempo_restante_teste");
                DataAnteriorTeste = conLic.rs.getDate("data_a_teste");
                VerificaNumerodeSerie();
                
                if (Licenciado==0&&TempoTesteRestante>0){
                    jbtTestar.setText("Testar - Dias Restante: "+TempoTesteRestante);
                    jbtTestar.setEnabled(true);
                }else{
                    jbtTestar.setText("Testar - Dias Restante: 0");
                    jbtTestar.setEnabled(false);
                }
                
            }
        } catch (SQLException ex) {
            Logger.getLogger(FormLicenciamento.class.getName()).log(Level.SEVERE, null, ex);
        }
        conLic.desconecta();
    }
    
     public void ConvertDataParaString(java.sql.Date Data){
        
        DataConvertidaString = df.format(Data);
        
    }
    
    public void ConverteStringparaData(String Data){
        
        String dia = "" + Data.charAt(0) + Data.charAt(1);
        String mes = "" + Data.charAt(3) + Data.charAt(4);
        String ano = "" + Data.charAt(6) + Data.charAt(7) + Data.charAt(8) + Data.charAt(9);
        String dtfSQLData = ano+"-"+mes+"-"+dia;
        DataConvertidaSQL = java.sql.Date.valueOf(dtfSQLData);
        
    }
    
    public void VerificaNumerodeSerie(){
        if (Serial==null||Serial.equals("")){
            DataIni = DataHoje;
            jtfDataInst.setText(DataIni);
            String dia = "" + DataIni.charAt(0) + DataIni.charAt(1);
            String mes = "" + DataIni.charAt(3) + DataIni.charAt(4);
            String ano = "" + DataIni.charAt(6) + DataIni.charAt(7) + DataIni.charAt(8) + DataIni.charAt(9);
            long numerosData = Integer.parseInt(dia+mes+ano);
            Serial = String.valueOf((numerosData*999000));
            jtfSerial.setText(Serial);
            
            conLic.conecta();
            try {
                pst = conLic.conn.prepareStatement("update licenciamento set serial=?, datainst=?, datarenova=? where codigo=?");
                pst.setString(1, Serial);
                pst.setString(2, DataIni);
                pst.setString(3, DataIni);
                pst.setInt(4, 1);
                pst.execute();
            } catch (SQLException ex) {
                Logger.getLogger(FormLicenciamento.class.getName()).log(Level.SEVERE, null, ex);
            }
            conLic.desconecta();
            
        }else{
            jtfSerial.setText(Serial);
            jtfDataInst.setText(DataIni);
        }
    }
    
    public void ObtemChaveDesbloqueio(){
       
        String dia, mes, ano;
        dia = "" + DataIni.charAt(0) + DataIni.charAt(1);
        mes = "" + DataIni.charAt(3) + DataIni.charAt(4);
        ano = "" + DataIni.charAt(6) + DataIni.charAt(7) + DataIni.charAt(8) + DataIni.charAt(9);
        int numeroData = Integer.parseInt(dia+mes+ano);
        long codBloq = Long.parseLong(Serial);
        chavedesbloqueio = String.valueOf((codBloq*999000)+numeroData);
    }

    public void AbreFormPrincipal(){
        FormPrincipal formP = new FormPrincipal();
        formP.ObterUsuarioSenha(nome, senha, permissao);
        Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
        File arquivo = new File(caminhoTXT+"/"+"sislp.ico.png");
        formP.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoTXT+"/"+"sislp.ico.png"));
        formP.setVisible(true);
    }
    
    public void VerificaDataRenivacao(){
        
    }
    
    public void QuebraData(String data){
        
        String dia = "" + data.charAt(0) + data.charAt(1);
        String mes = "" + data.charAt(3) + data.charAt(4);
        String ano = "" + data.charAt(6) + data.charAt(7) + data.charAt(8) + data.charAt(9);
    
        DataFormatada = ano+"-"+mes+"-"+dia;
        
     }
    
    public void ConvertDataSQLparaTempoMiliseconds(java.sql.Date Data){
         try {    
            GregorianCalendar dtV = new GregorianCalendar();  
            String DataConvertida = df.format(Data);
            dtV.setTime(df.parse(DataConvertida));
            DataTempoMili = dtV.getTimeInMillis();
        } catch (ParseException ex) {
            Logger.getLogger(FormLicenciamento.class.getName()).log(Level.SEVERE, null, ex);
        }
            
    }
    
    public void ValidaTeste(){
        conLic.conecta();
        PreparedStatement pst;
        ConverteStringparaData(DataHoje);
        DtHoje = DataConvertidaSQL;
        ConvertDataSQLparaTempoMiliseconds(DtHoje);
        long DtHojeMili = DataTempoMili;
        DataTempoMili = 0;
        long DtITesteMili = 0;
        long DtAnteriorMili = 0;
        
        if(DataInicialTeste==null){
                    
                    try {
                        pst = conLic.conn.prepareStatement("update licenciamento set data_i_teste=? where codigo=?");
                        pst.setDate(1, DtHoje);
                        pst.setInt(2, 1);
                        pst.execute();
                    } catch (SQLException ex) {
                        Logger.getLogger(FormLicenciamento.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    ConvertDataSQLparaTempoMiliseconds(DtHoje);
                    DtITesteMili = DataTempoMili;
                    DataTempoMili = 0;
                    
        }else{
            ConvertDataSQLparaTempoMiliseconds(DataInicialTeste);
            DtITesteMili = DataTempoMili;
            DataTempoMili = 0;
        }
        
        if (DataAnteriorTeste==null){
            DtAnteriorMili = 0;
        }else{
            ConvertDataSQLparaTempoMiliseconds(DataAnteriorTeste);
            DtAnteriorMili = DataTempoMili;
            DataTempoMili = 0;
        }
        
        
        if (Licenciado==0){
//            JOptionPane.showMessageDialog(rootPane, "Tempo T Rest: "+TempoTesteRestante);
            if (TempoTesteRestante>0&&TempoTesteRestante<=30){
                
                
//                JOptionPane.showMessageDialog(rootPane, "dtHojeMili: "+DtHojeMili+" dtAnteriorMili: "+DtAnteriorMili);
                if (DtHojeMili>DtAnteriorMili){
                    try {
                        pst = conLic.conn.prepareStatement("update licenciamento set tempo_restante_teste=?, data_a_teste=? where codigo=?");
                        pst.setInt(1, TempoTesteRestante-1);
                        pst.setDate(2, DtHoje);
                        pst.setInt(3, 1);
                        pst.execute();
                        AbreFormPrincipal();
                        dispose();
                    } catch (SQLException ex) {
                        Logger.getLogger(FormLicenciamento.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    
                }else if (DtHojeMili==DtAnteriorMili){
                    
                    AbreFormPrincipal();
                    dispose();
                
                }else if (DtHojeMili<DtAnteriorMili||DtHojeMili<DtITesteMili){
                    try {
                        pst = conLic.conn.prepareStatement("update licenciamento set tempo_restante_teste=? where codigo=?");
                        pst.setInt(1, TempoTesteRestante-1);
                        pst.setInt(2, 1);
                        pst.execute();
                        AbreFormPrincipal();
                        dispose();
                    } catch (SQLException ex) {
                        Logger.getLogger(FormLicenciamento.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        }
        conLic.desconecta();
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jtfSerial = new javax.swing.JTextField();
        jtfLicenciamento = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jbtSair = new javax.swing.JButton();
        jbtLic = new javax.swing.JButton();
        jtfDataInst = new javax.swing.JTextField();
        jbtTestar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Licenciamento");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                AoFechar(evt);
            }
        });
        getContentPane().setLayout(null);

        jLabel1.setText("Serial:");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(10, 10, 400, 20);

        jtfSerial.setEditable(false);
        jtfSerial.setForeground(java.awt.Color.blue);
        getContentPane().add(jtfSerial);
        jtfSerial.setBounds(10, 30, 400, 22);
        getContentPane().add(jtfLicenciamento);
        jtfLicenciamento.setBounds(10, 130, 400, 22);

        jLabel2.setText("Data da instalação:");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(10, 60, 370, 20);

        jLabel3.setText("Numero de Licenciamento:");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(10, 110, 400, 20);

        jbtSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jbtSair.setText("Sair");
        jbtSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtSairActionPerformed(evt);
            }
        });
        getContentPane().add(jbtSair);
        jbtSair.setBounds(310, 160, 100, 40);

        jbtLic.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/Files-textResultado.png"))); // NOI18N
        jbtLic.setText("Licenciar");
        jbtLic.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtLicActionPerformed(evt);
            }
        });
        getContentPane().add(jbtLic);
        jbtLic.setBounds(210, 160, 100, 40);

        jtfDataInst.setEditable(false);
        jtfDataInst.setForeground(java.awt.Color.blue);
        getContentPane().add(jtfDataInst);
        jtfDataInst.setBounds(10, 80, 160, 22);

        jbtTestar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/eye.png"))); // NOI18N
        jbtTestar.setText("Testar - Dias Restante:");
        jbtTestar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtTestarActionPerformed(evt);
            }
        });
        getContentPane().add(jbtTestar);
        jbtTestar.setBounds(10, 160, 200, 40);

        setSize(new java.awt.Dimension(440, 242));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void jbtSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtSairActionPerformed
        System.exit(0);
    }//GEN-LAST:event_jbtSairActionPerformed

    private void jbtLicActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtLicActionPerformed
        if (jtfLicenciamento.getText().equals("")){
            JOptionPane.showMessageDialog(rootPane, "Digite o Código de Desbloqueio.");
        } else {       
        
                if (chavedesbloqueio.equals(jtfLicenciamento.getText())){
                    conLic.conecta();
                    try {
                        Date hojeCalc = new Date();
                        hojeCalc.setDate(hojeCalc.getDate()+366);
                        DataVenc = df.format(hojeCalc);
                        pst = conLic.conn.prepareStatement("update licenciamento set datarenova=?, chavedesbloqueio=?, licenciado=? where codigo=?");
                        pst.setString(1, DataVenc);
                        pst.setString(2, chavedesbloqueio);
                        pst.setInt(3, 1);
                        pst.setInt(4, 1);
                        pst.execute();
                    } catch (SQLException ex) {
                        Logger.getLogger(FormLicenciamento.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    conLic.desconecta();
                    AbreFormPrincipal();
                    dispose(); 
                }else{
                    JOptionPane.showMessageDialog(rootPane, "Serial não Corresponde.");
                    jtfLicenciamento.setText("");
                    jtfLicenciamento.grabFocus();
                }
        }
    }//GEN-LAST:event_jbtLicActionPerformed

    private void jbtTestarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtTestarActionPerformed
        ValidaTeste();
    }//GEN-LAST:event_jbtTestarActionPerformed

    private void AoFechar(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_AoFechar
        System.exit(0);
    }//GEN-LAST:event_AoFechar

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormLicenciamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormLicenciamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormLicenciamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormLicenciamento.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormLicenciamento().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JButton jbtLic;
    private javax.swing.JButton jbtSair;
    private javax.swing.JButton jbtTestar;
    private javax.swing.JTextField jtfDataInst;
    private javax.swing.JTextField jtfLicenciamento;
    private javax.swing.JTextField jtfSerial;
    // End of variables declaration//GEN-END:variables
}
