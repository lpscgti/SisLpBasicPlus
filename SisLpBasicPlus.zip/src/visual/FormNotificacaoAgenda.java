/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import java.awt.event.ComponentEvent;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import static visual.FormPrincipal.AreaDeTrabalhoPrincipal;

/**
 *
 * @author Lindembergue
 */
public class FormNotificacaoAgenda extends javax.swing.JInternalFrame {
    ConectaBanco ConNotAg = new ConectaBanco();
    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat hf1 = new SimpleDateFormat("HH:mm");
    Clip oClip;
    /**
     * Creates new form FormNotificacaoAgenda
     */
    public FormNotificacaoAgenda() {
        initComponents();
        AcessaDados();
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
        
    }

   
    public void TocaSom() throws IOException, SQLException{
            
            ConNotAg.conecta();
            
            ConNotAg.executaSQL("select * from config_agenda where codigo=1");
            if (ConNotAg.rs.first()){
                
                if(ConNotAg.rs.getInt("usarsom")==1){
                    try {
                    Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
                    File file = new File(caminhoTXT+"/"+"SomNotAgenda.wav");
                    // Carrega o arquivo de áudio (não funciona com .mp3, só .wav) 
//                    URL oUrl = new URL(caminhoTXT+"/"+"SomNotAgenda.wav");
                    
                    oClip = AudioSystem.getClip();
                    
                    AudioInputStream oStream = AudioSystem.getAudioInputStream(file);
                    oClip.open(oStream);
                    
                    if(ConNotAg.rs.getInt("somnot")==0){
                        oClip.loop(0); // Toca uma vez
                    }else{
                        oClip.loop(Clip.LOOP_CONTINUOUSLY);
                    //clip.loop(Clip.LOOP_CONTINUOUSLY); // Toca continuamente (para o caso de músicas)
                    }
                        
                    
                    } catch (LineUnavailableException ex) {
                        Logger.getLogger(FormNotificacaoAgenda.class.getName()).log(Level.SEVERE, null, ex);
                    } catch (UnsupportedAudioFileException ex) {
                        Logger.getLogger(FormNotificacaoAgenda.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                
            }
            ConNotAg.desconecta();
        }
            
    
    
    public void AcessaDados(){
        
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat hf = new SimpleDateFormat("HH:mm:ss");
        Date hoje = new Date();
        String Data = (df.format(hoje));
        String Hora = (hf.format(hoje));
    
            String dhh = ""+Hora.charAt(0)+Hora.charAt(1);
            String dmm = ""+Hora.charAt(3)+Hora.charAt(4);
            String dss = ""+Hora.charAt(6)+Hora.charAt(7);
            String dDD = ""+Data.charAt(0)+Data.charAt(1);
            String dMM = ""+Data.charAt(3)+Data.charAt(4);
            String dYYYY = ""+Data.charAt(6)+Data.charAt(7)+Data.charAt(8)+Data.charAt(9);
            
            String HoraM = dhh+":"+dmm+":"+dss;
            String DataM = dYYYY+"-"+dMM+"-"+dDD;
            System.out.println(DataM);
            System.out.println(HoraM);
            java.sql.Date DtI = java.sql.Date.valueOf(DataM);
        
        ConNotAg.conecta();
        
        ConNotAg.executaSQL("select * from agenda where data<=#"+DtI+" 22:50:00# and hora<=#"+DtI+" "+HoraM+"# and situacao='AGUARDANDO'");
        try {
            if (ConNotAg.rs.first()){
                String Mensagem = ConNotAg.rs.getString("titulo")+"\n"+ConNotAg.rs.getString("descricao")+" às "+hf1.format(ConNotAg.rs.getTime("hora"))+" de Prioridade "+ConNotAg.rs.getInt("prioridade")+". \n";
                jTextAreaMensagem.setText(Mensagem);
                 while (ConNotAg.rs.next()){
                 Mensagem = Mensagem+"\n"+ConNotAg.rs.getString("titulo")+"\n"+ConNotAg.rs.getString("descricao")+" às "+hf1.format(ConNotAg.rs.getTime("hora"))+" de Prioridade "+ConNotAg.rs.getInt("prioridade")+". \n";
                 jTextAreaMensagem.setText(Mensagem);
            }
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(FormNotificacaoAgenda.class.getName()).log(Level.SEVERE, null, ex);
        }
        ConNotAg.desconecta();
        try {
            TocaSom();
        } catch (IOException ex) {
            Logger.getLogger(FormNotificacaoAgenda.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(FormNotificacaoAgenda.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTextAreaMensagem = new javax.swing.JTextArea();
        jButtonAbriAgenda = new javax.swing.JButton();
        jButtonFecha = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setTitle("Notificação da Agenda");
        setToolTipText("Informação sobre Compromissos Agendados.");
        addInternalFrameListener(new javax.swing.event.InternalFrameListener() {
            public void internalFrameActivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameClosed(javax.swing.event.InternalFrameEvent evt) {
                AoFechar(evt);
            }
            public void internalFrameClosing(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeactivated(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameDeiconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameIconified(javax.swing.event.InternalFrameEvent evt) {
            }
            public void internalFrameOpened(javax.swing.event.InternalFrameEvent evt) {
                ExecutarAoAbrirJanela(evt);
            }
        });
        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentMoved(java.awt.event.ComponentEvent evt) {
                formComponentMoved(evt);
            }
        });
        getContentPane().setLayout(null);

        jTextAreaMensagem.setEditable(false);
        jTextAreaMensagem.setColumns(20);
        jTextAreaMensagem.setFont(new java.awt.Font("Times New Roman", 2, 18)); // NOI18N
        jTextAreaMensagem.setForeground(new java.awt.Color(51, 153, 255));
        jTextAreaMensagem.setLineWrap(true);
        jTextAreaMensagem.setRows(5);
        jTextAreaMensagem.setWrapStyleWord(true);
        jScrollPane1.setViewportView(jTextAreaMensagem);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(10, 11, 230, 120);

        jButtonAbriAgenda.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jButtonAbriAgenda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/open folderResultado.png"))); // NOI18N
        jButtonAbriAgenda.setText("Abrir Agenda");
        jButtonAbriAgenda.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonAbriAgenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAbriAgendaActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAbriAgenda);
        jButtonAbriAgenda.setBounds(10, 140, 110, 30);

        jButtonFecha.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        jButtonFecha.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jButtonFecha.setText("Fechar Mensagem");
        jButtonFecha.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonFecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFechaActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonFecha);
        jButtonFecha.setBounds(130, 140, 110, 30);

        setBounds(0, 0, 250, 206);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonFechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFechaActionPerformed
        oClip.stop();
        dispose();
    }//GEN-LAST:event_jButtonFechaActionPerformed

    private void jButtonAbriAgendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAbriAgendaActionPerformed
        FormAgenda FrmAgenda;
        FrmAgenda = new FormAgenda();
        FormPrincipal.AbreNovaJanelaS(FrmAgenda);
        oClip.stop();
        dispose();
    }//GEN-LAST:event_jButtonAbriAgendaActionPerformed

    private void formComponentMoved(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentMoved
                int lDesk = AreaDeTrabalhoPrincipal.getWidth();
                int aDesk = AreaDeTrabalhoPrincipal.getHeight();
                int lIFrame = this.getWidth();
                int aIFrame = this.getHeight();
                setLocation((lDesk - 10) - lIFrame , 10);
    }//GEN-LAST:event_formComponentMoved

    private void ExecutarAoAbrirJanela(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_ExecutarAoAbrirJanela
        try {
            TocaSom();
        } catch (IOException ex) {
            Logger.getLogger(FormNotificacaoAgenda.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(FormNotificacaoAgenda.class.getName()).log(Level.SEVERE, null, ex);
        }
        FormPrincipal.RetornoNotAgenda = 1;
        
    }//GEN-LAST:event_ExecutarAoAbrirJanela

    private void AoFechar(javax.swing.event.InternalFrameEvent evt) {//GEN-FIRST:event_AoFechar
        FormPrincipal.RetornoNotAgenda = 0;
    }//GEN-LAST:event_AoFechar

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAbriAgenda;
    private javax.swing.JButton jButtonFecha;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextAreaMensagem;
    // End of variables declaration//GEN-END:variables
}
