/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.ConnectionFactory2;
import controle.ControleEmpresa;
import java.awt.BorderLayout;
import java.awt.Image;
import java.nio.file.Path;
import java.nio.file.Paths;
import modelo.ModeloTabela;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;

/**
 *
 * @author ProgXBERGUE
 */
public class FormContasRecebidas extends javax.swing.JInternalFrame {
    ConectaBanco conCR = new ConectaBanco();
    DecimalFormat formatoNum = new DecimalFormat("#,##0.00");
    ControleEmpresa ctrl_de = new ControleEmpresa();
    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    
    int CodConta, CodContaHis;
    String DtAbertura,DocOrigem, TipoDocOrigem, Cliente, DtRecebimento, sql;
    double ValorRec, RestPag, ValorPag, RestPagA;
    java.sql.Date DataConvertidaSQL;
    public static String NomeJIF = "FormContasRecebidas";
    PreparedStatement pst;
    /**
     * Creates new form FormContasRecebidas
     */
    public FormContasRecebidas() {
        initComponents();
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
        jbPrint.setEnabled(false);
        atualizaTabela();
    }
    
    public void ConvertDataParaString(java.sql.Date Data){
        
        df.format(Data);
        
    }
    
    public void ConverteStringparaData(String Data){
        
        String dia = "" + Data.charAt(0) + Data.charAt(1);
        String mes = "" + Data.charAt(3) + Data.charAt(4);
        String ano = "" + Data.charAt(6) + Data.charAt(7) + Data.charAt(8) + Data.charAt(9);
        String dtfSQLData = ano+"-"+mes+"-"+dia;
        DataConvertidaSQL = java.sql.Date.valueOf(dtfSQLData);
        
    }
    
    public void Print(int CodConta){
        int i = JOptionPane.showConfirmDialog(rootPane, "Deseja realizar a impressão do comprovante?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
            if(i == JOptionPane.YES_OPTION) {
                ctrl_de.Obtem_Dados_da_Empresa();
                try {
                    Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                    Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                    Map<String, Object> parametros = new HashMap<String, Object>();
                    Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                    //dados empresa
                    parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                    parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                    parametros.put( "cnpj", ctrl_de.de_cnpj );
                    parametros.put( "de_ie", ctrl_de.de_ie );
                    parametros.put( "endereco", ctrl_de.de_endereco );
                    parametros.put( "bairro", ctrl_de.de_bairro );
                    parametros.put( "cidade", ctrl_de.de_cidade );
                    parametros.put( "estado", ctrl_de.de_estado );
                    parametros.put( "cep", ctrl_de.de_cep );
                    parametros.put( "telefone1", ctrl_de.de_fone1 );
                    parametros.put( "telefone2", ctrl_de.de_fone2 );
                    parametros.put( "de_site", ctrl_de.de_site );
                    parametros.put( "email", ctrl_de.de_email );
                    parametros.put("logoimg",imagePath);
                    parametros.put( "idconta", CodConta );
                    JasperPrint jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteContaReceber.jasper", parametros, ConnectionFactory2.getSlpConnection());
                    JRViewer viewer = new JRViewer(jpPrint);
                    viewer.setZoomRatio((float) 0.5);
                    JFrame frameRelatorio = new JFrame();
                    frameRelatorio.add( viewer, BorderLayout.CENTER );
                    frameRelatorio.setTitle("Comprovante de Pagamento");
                    frameRelatorio.setSize( 500, 500 );
                    frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                    frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                    frameRelatorio.setVisible( true );
                } catch (JRException ex) {
                    JOptionPane.showMessageDialog(null, "Erro ao Gerar Comprovante de Pagamento para Impressão!/nErro: "+ex);
                } catch (SQLException ex) {
                    Logger.getLogger(FormVendas.class.getName()).log(Level.SEVERE, null, ex);
                }
             //conOs.desconecta();
            }
            jbPrint.setEnabled(false);
    }
        
    /**    @SuppressWarnings("unchecked")

     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTableNotasRecebidas = new javax.swing.JTable();
        jbSair = new javax.swing.JButton();
        jtfCodConta = new javax.swing.JTextField();
        jtfCliente = new javax.swing.JTextField();
        jtfDtReceb = new javax.swing.JTextField();
        jtfValorRec = new javax.swing.JTextField();
        jtfCodOrigem = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jbCancelarRecebimento = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jcbPesquisa = new javax.swing.JComboBox<>();
        jtfPesquisa = new controle.ClassUpperField();
        jbPrint = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        jtfTipoOrigem = new javax.swing.JTextField();

        setBackground(new java.awt.Color(255, 255, 255));
        setBorder(null);
        setTitle("Contas Recebidas");
        getContentPane().setLayout(null);

        jTableNotasRecebidas.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTableNotasRecebidas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableNotasRecebidasMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableNotasRecebidas);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(10, 40, 820, 280);

        jbSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jbSair.setText("Sair");
        jbSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbSairActionPerformed(evt);
            }
        });
        getContentPane().add(jbSair);
        jbSair.setBounds(730, 410, 100, 40);

        jtfCodConta.setEditable(false);
        jtfCodConta.setBackground(new java.awt.Color(255, 255, 255));
        jtfCodConta.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        jtfCodConta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtfCodContaActionPerformed(evt);
            }
        });
        getContentPane().add(jtfCodConta);
        jtfCodConta.setBounds(10, 360, 60, 25);

        jtfCliente.setEditable(false);
        jtfCliente.setBackground(new java.awt.Color(255, 255, 255));
        jtfCliente.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        getContentPane().add(jtfCliente);
        jtfCliente.setBounds(210, 360, 280, 25);

        jtfDtReceb.setEditable(false);
        jtfDtReceb.setBackground(new java.awt.Color(255, 255, 255));
        jtfDtReceb.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        getContentPane().add(jtfDtReceb);
        jtfDtReceb.setBounds(490, 360, 70, 25);

        jtfValorRec.setEditable(false);
        jtfValorRec.setBackground(new java.awt.Color(255, 255, 255));
        jtfValorRec.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        getContentPane().add(jtfValorRec);
        jtfValorRec.setBounds(560, 360, 70, 25);

        jtfCodOrigem.setEditable(false);
        jtfCodOrigem.setBackground(new java.awt.Color(255, 255, 255));
        jtfCodOrigem.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        getContentPane().add(jtfCodOrigem);
        jtfCodOrigem.setBounds(150, 360, 60, 25);

        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel2.setText("<html> Código<br> Conta</html>");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(10, 330, 60, 30);

        jLabel4.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel4.setText("<html>Código<br>Origem</html>");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(150, 330, 60, 30);

        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText("<html>Nome<br>Cliente</html>");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(210, 330, 280, 30);

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("<html><center>Data<br>Recebimento</html>");
        getContentPane().add(jLabel6);
        jLabel6.setBounds(490, 330, 70, 30);

        jLabel7.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel7.setText("<html><center>Valor<br>Recebido</html>");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(560, 330, 70, 30);

        jbCancelarRecebimento.setForeground(java.awt.Color.red);
        jbCancelarRecebimento.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jbCancelarRecebimento.setText("Cancelar Recebimento");
        jbCancelarRecebimento.setEnabled(false);
        jbCancelarRecebimento.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbCancelarRecebimentoActionPerformed(evt);
            }
        });
        getContentPane().add(jbCancelarRecebimento);
        jbCancelarRecebimento.setBounds(640, 325, 190, 60);
        getContentPane().add(jSeparator1);
        jSeparator1.setBounds(10, 400, 820, 10);

        jcbPesquisa.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Cliente:", "Nota:" }));
        getContentPane().add(jcbPesquisa);
        jcbPesquisa.setBounds(10, 10, 120, 25);

        jtfPesquisa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jtfPesquisaKeyReleased(evt);
            }
        });
        getContentPane().add(jtfPesquisa);
        jtfPesquisa.setBounds(140, 10, 690, 25);

        jbPrint.setForeground(java.awt.Color.blue);
        jbPrint.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/printer.png"))); // NOI18N
        jbPrint.setText("Imprimir");
        jbPrint.setToolTipText("");
        jbPrint.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbPrint.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbPrintActionPerformed(evt);
            }
        });
        getContentPane().add(jbPrint);
        jbPrint.setBounds(10, 410, 160, 40);

        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel8.setText("<html><center>Tipo.<br>Origem</html>");
        getContentPane().add(jLabel8);
        jLabel8.setBounds(70, 330, 80, 30);

        jtfTipoOrigem.setEditable(false);
        jtfTipoOrigem.setBackground(new java.awt.Color(255, 255, 255));
        jtfTipoOrigem.setFont(new java.awt.Font("Tahoma", 0, 8)); // NOI18N
        getContentPane().add(jtfTipoOrigem);
        jtfTipoOrigem.setBounds(70, 360, 80, 25);

        setBounds(0, 0, 841, 488);
    }// </editor-fold>//GEN-END:initComponents

    private void jbSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbSairActionPerformed
        dispose();
    }//GEN-LAST:event_jbSairActionPerformed

    private void jTableNotasRecebidasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableNotasRecebidasMouseClicked
        
        CodConta = ((int) jTableNotasRecebidas.getValueAt(jTableNotasRecebidas.getSelectedRow(), 0));
        CodContaHis = ((int) jTableNotasRecebidas.getValueAt(jTableNotasRecebidas.getSelectedRow(), 1));
        DtAbertura = ((String) jTableNotasRecebidas.getValueAt(jTableNotasRecebidas.getSelectedRow(), 2));
        Cliente = ((String) jTableNotasRecebidas.getValueAt(jTableNotasRecebidas.getSelectedRow(), 3));
        TipoDocOrigem = ((String) jTableNotasRecebidas.getValueAt(jTableNotasRecebidas.getSelectedRow(), 4));
        DocOrigem = String.valueOf((((int) jTableNotasRecebidas.getValueAt(jTableNotasRecebidas.getSelectedRow(), 5))));
        DtRecebimento = ((String) jTableNotasRecebidas.getValueAt(jTableNotasRecebidas.getSelectedRow(), 6));
        String VRec = ((String) jTableNotasRecebidas.getValueAt(jTableNotasRecebidas.getSelectedRow(), 7));
        ValorRec = Double.parseDouble(VRec.replace(',', '.')); 
        
        jtfCodConta.setText(String.valueOf(CodConta));
        jtfTipoOrigem.setText(TipoDocOrigem);
        jtfCodOrigem.setText(DocOrigem);
        jtfCliente.setText(Cliente);
        jtfDtReceb.setText(DtRecebimento);
        jtfValorRec.setText(String.valueOf(formatoNum.format(ValorRec)));
        jbCancelarRecebimento.setEnabled(true);
        jbPrint.setEnabled(true);
        
        
    }//GEN-LAST:event_jTableNotasRecebidasMouseClicked

    private void jbCancelarRecebimentoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbCancelarRecebimentoActionPerformed
        if (FormPrincipal.UsuarioPermissao.equals("2")){
                
                DialogConfSenha DPSenha = new DialogConfSenha();
                DPSenha.setModal(true);
                DPSenha.setVisible(true);
                String SenhaDig = DPSenha.Senha;
        
                if (FormPrincipal.SenhaULogado.equals(SenhaDig)){
        
                    int i = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente cancelar o recebimento dessa nota?","Confirmando Cancelamento", JOptionPane.YES_NO_OPTION);
                    if(i == JOptionPane.YES_OPTION) {
                        
                        CancelaRecebimento(CodConta);
                        jbCancelarRecebimento.setEnabled(false);
                    }
                }
        
        }else{
            
            JOptionPane.showMessageDialog(rootPane, "Você não possui permissão suficiente\n para executar esta ação.");
        
        }
    }//GEN-LAST:event_jbCancelarRecebimentoActionPerformed

    private void jtfPesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtfPesquisaKeyReleased
            Pesquisa();
    }//GEN-LAST:event_jtfPesquisaKeyReleased

    private void jtfPesquisaKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtfPesquisaKeyPressed
            
    }//GEN-LAST:event_jtfPesquisaKeyPressed

    private void jbPrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbPrintActionPerformed
        int CodConta = Integer.parseInt(jtfCodConta.getText());
        Print(CodConta);
    }//GEN-LAST:event_jbPrintActionPerformed

    private void jtfCodContaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtfCodContaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jtfCodContaActionPerformed

    public void Pesquisa(){
        
        int CampoEscolhido = (jcbPesquisa.getSelectedIndex());
        String DadosParaPesquisar = jtfPesquisa.getText();
        
        if (CampoEscolhido == 0 ){
            preencherjTablejTablePesquisa("select contas_receber.codigo, contas_receber.codcliente, contas_receber.cliente, contas_receber.dtlancamento, contas_receber.dtvencimento, contas_receber.nparcela, contas_receber.parcelan, contas_receber.valor, contas_receber.valorcj, contas_receber.valortotalvcj, contas_receber.valorrest, contas_receber.situacao, contas_receber.origem, contas_receber.codorigem, contas_receber_historico.codigo as cod_conta_his, contas_receber_historico.datapg as datapgh, contas_receber_historico.valorapg, contas_receber_historico.valorpago from ((contas_receber inner join clientes on contas_receber.codcliente=clientes.codigo) inner join contas_receber_historico on contas_receber_historico.conta=contas_receber.codigo) where contas_receber.cliente like '"+DadosParaPesquisar+"%' order by contas_receber_historico.datapg desc");
        }
        
        if (CampoEscolhido == 1 ){
            if ("".equals(jtfPesquisa.getText())){
            
            } else {
                int idConta = Integer.parseInt(DadosParaPesquisar);
            preencherjTablejTablePesquisa("select contas_receber.codigo, contas_receber.codcliente, contas_receber.cliente, contas_receber.dtlancamento, contas_receber.dtvencimento, contas_receber.nparcela, contas_receber.parcelan, contas_receber.valor, contas_receber.valorcj, contas_receber.valortotalvcj, contas_receber.valorrest, contas_receber.situacao, contas_receber.origem, contas_receber.codorigem, contas_receber_historico.codigo as cod_conta_his, contas_receber_historico.datapg as datapgh, contas_receber_historico.valorapg, contas_receber_historico.valorpago from ((contas_receber inner join clientes on contas_receber.codcliente=clientes.codigo) inner join contas_receber_historico on contas_receber_historico.conta=contas_receber.codigo) where contas_receber.codigo='"+idConta+"' order by contas_receber.codigo desc");
            }
        }
                
    }

    public void CancelaRecebimento(int CdConta){
        
        conCR.conecta();
        
        try {
            int contagemsql = 0;
            java.sql.Date datatmp=null;
            sql = "select contas_receber.codigo, contas_receber_historico.codigo, contas_receber.codcliente, contas_receber.cliente, contas_receber.dtlancamento, contas_receber.dtvencimento, contas_receber.nparcela, contas_receber.parcelan, contas_receber.valor, contas_receber.valorcj, contas_receber.valortotalvcj, contas_receber.valorrest, contas_receber.situacao, contas_receber.origem, contas_receber.codorigem, contas_receber_historico.datapg as datapgh, contas_receber_historico.valorapg, contas_receber_historico.valorpago from ((contas_receber inner join clientes on contas_receber.codcliente=clientes.codigo) inner join contas_receber_historico on contas_receber_historico.conta=contas_receber.codigo) where contas_receber.codigo='"+CdConta+"' order by contas_receber_historico.codigo";
            conCR.executaSQL(sql);
            if (conCR.rs.last()){
                contagemsql = conCR.rs.getRow();
                JOptionPane.showMessageDialog(null, "Numero de linhas: "+contagemsql);
                
            
                if (contagemsql>1){
                    conCR.rs.last();
                    conCR.rs.previous();
                    datatmp = conCR.rs.getDate("datapg");
                    
                    sql = "select contas_receber.codigo, contas_receber_historico.codigo, contas_receber.codcliente, contas_receber.cliente, contas_receber.dtlancamento, contas_receber.dtvencimento, contas_receber.nparcela, contas_receber.parcelan, contas_receber.valor, contas_receber.valorcj, contas_receber.valortotalvcj, contas_receber.valorrest, contas_receber.situacao, contas_receber.origem, contas_receber.codorigem, contas_receber_historico.datapg as datapgh, contas_receber_historico.valorapg, contas_receber_historico.valorpago from ((contas_receber inner join clientes on contas_receber.codcliente=clientes.codigo) inner join contas_receber_historico on contas_receber_historico.conta=contas_receber.codigo) where contas_receber_historico.codigo='"+CodContaHis+"'";
                    conCR.executaSQL(sql);
                    if (conCR.rs.first()){
                        RestPag = conCR.rs.getDouble("valorrest");
                        ValorPag = conCR.rs.getDouble("valorpago");
                        RestPagA = RestPag + ValorPag;
                        
                    }
                    
                    pst = conCR.conn.prepareStatement("update contas_receber set situacao=?, valorrest=?, dtpg=? where codigo=?");
                    pst.setString(1, "NP");
                    pst.setDouble(2, RestPagA);
                    pst.setDate(3, datatmp);
                    pst.setInt(4, CdConta);
                    pst.execute();
                    
                    sql = "delete from contas_receber_historico where codigo=?";
                    pst = conCR.conn.prepareStatement(sql);
                    pst.setInt(1, CodContaHis);
                    pst.execute();
                    
                }else{
                    sql = "select contas_receber.codigo, contas_receber_historico.codigo, contas_receber.codcliente, contas_receber.cliente, contas_receber.dtlancamento, contas_receber.dtvencimento, contas_receber.nparcela, contas_receber.parcelan, contas_receber.valor, contas_receber.valorcj, contas_receber.valortotalvcj, contas_receber.valorrest, contas_receber.situacao, contas_receber.origem, contas_receber.codorigem, contas_receber_historico.datapg as datapgh, contas_receber_historico.valorapg, contas_receber_historico.valorpago from ((contas_receber inner join clientes on contas_receber.codcliente=clientes.codigo) inner join contas_receber_historico on contas_receber_historico.conta=contas_receber.codigo) where contas_receber_historico.codigo='"+CodContaHis+"'";
                    conCR.executaSQL(sql);
                    
                    if (conCR.rs.first()){
                        RestPag = conCR.rs.getDouble("valorrest");
                        ValorPag = conCR.rs.getDouble("valorpago");
                        RestPagA = RestPag + ValorPag;
                        
                    }
                    
                    pst = conCR.conn.prepareStatement("update contas_receber set situacao=?, valorrest=?, dtpg=? where codigo=?");
                    pst.setString(1, "NP");
                    pst.setDouble(2, RestPagA);
                    pst.setDate(3, null);
                    pst.setInt(4, CdConta);
                    pst.execute();
                    
                    sql = "delete from contas_receber_historico where codigo=?";
                    pst = conCR.conn.prepareStatement(sql);
                    pst.setInt(1, CodContaHis);
                    pst.execute();
                    
                }
                
                
            
            }
                        
            atualizaTabela();
            
        } catch (SQLException ex) {
            Logger.getLogger(FormContasRecebidas.class.getName()).log(Level.SEVERE, null, ex);
        }
        conCR.desconecta();
        
    }
    
    public void atualizaTabela(){
        
        conCR.conecta();
        sql = "select contas_receber.codigo, contas_receber.codcliente, contas_receber.cliente, contas_receber.dtlancamento, contas_receber.dtvencimento, contas_receber.nparcela, contas_receber.parcelan, contas_receber.valor, contas_receber.valorcj, contas_receber.valortotalvcj, contas_receber.valorrest, contas_receber.situacao, contas_receber.origem, contas_receber.codorigem, contas_receber_historico.codigo as cod_conta_his, contas_receber_historico.datapg as datapgh, contas_receber_historico.valorapg, contas_receber_historico.valorpago from ((contas_receber inner join clientes on contas_receber.codcliente=clientes.codigo) inner join contas_receber_historico on contas_receber_historico.conta=contas_receber.codigo) order by contas_receber.dtpg desc" ;
        try {
            conCR.executaSQL(sql);
            if (conCR.rs.first()){
                preencherjTablejTablePesquisa(sql);
                jtfPesquisa.requestFocus();
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Não foi possivel organizar por data de recebimento\nisso pode ter ocorrido devido a alguma\nconta recebida baixada de forma incorreta.\na ordenação está por codigo de registro de recebimento\npor ordem decrescente");
        }
        conCR.desconecta();
    }
    
    public void preencherjTablejTablePesquisa(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"<html>Cod. <br>Conta</html>","<html>Cod. <br>Controle</html>","Dt. Abert.","Cliente","Origem","Cod. Origem", "Dt. Rec.", "Valor Rec.","Valor Dev.", "Valor Total", "Qtd. Parc.", "Parcela", "Valor Parc", "Dt. Venc", "Situação", "Resta.","Val. P.C.J"};
        conCR.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conCR.executaSQL(SQL);
        try {
            conCR.rs.first();
            do{
                dados.add(new Object[]{
                    conCR.rs.getInt("codigo"),
                    conCR.rs.getInt("cod_conta_his"),
                    df.format(conCR.rs.getDate("dtlancamento")),
                    conCR.rs.getString("cliente"),
                    conCR.rs.getString("origem"),
                    conCR.rs.getInt("codorigem"),
                    df.format(conCR.rs.getDate("datapgh")),
                    String.valueOf(formatoNum.format(conCR.rs.getDouble("valorpago"))),
                    String.valueOf(formatoNum.format(conCR.rs.getDouble("valorapg"))),
                    String.valueOf(formatoNum.format(conCR.rs.getDouble("valortotalvcj"))),
                    conCR.rs.getInt("nparcela"), conCR.rs.getInt("parcelan"),
                    String.valueOf(formatoNum.format(conCR.rs.getDouble("valor"))),
                    df.format(conCR.rs.getDate("dtvencimento")),
                    conCR.rs.getString("situacao"),
                    String.valueOf(formatoNum.format(conCR.rs.getDouble("valorrest"))),
                    String.valueOf(formatoNum.format(conCR.rs.getDouble("valorcj")))});
        }while(conCR.rs.next());
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane,"Erro ao Preencher ArrayList"+ex);
        }
        
        DefaultTableCellRenderer cellRenderC = new DefaultTableCellRenderer();
	cellRenderC.setHorizontalAlignment(SwingConstants.CENTER);
        DefaultTableCellRenderer cellRenderD = new DefaultTableCellRenderer();
	cellRenderD.setHorizontalAlignment(SwingConstants.RIGHT);
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableNotasRecebidas.setModel(modelo);
        jTableNotasRecebidas.getColumnModel().getColumn(0).setPreferredWidth(50);
        jTableNotasRecebidas.getColumnModel().getColumn(0).setCellRenderer(cellRenderD);
        jTableNotasRecebidas.getColumnModel().getColumn(0).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(1).setPreferredWidth(50);
        jTableNotasRecebidas.getColumnModel().getColumn(1).setCellRenderer(cellRenderD);
        jTableNotasRecebidas.getColumnModel().getColumn(1).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(2).setPreferredWidth(80);
        jTableNotasRecebidas.getColumnModel().getColumn(2).setCellRenderer(cellRenderC);
        jTableNotasRecebidas.getColumnModel().getColumn(2).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(3).setPreferredWidth(230);
        jTableNotasRecebidas.getColumnModel().getColumn(3).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(4).setPreferredWidth(80);
        jTableNotasRecebidas.getColumnModel().getColumn(4).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(5).setPreferredWidth(70);
        jTableNotasRecebidas.getColumnModel().getColumn(5).setCellRenderer(cellRenderD);
        jTableNotasRecebidas.getColumnModel().getColumn(5).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(6).setPreferredWidth(70);
        jTableNotasRecebidas.getColumnModel().getColumn(6).setCellRenderer(cellRenderD);
        jTableNotasRecebidas.getColumnModel().getColumn(6).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(7).setPreferredWidth(70);
        jTableNotasRecebidas.getColumnModel().getColumn(7).setCellRenderer(cellRenderD);
        jTableNotasRecebidas.getColumnModel().getColumn(7).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(8).setPreferredWidth(70);
        jTableNotasRecebidas.getColumnModel().getColumn(8).setCellRenderer(cellRenderD);
        jTableNotasRecebidas.getColumnModel().getColumn(8).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(9).setPreferredWidth(70);
        jTableNotasRecebidas.getColumnModel().getColumn(9).setCellRenderer(cellRenderD);
        jTableNotasRecebidas.getColumnModel().getColumn(9).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(10).setPreferredWidth(70);
        jTableNotasRecebidas.getColumnModel().getColumn(10).setCellRenderer(cellRenderD);
        jTableNotasRecebidas.getColumnModel().getColumn(10).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(11).setPreferredWidth(70);
        jTableNotasRecebidas.getColumnModel().getColumn(11).setCellRenderer(cellRenderD);
        jTableNotasRecebidas.getColumnModel().getColumn(11).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(12).setPreferredWidth(80);
        jTableNotasRecebidas.getColumnModel().getColumn(12).setCellRenderer(cellRenderD);
        jTableNotasRecebidas.getColumnModel().getColumn(12).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(13).setPreferredWidth(70);
        jTableNotasRecebidas.getColumnModel().getColumn(13).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(14).setPreferredWidth(70);
        jTableNotasRecebidas.getColumnModel().getColumn(14).setCellRenderer(cellRenderC);
        jTableNotasRecebidas.getColumnModel().getColumn(14).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(15).setPreferredWidth(70);
        jTableNotasRecebidas.getColumnModel().getColumn(15).setCellRenderer(cellRenderD);
        jTableNotasRecebidas.getColumnModel().getColumn(15).setResizable(false);
        
        jTableNotasRecebidas.getColumnModel().getColumn(16).setPreferredWidth(70);
        jTableNotasRecebidas.getColumnModel().getColumn(16).setCellRenderer(cellRenderD);
        jTableNotasRecebidas.getColumnModel().getColumn(16).setResizable(false);
        
       
        jTableNotasRecebidas.setAutoResizeMode(jTableNotasRecebidas.AUTO_RESIZE_OFF);
        jTableNotasRecebidas.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conCR.desconecta();
              
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable jTableNotasRecebidas;
    private javax.swing.JButton jbCancelarRecebimento;
    private javax.swing.JButton jbPrint;
    private javax.swing.JButton jbSair;
    private javax.swing.JComboBox<String> jcbPesquisa;
    private javax.swing.JTextField jtfCliente;
    private javax.swing.JTextField jtfCodConta;
    private javax.swing.JTextField jtfCodOrigem;
    private javax.swing.JTextField jtfDtReceb;
    private controle.ClassUpperField jtfPesquisa;
    private javax.swing.JTextField jtfTipoOrigem;
    private javax.swing.JTextField jtfValorRec;
    // End of variables declaration//GEN-END:variables
}
