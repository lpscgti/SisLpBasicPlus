/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.Conf;
import controle.ConnectionFactory2;
import controle.ControleEmpresa;
import controle.ControleVenda;
import controle.PlanodeFundoForms;
import modelo.ModeloTabela;
import modelo.ModeloVendas;
import java.awt.BorderLayout;
import java.awt.Image;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;

/**
 *
 * @author Lindembergue
 */
public class FormVendas extends javax.swing.JInternalFrame {
    
    ConectaBanco conVenda = new ConectaBanco();
    ModeloVendas modVenda = new ModeloVendas();
    ControleVenda controlVenda = new ControleVenda();
    ControleEmpresa ctrl_de = new ControleEmpresa();
    int CodVenda, CodCliente, CodProduto, CodFuncionario, QtdVend, TipoPag, flag = 1, IdConta = 0, NovaVenda = 0, ClienteSel=0;
    String DataHoje, NomeCliente, NomeProduto, NomeFuncionario, caminho, caminhoDb;
    double TotalVenda, PrUnit, TotalProdVend, Desconto, DesconcoCalc, ConverteValor;
    DecimalFormat formatoNum;
    public static String NomeJIF = "FormVendas";

    /**
     * Creates new form FormVendas
     */
    
    public FormVendas() {
        initComponents();
        formatoNum = new DecimalFormat("#0.00");
        ColocaImagemFundoFrame();
        Lerarquivo();
        desativaitens();
        jTextFieldCodVenda.setEditable(false);
        jTextFieldTotalVenda.setEditable(false);
        jTextFieldCodCliente.setEditable(false);
        jTextFieldCodProd.setEditable(false);
        try {
            MaskFormatter data = new MaskFormatter("##/##/####");
            jFormattedTextFieldDtVenda.setFormatterFactory(new DefaultFormatterFactory(data));
        } catch (ParseException ex) {
            Logger.getLogger(FormCadClientes.class.getName()).log(Level.SEVERE, null, ex);
        }
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date hoje = new Date();
        DataHoje = (df.format(hoje));
        jFormattedTextFieldDtVenda.setText(DataHoje);
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
     public void Lerarquivo(){

        Conf cfg = new Conf();
        Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
        caminho = String.valueOf(caminhoTXT+"\\");
        
            try {
                cfg.ConfigLido();
                String c = "jdbc:ucanaccess://"+caminho+"sislpbasicdb.mdb";
                caminhoDb = c;
            } catch (IOException ex) {
//                Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
        
    }
    
     public void convertValorVirgula(String ValorEntrada){
          
        
        if (ValorEntrada.equals("")){
            ValorEntrada = "0";
        }else{
        ConverteValor = Double.parseDouble(ValorEntrada.replace(',', '.'));  
        }
    }
     

     public void preencherTabelaItensVendas(String SQL){
        
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Cod.","Produto","Pr. Venda", "Desconto","Qtd. Venda","Total R$"};
        conVenda.conecta();
        conVenda.executaSQL(SQL);
        
        try {
            
            conVenda.rs.first();
            do{
                double PrProdutoVenda = conVenda.rs.getDouble("prvenda");
                int qtdVendida = conVenda.rs.getInt("quantidade");
                double vDescont = conVenda.rs.getInt("desconto");
                double ProdVend = (PrProdutoVenda*qtdVendida);
                double DescCalc = (ProdVend/100)*vDescont;
                double VtProdVend = (ProdVend-DescCalc);
                dados.add(new Object[]{conVenda.rs.getString("codigo"), conVenda.rs.getString("produto"), String.valueOf(formatoNum.format(conVenda.rs.getDouble("prvenda"))), String.valueOf(formatoNum.format(conVenda.rs.getDouble("desconto"))),conVenda.rs.getInt("quantidade"), String.valueOf(formatoNum.format(VtProdVend))});
                
            }while(conVenda.rs.next());
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane,"Erro ao Preencher ArrayList"+ex);
        }
        
        DefaultTableCellRenderer cellRenderD = new DefaultTableCellRenderer();
	cellRenderD.setHorizontalAlignment(SwingConstants.RIGHT);
        
        DefaultTableCellRenderer cellRenderC = new DefaultTableCellRenderer();
	cellRenderC.setHorizontalAlignment(SwingConstants.CENTER);
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableItensVenda.setModel(modelo);
        jTableItensVenda.getColumnModel().getColumn(0).setPreferredWidth(50);
        jTableItensVenda.getColumnModel().getColumn(0).setResizable(false);
        jTableItensVenda.getColumnModel().getColumn(1).setPreferredWidth(270);
        jTableItensVenda.getColumnModel().getColumn(1).setResizable(false);
        jTableItensVenda.getColumnModel().getColumn(2).setPreferredWidth(90);
        jTableItensVenda.getColumnModel().getColumn(2).setCellRenderer(cellRenderD);
        jTableItensVenda.getColumnModel().getColumn(2).setResizable(false);
        jTableItensVenda.getColumnModel().getColumn(3).setPreferredWidth(90);
        jTableItensVenda.getColumnModel().getColumn(3).setCellRenderer(cellRenderD);
        jTableItensVenda.getColumnModel().getColumn(3).setResizable(false);
        jTableItensVenda.getColumnModel().getColumn(4).setPreferredWidth(95);
        jTableItensVenda.getColumnModel().getColumn(4).setCellRenderer(cellRenderD);
        jTableItensVenda.getColumnModel().getColumn(4).setResizable(false);
        jTableItensVenda.getColumnModel().getColumn(5).setPreferredWidth(95);
        jTableItensVenda.getColumnModel().getColumn(5).setCellRenderer(cellRenderD);
        jTableItensVenda.getColumnModel().getColumn(5).setResizable(false);
//        jTableItensVenda.getColumnModel().getColumn(6).setPreferredWidth(100);
//        jTableItensVenda.getColumnModel().getColumn(6).setResizable(false);
//        jTableItensVenda.getColumnModel().getColumn(7).setPreferredWidth(100);
//        jTableItensVenda.getColumnModel().getColumn(7).setResizable(false);
//        jTableItensVenda.getColumnModel().getColumn(8).setPreferredWidth(100);
//        jTableItensVenda.getColumnModel().getColumn(8).setResizable(false);
        jTableItensVenda.getTableHeader().setReorderingAllowed(false);
        jTableItensVenda.setAutoResizeMode(jTableItensVenda.AUTO_RESIZE_OFF);
        jTableItensVenda.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conVenda.desconecta();
        SomaProduto();      
    }
     
     
     public void SomaProduto(){
         
        TotalVenda = 0;
        
        conVenda.conecta();
        conVenda.executaSQL("select * from (vendas_desc inner join produtos"
                +" on vendas_desc.produto = produtos.codigo)"
                +" where vendas_desc.venda="+CodVenda);
        try {
            //connVendaPsq.rs.first();
            while (conVenda.rs.next()){
                TotalVenda = TotalVenda+conVenda.rs.getDouble("total");
            }
            jTextFieldTotalVenda.setText(String.valueOf(formatoNum.format(TotalVenda)));
        } catch (SQLException ex) {
            Logger.getLogger(FormVendas.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
     
     public void desativaitens(){
         jTextFieldCodVenda.setEnabled(false);
         jTextFieldCodCliente.setEnabled(false);
         jTextFieldNome.setEnabled(false);
         jFormattedTextFieldDtVenda.setEnabled(false);
         jTextFieldCodProd.setEnabled(false);
         jTextFieldNomeProd.setEnabled(false);
         jTextFieldPrecoProd.setEnabled(false);
         QTD.setEnabled(false);
         jTextFieldDesconto.setEnabled(false);
         jButtonPesqCliente.setEnabled(false);
         jButtonPesqProd.setEnabled(false);
         jButtonAdd.setEnabled(false);
         jButtonRem.setEnabled(false);
         jTableItensVenda.setEnabled(false);
         jComboBoxTipoPag.setEnabled(false);
     }
     
     public void ativaitens(){
         jTextFieldCodVenda.setEnabled(true);
         jTextFieldCodCliente.setEnabled(true);
         jTextFieldNome.setEnabled(true);
         jFormattedTextFieldDtVenda.setEnabled(true);
         jTextFieldCodProd.setEnabled(true);
         jTextFieldNomeProd.setEnabled(true);
         jTextFieldPrecoProd.setEnabled(true);
         QTD.setEnabled(true);
         jTextFieldDesconto.setEnabled(true);
         jButtonPesqCliente.setEnabled(true);
         jButtonPesqProd.setEnabled(true);
         jButtonAdd.setEnabled(true);
         jButtonRem.setEnabled(true);
         jTableItensVenda.setEnabled(true);
         jComboBoxTipoPag.setEnabled(true);
     }
     
     public void Limpaitens(){
         jTextFieldCodVenda.setText("");
         jTextFieldCodCliente.setText("");
         jTextFieldNome.setText("");
         jFormattedTextFieldDtVenda.setText("");
         jTextFieldCodProd.setText("");
         jTextFieldNomeProd.setText("");
         jTextFieldPrecoProd.setText("0.00");
         QTD.setValue(1);
         jTextFieldDesconto.setText("0");;
         }
     
     public void limpatabelaPesquisa(){
            
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{};
        dados.removeAll(dados);
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        
        
    }
    
   public void limpatabelaItensVendas(){
        
      ArrayList dados = new ArrayList();
      String[] Colunas = new String[]{};
      dados.removeAll(dados);
      ModeloTabela modelo = new ModeloTabela(dados, Colunas);
      jTableItensVenda.setModel(modelo);
      
    }
    
   public void PrintVendaAVista(){
       
        int i = JOptionPane.showConfirmDialog(rootPane, "Venda Gerada com Sucesso.\nDeseja realizar a impressão?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
                                if(i == JOptionPane.YES_OPTION) {
                              
                                try {
                                    Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                                    Map<String, Object> parametros = new HashMap<String, Object>();
                                    Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                                    //dados empresa
                                    parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                                    parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                                    parametros.put( "cnpj", ctrl_de.de_cnpj );
                                    parametros.put( "de_ie", ctrl_de.de_ie );
                                    parametros.put( "endereco", ctrl_de.de_endereco );
                                    parametros.put( "bairro", ctrl_de.de_bairro );
                                    parametros.put( "cidade", ctrl_de.de_cidade );
                                    parametros.put( "estado", ctrl_de.de_estado );
                                    parametros.put( "cep", ctrl_de.de_cep );
                                    parametros.put( "telefone1", ctrl_de.de_fone1 );
                                    parametros.put( "telefone2", ctrl_de.de_fone2 );
                                    parametros.put( "de_site", ctrl_de.de_site );
                                    parametros.put( "email", ctrl_de.de_email );
                                    parametros.put("logoimg",imagePath);
                                    parametros.put( "CodVenda", CodVenda );
                                    JasperPrint jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteVendaAVista.jasper", parametros, ConnectionFactory2.getSlpConnection());
                                    JRViewer viewer = new JRViewer(jpPrint);
                                    viewer.setZoomRatio((float) 0.5);
                                    JFrame frameRelatorio = new JFrame();
                                    frameRelatorio.add( viewer, BorderLayout.CENTER );
                                    frameRelatorio.setTitle("Nova Venda Gerada");
                                    frameRelatorio.setSize( 500, 500 );
                                    frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                                    frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                                    frameRelatorio.setVisible( true );
                                    }catch (JRException ex) {
                                    JOptionPane.showMessageDialog(null, "Erro ao Gerar Venda para Impressão!/nErro: "+ex);
//                                    } catch (SQLException ex) {
//                                    Logger.getLogger(FormVendas.class.getName()).log(Level.SEVERE, null, ex);
                                }   catch (SQLException ex) {
                                        Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                    //conOs.desconecta(); //conOs.desconecta();
                                     //conOs.desconecta(); //conOs.desconecta();
                               
                                }
    
                                
    }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextFieldCodVenda = new javax.swing.JTextField();
        jTextFieldCodCliente = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jFormattedTextFieldDtVenda = new javax.swing.JFormattedTextField();
        jLabel5 = new javax.swing.JLabel();
        jTextFieldCodProd = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextFieldPrecoProd = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableItensVenda = new javax.swing.JTable();
        jLabel9 = new javax.swing.JLabel();
        jButtonRem = new javax.swing.JButton();
        jButtonAdd = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        jTextFieldDesconto = new javax.swing.JTextField();
        QTD = new javax.swing.JSpinner();
        jTextFieldNome = new controle.ClassUpperField();
        jTextFieldNomeProd = new controle.ClassUpperField();
        jButtonPesqCliente = new javax.swing.JToggleButton();
        jButtonPesqProd = new javax.swing.JButton();
        jPanel1 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jTextFieldTotalVenda = new javax.swing.JTextField();
        jComboBoxTipoPag = new javax.swing.JComboBox();
        jButtonNovo = new javax.swing.JButton();
        jButtonFinalizar = new javax.swing.JButton();
        jButtonSair = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setTitle("Efetuar Vendas");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Cód. Venda:");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 10, 90, 16);

        jTextFieldCodVenda.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jTextFieldCodVenda.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jPanelFundo.add(jTextFieldCodVenda);
        jTextFieldCodVenda.setBounds(10, 30, 90, 30);

        jTextFieldCodCliente.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldCodCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldCodClienteActionPerformed(evt);
            }
        });
        jPanelFundo.add(jTextFieldCodCliente);
        jTextFieldCodCliente.setBounds(100, 30, 90, 30);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Cód. Cliente:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(100, 10, 90, 16);

        jLabel3.setForeground(java.awt.Color.white);
        jLabel3.setText("Nome do Cliente:");
        jPanelFundo.add(jLabel3);
        jLabel3.setBounds(190, 10, 390, 16);

        jLabel4.setForeground(java.awt.Color.white);
        jLabel4.setText("Data da Venda:");
        jPanelFundo.add(jLabel4);
        jLabel4.setBounds(630, 10, 100, 16);

        jFormattedTextFieldDtVenda.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.DateFormatter()));
        jPanelFundo.add(jFormattedTextFieldDtVenda);
        jFormattedTextFieldDtVenda.setBounds(630, 30, 100, 30);

        jLabel5.setForeground(java.awt.Color.white);
        jLabel5.setText("Cód. Produto:");
        jPanelFundo.add(jLabel5);
        jLabel5.setBounds(10, 70, 90, 16);

        jTextFieldCodProd.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jPanelFundo.add(jTextFieldCodProd);
        jTextFieldCodProd.setBounds(10, 90, 90, 30);

        jLabel6.setForeground(java.awt.Color.white);
        jLabel6.setText("Produto:");
        jPanelFundo.add(jLabel6);
        jLabel6.setBounds(100, 70, 310, 16);

        jLabel7.setForeground(java.awt.Color.white);
        jLabel7.setText("Quant. Prod.");
        jPanelFundo.add(jLabel7);
        jLabel7.setBounds(560, 70, 90, 16);

        jTextFieldPrecoProd.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldPrecoProd.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldPrecoProdKeyTyped(evt);
            }
        });
        jPanelFundo.add(jTextFieldPrecoProd);
        jTextFieldPrecoProd.setBounds(420, 90, 70, 30);

        jLabel8.setForeground(java.awt.Color.white);
        jLabel8.setText("Preço:");
        jPanelFundo.add(jLabel8);
        jLabel8.setBounds(420, 70, 70, 16);

        jTableItensVenda.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTableItensVenda);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 150, 720, 330);

        jLabel9.setForeground(java.awt.Color.white);
        jLabel9.setText("Descrição dos Itens desta Venda:");
        jPanelFundo.add(jLabel9);
        jLabel9.setBounds(10, 130, 690, 20);

        jButtonRem.setText("-");
        jButtonRem.setToolTipText("Remover Produto");
        jButtonRem.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonRem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonRemActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonRem);
        jButtonRem.setBounds(690, 90, 40, 30);

        jButtonAdd.setText("+");
        jButtonAdd.setToolTipText("Adicionar Produto");
        jButtonAdd.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonAdd);
        jButtonAdd.setBounds(650, 90, 40, 30);

        jLabel12.setForeground(java.awt.Color.white);
        jLabel12.setText("Desc. %");
        jPanelFundo.add(jLabel12);
        jLabel12.setBounds(490, 70, 70, 16);

        jTextFieldDesconto.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jTextFieldDesconto.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldDescontoKeyTyped(evt);
            }
        });
        jPanelFundo.add(jTextFieldDesconto);
        jTextFieldDesconto.setBounds(490, 90, 70, 30);

        QTD.setModel(new javax.swing.SpinnerNumberModel(1, 1, null, 1));
        jPanelFundo.add(QTD);
        QTD.setBounds(560, 90, 90, 30);
        jPanelFundo.add(jTextFieldNome);
        jTextFieldNome.setBounds(190, 30, 400, 30);
        jPanelFundo.add(jTextFieldNomeProd);
        jTextFieldNomeProd.setBounds(100, 90, 280, 30);

        jButtonPesqCliente.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/btn_pesq_15.png"))); // NOI18N
        jButtonPesqCliente.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonPesqCliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesqClienteActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesqCliente);
        jButtonPesqCliente.setBounds(590, 30, 40, 30);

        jButtonPesqProd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icons/btn_pesq_15.png"))); // NOI18N
        jButtonPesqProd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesqProdActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesqProd);
        jButtonPesqProd.setBounds(380, 90, 40, 30);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 10, 740, 490);

        jPanel1.setBackground(java.awt.Color.white);
        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        jPanel1.setLayout(null);

        jLabel10.setText("Total da Venda R$:");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(10, 10, 110, 40);

        jTextFieldTotalVenda.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jPanel1.add(jTextFieldTotalVenda);
        jTextFieldTotalVenda.setBounds(120, 10, 150, 40);

        jComboBoxTipoPag.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jComboBoxTipoPag.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "À Vista", "À Prazo" }));
        jComboBoxTipoPag.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoPagActionPerformed(evt);
            }
        });
        jPanel1.add(jComboBoxTipoPag);
        jComboBoxTipoPag.setBounds(280, 10, 140, 40);

        jButtonNovo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/add.png"))); // NOI18N
        jButtonNovo.setText("Nova Venda");
        jButtonNovo.setToolTipText("");
        jButtonNovo.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonNovo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovoActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonNovo);
        jButtonNovo.setBounds(430, 10, 100, 40);

        jButtonFinalizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/applyResultado.png"))); // NOI18N
        jButtonFinalizar.setText("Finalizar");
        jButtonFinalizar.setToolTipText("");
        jButtonFinalizar.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonFinalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonFinalizarActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonFinalizar);
        jButtonFinalizar.setBounds(530, 10, 100, 40);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Cancelar");
        jButtonSair.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        jPanel1.add(jButtonSair);
        jButtonSair.setBounds(630, 10, 100, 40);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(10, 510, 740, 60);

        setBounds(0, 0, 759, 600);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
    
    if (NovaVenda == 0){
        dispose();
    }else{
    controlVenda.CancelaVenda();
    dispose();
    }    


    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonRemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonRemActionPerformed
       
       int CodRemProduto;
       int QtdVend;
       int qtdEstoque;
       int qtdEstoqueAtual;
       CodRemProduto = Integer.parseInt("" + jTableItensVenda.getValueAt(jTableItensVenda.getSelectedRow(), 0));
       QtdVend = Integer.parseInt("" + jTableItensVenda.getValueAt(jTableItensVenda.getSelectedRow(), 4));
       conVenda.conecta();
        try {
            conVenda.executaSQL("select * from produtos where codigo='"+CodRemProduto+"'");
            conVenda.rs.first();
            qtdEstoque = conVenda.rs.getInt("quantidade");
            qtdEstoqueAtual = qtdEstoque+QtdVend;
            PreparedStatement pst = conVenda.conn.prepareStatement("update produtos set quantidade=? where codigo=?");
            pst.setInt(1, qtdEstoqueAtual);
            pst.setInt(2, CodRemProduto);
            pst.execute();
            conVenda.executaSQL("select * from produtos where codigo='"+CodRemProduto+"'");
            pst = conVenda.conn.prepareStatement("delete from vendas_desc where venda=? and produto=?");
            pst.setInt(1, CodVenda);
            pst.setInt(2, CodRemProduto);
            pst.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao escluir produto da lista.\nErro Código: "+ex);
        }
            jTextFieldCodProd.setText("");
            jTextFieldNomeProd.setText("");
            jTextFieldPrecoProd.setText("0");
            jTextFieldDesconto.setText("0");
            QTD.setValue(1);
            
//       preencherTabelaItensVendas("select vendas_desc.venda, produtos.produto, produtos.prvenda, vendas_desc.desconto, vendas_desc.quantidade, vendas_desc.total from (vendas_desc inner join produtos on produtos.codigo=vendas_desc.produto) where vendas_desc.venda="+CodVenda);
        preencherTabelaItensVendas("select vendas_desc.venda, produtos.codigo, produtos.produto, produtos.prvenda, vendas_desc.desconto, vendas_desc.quantidade, vendas_desc.total from (vendas_desc inner join produtos on produtos.codigo=vendas_desc.produto) where vendas_desc.venda="+CodVenda);
           
    }//GEN-LAST:event_jButtonRemActionPerformed

    private void jButtonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddActionPerformed
        int qtdDisponivel=0;
        try {
            conVenda.conecta();
            conVenda.executaSQL("select * from vendas_desc where venda='"+CodVenda+"' and produto='"+CodProduto+"'");
            
            if (conVenda.rs.first()){
                JOptionPane.showMessageDialog(rootPane, "O Produto já foi adicionado\nRemova-o para readicionar com alterações.");
            }else{
            
            conVenda.executaSQL("select * from produtos where codigo='"+CodProduto+"'");
            conVenda.rs.first();
            qtdDisponivel = conVenda.rs.getInt("quantidade");
            QtdVend = (int) QTD.getValue();
            Desconto = Double.parseDouble(jTextFieldDesconto.getText());
            double ProdVend = (PrUnit*QtdVend); 
            DesconcoCalc = (ProdVend/100)*Desconto;
            TotalProdVend = (ProdVend-DesconcoCalc);
            if (qtdDisponivel >= (int) QTD.getValue()){
            modVenda.setIdVenda(CodVenda);
            modVenda.setIdProduto(CodProduto);
            modVenda.setNomeProduto(NomeProduto);
            modVenda.setPr_venda_prod(PrUnit);
            modVenda.setDesconto(Desconto);
            modVenda.setQtd_produto((int) QTD.getValue());
            modVenda.setTotal_vendido(TotalProdVend);
            controlVenda.AddItem(modVenda);
            
            } else {
                JOptionPane.showMessageDialog(rootPane, "Quantidade do Item indisponível!\n Quantidade Atual do Item = "+qtdDisponivel);
            }
            jTextFieldCodProd.setText("");
            jTextFieldNomeProd.setText("");
            jTextFieldPrecoProd.setText("0");
            jTextFieldDesconto.setText("0");
            QTD.setValue(1);
            }
        } catch (SQLException ex) {
           //JOptionPane.showMessageDialog(rootPane, "erro ao verificar a quantidade! "+ex);
        }
        jTextFieldDesconto.setText("0");
        QTD.setValue(1);
        
//total = total+Double.parseDouble(jTextFieldPrUnit.getText())*Integer.parseInt(jTextFieldQuantidade.getText());
//jTextFieldTotalVenda.setText(String.valueOf(total));
preencherTabelaItensVendas("select vendas_desc.venda, produtos.codigo, produtos.produto, produtos.prvenda, vendas_desc.desconto, vendas_desc.quantidade, vendas_desc.total from (vendas_desc inner join produtos on produtos.codigo=vendas_desc.produto) where vendas_desc.venda="+CodVenda);

//preencherTabelaItensVendas();
    }//GEN-LAST:event_jButtonAddActionPerformed

    private void jButtonNovoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovoActionPerformed
        
        NovaVenda = 1;        
        conVenda.conecta();
        try {
            PreparedStatement pst = conVenda.conn.prepareStatement("insert into vendas (valorvenda) values (?)");
            pst.setDouble(1, 0);
            pst.execute();
            conVenda.executaSQL("select * from vendas order by codigo");
            conVenda.rs.last();
            CodVenda = conVenda.rs.getInt("codigo");
            jTextFieldCodVenda.setText(String.valueOf(CodVenda));            
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao Gerar Nova Venda no Banco de Dados!"+ex);
        }
        ativaitens();
        jComboBoxTipoPag.setSelectedIndex(0);
        jButtonNovo.setEnabled(false);
        
    }//GEN-LAST:event_jButtonNovoActionPerformed

    private void jButtonFinalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonFinalizarActionPerformed
        
    
        if (jComboBoxTipoPag.getSelectedItem().equals("À Vista")){
                
                modVenda.setIdVenda(CodVenda);
                modVenda.setIdCliente(CodCliente);
                modVenda.setCliente(NomeCliente);
                modVenda.setDtVenda(jFormattedTextFieldDtVenda.getText());
                ConverteValor = 0;
                convertValorVirgula(jTextFieldTotalVenda.getText());
                modVenda.setValorVenda(ConverteValor);
                modVenda.setTipo_pag((String)jComboBoxTipoPag.getSelectedItem());
                controlVenda.FechaVenda(modVenda);
                controlVenda.GeraContaReceber(modVenda);
                JOptionPane.showMessageDialog(null, "Venda finalizada com sucesso!");
                PrintVendaAVista();
                dispose();
                
        }else {
        
                modVenda.setIdVenda(CodVenda);
                modVenda.setIdCliente(CodCliente);
                modVenda.setCliente(NomeCliente);
                modVenda.setDtVenda(jFormattedTextFieldDtVenda.getText());
                ConverteValor = 0;
                convertValorVirgula(jTextFieldTotalVenda.getText());
                modVenda.setValorVenda(ConverteValor);
                modVenda.setTipo_pag((String)jComboBoxTipoPag.getSelectedItem());
                controlVenda.FechaVenda(modVenda);
                
                FormParcelaVendas frmParcVend = new FormParcelaVendas(CodVenda);
                FormPrincipal.AbreNovaJanelaS(frmParcVend);
                frmParcVend.setVisible(true);
                dispose();
        }
        
    }//GEN-LAST:event_jButtonFinalizarActionPerformed

    private void jComboBoxTipoPagActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoPagActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxTipoPagActionPerformed

    private void jTextFieldDescontoKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldDescontoKeyTyped
        String caracteres="0987654321,.";
        if(!caracteres.contains(evt.getKeyChar()+"")){
        evt.consume();
       
        }
    }//GEN-LAST:event_jTextFieldDescontoKeyTyped

    private void jTextFieldPrecoProdKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldPrecoProdKeyTyped
        String caracteres="0987654321,.";
        if(!caracteres.contains(evt.getKeyChar()+"")){
        evt.consume();
        }
    }//GEN-LAST:event_jTextFieldPrecoProdKeyTyped

    private void jTextFieldCodClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldCodClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldCodClienteActionPerformed

    private void jButtonPesqProdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesqProdActionPerformed
        DialogPesqProdutos DPProd = new DialogPesqProdutos();
        DPProd.setModal(true);
        DPProd.setVisible(true);
        CodProduto = DPProd.CodProduto;
        NomeProduto = DPProd.NomeProduto;
        PrUnit = DPProd.PrecoProduto;
        jTextFieldPrecoProd.setText(String.valueOf(formatoNum.format(PrUnit)));
        jTextFieldCodProd.setText(String.valueOf(CodProduto));
        jTextFieldNomeProd.setText(String.valueOf(NomeProduto));
        QTD.setValue(1);
        jTextFieldDesconto.setText("0");
        
        jTextFieldCodProd.setEnabled(true);
        jTextFieldNomeProd.setEnabled(true);
        jTextFieldPrecoProd.setEnabled(true);
        QTD.setEnabled(true);
        jTextFieldDesconto.setEnabled(true);
        jButtonAdd.setEnabled(true);
        jButtonRem.setEnabled(true);
    }//GEN-LAST:event_jButtonPesqProdActionPerformed

    private void jButtonPesqClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesqClienteActionPerformed
        DialogPesqCliente DPCli = new DialogPesqCliente();
        DPCli.setModal(true);
        DPCli.setVisible(true);
        CodCliente = DPCli.CodCliente;
        NomeCliente = DPCli.NomeCliente;
        jTextFieldCodCliente.setText(String.valueOf(CodCliente));
        jTextFieldNome.setText(NomeCliente);
        
        jTextFieldNome.setEditable(false);
        jTextFieldNomeProd.setEnabled(true);
        jButtonPesqProd.setEnabled(true);
        ClienteSel = 1;
    }//GEN-LAST:event_jButtonPesqClienteActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JSpinner QTD;
    private javax.swing.JButton jButtonAdd;
    private javax.swing.JButton jButtonFinalizar;
    private javax.swing.JButton jButtonNovo;
    private javax.swing.JToggleButton jButtonPesqCliente;
    private javax.swing.JButton jButtonPesqProd;
    private javax.swing.JButton jButtonRem;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JComboBox jComboBoxTipoPag;
    private javax.swing.JFormattedTextField jFormattedTextFieldDtVenda;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableItensVenda;
    private javax.swing.JTextField jTextFieldCodCliente;
    private javax.swing.JTextField jTextFieldCodProd;
    private javax.swing.JTextField jTextFieldCodVenda;
    private javax.swing.JTextField jTextFieldDesconto;
    private controle.ClassUpperField jTextFieldNome;
    private controle.ClassUpperField jTextFieldNomeProd;
    private javax.swing.JTextField jTextFieldPrecoProd;
    private javax.swing.JTextField jTextFieldTotalVenda;
    // End of variables declaration//GEN-END:variables
}
