/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.ConnectionFactory2;
import controle.ControleEmpresa;
import controle.ControleParcelaOrcamento;
import controle.PlanodeFundoForms;
import modelo.ModeloTabela;
import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import modelo.ModeloParcelaOrcamento;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;

/**
 *
 * @author Lindembergue
 */
public class FormParcelaOrcamento extends javax.swing.JInternalFrame {

ConectaBanco conParcOS = new ConectaBanco();
ModeloParcelaOrcamento modParcOrc = new ModeloParcelaOrcamento();
ControleParcelaOrcamento controPar = new ControleParcelaOrcamento();
ControleEmpresa ctrl_de = new ControleEmpresa();
int CodCliente, CodigoOrc, CodConta, qtdParcela, i = 1, cont = 1;
double porcent, valorVenda, valorParcela, valorentrada, TotalProd;
double valorAtializadoParcela;
double ConverteValor;
String DataHoje, caminhoDb;
DecimalFormat formatoNum = new DecimalFormat("#0.00");
DecimalFormat formatoNumP = new DecimalFormat("#0.0");
SimpleDateFormat DatFormat = new SimpleDateFormat("dd/MM/yyyy");


    /**
     * Creates new form FormParcelaOS
     */
    public FormParcelaOrcamento(int CodOrc) {
        CodigoOrc = CodOrc;
        initComponents();
        ColocaImagemFundoFrame();
               
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        Date hoje = new Date();
        DataHoje = (df.format(hoje));
        jTextFieldCodOrc.setText(String.valueOf(CodOrc));
        jTextFieldCodOrc.setEditable(false);
        jTextFieldQtdParc.setText("1");
        jTextFieldTxJuros.setText("0");
        conParcOS.conecta();
        conParcOS.executaSQL("select * from orcamentos where id_orcamento="+CodOrc);
        try {
            conParcOS.rs.first();
            CodCliente = conParcOS.rs.getInt("id_cliente");
            jTextFieldValorTotalOrc.setText(String.valueOf(conParcOS.rs.getDouble("valor_orcamento")));
            jdcDataBase.setDate(conParcOS.rs.getDate("data_orcamento"));
            conParcOS.executaSQL("select * from config where codigo=1");
            conParcOS.rs.first();
            jTextFieldTxJuros.setText(formatoNum.format(conParcOS.rs.getDouble("jurosmes")));
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Erro ao buscar dados da OS!\nErro: "+ex);
        }
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
    public void LimpaDadosPreenchidos(){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{};
        dados.removeAll(dados);
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableParcelaOS.setModel(modelo);
        i = 1; cont = 1; porcent = 0; valorParcela = 0; qtdParcela = 1;
    }
    
    public void PrintOrcParce(){
        ctrl_de.Obtem_Dados_da_Empresa();
        conParcOS.conecta();
        conParcOS.executaSQL("select * from orcamentos_descricao where id_orcamento='"+CodigoOrc+"'");
        TotalProd = 0;
        try {
            if(conParcOS.rs.first()){
                do{
                    TotalProd = TotalProd+conParcOS.rs.getDouble("total_vendido");
                }while(conParcOS.rs.next());
            }
        } catch (SQLException ex) {
            Logger.getLogger(FormParcelaOrcamento.class.getName()).log(Level.SEVERE, null, ex);
        }
        conParcOS.desconecta();
        
        int i = JOptionPane.showConfirmDialog(rootPane, "Deseja realizar a impressão do Comprovante?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
                if(i == JOptionPane.YES_OPTION) {
                   
                    try {
                            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                            Map<String, Object> parametros = new HashMap<String, Object>();
                            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                            //dados empresa
                            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                            parametros.put( "cnpj", ctrl_de.de_cnpj );
                            parametros.put( "de_ie", ctrl_de.de_ie );
                            parametros.put( "endereco", ctrl_de.de_endereco );
                            parametros.put( "bairro", ctrl_de.de_bairro );
                            parametros.put( "cidade", ctrl_de.de_cidade );
                            parametros.put( "estado", ctrl_de.de_estado );
                            parametros.put( "cep", ctrl_de.de_cep );
                            parametros.put( "telefone1", ctrl_de.de_fone1 );
                            parametros.put( "telefone2", ctrl_de.de_fone2 );
                            parametros.put( "de_site", ctrl_de.de_site );
                            parametros.put( "email", ctrl_de.de_email );
                            parametros.put("logoimg",imagePath);
                            parametros.put( "CodConta", CodConta );
                            JasperPrint jpPrint;
                            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteOrcAP.jasper", parametros, ConnectionFactory2.getSlpConnection());
                            JRViewer viewer = new JRViewer(jpPrint);
                            viewer.setZoomRatio((float) 0.5);
                            JFrame frameRelatorio = new JFrame();
                            frameRelatorio.add( viewer, BorderLayout.CENTER );
                            frameRelatorio.setTitle("Comprovante de Parcelamento");
                            frameRelatorio.setSize( 500, 500 );
                            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                            frameRelatorio.setVisible( true );
                    }   catch (SQLException ex) {
                            Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
                    }   catch (JRException ex) {
                            Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
                    }
                   
            }
    }
    
    public void PrintOrcParceEntrada(){
        ctrl_de.Obtem_Dados_da_Empresa();
        conParcOS.conecta();
        conParcOS.executaSQL("select * from orcamentos_descricao where id_orcamento='"+CodigoOrc+"'");
        TotalProd = 0;
        try {
            if(conParcOS.rs.first()){
                do{
                    TotalProd = TotalProd+conParcOS.rs.getDouble("total_vendido");
                }while(conParcOS.rs.next());
            }
        } catch (SQLException ex) {
            Logger.getLogger(FormParcelaOrcamento.class.getName()).log(Level.SEVERE, null, ex);
        }
        conParcOS.desconecta();
        
        int i = JOptionPane.showConfirmDialog(rootPane, "Deseja realizar a impressão do Comprovante?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
                if(i == JOptionPane.YES_OPTION) {
                   
                    try {
                            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                            Map<String, Object> parametros = new HashMap<String, Object>();
                            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                            //dados empresa
                            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                            parametros.put( "cnpj", ctrl_de.de_cnpj );
                            parametros.put( "de_ie", ctrl_de.de_ie );
                            parametros.put( "endereco", ctrl_de.de_endereco );
                            parametros.put( "bairro", ctrl_de.de_bairro );
                            parametros.put( "cidade", ctrl_de.de_cidade );
                            parametros.put( "estado", ctrl_de.de_estado );
                            parametros.put( "cep", ctrl_de.de_cep );
                            parametros.put( "telefone1", ctrl_de.de_fone1 );
                            parametros.put( "telefone2", ctrl_de.de_fone2 );
                            parametros.put( "de_site", ctrl_de.de_site );
                            parametros.put( "email", ctrl_de.de_email );
                            parametros.put("logoimg",imagePath);
                            parametros.put( "CodConta", CodConta );
                            JasperPrint jpPrint;
                            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteOrcAPEntrada.jasper", parametros, ConnectionFactory2.getSlpConnection());
                            JRViewer viewer = new JRViewer(jpPrint);
                            viewer.setZoomRatio((float) 0.5);
                            JFrame frameRelatorio = new JFrame();
                            frameRelatorio.add( viewer, BorderLayout.CENTER );
                            frameRelatorio.setTitle("Comprovante de Parcelamento");
                            frameRelatorio.setSize( 500, 500 );
                            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                            frameRelatorio.setVisible( true );
                    }   catch (SQLException ex) {
                            Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
                    }   catch (JRException ex) {
                            Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
                    }
                   
            }
                                            
    }
    
    public void preencherTabelaParcelamento(){
        ArrayList dados = new ArrayList();
        //AjustaData dataParcela = new AjustaData();
        String[] Colunas = new String[]{"Codigo","Data Venc.","Valor R$"};
        
        double valorTotal=0;
        String data = DatFormat.format(jdcDataBase.getDate());
        String dia, diai,mes,ano;
        diai = ""+data.charAt(0)+data.charAt(1);
        dia = ""+data.charAt(0)+data.charAt(1)+"/";
        mes = ""+data.charAt(3)+data.charAt(4);
        ano = "/"+data.charAt(6)+data.charAt(7)+data.charAt(8)+data.charAt(9);
        valorAtializadoParcela = valorParcela+(valorParcela*(porcent/100));
        int anoInt = Integer.parseInt("" + data.charAt(6) + data.charAt(7) + data.charAt(8) + data.charAt(9));
        int mesInt = Integer.parseInt(mes);
        int vDfev = 0;
        while (i <= qtdParcela){
            valorTotal = valorTotal+valorAtializadoParcela;
            if (mesInt < 10){
                
                vDfev = Integer.parseInt(diai);
                if (mesInt==2&&vDfev>28){
                    dados.add(new Object[]{i,"01/" + "03/" + anoInt, String.valueOf(formatoNum.format(valorAtializadoParcela))});
                }else{
                    dados.add(new Object[]{i, dia+ "0" + mesInt + "/" + anoInt, String.valueOf(formatoNum.format(valorAtializadoParcela))});  
                }
            
            }else{
            dados.add(new Object[]{i, dia+ mesInt + "/" + anoInt, String.valueOf(formatoNum.format(valorAtializadoParcela))});
            }
            mesInt++;
            if (mesInt > 12){
                anoInt++;
                mesInt = 1;
            }
            
            i++;
            cont++;
        }
        jTextFieldValorParc.setText(String.valueOf(formatoNum.format(valorAtializadoParcela)));
        jFormattedTextFieldValorTotalCJ.setText(String.valueOf(formatoNum.format(valorTotal+valorentrada)));
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableParcelaOS.setModel(modelo);
        jTableParcelaOS.getColumnModel().getColumn(0).setPreferredWidth(125);
        jTableParcelaOS.getColumnModel().getColumn(0).setResizable(false);
        jTableParcelaOS.getColumnModel().getColumn(1).setPreferredWidth(150);
        jTableParcelaOS.getColumnModel().getColumn(1).setResizable(false);
        jTableParcelaOS.getColumnModel().getColumn(2).setPreferredWidth(150);
        jTableParcelaOS.getColumnModel().getColumn(2).setResizable(false);
        jTableParcelaOS.getTableHeader().setReorderingAllowed(false);
        jTableParcelaOS.setAutoResizeMode(jTableParcelaOS.AUTO_RESIZE_OFF);
        jTableParcelaOS.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
                     
    }
    
    public void convertValorVirgula(String ValorEntrada){
          
        if (ValorEntrada.equals("")){
            ValorEntrada = "0";
        }else{
        ConverteValor = Double.parseDouble(ValorEntrada.replace(',', '.'));  
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jTextFieldCodOrc = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldValorTotalOrc = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jTextFieldQtdParc = new javax.swing.JTextField();
        jTextFieldTxJuros = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jButtonGerarParcela = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableParcelaOS = new javax.swing.JTable();
        jTextFieldValorParc = new javax.swing.JFormattedTextField();
        jdcDataBase = new com.toedter.calendar.JDateChooser();
        jLabel10 = new javax.swing.JLabel();
        jCBEntrada = new javax.swing.JComboBox<>();
        jTextFieldValorEntrada = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jButtonSair = new javax.swing.JButton();
        jButtonCancelar = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jFormattedTextFieldValorTotalCJ = new javax.swing.JFormattedTextField();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setTitle("Parcelamento");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Cod. OS:");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 11, 80, 16);

        jTextFieldCodOrc.setBorder(null);
        jPanelFundo.add(jTextFieldCodOrc);
        jTextFieldCodOrc.setBounds(10, 30, 90, 25);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Valor Total:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(105, 10, 80, 16);

        jTextFieldValorTotalOrc.setBorder(null);
        jPanelFundo.add(jTextFieldValorTotalOrc);
        jTextFieldValorTotalOrc.setBounds(105, 30, 90, 25);

        jLabel3.setForeground(java.awt.Color.white);
        jLabel3.setText("Prx. Data Venc.:");
        jPanelFundo.add(jLabel3);
        jLabel3.setBounds(200, 60, 130, 20);

        jTextFieldQtdParc.setBorder(null);
        jTextFieldQtdParc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldQtdParcActionPerformed(evt);
            }
        });
        jPanelFundo.add(jTextFieldQtdParc);
        jTextFieldQtdParc.setBounds(10, 80, 90, 25);

        jTextFieldTxJuros.setBorder(null);
        jPanelFundo.add(jTextFieldTxJuros);
        jTextFieldTxJuros.setBounds(105, 80, 90, 25);

        jLabel4.setForeground(java.awt.Color.white);
        jLabel4.setText("Qtd. Parcelas:");
        jPanelFundo.add(jLabel4);
        jLabel4.setBounds(10, 60, 80, 16);

        jLabel5.setForeground(java.awt.Color.white);
        jLabel5.setText("Tx. de Juros:");
        jPanelFundo.add(jLabel5);
        jLabel5.setBounds(105, 60, 80, 16);

        jLabel6.setForeground(java.awt.Color.white);
        jLabel6.setText("Valor da Parc.:");
        jPanelFundo.add(jLabel6);
        jLabel6.setBounds(340, 60, 100, 20);

        jButtonGerarParcela.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/accept.png"))); // NOI18N
        jButtonGerarParcela.setText("Gerar");
        jButtonGerarParcela.setToolTipText("Gerar Parcela(s)");
        jButtonGerarParcela.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonGerarParcela.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonGerarParcelaActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonGerarParcela);
        jButtonGerarParcela.setBounds(340, 120, 100, 30);

        jTableParcelaOS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(jTableParcelaOS);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 160, 430, 190);

        jTextFieldValorParc.setEditable(false);
        jTextFieldValorParc.setBackground(new java.awt.Color(0, 153, 255));
        jTextFieldValorParc.setForeground(java.awt.Color.white);
        jTextFieldValorParc.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.00"))));
        jTextFieldValorParc.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        jPanelFundo.add(jTextFieldValorParc);
        jTextFieldValorParc.setBounds(340, 80, 100, 25);
        jPanelFundo.add(jdcDataBase);
        jdcDataBase.setBounds(200, 80, 130, 25);

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Com Entrada?");
        jPanelFundo.add(jLabel10);
        jLabel10.setBounds(200, 10, 130, 16);

        jCBEntrada.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sim", "Não" }));
        jCBEntrada.setSelectedIndex(1);
        jCBEntrada.setToolTipText("");
        jCBEntrada.setBorder(null);
        jCBEntrada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCBEntradaActionPerformed(evt);
            }
        });
        jPanelFundo.add(jCBEntrada);
        jCBEntrada.setBounds(200, 30, 130, 25);

        jTextFieldValorEntrada.setEditable(false);
        jTextFieldValorEntrada.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jTextFieldValorEntradaKeyTyped(evt);
            }
        });
        jPanelFundo.add(jTextFieldValorEntrada);
        jTextFieldValorEntrada.setBounds(335, 30, 105, 25);

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Valor da Entrada:");
        jPanelFundo.add(jLabel11);
        jLabel11.setBounds(335, 10, 105, 16);

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::");
        jPanelFundo.add(jLabel8);
        jLabel8.setBounds(10, 120, 330, 30);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 10, 450, 360);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(370, 390, 90, 40);

        jButtonCancelar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jButtonCancelar.setText("Cancelar");
        jButtonCancelar.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonCancelar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonCancelar);
        jButtonCancelar.setBounds(280, 390, 90, 40);

        jButtonSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/applyResultado.png"))); // NOI18N
        jButtonSalvar.setText("Salvar");
        jButtonSalvar.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSalvar);
        jButtonSalvar.setBounds(190, 390, 90, 40);

        jLabel7.setText("Valor Total C/Juros R$:");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(10, 380, 160, 20);

        jFormattedTextFieldValorTotalCJ.setEditable(false);
        jFormattedTextFieldValorTotalCJ.setBackground(new java.awt.Color(255, 255, 255));
        jFormattedTextFieldValorTotalCJ.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 153, 255)));
        jFormattedTextFieldValorTotalCJ.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("¤#,##0.00"))));
        getContentPane().add(jFormattedTextFieldValorTotalCJ);
        jFormattedTextFieldValorTotalCJ.setBounds(10, 400, 160, 25);

        setBounds(0, 0, 467, 469);
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldQtdParcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldQtdParcActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldQtdParcActionPerformed

    private void jButtonGerarParcelaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonGerarParcelaActionPerformed

        LimpaDadosPreenchidos();
        qtdParcela = Integer.parseInt(jTextFieldQtdParc.getText());
        ConverteValor = 0;
        convertValorVirgula(jTextFieldTxJuros.getText());
        porcent = ConverteValor;
        ConverteValor = 0;
        if (jCBEntrada.getSelectedIndex()==0){
            
            convertValorVirgula(jTextFieldValorEntrada.getText());
            valorentrada = ConverteValor;
            ConverteValor = 0;
            convertValorVirgula(jTextFieldValorTotalOrc.getText());
            valorVenda = ConverteValor-valorentrada;
            
        }else{
            convertValorVirgula(jTextFieldValorTotalOrc.getText());
            valorVenda = ConverteValor;
        }
//        convertValorVirgula(jTextFieldValorTotalOrc.getText());
//        valorVenda = ConverteValor;
//        ConverteValor = 0;
        valorParcela = valorVenda/qtdParcela;
        jTableParcelaOS.removeAll();
        
        preencherTabelaParcelamento();
    }//GEN-LAST:event_jButtonGerarParcelaActionPerformed

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
dispose();
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonCancelarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelarActionPerformed
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{};
        dados.removeAll(dados);
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableParcelaOS.setModel(modelo);
        i = 1; cont = 1; porcent = 0; valorParcela = 0; qtdParcela = 1;
    }//GEN-LAST:event_jButtonCancelarActionPerformed

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
    int Pergunta = JOptionPane.showConfirmDialog(rootPane, "Deseja Realmanete Gerar as Parcelas?","Confirmando Parcelas a Gerar", JOptionPane.YES_NO_OPTION);
        if(Pergunta == JOptionPane.YES_OPTION) {
        
        int j = 1;
        String datavenc = DatFormat.format(jdcDataBase.getDate());
        String dia, mes, ano;
        dia = "" + datavenc.charAt(0) + datavenc.charAt(1) + "/";
        mes = "" + datavenc.charAt(3) + datavenc.charAt(4);
        ano = "/" + datavenc.charAt(6) + datavenc.charAt(7) + datavenc.charAt(8) + datavenc.charAt(9);
        int anoInt = Integer.parseInt("" + datavenc.charAt(6) + datavenc.charAt(7) + datavenc.charAt(8) + datavenc.charAt(9));
        int mesInt = Integer.parseInt(mes);
        while (j < cont){
            if (mesInt < 10) {
                modParcOrc.setDtLanc(DataHoje);
                modParcOrc.setCodCliente(CodCliente);
                modParcOrc.setCodOrc(Integer.parseInt(jTextFieldCodOrc.getText()));
                modParcOrc.setValorParcela(valorParcela + (valorParcela * (porcent / 100)));
                
                ConverteValor = 0;
                convertValorVirgula(jTextFieldValorTotalOrc.getText());
                modParcOrc.setValorTotal(ConverteValor);
                
                ConverteValor = 0;
                convertValorVirgula(jFormattedTextFieldValorTotalCJ.getText());
                modParcOrc.setValorTotalTCJ(ConverteValor);
                
                modParcOrc.setEntrada(String.valueOf(jCBEntrada.getSelectedItem()));
                modParcOrc.setValorEntrada(valorentrada);
                modParcOrc.setNumParcelas(qtdParcela);
                modParcOrc.setParcelaNum(j);
                modParcOrc.setDtVenc(dia + "0" + mesInt + "/" + anoInt);
                controPar.SalvaParcela(modParcOrc);
                
            } else {
                
                modParcOrc.setDtLanc(DataHoje);
                modParcOrc.setCodCliente(CodCliente);
                modParcOrc.setCodOrc(Integer.parseInt(jTextFieldCodOrc.getText()));
                modParcOrc.setValorParcela(valorParcela + (valorParcela * (porcent / 100)));
                
                ConverteValor = 0;
                convertValorVirgula(jTextFieldValorTotalOrc.getText());
                modParcOrc.setValorTotal(ConverteValor);
                
                ConverteValor = 0;
                convertValorVirgula(jFormattedTextFieldValorTotalCJ.getText());
                modParcOrc.setValorTotalTCJ(ConverteValor);
                
                modParcOrc.setEntrada(String.valueOf(jCBEntrada.getSelectedItem()));
                modParcOrc.setValorEntrada(valorentrada);
                modParcOrc.setNumParcelas(qtdParcela);
                modParcOrc.setParcelaNum(j);
                modParcOrc.setDtVenc(dia + mesInt + "/" + anoInt);
                controPar.SalvaParcela(modParcOrc);
                        
            }
            mesInt++;
            if (mesInt > 12) {
                anoInt++;
                mesInt = 1;
            }
            j++;
        }
        
        conParcOS.conecta();
        conParcOS.executaSQL("select * from orcamentos_parcelados where  id_orcamento='"+CodigoOrc+"'");
            try {
                conParcOS.rs.first();
                CodConta = conParcOS.rs.getInt("id");
            } catch (SQLException ex) {
                Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
            }conParcOS.desconecta();
        
        JOptionPane.showMessageDialog(rootPane, "Parcelas geradas!");
        
        
        if (jCBEntrada.getSelectedIndex()==0){
            PrintOrcParceEntrada();
        }else{
            PrintOrcParce();
        }
        
        dispose();
        }else{
            
        }
        
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jCBEntradaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jCBEntradaActionPerformed
        if (jCBEntrada.getSelectedIndex()==0){
            jTextFieldValorEntrada.setEditable(true);
            jTextFieldValorEntrada.setText("0,00");
        }else{
            jTextFieldValorEntrada.setEditable(false);
            jTextFieldValorEntrada.setText("0,00");
        }
    }//GEN-LAST:event_jCBEntradaActionPerformed

    private void jTextFieldValorEntradaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldValorEntradaKeyTyped
        String caracteres="0987654321,.";
        if(!caracteres.contains(evt.getKeyChar()+"")){
            evt.consume();

        }
    }//GEN-LAST:event_jTextFieldValorEntradaKeyTyped

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCancelar;
    private javax.swing.JButton jButtonGerarParcela;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JComboBox<String> jCBEntrada;
    private javax.swing.JFormattedTextField jFormattedTextFieldValorTotalCJ;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTableParcelaOS;
    private javax.swing.JTextField jTextFieldCodOrc;
    private javax.swing.JTextField jTextFieldQtdParc;
    private javax.swing.JTextField jTextFieldTxJuros;
    private javax.swing.JTextField jTextFieldValorEntrada;
    private javax.swing.JFormattedTextField jTextFieldValorParc;
    private javax.swing.JTextField jTextFieldValorTotalOrc;
    private com.toedter.calendar.JDateChooser jdcDataBase;
    // End of variables declaration//GEN-END:variables
}
