/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.ControleRelatorios;
import controle.PlanodeFundoForms;
import java.awt.event.ActionEvent;
import java.awt.event.KeyEvent;
import modelo.ModeloTabela;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;
import javax.swing.ListSelectionModel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author Lindembergue
 */
public class FormPesqPedidos extends javax.swing.JInternalFrame {
ConectaBanco conPesProd = new ConectaBanco();
String Usuario, UsuTipo;
DecimalFormat formatoNum;
SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
public static String NomeJIF = "FormPesqPedidos";
int CodPedido;
    ControleRelatorios ctrlRel = new ControleRelatorios();
    /**
     * Creates new form FormPesqProduto
     */
    public FormPesqPedidos() {
       
        initComponents();
        formatoNum = new DecimalFormat("#0.00");
        ColocaImagemFundoFrame();
        jTextFieldCampoPesquisa.grabFocus();
        jComboBoxTipoPesquisa.setSelectedIndex(1);
        preencherTablePesquisaOS("select pedidos.id_pedido, pedidos.valortotal, fornecedores.nome as fornecedor, pedidos.data from (pedidos inner join fornecedores on fornecedores.codigo=pedidos.fornecedor) order by data desc");
    
        jTextFieldCampoPesquisa.grabFocus();
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
        AcaoAoteclarEnter();
    }
    
    private void AcaoAoteclarEnter() {
        jTablePesquisaOS.getInputMap(JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT).put(KeyStroke.getKeyStroke(KeyEvent.VK_ENTER, 0), "Enter");
        jTablePesquisaOS.getActionMap().put("Enter", new AbstractAction() {
            @Override
            public void actionPerformed(ActionEvent ae) {
                ctrlRel.PrintPedido(CodPedido);
            }
        });
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
     
    
    public void toUpperCase(String texto, java.awt.event.KeyEvent evento){
        evento.setKeyChar(texto.toUpperCase().charAt(0));
    }
    
    public void preencherTablePesquisaOS(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Cód. Pedido","Fornecedor","Data"};
        conPesProd.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conPesProd.executaSQL(SQL);
        
        try {
            conPesProd.rs.first();
           
            //JOptionPane.showMessageDialog(rootPane, conOsPesquisa.rs.getString("id"));
            do{
                dados.add(new Object[]{conPesProd.rs.getInt("id_pedido"), conPesProd.rs.getString("fornecedor"), df.format(conPesProd.rs.getDate("data"))});
            }while(conPesProd.rs.next());
            
        } catch (SQLException ex) {
            //JOptionPane.showMessageDialog(rootPane,"Erro ao Obter Dados. \n Informação digitada não encontrada.");
        }
        
        DefaultTableCellRenderer cellRenderD = new DefaultTableCellRenderer();
	cellRenderD.setHorizontalAlignment(SwingConstants.RIGHT);
        
        DefaultTableCellRenderer cellRenderC = new DefaultTableCellRenderer();
	cellRenderC.setHorizontalAlignment(SwingConstants.CENTER);
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTablePesquisaOS.setModel(modelo);
        jTablePesquisaOS.getColumnModel().getColumn(0).setPreferredWidth(110);
        jTablePesquisaOS.getColumnModel().getColumn(0).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(0).setCellRenderer(cellRenderD);
        jTablePesquisaOS.getColumnModel().getColumn(1).setPreferredWidth(450);
        jTablePesquisaOS.getColumnModel().getColumn(1).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(2).setPreferredWidth(128);
        jTablePesquisaOS.getColumnModel().getColumn(2).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(2).setCellRenderer(cellRenderD);
        jTablePesquisaOS.getTableHeader().setReorderingAllowed(false);
        jTablePesquisaOS.setAutoResizeMode(jTablePesquisaOS.AUTO_RESIZE_OFF);
        jTablePesquisaOS.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conPesProd.desconecta();
              
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBoxTipoPesquisa = new javax.swing.JComboBox();
        jButtonPesquisar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisaOS = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldCampoPesquisa = new controle.ClassUpperField();
        jButtonSair = new javax.swing.JButton();
        jButtonNovaVenda = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jbPrintPed = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setTitle("Pedidos Efetuados");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Pesquisar por:");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 10, 200, 16);

        jComboBoxTipoPesquisa.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Código", "Cliente", "Data", "Todas" }));
        jComboBoxTipoPesquisa.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));
        jComboBoxTipoPesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoPesquisaActionPerformed(evt);
            }
        });
        jPanelFundo.add(jComboBoxTipoPesquisa);
        jComboBoxTipoPesquisa.setBounds(10, 30, 200, 30);

        jButtonPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/Search44Resultado.png"))); // NOI18N
        jButtonPesquisar.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(51, 153, 255)));
        jButtonPesquisar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesquisar);
        jButtonPesquisar.setBounds(670, 30, 40, 30);

        jTablePesquisaOS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTablePesquisaOS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePesquisaOSMouseClicked(evt);
            }
        });
        jTablePesquisaOS.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTablePesquisaOSKeyReleased(evt);
            }
        });
        jScrollPane1.setViewportView(jTablePesquisaOS);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 70, 700, 370);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Digite aqui os dados a pesquisar:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(210, 10, 390, 16);

        jTextFieldCampoPesquisa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldCampoPesquisaKeyReleased(evt);
            }
        });
        jPanelFundo.add(jTextFieldCampoPesquisa);
        jTextFieldCampoPesquisa.setBounds(210, 30, 460, 30);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 11, 720, 449);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(630, 470, 100, 40);

        jButtonNovaVenda.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/add.png"))); // NOI18N
        jButtonNovaVenda.setText("Novo");
        jButtonNovaVenda.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonNovaVenda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonNovaVendaActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonNovaVenda);
        jButtonNovaVenda.setBounds(430, 470, 100, 40);

        jButtonExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jButtonExcluir.setText("Excluir");
        jButtonExcluir.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonExcluir);
        jButtonExcluir.setBounds(530, 470, 100, 40);

        jbPrintPed.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/printer.png"))); // NOI18N
        jbPrintPed.setText("Imprimir");
        jbPrintPed.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jbPrintPed.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbPrintPedActionPerformed(evt);
            }
        });
        getContentPane().add(jbPrintPed);
        jbPrintPed.setBounds(330, 470, 100, 40);

        setBounds(0, 0, 740, 540);
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxTipoPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoPesquisaActionPerformed
        jTextFieldCampoPesquisa.grabFocus();
    }//GEN-LAST:event_jComboBoxTipoPesquisaActionPerformed

    private void jButtonPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarActionPerformed
        //        Cód.          = 0 Código, Cliente, Data, Todas
        //        Cliente       = 1
        //        Data          = 2
        //        Funcionario   = 3
        //        Todas         = 4

        int CampoEscolhido = (jComboBoxTipoPesquisa.getSelectedIndex());

        String DadosParaPesquisar = jTextFieldCampoPesquisa.getText();

        //preencherTablePesquisaOS("select os.id, clientes.nome_cliente, os.dt_abertura, funcionarios.nome_funcionario, os.status, os.total_os from os join clientes on clientes.id_cliente=os.id_cliente  join funcionarios on funcionarios.id_funcionario=os.id_funcionario where nome_cliente='%"+DadosParaPesquisar+"%'");

        if (CampoEscolhido == 0 ){
            if ("".equals(jTextFieldCampoPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite o codigo da Venda para pesquisar.");
            } else {
                int idCliente = Integer.parseInt(DadosParaPesquisar);
                preencherTablePesquisaOS("select pedidos.id_pedido, fornecedores.nome as fornecedor, pedidos.data from (pedidos inner join fornecedores on fornecedores.codigo=pedidos.fornecedor) where pedidos.id_pedido='"+idCliente+"'");
            }        
        

        }

        if (CampoEscolhido == 1){
            preencherTablePesquisaOS("select pedidos.id_pedido, fornecedores.nome as fornecedor, pedidos.data from (pedidos inner join fornecedores on fornecedores.codigo=pedidos.fornecedor) where fornecedores.nome like '"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 2){
            preencherTablePesquisaOS("select pedidos.id_pedido, fornecedores.nome as fornecedor, pedidos.data from (pedidos inner join fornecedores on fornecedores.codigo=pedidos.fornecedor) where pedidos.data like '"+DadosParaPesquisar+"%'");
        }
        
        if (CampoEscolhido == 3){
            preencherTablePesquisaOS("select pedidos.id_pedido, fornecedores.nome as fornecedor, pedidos.data from (pedidos inner join fornecedores on fornecedores.codigo=pedidos.fornecedor) order by data desc");
        }
        else{
            //JOptionPane.showMessageDialog(rootPane, "Erro ao Pesquisar dados!");
        }
    }//GEN-LAST:event_jButtonPesquisarActionPerformed

    private void jTablePesquisaOSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePesquisaOSMouseClicked
            
            String codOStex = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
            CodPedido = Integer.parseInt(codOStex);
            jbPrintPed.setText("Reimprimir Pedido: "+codOStex);
            
    }//GEN-LAST:event_jTablePesquisaOSMouseClicked

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
        dispose();
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonNovaVendaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonNovaVendaActionPerformed
    FormPedido FrmPedido = new FormPedido();
    FormPrincipal.AbreNovaJanelaS(FrmPedido);
//    FrmPedido.setVisible(true);
    dispose();
    }//GEN-LAST:event_jButtonNovaVendaActionPerformed

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed

    if (FormPrincipal.UsuarioPermissao.equals("2")){
        ExcluiVenda();
    }else{
        JOptionPane.showMessageDialog(rootPane, "Você não possui permissão suficiente para executar essa ação.");
    }
       
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jTextFieldCampoPesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldCampoPesquisaKeyReleased
        
        
        int CampoEscolhido = (jComboBoxTipoPesquisa.getSelectedIndex());

        String DadosParaPesquisar = jTextFieldCampoPesquisa.getText();

        //preencherTablePesquisaOS("select os.id, clientes.nome_cliente, os.dt_abertura, funcionarios.nome_funcionario, os.status, os.total_os from os join clientes on clientes.id_cliente=os.id_cliente  join funcionarios on funcionarios.id_funcionario=os.id_funcionario where nome_cliente='%"+DadosParaPesquisar+"%'");

        if (CampoEscolhido == 0 ){
            if ("".equals(jTextFieldCampoPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite o codigo da Venda para pesquisar.");
            } else {
                int idCliente = Integer.parseInt(DadosParaPesquisar);
                preencherTablePesquisaOS("select pedidos.id_pedido, fornecedores.nome as fornecedor, pedidos.data from (pedidos inner join fornecedores on fornecedores.codigo=pedidos.fornecedor) where pedidos.id_pedido='"+idCliente+"'");
            }        
        

        }

        if (CampoEscolhido == 1){
            preencherTablePesquisaOS("select pedidos.id_pedido, fornecedores.nome as fornecedor, pedidos.data from (pedidos inner join fornecedores on fornecedores.codigo=pedidos.fornecedor) where fornecedores.nome like '"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 2){
            preencherTablePesquisaOS("select pedidos.id_pedido, fornecedores.nome as fornecedor, pedidos.data from (pedidos inner join fornecedores on fornecedores.codigo=pedidos.fornecedor) where pedidos.data like '"+DadosParaPesquisar+"%'");
        }
        
        if (CampoEscolhido == 3){
            preencherTablePesquisaOS("select pedidos.id_pedido, fornecedores.nome as fornecedor, pedidos.data from (pedidos inner join fornecedores on fornecedores.codigo=pedidos.fornecedor) order by data desc");
        }
        else{
            //JOptionPane.showMessageDialog(rootPane, "Erro ao Pesquisar dados!");
        }
        
    }//GEN-LAST:event_jTextFieldCampoPesquisaKeyReleased

    private void jbPrintPedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbPrintPedActionPerformed
        ctrlRel.PrintPedido(CodPedido);
    }//GEN-LAST:event_jbPrintPedActionPerformed

    private void jTablePesquisaOSKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTablePesquisaOSKeyReleased
            String codOStex = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
            CodPedido = Integer.parseInt(codOStex);
            jbPrintPed.setText("Reimprimir Pedido: "+codOStex);
    }//GEN-LAST:event_jTablePesquisaOSKeyReleased
    
    public void ExcluiVenda(){
        int is = JOptionPane.showConfirmDialog(rootPane, "Deseja realmente Excluir?","Confirmando Exclusão", JOptionPane.YES_NO_OPTION);
    if(is == JOptionPane.YES_OPTION) {
        
        conPesProd.conecta();
        
        int codVendaSel = jTablePesquisaOS.getSelectedRow();
        
        if (codVendaSel==(-1)){
            
            JOptionPane.showMessageDialog(rootPane, "Por favor, selecione um Item cadastrado.");
        
        } else {String codProdx = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
            
            int cdVenda = Integer.parseInt(codProdx);
            
            //
            try {
                PreparedStatement pst;
                pst = conPesProd.conn.prepareStatement("delete  from pedidos_desc where pedido=?");
                pst.setInt(1, cdVenda);
                pst.execute();
                pst = conPesProd.conn.prepareStatement("delete  from pedidos where id_pedido=?");
                pst.setInt(1, cdVenda);
                pst.execute();
                JOptionPane.showMessageDialog(null, "Excluido com sucesso!");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Erro ao Excluir dados\n Erro código: "+ex);
            }
            
        }
        preencherTablePesquisaOS("select pedidos.id_pedido, fornecedores.nome as fornecedor, pedidos.data from (pedidos inner join fornecedores on fornecedores.codigo=pedidos.fornecedor) order by cdate(pedidos.data) desc");
        } 
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonNovaVenda;
    private javax.swing.JButton jButtonPesquisar;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JComboBox jComboBoxTipoPesquisa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisaOS;
    private controle.ClassUpperField jTextFieldCampoPesquisa;
    private javax.swing.JButton jbPrintPed;
    // End of variables declaration//GEN-END:variables
}
