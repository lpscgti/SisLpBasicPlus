/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.EncontrarValorNaTabela;
import controle.ExecutaTarefaAgendaAt;
import modelo.ModeloTabelaColorRender;
import modelo.ModeloTabela;
import modelo.ModeloTabelaColorRenderDestaque;
import modelo.ModeloTabelaColorRenderDestaqueTotal;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;
import org.jfree.data.time.SimpleTimePeriod;


/**
 *
 * @author Lindembergue
 */
public class FormAgenda extends javax.swing.JInternalFrame {
    ConectaBanco conAgenda = new ConectaBanco();
    ExecutaTarefaAgendaAt exeT = new ExecutaTarefaAgendaAt();
    EncontrarValorNaTabela evnT = new EncontrarValorNaTabela();
    ModeloTabelaColorRender MTCR = new ModeloTabelaColorRender();
    ModeloTabelaColorRenderDestaque MTCRD = new ModeloTabelaColorRenderDestaque();
    
    
    private String Data, Hora, Titulo, Descricao, Prioridade, Status;
    private int Cod, Flag, FlagEdita;
    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat hf = new SimpleDateFormat("HH:mm");
    
    
    /**
     * Creates new form FormAgenda
     */
    public FormAgenda() {
        
        initComponents();

        exeT.Iniciar();
        Flag = 0;
        FlagEdita = 0;
        
        if (exeT.FlagAgenda==1){
            preencherjTableAgendaHorariosUtrapassados();
            jLabelTituloAgenda.setText("Mostrando Todos os Compromissos Em Atraso.");
        }else{
            jLabelTituloAgenda.setText("Mostrando Todos os Compromissos Agendados.");
            preencherjTableAgenda("select * from agenda where situacao='AGUARDANDO' order by data asc , hora asc");
            
        }
        preencherjTableHoras("select * from agenda_horas");
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
       
    }
    public void preencherjTableAgendaHorariosUtrapassados(){
        
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat hf = new SimpleDateFormat("HH:mm:ss");
        Date hoje = new Date();
        Data = (df.format(hoje));
        Hora = (hf.format(hoje));
    
            String dhh = ""+Hora.charAt(0)+Hora.charAt(1);
            String dmm = ""+Hora.charAt(3)+Hora.charAt(4);
            String dss = ""+Hora.charAt(6)+Hora.charAt(7);
            String dDD = ""+Data.charAt(0)+Data.charAt(1);
            String dMM = ""+Data.charAt(3)+Data.charAt(4);
            String dYYYY = ""+Data.charAt(6)+Data.charAt(7)+Data.charAt(8)+Data.charAt(9);
            
            String HoraM = dhh+":"+dmm+":"+dss;
            String DataM = dYYYY+"-"+dMM+"-"+dDD;
            System.out.println(DataM);
            System.out.println(HoraM);
            java.sql.Date DtI = java.sql.Date.valueOf(DataM);
        
        
        preencherjTableAgendaHU("select * from agenda where data<=#"+DtI+" 22:50:00# and hora<=#"+DtI+" "+HoraM+"# and situacao='AGUARDANDO'");
        jButtonVerCEs.setText("Mostrar Compromissos Agendados");
    }
    
    public void preencherjTableAgendaHU(String SQL){
            
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Cod","Título","Prioridade","Data","Hora","Descrição"};
        conAgenda.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conAgenda.executaSQL(SQL);
        
        try {
            conAgenda.rs.first();
            do{
                               
                dados.add(new Object[]{conAgenda.rs.getInt("id"), conAgenda.rs.getString("titulo"),conAgenda.rs.getString("prioridade"), df.format(conAgenda.rs.getDate("data")), hf.format(conAgenda.rs.getTime("hora")), conAgenda.rs.getString("Descricao")});
                
            }while(conAgenda.rs.next());
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane, ex);
        }
        
        
        MTCRD.NomeTabela = jTableAgenda.getName();
        jTableAgenda.setDefaultRenderer(Object.class, new ModeloTabelaColorRenderDestaqueTotal());
                
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableAgenda.setModel(modelo);
        jTableAgenda.getColumnModel().getColumn(0).setPreferredWidth(60);
        jTableAgenda.getColumnModel().getColumn(0).setResizable(false);
        jTableAgenda.getColumnModel().getColumn(1).setPreferredWidth(150);
        jTableAgenda.getColumnModel().getColumn(1).setResizable(false);
        jTableAgenda.getColumnModel().getColumn(2).setPreferredWidth(100);
        jTableAgenda.getColumnModel().getColumn(2).setResizable(false);
        jTableAgenda.getColumnModel().getColumn(3).setPreferredWidth(100);
        jTableAgenda.getColumnModel().getColumn(3).setResizable(false);
        jTableAgenda.getColumnModel().getColumn(4).setPreferredWidth(100);
        jTableAgenda.getColumnModel().getColumn(4).setResizable(false);
        jTableAgenda.getColumnModel().getColumn(5).setPreferredWidth(300);
        jTableAgenda.getColumnModel().getColumn(5).setResizable(false);
        jTableAgenda.getTableHeader().setReorderingAllowed(false);
        jTableAgenda.setAutoResizeMode(jTableAgenda.AUTO_RESIZE_OFF);
        jTableAgenda.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conAgenda.desconecta();
      
    }
    
    
    public void preencherjTableAgenda(String SQL){
               
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Cod","Título","Prioridade","Data","Hora","Descrição"};
        conAgenda.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conAgenda.executaSQL(SQL);
        
        try {
            conAgenda.rs.first();
            do{
                               
                dados.add(new Object[]{conAgenda.rs.getInt("id"), conAgenda.rs.getString("titulo"), conAgenda.rs.getString("prioridade"), df.format(conAgenda.rs.getDate("data")), hf.format(conAgenda.rs.getTime("hora")), conAgenda.rs.getString("Descricao")});
                
            }while(conAgenda.rs.next());
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane, ex);
        }
        
        
        jTableAgenda.setDefaultRenderer(Object.class, new ModeloTabelaColorRender());
                
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableAgenda.setModel(modelo);
        jTableAgenda.getColumnModel().getColumn(0).setPreferredWidth(60);
        jTableAgenda.getColumnModel().getColumn(0).setResizable(false);
        jTableAgenda.getColumnModel().getColumn(1).setPreferredWidth(150);
        jTableAgenda.getColumnModel().getColumn(1).setResizable(false);
        jTableAgenda.getColumnModel().getColumn(2).setPreferredWidth(100);
        jTableAgenda.getColumnModel().getColumn(2).setResizable(false);
        jTableAgenda.getColumnModel().getColumn(3).setPreferredWidth(100);
        jTableAgenda.getColumnModel().getColumn(3).setResizable(false);
        jTableAgenda.getColumnModel().getColumn(4).setPreferredWidth(100);
        jTableAgenda.getColumnModel().getColumn(4).setResizable(false);
        jTableAgenda.getColumnModel().getColumn(5).setPreferredWidth(300);
        jTableAgenda.getColumnModel().getColumn(5).setResizable(false);
        jTableAgenda.getTableHeader().setReorderingAllowed(false);
        jTableAgenda.setAutoResizeMode(jTableAgenda.AUTO_RESIZE_OFF);
        jTableAgenda.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conAgenda.desconecta();
               
    }
    
    public void preencherjTableHoras(String SQL){
        
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"","Hora"};
        conAgenda.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conAgenda.executaSQL(SQL);
        
        try {
            
            conAgenda.rs.first();
            
            do{

               dados.add(new Object[]{conAgenda.rs.getInt("id"), conAgenda.rs.getString("hora")});
            
            }while(conAgenda.rs.next());
            
        } catch (SQLException ex) {
            //JOptionPane.showMessageDialog(rootPane,"Erro ao Preencher ArrayList"+ex);
        }
        
        jTableHorario.setDefaultRenderer(Object.class, new ModeloTabelaColorRender());
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTableHorario.setModel(modelo);
        jTableHorario.getColumnModel().getColumn(0).setPreferredWidth(42);
        jTableHorario.getColumnModel().getColumn(0).setResizable(false);
        jTableHorario.getColumnModel().getColumn(1).setPreferredWidth(107);
        jTableHorario.getColumnModel().getColumn(1).setResizable(false);
        jTableHorario.getTableHeader().setReorderingAllowed(false);
        jTableHorario.setAutoResizeMode(jTableHorario.AUTO_RESIZE_OFF);
        jTableHorario.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conAgenda.desconecta();
       }
    
    public void FlagjB (){
        
        if (Flag==0){
            
            Flag = 1;
            preencherjTableAgenda("select * from agenda where situacao='ENCERRADO' order by data asc , hora asc");
            jButtonVerCEs.setText("Retornar Compromissos Agendados");
            jLabelTituloAgenda.setText("Mostrando Todos os Compromissos Encerrados.");
        
        }else{
        
            preencherjTableAgenda("select * from agenda where situacao='AGUARDANDO' order by data asc , hora asc");
            Flag = 0;
            jButtonVerCEs.setText("Mostrar Compromissos Encerrados");
            jLabelTituloAgenda.setText("Mostrando Todos os Compromissos Agendados.");
            
        }
        
    }
    
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jDateChooserData = new com.toedter.calendar.JDateChooser();
        jSeparator1 = new javax.swing.JSeparator();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableHorario = new javax.swing.JTable();
        jSeparator2 = new javax.swing.JSeparator();
        jTextTitulo = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextAreaDescricao = new javax.swing.JTextArea();
        jComboBoxPrioridade = new javax.swing.JComboBox();
        jButtonAdd = new javax.swing.JButton();
        jLabelTituloAgenda = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTableAgenda = new javax.swing.JTable();
        jPanel3 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jTextFieldDT = new javax.swing.JTextField();
        jTextFieldHORA = new javax.swing.JTextField();
        jComboBoxSIT = new javax.swing.JComboBox();
        jTextFieldTitulo = new javax.swing.JTextField();
        jTextFieldDESCRICAO = new javax.swing.JTextField();
        jTextFieldPRIORIDADE = new javax.swing.JTextField();
        jButtonVerCEs = new javax.swing.JButton();
        jButtonSalvar = new javax.swing.JButton();
        jButtonExcluir = new javax.swing.JButton();
        jButtonSair = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setTitle("Agenda");
        getContentPane().setLayout(null);

        jPanel1.setBackground(java.awt.Color.white);
        jPanel1.setLayout(null);

        jPanel2.setBackground(java.awt.Color.white);
        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        jPanel2.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        jLabel1.setText("  Selecione a Data");
        jPanel2.add(jLabel1);
        jLabel1.setBounds(0, 0, 150, 30);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        jLabel2.setText("  Selecione um Horário");
        jPanel2.add(jLabel2);
        jLabel2.setBounds(0, 80, 150, 30);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        jLabel4.setText("  Título");
        jPanel2.add(jLabel4);
        jLabel4.setBounds(0, 260, 150, 30);

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        jLabel10.setText("  Descrição do  Compromisso");
        jPanel2.add(jLabel10);
        jLabel10.setBounds(0, 320, 150, 30);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 10)); // NOI18N
        jLabel3.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel3.setText("Prioridade:    ");
        jPanel2.add(jLabel3);
        jLabel3.setBounds(10, 440, 90, 25);
        jPanel2.add(jDateChooserData);
        jDateChooserData.setBounds(10, 30, 140, 30);
        jPanel2.add(jSeparator1);
        jSeparator1.setBounds(0, 72, 160, 10);

        jTableHorario.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(jTableHorario);

        jPanel2.add(jScrollPane2);
        jScrollPane2.setBounds(10, 110, 140, 140);
        jPanel2.add(jSeparator2);
        jSeparator2.setBounds(0, 260, 160, 10);

        jTextTitulo.setFont(new java.awt.Font("Monospaced", 0, 13)); // NOI18N
        jPanel2.add(jTextTitulo);
        jTextTitulo.setBounds(10, 290, 140, 30);

        jTextAreaDescricao.setColumns(20);
        jTextAreaDescricao.setLineWrap(true);
        jTextAreaDescricao.setRows(4);
        jTextAreaDescricao.setTabSize(0);
        jTextAreaDescricao.setWrapStyleWord(true);
        jTextAreaDescricao.setBorder(null);
        jScrollPane3.setViewportView(jTextAreaDescricao);

        jPanel2.add(jScrollPane3);
        jScrollPane3.setBounds(10, 350, 140, 80);

        jComboBoxPrioridade.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "1", "2", "3", "4", "5" }));
        jPanel2.add(jComboBoxPrioridade);
        jComboBoxPrioridade.setBounds(100, 440, 50, 25);

        jButtonAdd.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/add.png"))); // NOI18N
        jButtonAdd.setText("Adicionar");
        jButtonAdd.setMargin(new java.awt.Insets(0, 0, 0, 0));
        jButtonAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddActionPerformed(evt);
            }
        });
        jPanel2.add(jButtonAdd);
        jButtonAdd.setBounds(10, 470, 140, 40);

        jPanel1.add(jPanel2);
        jPanel2.setBounds(10, 10, 160, 520);

        jLabelTituloAgenda.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabelTituloAgenda.setForeground(new java.awt.Color(51, 153, 255));
        jLabelTituloAgenda.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelTituloAgenda.setText("Título");
        jLabelTituloAgenda.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        jPanel1.add(jLabelTituloAgenda);
        jLabelTituloAgenda.setBounds(180, 10, 710, 30);

        jTableAgenda.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTableAgenda.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTableAgendaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTableAgenda);

        jPanel1.add(jScrollPane1);
        jScrollPane1.setBounds(180, 40, 710, 290);

        jPanel3.setBackground(java.awt.Color.white);
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)), "Detalhes do Compromisso", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 11))); // NOI18N
        jPanel3.setLayout(null);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel5.setText("Data:");
        jPanel3.add(jLabel5);
        jLabel5.setBounds(10, 20, 50, 25);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel6.setText("Hora:");
        jPanel3.add(jLabel6);
        jLabel6.setBounds(170, 20, 50, 25);

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel7.setText("Situação:");
        jPanel3.add(jLabel7);
        jLabel7.setBounds(400, 20, 70, 25);

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel11.setText("Título:");
        jPanel3.add(jLabel11);
        jLabel11.setBounds(10, 50, 50, 25);

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel8.setText("Descrição do Compromisso:");
        jPanel3.add(jLabel8);
        jLabel8.setBounds(10, 80, 170, 25);

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel9.setText("Nível de Prioridade:");
        jPanel3.add(jLabel9);
        jLabel9.setBounds(10, 110, 120, 25);

        jTextFieldDT.setEditable(false);
        jTextFieldDT.setBackground(java.awt.Color.white);
        jTextFieldDT.setBorder(null);
        jTextFieldDT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldDTActionPerformed(evt);
            }
        });
        jPanel3.add(jTextFieldDT);
        jTextFieldDT.setBounds(60, 20, 90, 25);

        jTextFieldHORA.setEditable(false);
        jTextFieldHORA.setBackground(java.awt.Color.white);
        jTextFieldHORA.setBorder(null);
        jPanel3.add(jTextFieldHORA);
        jTextFieldHORA.setBounds(220, 20, 60, 25);

        jComboBoxSIT.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "AGUARDANDO", "ENCERRADO" }));
        jComboBoxSIT.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(153, 153, 153)));
        jComboBoxSIT.setEnabled(false);
        jPanel3.add(jComboBoxSIT);
        jComboBoxSIT.setBounds(470, 20, 230, 25);

        jTextFieldTitulo.setBorder(null);
        jPanel3.add(jTextFieldTitulo);
        jTextFieldTitulo.setBounds(60, 50, 470, 25);

        jTextFieldDESCRICAO.setEditable(false);
        jTextFieldDESCRICAO.setBackground(java.awt.Color.white);
        jTextFieldDESCRICAO.setBorder(null);
        jPanel3.add(jTextFieldDESCRICAO);
        jTextFieldDESCRICAO.setBounds(180, 80, 480, 25);

        jTextFieldPRIORIDADE.setEditable(false);
        jTextFieldPRIORIDADE.setBackground(java.awt.Color.white);
        jTextFieldPRIORIDADE.setBorder(null);
        jPanel3.add(jTextFieldPRIORIDADE);
        jTextFieldPRIORIDADE.setBounds(130, 110, 80, 25);

        jButtonVerCEs.setText("Mostrar Compromissos Encerrados");
        jButtonVerCEs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonVerCEsActionPerformed(evt);
            }
        });
        jPanel3.add(jButtonVerCEs);
        jButtonVerCEs.setBounds(10, 140, 410, 40);

        jButtonSalvar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/editResultado.png"))); // NOI18N
        jButtonSalvar.setText("Alterar");
        jButtonSalvar.setEnabled(false);
        jButtonSalvar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSalvarActionPerformed(evt);
            }
        });
        jPanel3.add(jButtonSalvar);
        jButtonSalvar.setBounds(430, 140, 90, 40);

        jButtonExcluir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/button_cancelResultado.png"))); // NOI18N
        jButtonExcluir.setText("Excluir");
        jButtonExcluir.setEnabled(false);
        jButtonExcluir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonExcluirActionPerformed(evt);
            }
        });
        jPanel3.add(jButtonExcluir);
        jButtonExcluir.setBounds(520, 140, 90, 40);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.setToolTipText("");
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        jPanel3.add(jButtonSair);
        jButtonSair.setBounds(610, 140, 90, 40);

        jPanel1.add(jPanel3);
        jPanel3.setBounds(180, 340, 710, 190);

        getContentPane().add(jPanel1);
        jPanel1.setBounds(0, 0, 900, 540);

        setBounds(0, 0, 900, 564);
    }// </editor-fold>//GEN-END:initComponents

    private void jButtonAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddActionPerformed
        
        if ( FlagEdita == 0){
            Data = (df.format(jDateChooserData.getDate()));
            Hora = "" + jTableHorario.getValueAt(jTableHorario.getSelectedRow(),1);
            Titulo = jTextTitulo.getText();
            Descricao = jTextAreaDescricao.getText();
            Prioridade = String.valueOf(jComboBoxPrioridade.getSelectedItem());
            
            String dhh = ""+Hora.charAt(0)+Hora.charAt(1);
            String dmm = ""+Hora.charAt(3)+Hora.charAt(4);
            String dDD = ""+Data.charAt(0)+Data.charAt(1);
            String dMM = ""+Data.charAt(3)+Data.charAt(4);
            String dYYYY = ""+Data.charAt(6)+Data.charAt(7)+Data.charAt(8)+Data.charAt(9);
            
            String HoraM = dhh+":"+dmm+":00";
            String DataM = dYYYY+"-"+dMM+"-"+dDD;
//            JOptionPane.showMessageDialog(rootPane, DataM+" "+HoraM);
            java.sql.Date Dt = java.sql.Date.valueOf(DataM);
            java.sql.Time Ht = java.sql.Time.valueOf(HoraM);
            
            conAgenda.conecta();
            try {
                
                PreparedStatement pst = conAgenda.conn.prepareStatement("insert into agenda (prioridade, titulo, descricao, data, hora, situacao)values(?,?,?,?,?,?)");
                pst.setInt(1, Integer.parseInt(Prioridade));
                pst.setString(2, Titulo);
                pst.setString(3, Descricao);
                pst.setDate(4, Dt);
                pst.setTime(5, Ht);
                pst.setString(6, "AGUARDANDO");
                pst.execute();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, ex);
            }
            Data = null;
            Hora = null;
            Titulo = null;
            Descricao = null;
            Prioridade = null;
            Date hoje = new Date();
            jDateChooserData.setDate(hoje);
            jTableHorario.setRowSelectionInterval(0,0);
            jTextAreaDescricao.setText("");
            jComboBoxPrioridade.setSelectedIndex(3);
            exeT.Iniciar();
            preencherjTableAgenda("select * from agenda where situacao='AGUARDANDO' order by data asc , hora asc");
            conAgenda.desconecta();
        
        }else {
            conAgenda.conecta();
            int i = JOptionPane.showConfirmDialog(rootPane, "Deseja Aterar Dados do Compromisso?","Comfirmar Alteração.", JOptionPane.YES_NO_OPTION);
            if(i == JOptionPane.YES_OPTION) {
                Data = (df.format(jDateChooserData.getDate()));
                Hora = "" + jTableHorario.getValueAt(jTableHorario.getSelectedRow(),1);
                Descricao = jTextAreaDescricao.getText();
                Prioridade = String.valueOf(jComboBoxPrioridade.getSelectedItem());
                String dhh = ""+Hora.charAt(0)+Hora.charAt(1);
                String dmm = ""+Hora.charAt(3)+Hora.charAt(4);
                String dDD = ""+Data.charAt(0)+Data.charAt(1);
                String dMM = ""+Data.charAt(3)+Data.charAt(4);
                String dYYYY = ""+Data.charAt(6)+Data.charAt(7)+Data.charAt(8)+Data.charAt(9);

                String HoraM = dhh+":"+dmm+":00";
                String DataM = dYYYY+"-"+dMM+"-"+dDD;

                java.sql.Date Dt2 = java.sql.Date.valueOf(DataM);
                java.sql.Time Ht2 = java.sql.Time.valueOf(HoraM);
            try {
                PreparedStatement pst = conAgenda.conn.prepareStatement("update agenda set titulo=?, prioridade=?, descricao=?, data=?, hora=?, situacao=? where id=?");
                pst.setString(1, Titulo);
                pst.setInt(2, Integer.parseInt(Prioridade));
                pst.setString(3, Descricao);
                pst.setDate(4, Dt2);
                pst.setTime(5, Ht2);
                pst.setString(6, String.valueOf(jComboBoxSIT.getSelectedItem()));
                pst.setInt(7, Cod);
                pst.execute();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(rootPane, ex);
            }
            Data = null;
            Hora = null;
            Titulo = null;
            Descricao = null;
            Prioridade = null;
            Date hoje = new Date();
            jDateChooserData.setDate(hoje);
            jTableHorario.setRowSelectionInterval(0,0);
            jTextTitulo.setText("");
            jTextAreaDescricao.setText("");
            jComboBoxPrioridade.setSelectedIndex(3);
            exeT.Iniciar();
            jLabelTituloAgenda.setText("Mostrando Todos os Compromissos Agendados.");
            preencherjTableAgenda("select * from agenda where situacao='AGUARDANDO' order by data asc , hora asc");
            jButtonSalvar.setEnabled(false);
            conAgenda.desconecta();
            Cod = 0;
            Flag = 0;
            FlagEdita = 0;
            jButtonVerCEs.setText("Mostrar Compromissos Encerrados");
            jButtonAdd.setText("Adicionar");
            }
            LimpaItens();
                
        }
    }//GEN-LAST:event_jButtonAddActionPerformed

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
        dispose();
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jTextFieldDTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldDTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldDTActionPerformed

    private void jTableAgendaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTableAgendaMouseClicked
        String codX = ("" + jTableAgenda.getValueAt(jTableAgenda.getSelectedRow(), 0));
        Cod = Integer.parseInt(codX);
        
       if (Flag == 0){
            conAgenda.conecta();
        
            conAgenda.executaSQL("select * from agenda where situacao='AGUARDANDO' and id= '"+Cod+"'");
            try {
                conAgenda.rs.first();
                jTextFieldDT.setText(String.valueOf(df.format(conAgenda.rs.getDate("data"))));
                jTextFieldHORA.setText(String.valueOf(hf.format(conAgenda.rs.getTime("hora"))));
                jComboBoxSIT.setSelectedItem(String.valueOf(conAgenda.rs.getString("situacao")));
                jTextFieldTitulo.setText(conAgenda.rs.getString("titulo"));
                jTextFieldDESCRICAO.setText(conAgenda.rs.getString("descricao"));
                jTextFieldPRIORIDADE.setText(String.valueOf(conAgenda.rs.getInt("prioridade")));

            } catch (SQLException ex) {
                //Logger.getLogger(FormAgenda.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            jButtonSalvar.setEnabled(true);
            jButtonExcluir.setEnabled(true);
            conAgenda.desconecta();
            
       }else{
           
            conAgenda.conecta();
                    
            conAgenda.executaSQL("select * from agenda where situacao='ENCERRADO' and id= '"+Cod+"'");
            try {
            conAgenda.rs.first();
            jTextFieldDT.setText(String.valueOf(df.format(conAgenda.rs.getDate("data"))));
            jTextFieldHORA.setText(String.valueOf(hf.format(conAgenda.rs.getTime("hora"))));
            jComboBoxSIT.setSelectedItem(String.valueOf(conAgenda.rs.getString("situacao")));
            jTextFieldTitulo.setText(conAgenda.rs.getString("titulo"));
            jTextFieldDESCRICAO.setText(conAgenda.rs.getString("descricao"));
            jTextFieldPRIORIDADE.setText(String.valueOf(conAgenda.rs.getInt("prioridade")));
                  
            } catch (SQLException ex) {
                //Logger.getLogger(FormAgenda.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            jButtonSalvar.setEnabled(true);
            jButtonExcluir.setEnabled(true);
            conAgenda.desconecta();
       }
        
        
    }//GEN-LAST:event_jTableAgendaMouseClicked

    private void jButtonSalvarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSalvarActionPerformed
        conAgenda.conecta();
        
        FlagEdita = 1;
        int CodHORA = 0;
        Data = jTextFieldDT.getText();
        Hora = jTextFieldHORA.getText();
        Titulo = jTextFieldTitulo.getText();
        jComboBoxSIT.setEnabled(true);
        jButtonAdd.setText("Salvar");
        try {
        try {
            
            conAgenda.executaSQL("select * from agenda_horas where hora='"+Hora+"'");
            conAgenda.rs.first();
            CodHORA = conAgenda.rs.getInt("id");
            jDateChooserData.setDate(new SimpleDateFormat("dd/MM/yyyy").parse(Data));
            evnT.EncontraNaTabela(jTableHorario, Hora);
            jTextTitulo.setText(Titulo);
            jTextAreaDescricao.setText(jTextFieldDESCRICAO.getText());
            jComboBoxPrioridade.setSelectedItem(String.valueOf(jTextFieldPRIORIDADE.getText()));
            
        } catch (SQLException ex) {
            Logger.getLogger(FormAgenda.class.getName()).log(Level.SEVERE, null, ex);
        }
        } catch (ParseException ex) {
            Logger.getLogger(FormAgenda.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        conAgenda.desconecta();
    }//GEN-LAST:event_jButtonSalvarActionPerformed

    private void jButtonExcluirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonExcluirActionPerformed
        conAgenda.conecta();
        
        int i = JOptionPane.showConfirmDialog(rootPane, "Tem certeza que deseja\nExluir esse Compromisso?","Confirmando Exclusão.", JOptionPane.YES_NO_OPTION);
        if(i == JOptionPane.YES_OPTION) {
        
        try {
            PreparedStatement pst = conAgenda.conn.prepareStatement("delete from agenda where id=?");
            pst.setInt(1, Cod);
            pst.execute();
        } catch (SQLException ex) {
            //Logger.getLogger(FormAgenda.class.getName()).log(Level.SEVERE, null, ex);
        }
        jButtonSalvar.setEnabled(false);
        jButtonExcluir.setEnabled(false);
        conAgenda.desconecta();
        Cod = 0;
        Flag = 0;
        preencherjTableAgenda("select * from agenda where situacao='AGUARDANDO' order by data asc , hora asc");
        jButtonVerCEs.setText("Mostrar Compromissos Encerrados");
        jTableHorario.setRowSelectionInterval(0,0);
        
        }
    }//GEN-LAST:event_jButtonExcluirActionPerformed

    private void jButtonVerCEsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonVerCEsActionPerformed
        
        if (jButtonVerCEs.getText().equals("Mostrar Compromissos Agendados")){
             preencherjTableAgenda("select * from agenda where situacao='AGUARDANDO' order by data asc , hora asc");
             jButtonVerCEs.setText("Mostrar Compromissos Encerrados");
             jLabelTituloAgenda.setText("Mostrando Todos os Compromissos Agendados.");
        }else{
            exeT.Iniciar();
            FlagjB();
            jTableHorario.setRowSelectionInterval(0,0);
        }
        
    }//GEN-LAST:event_jButtonVerCEsActionPerformed

    public void LimpaItens(){
        jTextFieldDT.setText("");
        jTextFieldHORA.setText("");
        jComboBoxSIT.setEnabled(false);
        jTextFieldTitulo.setText("");
        jTextFieldDESCRICAO.setText("");
        jTextFieldPRIORIDADE.setText("");
        jButtonSalvar.setEnabled(false);
        jButtonExcluir.setEnabled(false);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAdd;
    private javax.swing.JButton jButtonExcluir;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JButton jButtonSalvar;
    private javax.swing.JButton jButtonVerCEs;
    private javax.swing.JComboBox jComboBoxPrioridade;
    private javax.swing.JComboBox jComboBoxSIT;
    private com.toedter.calendar.JDateChooser jDateChooserData;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLabel jLabelTituloAgenda;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    public static javax.swing.JTable jTableAgenda;
    private javax.swing.JTable jTableHorario;
    private javax.swing.JTextArea jTextAreaDescricao;
    private javax.swing.JTextField jTextFieldDESCRICAO;
    private javax.swing.JTextField jTextFieldDT;
    private javax.swing.JTextField jTextFieldHORA;
    private javax.swing.JTextField jTextFieldPRIORIDADE;
    private javax.swing.JTextField jTextFieldTitulo;
    private javax.swing.JTextField jTextTitulo;
    // End of variables declaration//GEN-END:variables
}
