/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visual;

import controle.ConectaBanco;
import controle.PlanodeFundoForms;
import java.beans.PropertyVetoException;
import modelo.ModeloTabela;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.ListSelectionModel;

/**
 *
 * @author Lindembergue
 */
public class FormPesqFornecedor extends javax.swing.JInternalFrame {
ConectaBanco conPesForn = new ConectaBanco();
String Usuario, UsuTipo;
public static String NomeJIF = "FormPesqFornecedor";
public boolean a_form_ex = false; //identifica se o jormulario foi aberto a partir de outro formulario.
public JInternalFrame jifr; //declara classe jif para permitir que o codigo consiga restaurar a janela do formulario de origem.
    /**
     * Creates new form FormPesqFornecedor
     */
    public FormPesqFornecedor() {
        initComponents();
        ColocaImagemFundoFrame();
        jTextFieldCampoPesquisa.grabFocus();
        VerificaSeFornecedoresCadastrados();
        jComboBoxTipoPesquisa.setSelectedIndex(1);
        preencherTablePesquisaOS("select * from fornecedores order by codigo desc");
        jTextFieldCampoPesquisa.grabFocus();
        this.setFrameIcon(new ImageIcon(this.getClass().getResource("/imagens/sislp.ico.16.png")));
    }
    
    public void VerificaSeFornecedoresCadastrados(){
        
        conPesForn.conecta();
        conPesForn.executaSQL("select * from fornecedores");
    try {
        if (conPesForn.rs.first()){
            
        }else{
            JOptionPane.showMessageDialog(rootPane, "Não Existem Fornecedores");
            dispose();
        }
    } catch (SQLException ex) {
        Logger.getLogger(FormPesqCliente.class.getName()).log(Level.SEVERE, null, ex);
    }
        conPesForn.desconecta();
        
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jPanelFundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
    
    public void preencherTablePesquisaOS(String SQL){
        ArrayList dados = new ArrayList();
        String[] Colunas = new String[]{"Còdigo","Fornecedor","Endereço","Bairro","Cidade", "Fone", "Fone", "E-Mail", "Site"};
        conPesForn.conecta();
        //connVendaPsq.executaSQL("select * from clientes inner join itens_clientes_tel on clientes.id_cliente = itens_clientes_tel.id_cliente inner join telefone on itens_clientes_tel.id_tel=telefone.id_telefone inner join bairro on clientes.id_bairro=bairro.id_bairro inner join cidades on bairro.id_cidade=cidades.id_cidade inner join estados on cidades.id_estado=estados.id_estado");
        conPesForn.executaSQL(SQL);
        
        try {
            conPesForn.rs.first();
            //JOptionPane.showMessageDialog(rootPane, conOsPesquisa.rs.getString("id"));
            do{
                dados.add(new Object[]{conPesForn.rs.getString("codigo"), conPesForn.rs.getString("nome"), conPesForn.rs.getString("endereco"), conPesForn.rs.getString("bairro"), conPesForn.rs.getString("cidade"), conPesForn.rs.getString("tel1"), conPesForn.rs.getString("tel2"), conPesForn.rs.getString("email"), conPesForn.rs.getString("site")});
            }while(conPesForn.rs.next());
        } catch (SQLException ex) {
//            JOptionPane.showMessageDialog(rootPane,"Erro ao Obter Dados. \n Informação digitada não encontrada.");
        }
        
        ModeloTabela modelo = new ModeloTabela(dados, Colunas);
        jTablePesquisaOS.setModel(modelo);
        jTablePesquisaOS.getColumnModel().getColumn(0).setPreferredWidth(60);
        jTablePesquisaOS.getColumnModel().getColumn(0).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(1).setPreferredWidth(240);
        jTablePesquisaOS.getColumnModel().getColumn(1).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(2).setPreferredWidth(250);
        jTablePesquisaOS.getColumnModel().getColumn(2).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(3).setPreferredWidth(180);
        jTablePesquisaOS.getColumnModel().getColumn(3).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(4).setPreferredWidth(150);
        jTablePesquisaOS.getColumnModel().getColumn(4).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(5).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(5).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(6).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(6).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(7).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(7).setResizable(false);
        jTablePesquisaOS.getColumnModel().getColumn(8).setPreferredWidth(100);
        jTablePesquisaOS.getColumnModel().getColumn(8).setResizable(false);
//        jTablePesquisaOS.getColumnModel().getColumn(10).setPreferredWidth(100);
//        jTablePesquisaOS.getColumnModel().getColumn(10).setResizable(false);
        jTablePesquisaOS.getTableHeader().setReorderingAllowed(false);
        jTablePesquisaOS.setAutoResizeMode(jTablePesquisaOS.AUTO_RESIZE_OFF);
        jTablePesquisaOS.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        conPesForn.desconecta();
              
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanelFundo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jComboBoxTipoPesquisa = new javax.swing.JComboBox();
        jButtonPesquisar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTablePesquisaOS = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        jTextFieldCampoPesquisa = new controle.ClassUpperField();
        jButtonSair = new javax.swing.JButton();
        jButtonAbrir = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setIconifiable(true);
        setTitle("Fornecedores  Cadastrados");
        getContentPane().setLayout(null);

        jPanelFundo.setBackground(new java.awt.Color(0, 153, 255));
        jPanelFundo.setLayout(null);

        jLabel1.setForeground(java.awt.Color.white);
        jLabel1.setText("Pesquisar por:");
        jPanelFundo.add(jLabel1);
        jLabel1.setBounds(10, 10, 200, 16);

        jComboBoxTipoPesquisa.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Cód. Fornecedor", "Nome Fornecedor", "CNPJ", "Todas" }));
        jComboBoxTipoPesquisa.setBorder(null);
        jComboBoxTipoPesquisa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxTipoPesquisaActionPerformed(evt);
            }
        });
        jPanelFundo.add(jComboBoxTipoPesquisa);
        jComboBoxTipoPesquisa.setBounds(10, 30, 200, 30);

        jButtonPesquisar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/Search44Resultado.png"))); // NOI18N
        jButtonPesquisar.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonPesquisar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonPesquisarActionPerformed(evt);
            }
        });
        jPanelFundo.add(jButtonPesquisar);
        jButtonPesquisar.setBounds(660, 30, 40, 30);

        jTablePesquisaOS.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jTablePesquisaOS.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTablePesquisaOSMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jTablePesquisaOS);

        jPanelFundo.add(jScrollPane1);
        jScrollPane1.setBounds(10, 70, 690, 400);

        jLabel2.setForeground(java.awt.Color.white);
        jLabel2.setText("Digite aqui os dados a pesquisar:");
        jPanelFundo.add(jLabel2);
        jLabel2.setBounds(210, 10, 390, 16);

        jTextFieldCampoPesquisa.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                jTextFieldCampoPesquisaKeyReleased(evt);
            }
        });
        jPanelFundo.add(jTextFieldCampoPesquisa);
        jTextFieldCampoPesquisa.setBounds(210, 30, 450, 30);

        getContentPane().add(jPanelFundo);
        jPanelFundo.setBounds(10, 11, 710, 480);

        jButtonSair.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/exit_PNG36.png"))); // NOI18N
        jButtonSair.setText("Sair");
        jButtonSair.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonSair.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSairActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonSair);
        jButtonSair.setBounds(630, 500, 90, 40);

        jButtonAbrir.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/open folderResultado.png"))); // NOI18N
        jButtonAbrir.setText("Abrir");
        jButtonAbrir.setMargin(new java.awt.Insets(2, 2, 2, 2));
        jButtonAbrir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAbrirActionPerformed(evt);
            }
        });
        getContentPane().add(jButtonAbrir);
        jButtonAbrir.setBounds(540, 500, 90, 40);

        setBounds(0, 0, 733, 574);
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBoxTipoPesquisaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxTipoPesquisaActionPerformed
        jTextFieldCampoPesquisa.grabFocus();
    }//GEN-LAST:event_jComboBoxTipoPesquisaActionPerformed

    private void jButtonPesquisarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonPesquisarActionPerformed
        //        Cód. Cliente  = 0
        //        Nome Cliente  = 1
        //        CNPJ = 2
        //        Todas         = 3

        int CampoEscolhido = (jComboBoxTipoPesquisa.getSelectedIndex());

        String DadosParaPesquisar = jTextFieldCampoPesquisa.getText();

        //preencherTablePesquisaOS("select os.id, clientes.nome_cliente, os.dt_abertura, funcionarios.nome_funcionario, os.status, os.total_os from os join clientes on clientes.id_cliente=os.id_cliente  join funcionarios on funcionarios.id_funcionario=os.id_funcionario where nome_cliente='%"+DadosParaPesquisar+"%'");

        if (CampoEscolhido == 0 ){
            if ("".equals(jTextFieldCampoPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite o codigo para pesquisar.");
            } else {
                int idFornecedor = Integer.parseInt(DadosParaPesquisar);
                preencherTablePesquisaOS("select * from fornecedores where codigo='"+idFornecedor+"'");
            }
        }

        if (CampoEscolhido == 1){
            preencherTablePesquisaOS("select * from fornecedores where nome like '"+DadosParaPesquisar+"%'");
        }

        if (CampoEscolhido == 2){
            preencherTablePesquisaOS("select * from fornecedores where cnpj like '"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 3){
            preencherTablePesquisaOS("select * from fornecedores order by codigo desc");
        }
        else{
            //JOptionPane.showMessageDialog(rootPane, "Erro ao Pesquisar dados!");
        }
    }//GEN-LAST:event_jButtonPesquisarActionPerformed

    private void jTablePesquisaOSMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTablePesquisaOSMouseClicked
        if (evt.getClickCount()==2){
            String codFornx = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
            int cdForn = Integer.parseInt(codFornx);
            FormAbrirEditarFornecedores FrmAbreForn = new FormAbrirEditarFornecedores();
            FrmAbreForn.AbreCadFornecedor(cdForn);
            FormPrincipal.AbreNovaJanelaS(FrmAbreForn);
            dispose();
        }
    }//GEN-LAST:event_jTablePesquisaOSMouseClicked

    private void jButtonSairActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSairActionPerformed
        if (a_form_ex==true){
            try {
                jifr.setIcon(false);
            } catch (PropertyVetoException ex) {

            }
        }
        dispose();
    }//GEN-LAST:event_jButtonSairActionPerformed

    private void jButtonAbrirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAbrirActionPerformed
        int codFornSel = jTablePesquisaOS.getSelectedRow();
        if (codFornSel==(-1)){
            JOptionPane.showMessageDialog(rootPane, "Por favor, selecione um fornecedor cadastrado.");
        } else {String codFornx = ("" + jTablePesquisaOS.getValueAt(jTablePesquisaOS.getSelectedRow(), 0));
            int cdForn = Integer.parseInt(codFornx);
            FormAbrirEditarFornecedores FrmAbreForn = new FormAbrirEditarFornecedores();
            FrmAbreForn.a_form_ex = true; 
            FrmAbreForn.jifr = this;
            FrmAbreForn.AbreCadFornecedor(cdForn);
            FormPrincipal.AbreNovaJanelaS(FrmAbreForn);
            dispose();
        }
    }//GEN-LAST:event_jButtonAbrirActionPerformed

    private void jTextFieldCampoPesquisaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jTextFieldCampoPesquisaKeyReleased
        
         //        Cód. Cliente  = 0
        //        Nome Cliente  = 1
        //        CNPJ = 2
        //        Todas         = 3

        int CampoEscolhido = (jComboBoxTipoPesquisa.getSelectedIndex());

        String DadosParaPesquisar = jTextFieldCampoPesquisa.getText();

        //preencherTablePesquisaOS("select os.id, clientes.nome_cliente, os.dt_abertura, funcionarios.nome_funcionario, os.status, os.total_os from os join clientes on clientes.id_cliente=os.id_cliente  join funcionarios on funcionarios.id_funcionario=os.id_funcionario where nome_cliente='%"+DadosParaPesquisar+"%'");

        if (CampoEscolhido == 0 ){
            if ("".equals(jTextFieldCampoPesquisa.getText())){
                JOptionPane.showMessageDialog(rootPane, "Digite o codigo para pesquisar.");
            } else {
                int idFornecedor = Integer.parseInt(DadosParaPesquisar);
                preencherTablePesquisaOS("select * from fornecedores where codigo='"+idFornecedor+"'");
            }
        }

        if (CampoEscolhido == 1){
            preencherTablePesquisaOS("select * from fornecedores where nome like '"+DadosParaPesquisar+"%'");
        }

        if (CampoEscolhido == 2){
            preencherTablePesquisaOS("select * from fornecedores where cnpj like '"+DadosParaPesquisar+"%'");
        }
        if (CampoEscolhido == 3){
            preencherTablePesquisaOS("select * from fornecedores order by codigo desc");
        }
        else{
            //JOptionPane.showMessageDialog(rootPane, "Erro ao Pesquisar dados!");
        }
        
    }//GEN-LAST:event_jTextFieldCampoPesquisaKeyReleased

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAbrir;
    private javax.swing.JButton jButtonPesquisar;
    private javax.swing.JButton jButtonSair;
    private javax.swing.JComboBox jComboBoxTipoPesquisa;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanelFundo;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTablePesquisaOS;
    private controle.ClassUpperField jTextFieldCampoPesquisa;
    // End of variables declaration//GEN-END:variables
}
