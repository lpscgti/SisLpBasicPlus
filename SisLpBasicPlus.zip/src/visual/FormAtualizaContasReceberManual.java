/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JInternalFrame.java to edit this template
 */
package visual;

import controle.ConectaBanco;
import controle.PlanodeFundoForms;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author linde
 */
public class FormAtualizaContasReceberManual extends javax.swing.JInternalFrame {

    ConectaBanco con_ac = new ConectaBanco();
    DecimalFormat formatoNum = new DecimalFormat("#0.00");
    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    java.sql.Date DataConvertidaSQL;
    java.util.Date DataConvertidaJava;
    String DataConvertidaString;
    double ValorConvertido;
    PreparedStatement pst;
    String sql;
    int cod_conta = 0;
    int cod_cliente = 0;
    String nome_cliente;
    java.sql.Date dt_lancamento;
    java.sql.Date dt_vencimento;
    int n_parcela;
    int parcela_n;
    double valor;
    double valor_cj;
    double valor_total_cj;
    String entrada;
    double valor_entrada;
    double valor_restante;
    String origem;
    int cod_origem;
    int Editando = 0;
           
    
    
    
    
    /**
     * Creates new form FormAtualizaContasReceberManual
     */
    public FormAtualizaContasReceberManual() {
        initComponents();
        ColocaImagemFundoFrame();
        LimpaItens();
        DesativaItens();
        
    }
    
    public void ColocaImagemFundoFrame(){
        int AlturaForm = this.getHeight();
        int LarguraForm = this.getWidth();
        jpanel_fundo.setBorder(new PlanodeFundoForms(AlturaForm, LarguraForm));
    }
    
    public void ConvertDataParaString(java.sql.Date Data){
        if (Data!=null){
            DataConvertidaString = df.format(Data);
        }else{
            DataConvertidaString = "";
        }
        
    }
    
    public void ConverteStringparaData(String Data){
        if (!Data.equals("")){
            String dia = "" + Data.charAt(0) + Data.charAt(1);
            String mes = "" + Data.charAt(3) + Data.charAt(4);
            String ano = "" + Data.charAt(6) + Data.charAt(7) + Data.charAt(8) + Data.charAt(9);
            String dtfSQLData = ano+"-"+mes+"-"+dia;
            DataConvertidaSQL = java.sql.Date.valueOf(dtfSQLData);
        }else{
            DataConvertidaSQL = null;
        }
        
    }
    
    public void convertValorVirgula(String Valor){
        
        if (Valor.equals("")){
            Valor = "0";
        }else{
          
        }
        ValorConvertido = Double.parseDouble(Valor.replace(',', '.'));
    }
    
    public void AtivaItens(){
        jtf_cod_conta.setEnabled(true);
        jtf_cod_conta.setEditable(false);
        jtf_cod_cliente.setEnabled(true);
        jtf_cod_cliente.setEditable(false);
        jtf_nome_cliente.setEnabled(true);
        jtf_nome_cliente.setEditable(false);
        jtf_origem.setEnabled(true);
        jtf_origem.setEditable(false);
        jtf_cod_origem.setEnabled(true);
        jtf_cod_origem.setEditable(false);
        jtf_dt_lancamento.setEnabled(true);
        jtf_dt_lancamento.setEditable(false);
        jtf_dt_vencimento.setEnabled(true);
        jtf_dt_vencimento.setEditable(false);
        jtf_n_parcelas.setEnabled(true);
        jtf_parcela_n.setEnabled(true);
        jtf_valor_parcela.setEnabled(true);
        jtf_valor_parcela_cj.setEnabled(true);
        jtf_valor_total_cj.setEnabled(true);
        jcb_entrada.setEnabled(false);
        jtf_valor_entrada.setEnabled(true);
        jtf_valor_restante.setEnabled(true);
    }
    
    public void DesativaItens(){
        jtf_cod_conta.setEnabled(false);
        jtf_cod_conta.setEditable(false);
        jtf_cod_cliente.setEnabled(false);
        jtf_cod_cliente.setEditable(false);
        jtf_nome_cliente.setEnabled(false);
        jtf_nome_cliente.setEditable(false);
        jtf_origem.setEnabled(false);
        jtf_origem.setEditable(false);
        jtf_cod_origem.setEnabled(false);
        jtf_cod_origem.setEditable(false);
        jtf_dt_lancamento.setEnabled(false);
        jtf_dt_lancamento.setEditable(false);
        jtf_dt_vencimento.setEnabled(false);
        jtf_dt_vencimento.setEditable(false);
        jtf_n_parcelas.setEnabled(false);
        jtf_n_parcelas.setEditable(false);
        jtf_parcela_n.setEnabled(false);
        jtf_parcela_n.setEditable(false);
        jtf_valor_parcela.setEnabled(false);
        jtf_valor_parcela.setEditable(false);
        jtf_valor_parcela_cj.setEnabled(false);
        jtf_valor_parcela_cj.setEditable(false);
        jtf_valor_total_cj.setEnabled(false);
        jtf_valor_total_cj.setEditable(false);
        jcb_entrada.setEnabled(false);
        jtf_valor_entrada.setEnabled(false);
        jtf_valor_entrada.setEditable(false);
        jtf_valor_restante.setEnabled(false);
        jtf_valor_restante.setEditable(false);
    }
    
    public void LimpaItens(){
        jtf_cod_conta.setText("");
        jtf_cod_conta.setText("");
        jtf_cod_cliente.setText("");
        jtf_nome_cliente.setText("");
        jtf_origem.setText("");
        jtf_cod_origem.setText("");
        jtf_dt_lancamento.setText("");
        jtf_dt_vencimento.setText("");
        jtf_n_parcelas.setText("");
        jtf_parcela_n.setText("");
        jtf_valor_parcela.setText("");
        jtf_valor_parcela_cj.setText("");
        jtf_valor_total_cj.setText("");
        jcb_entrada.setSelectedItem("");
        jtf_valor_entrada.setText("");
        jtf_valor_restante.setText("");
        cod_conta = 0;
        cod_cliente = 0;
        nome_cliente = "";
        dt_lancamento = null;
        dt_vencimento = null;
        n_parcela = 0;
        parcela_n = 0;
        valor = 0;
        valor_cj = 0;
        valor_total_cj = 0;
        entrada = "";
        valor_entrada = 0;
        valor_restante = 0;
        origem = "";
        cod_origem = 0;
    }
    
    public void ObtemDados(int conta){
        con_ac.conecta();
        try {
            sql = "select * from contas_receber where codigo='"+conta+"'";
            con_ac.executaSQL(sql);
            if (con_ac.rs.first()){
                cod_conta = con_ac.rs.getInt("codigo");
                cod_cliente = con_ac.rs.getInt("codcliente");
                nome_cliente = con_ac.rs.getString("cliente");
                dt_lancamento = con_ac.rs.getDate("dtlancamento");
                dt_vencimento = con_ac.rs.getDate("dtvencimento");
                n_parcela = con_ac.rs.getInt("nparcela");
                parcela_n = con_ac.rs.getInt("parcelan");
                valor = con_ac.rs.getDouble("valor");
                valor_cj = con_ac.rs.getDouble("valorcj");
                valor_total_cj = con_ac.rs.getDouble("valortotalvcj");
                entrada = con_ac.rs.getString("entrada");
                valor_entrada = con_ac.rs.getDouble("valorentrada");
                valor_restante = con_ac.rs.getDouble("valorrest");
                origem = con_ac.rs.getString("origem");
                cod_origem = con_ac.rs.getInt("codorigem");
                
                jtf_cod_conta.setText(String.valueOf(cod_conta));
                jtf_cod_cliente.setText(String.valueOf(cod_cliente));
                jtf_nome_cliente.setText(nome_cliente);
                jtf_origem.setText(origem);
                jtf_cod_origem.setText(String.valueOf(cod_origem));
                ConvertDataParaString(dt_lancamento);
                jtf_dt_lancamento.setText(DataConvertidaString);
                ConvertDataParaString(dt_vencimento);
                jtf_dt_vencimento.setText(DataConvertidaString);
                jtf_n_parcelas.setText(String.valueOf(n_parcela));
                jtf_parcela_n.setText(String.valueOf(parcela_n));
                jtf_valor_parcela.setText(String.valueOf(formatoNum.format(valor)));
                jtf_valor_parcela_cj.setText(String.valueOf(formatoNum.format(valor_cj)));
                jtf_valor_total_cj.setText(String.valueOf(formatoNum.format(valor_total_cj)));
                jcb_entrada.setSelectedItem(entrada);
                jtf_valor_entrada.setText(String.valueOf(formatoNum.format(valor_entrada)));
                jtf_valor_restante.setText(String.valueOf(formatoNum.format(valor_restante)));
                AtivaItens();
                        
            }
        } catch (SQLException ex) {
            Logger.getLogger(FormAtualizaContasReceberManual.class.getName()).log(Level.SEVERE, null, ex);
        }
        con_ac.desconecta();
        
    }
    
    public boolean SalvaDados(){
        con_ac.conecta();
        
        n_parcela = Integer.valueOf(jtf_n_parcelas.getText());
        parcela_n = Integer.valueOf(jtf_parcela_n.getText());
        ValorConvertido = 0;
        convertValorVirgula(jtf_valor_parcela.getText());
        valor = ValorConvertido;
        ValorConvertido = 0;
        convertValorVirgula(jtf_valor_parcela_cj.getText());
        valor_cj = ValorConvertido;
        ValorConvertido = 0;
        convertValorVirgula(jtf_valor_total_cj.getText());
        valor_total_cj = ValorConvertido;
        if (jcb_entrada.getSelectedItem()!=null){entrada = jcb_entrada.getSelectedItem().toString();}else{entrada = "";}
        ValorConvertido = 0;
        convertValorVirgula(jtf_valor_entrada.getText());
        valor_entrada = ValorConvertido;
        ValorConvertido = 0;
        convertValorVirgula(jtf_valor_restante.getText());
        valor_restante = ValorConvertido;
        
        sql = "update contas_receber set nparcela=?, parcelan=?, valor=?, valorcj=?, valortotalvcj=?, "
                + "entrada=?, valorentrada=?, valorrest=? where codigo=?";
        try {
            pst = con_ac.conn.prepareStatement(sql);
            pst.setInt(1, n_parcela);
            pst.setInt(2, parcela_n);
            pst.setDouble(3, valor);
            pst.setDouble(4, valor_cj);
            pst.setDouble(5, valor_total_cj);
            pst.setString(6, entrada);
            pst.setDouble(7, valor_entrada);
            pst.setDouble(8, valor_restante);
            pst.setInt(9, cod_conta);
            int n = pst.executeUpdate();
            if (n!=0){
                return true;
            }else{
                return false;
            }
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(rootPane, "Hove um erro ao salvar dados: Método SalvarDados, erro: "+ex);
        }
        
        con_ac.desconecta();
        return false;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jpanel_fundo = new javax.swing.JPanel();
        jtf_cod_conta = new javax.swing.JTextField();
        jtf_cod_cliente = new javax.swing.JTextField();
        jtf_nome_cliente = new javax.swing.JTextField();
        jtf_cod_origem = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jtf_origem = new javax.swing.JTextField();
        jtf_dt_lancamento = new javax.swing.JTextField();
        jtf_dt_vencimento = new javax.swing.JTextField();
        jtf_n_parcelas = new javax.swing.JTextField();
        jtf_parcela_n = new javax.swing.JTextField();
        jtf_valor_parcela = new javax.swing.JTextField();
        jtf_valor_parcela_cj = new javax.swing.JTextField();
        jtf_valor_total_cj = new javax.swing.JTextField();
        jcb_entrada = new javax.swing.JComboBox<>();
        jtf_valor_entrada = new javax.swing.JTextField();
        jtf_valor_restante = new javax.swing.JTextField();
        jbt_finalizar = new javax.swing.JButton();
        jbt_edit = new javax.swing.JButton();

        setBackground(java.awt.Color.white);
        setBorder(null);
        setTitle("Atauliza Conta a Receber Manualmente");
        setToolTipText("");
        getContentPane().setLayout(null);

        jpanel_fundo.setBackground(new java.awt.Color(0, 153, 255));
        jpanel_fundo.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        jpanel_fundo.setLayout(null);
        jpanel_fundo.add(jtf_cod_conta);
        jtf_cod_conta.setBounds(130, 10, 140, 25);
        jpanel_fundo.add(jtf_cod_cliente);
        jtf_cod_cliente.setBounds(130, 40, 140, 25);
        jpanel_fundo.add(jtf_nome_cliente);
        jtf_nome_cliente.setBounds(130, 70, 420, 25);
        jpanel_fundo.add(jtf_cod_origem);
        jtf_cod_origem.setBounds(130, 130, 140, 25);

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Cod. Conta:");
        jpanel_fundo.add(jLabel1);
        jLabel1.setBounds(10, 10, 120, 25);

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel2.setText("Cod. Cliente:");
        jpanel_fundo.add(jLabel2);
        jLabel2.setBounds(10, 40, 120, 25);

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Nome do Cliente:");
        jpanel_fundo.add(jLabel3);
        jLabel3.setBounds(10, 70, 120, 25);

        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Origem:");
        jpanel_fundo.add(jLabel16);
        jLabel16.setBounds(10, 100, 120, 25);

        jLabel17.setForeground(new java.awt.Color(255, 255, 255));
        jLabel17.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel17.setText("Cod. da Origem:");
        jpanel_fundo.add(jLabel17);
        jLabel17.setBounds(10, 130, 120, 25);

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Dt. de Lançamento:");
        jpanel_fundo.add(jLabel4);
        jLabel4.setBounds(10, 160, 120, 25);

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Dt. de Vencimento:");
        jpanel_fundo.add(jLabel5);
        jLabel5.setBounds(10, 190, 120, 25);

        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Nº de Parcelas:");
        jpanel_fundo.add(jLabel6);
        jLabel6.setBounds(10, 220, 120, 25);

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Parcela Nº:");
        jpanel_fundo.add(jLabel7);
        jLabel7.setBounds(10, 250, 120, 25);

        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Valor da Parcela:");
        jpanel_fundo.add(jLabel8);
        jLabel8.setBounds(10, 280, 120, 25);

        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("V. da Parcela C/J:");
        jpanel_fundo.add(jLabel9);
        jLabel9.setBounds(10, 310, 120, 25);

        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("V. Total C/J:");
        jpanel_fundo.add(jLabel10);
        jLabel10.setBounds(10, 340, 120, 25);

        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Entrada:");
        jpanel_fundo.add(jLabel11);
        jLabel11.setBounds(10, 370, 120, 25);

        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("Valor da Entrada:");
        jpanel_fundo.add(jLabel12);
        jLabel12.setBounds(10, 400, 120, 25);

        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Valor Restante:");
        jpanel_fundo.add(jLabel13);
        jLabel13.setBounds(10, 430, 120, 25);
        jpanel_fundo.add(jtf_origem);
        jtf_origem.setBounds(130, 100, 140, 25);
        jpanel_fundo.add(jtf_dt_lancamento);
        jtf_dt_lancamento.setBounds(130, 160, 140, 25);
        jpanel_fundo.add(jtf_dt_vencimento);
        jtf_dt_vencimento.setBounds(130, 190, 140, 25);

        jtf_n_parcelas.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtf_n_parcelasKeyTyped(evt);
            }
        });
        jpanel_fundo.add(jtf_n_parcelas);
        jtf_n_parcelas.setBounds(130, 220, 140, 25);

        jtf_parcela_n.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtf_parcela_nKeyTyped(evt);
            }
        });
        jpanel_fundo.add(jtf_parcela_n);
        jtf_parcela_n.setBounds(130, 250, 140, 25);

        jtf_valor_parcela.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtf_valor_parcelaKeyTyped(evt);
            }
        });
        jpanel_fundo.add(jtf_valor_parcela);
        jtf_valor_parcela.setBounds(130, 280, 140, 25);

        jtf_valor_parcela_cj.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtf_valor_parcela_cjKeyTyped(evt);
            }
        });
        jpanel_fundo.add(jtf_valor_parcela_cj);
        jtf_valor_parcela_cj.setBounds(130, 310, 140, 25);

        jtf_valor_total_cj.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtf_valor_total_cjKeyTyped(evt);
            }
        });
        jpanel_fundo.add(jtf_valor_total_cj);
        jtf_valor_total_cj.setBounds(130, 340, 140, 25);

        jcb_entrada.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Sim", "Não", " " }));
        jpanel_fundo.add(jcb_entrada);
        jcb_entrada.setBounds(130, 370, 140, 25);

        jtf_valor_entrada.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtf_valor_entradaKeyTyped(evt);
            }
        });
        jpanel_fundo.add(jtf_valor_entrada);
        jtf_valor_entrada.setBounds(130, 400, 140, 25);

        jtf_valor_restante.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                jtf_valor_restanteKeyTyped(evt);
            }
        });
        jpanel_fundo.add(jtf_valor_restante);
        jtf_valor_restante.setBounds(130, 430, 140, 25);

        getContentPane().add(jpanel_fundo);
        jpanel_fundo.setBounds(10, 10, 560, 470);

        jbt_finalizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/accept.png"))); // NOI18N
        jbt_finalizar.setText("Finalizar");
        jbt_finalizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_finalizarActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_finalizar);
        jbt_finalizar.setBounds(470, 490, 100, 40);

        jbt_edit.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagens/icones/16x16/editResultado.png"))); // NOI18N
        jbt_edit.setText("Editar");
        jbt_edit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbt_editActionPerformed(evt);
            }
        });
        getContentPane().add(jbt_edit);
        jbt_edit.setBounds(370, 490, 100, 40);

        setBounds(0, 0, 581, 567);
    }// </editor-fold>//GEN-END:initComponents

    private void jbt_finalizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_finalizarActionPerformed
        // TODO add your handling code here:
        if (Editando==1){
            if (SalvaDados()==true){
            DesativaItens();
            LimpaItens();
            dispose();
            }
        }else{
            dispose();
        }
    }//GEN-LAST:event_jbt_finalizarActionPerformed

    private void jtf_n_parcelasKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtf_n_parcelasKeyTyped
        // TODO add your handling code here:
        String caracteres="0987654321";
        if(!caracteres.contains(evt.getKeyChar()+"")){
        evt.consume();
       
        }
    }//GEN-LAST:event_jtf_n_parcelasKeyTyped

    private void jtf_parcela_nKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtf_parcela_nKeyTyped
        // TODO add your handling code here:
        String caracteres="0987654321";
        if(!caracteres.contains(evt.getKeyChar()+"")){
        evt.consume();
       
        }
    }//GEN-LAST:event_jtf_parcela_nKeyTyped

    private void jtf_valor_parcelaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtf_valor_parcelaKeyTyped
        // TODO add your handling code here:
        String caracteres="0987654321,.";
        if(!caracteres.contains(evt.getKeyChar()+"")){
        evt.consume();
       
        }
    }//GEN-LAST:event_jtf_valor_parcelaKeyTyped

    private void jtf_valor_parcela_cjKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtf_valor_parcela_cjKeyTyped
        // TODO add your handling code here:
        String caracteres="0987654321,.";
        if(!caracteres.contains(evt.getKeyChar()+"")){
        evt.consume();
       
        }
    }//GEN-LAST:event_jtf_valor_parcela_cjKeyTyped

    private void jtf_valor_total_cjKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtf_valor_total_cjKeyTyped
        // TODO add your handling code here:
        String caracteres="0987654321,.";
        if(!caracteres.contains(evt.getKeyChar()+"")){
        evt.consume();
       
        }
    }//GEN-LAST:event_jtf_valor_total_cjKeyTyped

    private void jtf_valor_entradaKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtf_valor_entradaKeyTyped
        // TODO add your handling code here:
        String caracteres="0987654321,.";
        if(!caracteres.contains(evt.getKeyChar()+"")){
        evt.consume();
       
        }
    }//GEN-LAST:event_jtf_valor_entradaKeyTyped

    private void jtf_valor_restanteKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_jtf_valor_restanteKeyTyped
        // TODO add your handling code here:
        String caracteres="0987654321,.";
        if(!caracteres.contains(evt.getKeyChar()+"")){
        evt.consume();
       
        }
    }//GEN-LAST:event_jtf_valor_restanteKeyTyped

    private void jbt_editActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbt_editActionPerformed
        // TODO add your handling code here:
        AtivaItens();
        jtf_n_parcelas.setEditable(true);
        jtf_parcela_n.setEditable(true);
        jtf_valor_parcela.setEditable(true);
        jtf_valor_parcela_cj.setEditable(true);
        jtf_valor_total_cj.setEditable(true);
        jcb_entrada.setEnabled(true);
        jtf_valor_entrada.setEditable(true);
        jtf_valor_restante.setEditable(true);
        Editando = 1;
        
    }//GEN-LAST:event_jbt_editActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JButton jbt_edit;
    private javax.swing.JButton jbt_finalizar;
    private javax.swing.JComboBox<String> jcb_entrada;
    private javax.swing.JPanel jpanel_fundo;
    private javax.swing.JTextField jtf_cod_cliente;
    private javax.swing.JTextField jtf_cod_conta;
    private javax.swing.JTextField jtf_cod_origem;
    private javax.swing.JTextField jtf_dt_lancamento;
    private javax.swing.JTextField jtf_dt_vencimento;
    private javax.swing.JTextField jtf_n_parcelas;
    private javax.swing.JTextField jtf_nome_cliente;
    private javax.swing.JTextField jtf_origem;
    private javax.swing.JTextField jtf_parcela_n;
    private javax.swing.JTextField jtf_valor_entrada;
    private javax.swing.JTextField jtf_valor_parcela;
    private javax.swing.JTextField jtf_valor_parcela_cj;
    private javax.swing.JTextField jtf_valor_restante;
    private javax.swing.JTextField jtf_valor_total_cj;
    // End of variables declaration//GEN-END:variables
}
