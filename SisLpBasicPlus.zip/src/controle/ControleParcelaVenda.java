/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;


import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelo.ModeloParcelaVenda;

/**
 *
 * @author Lindembergue
 */
public class ControleParcelaVenda {
    ConectaBanco connParVenda = new ConectaBanco();
    String DataFormatada;
    
    public void QuebraData(String data){
        
        String dia = "" + data.charAt(0) + data.charAt(1);
        String mes = "" + data.charAt(3) + data.charAt(4);
        String ano = "" + data.charAt(6) + data.charAt(7) + data.charAt(8) + data.charAt(9);
    
        DataFormatada = ano+"-"+mes+"-"+dia;
        
     }
    
    public void SalvaParcela(ModeloParcelaVenda mod){
        connParVenda.conecta();
        try {
            PreparedStatement pst = connParVenda.conn.prepareStatement("insert into contas_receber (origem, codorigem, dtlancamento,dtvencimento, nparcela, parcelan, valor, valorcj, valortotalvcj,entrada,valorentrada,valorrest, situacao) values (?,?,?,?,?,?,?,?,?,?,?,?,?)");
            pst.setString(1, "VENDA");
            pst.setInt(2, mod.getCodVenda());
            QuebraData(mod.getDtLanc());
            java.sql.Date DtL = java.sql.Date.valueOf(DataFormatada);
            pst.setDate(3,DtL);
            QuebraData(mod.getDt_Venc());
            java.sql.Date DtV = java.sql.Date.valueOf(DataFormatada);
            pst.setDate(4, DtV);
            pst.setInt(5, mod.getNumParcelas());
            pst.setInt(6, mod.getParcelaNum());
            pst.setDouble(7, mod.getValorParcela());
            pst.setDouble(8, mod.getValorParcelaCJ());
            pst.setDouble(9, mod.getValorParcelaTCJ());
            pst.setString(10, mod.getEntrada());
            pst.setDouble(11, mod.getValorEntrada());
            pst.setDouble(12, mod.getValorParcelaCJ());
            pst.setString(13, "NP");
            pst.execute();
        
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao salvar as parcelas.\nErro: " + ex);
        }
        
        connParVenda.desconecta();
        
        }
}
