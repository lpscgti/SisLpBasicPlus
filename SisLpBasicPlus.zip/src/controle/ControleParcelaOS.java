/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import modelo.ModeloParcelaOs;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Lindembergue
 */
public class ControleParcelaOS {
    ConectaBanco connParOs = new ConectaBanco();
    String DataFormatada;
    
    public void QuebraData(String data){
        
        String dia = "" + data.charAt(0) + data.charAt(1);
        String mes = "" + data.charAt(3) + data.charAt(4);
        String ano = "" + data.charAt(6) + data.charAt(7) + data.charAt(8) + data.charAt(9);
    
        DataFormatada = ano+"-"+mes+"-"+dia;
        
     }
     
    public void SalvaParcela(ModeloParcelaOs mod){
        connParOs.conecta();
        try {
            PreparedStatement pst = connParOs.conn.prepareStatement("insert into contas_receber (dtlancamento,dtvencimento, nparcela, parcelan, valor, valorcj, valortotalvcj, entrada,valorentrada,valorrest, situacao, os) values (?,?,?,?,?,?,?,?,?,?,?,?)");
            
            QuebraData(mod.getDtLanc());
            java.sql.Date DtL = java.sql.Date.valueOf(DataFormatada);
            pst.setDate(1,DtL);
            QuebraData(mod.getDtVenc());
            java.sql.Date DtV = java.sql.Date.valueOf(DataFormatada);
            pst.setDate(2, DtV);
            pst.setInt(3, mod.getNumParcelas());
            pst.setInt(4, mod.getParcelaNum());
            pst.setDouble(5, mod.getValorParcela());
            pst.setDouble(6, mod.getValorParcelaCJ());
            pst.setDouble(7, mod.getValorParcelaTCJ());
            pst.setString(8, mod.getEntrada());
            pst.setDouble(9, mod.getValorEntrada());
            pst.setDouble(10, mod.getValorParcelaCJ());
            pst.setString(11, "NP");
            pst.setInt(12, mod.getCodOS());
            pst.execute();
        
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao salvar as parcelas.\nErro: " + ex);
        }
        
        connParOs.desconecta();
        
        }
}
