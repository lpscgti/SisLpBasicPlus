/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;


/**
 *
 * @author Lindembergue
 */
public class ExecutaTarefaAgendaAt {
    ConectaBanco conExTag = new ConectaBanco();
    EncontrarValorNaTabela evnT = new EncontrarValorNaTabela();
    String Data, Hora, DataAg, HoraAg;
    public String DataMarcada, HoraMarcada;
    public int FlagAgenda=0;
    public int FlagAgendaPergunta=0;
    public int FlagAgendaPerguntaR=0;
    public int Codigo;
   
    
    public void Iniciar(){
        
    SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat hf = new SimpleDateFormat("HH:mm:ss");
    Date hoje = new Date();
    Data = (df.format(hoje));
    Hora = (hf.format(hoje));
    //JOptionPane.showMessageDialog(null, "Data : "+Data+" Hora: "+Hora);
    
    conExTag.conecta();
    
            String dhh = ""+Hora.charAt(0)+Hora.charAt(1);
            String dmm = ""+Hora.charAt(3)+Hora.charAt(4);
            String dss = ""+Hora.charAt(6)+Hora.charAt(7);
            String dDD = ""+Data.charAt(0)+Data.charAt(1);
            String dMM = ""+Data.charAt(3)+Data.charAt(4);
            String dYYYY = ""+Data.charAt(6)+Data.charAt(7)+Data.charAt(8)+Data.charAt(9);
            
            String HoraM = dhh+":"+dmm+":"+dss;
            String DataM = dYYYY+"-"+dMM+"-"+dDD;
    
        try {
            conExTag.executaSQL("select * from agenda where data<=#"+DataM+"# and hora<=#"+HoraM+"# and situacao='AGUARDANDO'");
            if (conExTag.rs.first()){
                
                FlagAgenda=1;
                
            }else{
                
                FlagAgenda=0;
                
            }
        
        } catch (SQLException ex) {
            //Logger.getLogger(ExecutaTarefaAgenda.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    
    conExTag.desconecta();
    }
    
}
