/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 *
 * @author Lindembergue Pereira
 */
public class obter_arquivo_conf {
    
    public String servidor_local;
    public String plano_fundo_arquivo;
    public String tema_visual;
    
    
    
    public static Properties LerArquivoConfig() throws FileNotFoundException, IOException{
        
        Properties props = new Properties();
        Path caminho_arquivo_conf = Paths.get(System.getProperty("user.dir")+"/base/");
        FileInputStream arquivo = new FileInputStream(caminho_arquivo_conf+"/"+"config.ini");
        props.load(arquivo);
        
        return props;
        
    }
        
    public void ObterInfoConfig() throws IOException{
        
        LerArquivoConfig();
        Properties prop = LerArquivoConfig();
        servidor_local = prop.getProperty("Servidor.bd.local");
        plano_fundo_arquivo = prop.getProperty("Caminho.imagem.fundo");
        tema_visual = prop.getProperty("Tema.visual");
//        JOptionPane.showMessageDialog(null, "Caminho do Servidor: "+servidor_local); 
//        JOptionPane.showMessageDialog(null, "Caminho do Img.plano de fundo: "+plano_fundo_arquivo);
               
    }
    
    public void SalvainfoConfig() throws IOException{
        
        Properties prop = new Properties();
        prop.setProperty("Servidor.bd.local", servidor_local);
        prop.setProperty("Caminho.imagem.fundo", plano_fundo_arquivo);
        prop.setProperty("Tema.visual", tema_visual);
        Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/base/");
        File file = new File(caminhoTXT+"/"+"config.ini");
        FileOutputStream fos = new FileOutputStream(file);
        prop.store(fos, "Arquivo de Configuração:");
        fos.close();
        
    }
    
}
