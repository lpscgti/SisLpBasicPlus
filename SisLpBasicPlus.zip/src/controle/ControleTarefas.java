/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Programmer
 */
public class ControleTarefas {
    
    ConectaBanco conTask = new ConectaBanco();
    ConectaBanco conTask2 = new ConectaBanco();
    
    public void ReparaRegistrosInvalidosCadastrados(){
        ConectaBanco conTask = new ConectaBanco();
        conTask.conecta();
        PreparedStatement pst;
        conTask.executaSQL("select * from vendas where valorvenda=0");
        try {
            if (conTask.rs.first()){
                do{
                int codTempVenda = conTask.rs.getInt("codigo");
                    CancelaVenda(codTempVenda);
                }while(conTask.rs.next());
            }
        }   catch (SQLException ex) {
                Logger.getLogger(ControleTarefas.class.getName()).log(Level.SEVERE, null, ex);
        }//Repara Registros das Vendas
        EliminaErrosClientes();
        ElimnaErrosProdutos();
        ElimnaErrosFornecedores();
        conTask.desconecta();
    }
    
    public void CancelaVenda(int codTempVenda){
        ConectaBanco conTask2 = new ConectaBanco();
        conTask2.conecta();
        PreparedStatement pst;
        try {
//            JOptionPane.showMessageDialog(null, "Codivo venda: "+codTempVenda);
            conTask2.executaSQL("select * from vendas_desc where venda='"+codTempVenda+"'");
            
            if (conTask2.rs.first()){
            
            do{
            int qtdVend = conTask2.rs.getInt("quantidade");
            int codProd = conTask2.rs.getInt("produto");
            conTask2.executaSQL("select * from produtos where codigo='"+codProd+"'");
            conTask2.rs.first();
            int qtdEstoque = conTask2.rs.getInt("quantidade");
            
            int somaqtdVend = qtdEstoque+qtdVend;
            pst = conTask2.conn.prepareStatement("update produtos set quantidade=? where codigo=?");
            pst.setInt(1, somaqtdVend);
            pst.setInt(2, codProd);
            pst.execute();
            
            pst = conTask2.conn.prepareStatement("delete from vendas_desc where venda=?");
            pst.setInt(1, codTempVenda);
            pst.execute();
            
            RemoveVendaContasReceber(codTempVenda);
            
            pst = conTask2.conn.prepareStatement("delete from vendas where codigo=?");
            pst.setInt(1, codTempVenda);
            pst.execute();
            
            } while(conTask2.rs.next());
            
            }else{
            RemoveVendaContasReceber(codTempVenda);
            pst = conTask2.conn.prepareStatement("delete from vendas where codigo=?");
            pst.setInt(1, codTempVenda);
            pst.execute();
            
        } 
        
        }catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao cancelar a venda!\nErro:" + ex );
            conTask2.desconecta();
        }     
    }
    
    public void RemoveVendaContasReceber(int CodVenda){
        ConectaBanco conTask = new ConectaBanco();
        conTask.conecta();
        PreparedStatement pst;
        conTask.executaSQL("select * from contas_receber where origem='VENDA' and codorigem='"+CodVenda+"'");
        try {
            if (conTask.rs.first()){
                do{
                    int CodConta = conTask.rs.getInt("codigo");
                    pst = conTask.conn.prepareStatement("delete  from contas_receber_historico where conta=?");
                    pst.setInt(1, CodConta);
                    pst.execute();
                
                }while(conTask.rs.next());
            }
        
                

            pst = conTask.conn.prepareStatement("delete  from contas_receber where origem='VENDA' and codorigem=?");
            pst.setInt(1, CodVenda);
            pst.execute();
            
            } catch (SQLException ex) {
            Logger.getLogger(ControleTarefas.class.getName()).log(Level.SEVERE, null, ex);
            }
            conTask.desconecta();
    }
    
    public void EliminaErrosClientes(){
            ConectaBanco conTask = new ConectaBanco();
            conTask.conecta();
        try {
            PreparedStatement pst;
            pst = conTask.conn.prepareStatement("delete  from clientes where nome=?");
            pst.setString(1, "nome");
            pst.execute();
            pst = conTask.conn.prepareStatement("delete  from clientes where nome=?");
            pst.setString(1, "");
            pst.execute();
            pst = conTask.conn.prepareStatement("delete  from clientes where nome=?");
            pst.setString(1, null);
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(ControleTarefas.class.getName()).log(Level.SEVERE, null, ex);
        }
            conTask.desconecta();

    }
    
    public void ElimnaErrosProdutos(){
        ConectaBanco conTask = new ConectaBanco();
        conTask.conecta();
        try {
            PreparedStatement pst;
            pst = conTask.conn.prepareStatement("delete  from produtos where produto=?");
            pst.setString(1, "nome");
            pst.execute();
            pst = conTask.conn.prepareStatement("delete  from produtos where produto=?");
            pst.setString(1, "");
            pst.execute();
            pst = conTask.conn.prepareStatement("delete  from produtos where produto=?");
            pst.setString(1, null);
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(ControleTarefas.class.getName()).log(Level.SEVERE, null, ex);
        }
            conTask.desconecta();
    }
    
    public void ElimnaErrosFornecedores(){
        ConectaBanco conTask = new ConectaBanco();
        conTask.conecta();
        try {
            PreparedStatement pst;
            pst = conTask.conn.prepareStatement("delete  from fornecedores where nome=?");
            pst.setString(1, "nome");
            pst.execute();
            pst = conTask.conn.prepareStatement("delete  from fornecedores where nome=?");
            pst.setString(1, "");
            pst.execute();
            pst = conTask.conn.prepareStatement("delete  from fornecedores where nome=?");
            pst.setString(1, null);
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(ControleTarefas.class.getName()).log(Level.SEVERE, null, ex);
        }
            conTask.desconecta();
    }
}

