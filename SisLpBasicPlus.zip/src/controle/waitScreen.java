/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Label;
import java.awt.Toolkit;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JWindow;
import javax.swing.SwingUtilities;

/**
 *
 * @author Programmer
 */
public class waitScreen extends JWindow {
    public waitScreen() {
        
        JPanel content = (JPanel) getContentPane();
        content.setBackground(Color.white);
        final JProgressBar barra = new JProgressBar();
        barra.setBackground(Color.lightGray);
        barra.setForeground(Color.BLUE);
        int width = 250;
        int height = 55;
        Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        int x = ((screen.width - width) / 2);
        int y = ((screen.height - height) / 2)-20;
        setBounds(x, y, width, height);
        Label label = new Label("Aguarde!!!");
        label.setForeground(Color.red);
        label.setFont(new Font("Serif", Font.BOLD, 15));
        label.setAlignment(1);
        content.add(label, BorderLayout.SOUTH);
        content.add(barra, BorderLayout.CENTER);
        Color branca = new Color(255, 255, 255, 255);
        content.setBorder(BorderFactory.createLineBorder(branca, 1));
        setType(Type.POPUP);
        setVisible(true);
        SwingUtilities.invokeLater(new Runnable(){
            public void run() {
                                
                barra.setIndeterminate(true);
                
            }
        });
    }
    
    public void fecha(){
        this.dispose();
    }
    
    public void abre(){
        new waitScreen();
    }
    
//    public static void main(String[] args) {
//    new waitScreen();
////                try {
////                    Thread.sleep(10000);
////                } catch (InterruptedException ex) {
////                Logger.getLogger(waitScreen.class.getName()).log(Level.SEVERE, null, ex);
////                }
//    }
}
