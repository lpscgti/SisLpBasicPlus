/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import modelo.ModeloOrcamento;
import modelo.ModeloVendas;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Lindembergue
 */
public class ControleOrcamento {  
    int codProduto;
    int codCliente;
    ConectaBanco connVenda = new ConectaBanco();
    String DataFormatada;
    
    public void QuebraData(String data){
        
        String dia = "" + data.charAt(0) + data.charAt(1);
        String mes = "" + data.charAt(3) + data.charAt(4);
        String ano = "" + data.charAt(6) + data.charAt(7) + data.charAt(8) + data.charAt(9);
    
        DataFormatada = ano+"-"+mes+"-"+dia;
        
     }
    
    public void AddItem(ModeloOrcamento ModOrcamento){
        connVenda.conecta();
        try {
            PreparedStatement pst = connVenda.conn.prepareStatement("insert into orcamentos_descricao (id_orcamento, id_produto, qtd_produto, desconto, total_vendido)values(?,?,?,?,?)");
            pst.setInt(1, ModOrcamento.getIdOrcamento());
            pst.setInt(2, ModOrcamento.getIdProduto());
            pst.setInt(3, ModOrcamento.getQtd_produto());
            pst.setDouble(4, ModOrcamento.getDesconto());
            pst.setDouble(5, ModOrcamento.getTotal_vendido());
            pst.execute();
            connVenda.desconecta();
        } catch (SQLException ex) {
            connVenda.desconecta();
            JOptionPane.showMessageDialog(null, "Erro ao adicionar item.\n Erro:" + ex);
        }
        connVenda.desconecta();
        return;
    }
    
      
    
    public void FechaOrcamento (ModeloOrcamento ModOrcamento){
        
        connVenda.conecta();
        
        try {
            PreparedStatement pst = connVenda.conn.prepareStatement("update orcamentos set data_orcamento=?, valor_orcamento=?, id_cliente=?, tipo_pag=? where id_orcamento=?");
            
            QuebraData(ModOrcamento.getDtOrcamento());
            java.sql.Date DtO = java.sql.Date.valueOf(DataFormatada);
            pst.setDate(1, DtO);
            
            pst.setDouble(2, ModOrcamento.getValorOrcamento());
            pst.setInt(3, ModOrcamento.getIdCliente());
            pst.setString(4, ModOrcamento.getTipo_pag());
            pst.setInt(5, ModOrcamento.getIdOrcamento());
            pst.execute();
            //JOptionPane.showMessageDialog(null, "Venda finalizada com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao finalizar orçamento!\n"+ex);
        }
        connVenda.desconecta();
        
        
        
    }
    
        public void CancelaOrcamento(){
        connVenda.conecta();
        PreparedStatement pst;
        connVenda.executaSQL("select * from orcamentos where valor_orcamento=0");
        
        
        try {
            connVenda.rs.first();
            int codTempOrcamento = connVenda.rs.getInt("id_orcamento");
           // JOptionPane.showMessageDialog(null, "Codivo orcamento: "+codTempVenda);
            connVenda.executaSQL("select * from (orcamentos_descricao inner join produtos on produtos.codigo=orcamentos_descricao.id_produto) where id_orcamento='"+codTempOrcamento+"'");
            connVenda.rs.first();
            if (connVenda.rs.getRow()==(0)){
            pst = connVenda.conn.prepareStatement("delete from orcamentos where valor_orcamento=?");
            pst.setInt(1, 0);
            pst.execute();
            }else{
            do{ 
                pst = connVenda.conn.prepareStatement("delete from orcamentos_descricao where id_orcamento=?");
                pst.setInt(1, codTempOrcamento);
                pst.execute();
                                
            } while(connVenda.rs.next());
            pst = connVenda.conn.prepareStatement("delete from orcamentos where valor_orcamento=?");
            pst.setInt(1, 0);
            pst.execute();
        } 
        
        }catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao cancelar a orcamento!\nErro:" + ex );
            connVenda.desconecta();
        }     
        }
        
    

    



}





