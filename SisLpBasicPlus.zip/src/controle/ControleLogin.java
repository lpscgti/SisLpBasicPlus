/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import modelo.ModeloLogin;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Lindembergue
 */
public class ControleLogin {
    ConectaBanco conCadU = new ConectaBanco();
    
    
    
    public void GravaLogin (ModeloLogin modlog){
        conCadU.conecta();
        try {
            PreparedStatement pst = conCadU.conn.prepareStatement("update login set nome=?, senha=?, permissao=?, login=? where id_login=?");
            pst.setString(1, modlog.getNome());
            pst.setString(2, modlog.getSenha());
            pst.setString(3, modlog.getPermissao());
            pst.setString(4, modlog.getLogin());
            pst.setInt(5, modlog.getId());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Usuário cadastrado com sucesso!");
        } catch (SQLException ex) {
            Logger.getLogger(ControleLogin.class.getName()).log(Level.SEVERE, null, ex);
        }
        conCadU.desconecta();
    }
}
