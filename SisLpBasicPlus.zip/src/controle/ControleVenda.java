/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import modelo.ModeloVendas;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Lindembergue
 */
public class ControleVenda {  
    int codProduto;
    int codCliente;
    ConectaBanco connVenda = new ConectaBanco();
    String DataFormatada;
    
    public void QuebraData(String data){
        
        String dia = "" + data.charAt(0) + data.charAt(1);
        String mes = "" + data.charAt(3) + data.charAt(4);
        String ano = "" + data.charAt(6) + data.charAt(7) + data.charAt(8) + data.charAt(9);
    
        DataFormatada = ano+"-"+mes+"-"+dia;
        
     }
    
    public void AddItem(ModeloVendas ModVenda){
        connVenda.conecta();
        try {
            PreparedStatement pst = connVenda.conn.prepareStatement("insert into vendas_desc (venda, produto, quantidade, desconto, total)values(?,?,?,?,?)");
            pst.setInt(1, ModVenda.getIdVenda());
            pst.setInt(2, ModVenda.getIdProduto());
            pst.setInt(3, ModVenda.getQtd_produto());
            pst.setDouble(4, ModVenda.getDesconto());
            pst.setDouble(5, ModVenda.getTotal_vendido());
            pst.execute();
            int quant = 0, reslt = 0;
            connVenda.executaSQL("select * from produtos where codigo='" + ModVenda.getIdProduto()+ "'");
            connVenda.rs.first();
            quant = connVenda.rs.getInt("quantidade");
            reslt = quant - ModVenda.getQtd_produto();
            pst = connVenda.conn.prepareStatement("update produtos set quantidade=? where codigo=?");
            pst.setInt(1, reslt);
            pst.setInt(2, ModVenda.getIdProduto());
            pst.execute();
            connVenda.desconecta();
        } catch (SQLException ex) {
            connVenda.desconecta();
            JOptionPane.showMessageDialog(null, "Erro ao adicionar item.\n Erro:" + ex);
        }
        connVenda.desconecta();
        return;
    }
    
      
    
    public void FechaVenda (ModeloVendas modeloVenda){
        
        connVenda.conecta();
        
        try {
            PreparedStatement pst = connVenda.conn.prepareStatement("update vendas set data=?, valorvenda=?, cliente=?, tipo=? where codigo=?");
            QuebraData(modeloVenda.getDtVenda());
            java.sql.Date DtI = java.sql.Date.valueOf(DataFormatada);
            pst.setDate(1, DtI);
            pst.setDouble(2, modeloVenda.getValorVenda());
            pst.setInt(3, modeloVenda.getIdCliente());
            pst.setString(4, modeloVenda.getTipo_pag());
            pst.setInt(5, modeloVenda.getIdVenda());
            pst.execute();
            //JOptionPane.showMessageDialog(null, "Venda finalizada com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao finalizar venda!\n"+ex);
        }
        
        connVenda.desconecta();
        
    }
    
        public void CancelaVenda(){
        
        connVenda.conecta();
        PreparedStatement pst;
        connVenda.executaSQL("select * from vendas where valorvenda=0");
        
        
        try {
        
            connVenda.rs.first();
            int codTempVenda = connVenda.rs.getInt("codigo");
           // JOptionPane.showMessageDialog(null, "Codivo venda: "+codTempVenda);
            ConectaBanco conTask2 = new ConectaBanco();
            conTask2.conecta();
        
//            JOptionPane.showMessageDialog(null, "Codivo venda: "+codTempVenda);
            conTask2.executaSQL("select * from vendas_desc where venda='"+codTempVenda+"'");
            
            if (conTask2.rs.first()){
            
            do{
            int qtdVend = conTask2.rs.getInt("quantidade");
            int codProd = conTask2.rs.getInt("produto");
            conTask2.executaSQL("select * from produtos where codigo='"+codProd+"'");
            conTask2.rs.first();
            int qtdEstoque = conTask2.rs.getInt("quantidade");
            
            int somaqtdVend = qtdEstoque+qtdVend;
            pst = conTask2.conn.prepareStatement("update produtos set quantidade=? where codigo=?");
            pst.setInt(1, somaqtdVend);
            pst.setInt(2, codProd);
            pst.execute();
            
            pst = conTask2.conn.prepareStatement("delete from vendas_desc where venda=?");
            pst.setInt(1, codTempVenda);
            pst.execute();
            
            pst = conTask2.conn.prepareStatement("delete from vendas where codigo=?");
            pst.setInt(1, codTempVenda);
            pst.execute();
            
            } while(conTask2.rs.next());
            
            }else{
            pst = conTask2.conn.prepareStatement("delete from vendas where codigo=?");
            pst.setInt(1, codTempVenda);
            pst.execute();
            }
            conTask2.desconecta();
        
              
        }catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao cancelar a venda!\nErro:" + ex );
            connVenda.desconecta();
        }     
        }
        
    

    public void GeraContaReceber(ModeloVendas modeloVenda){
        connVenda.conecta();
                            java.sql.Date DtV;
                            try {
                            PreparedStatement pst = connVenda.conn.prepareStatement("insert into contas_receber (codcliente, cliente, origem, codorigem, dtlancamento, dtvencimento, nparcela, parcelan, valor, valorcj, valortotalvcj, valorrest, situacao) values (?,?,?,?,?,?,?,?,?,?,?,?,?)");
                            pst.setInt(1, modeloVenda.getIdCliente());
                            pst.setString(2, modeloVenda.getCliente());
                            pst.setString(3, "VENDA");
                            pst.setInt(4, modeloVenda.getIdVenda());
                            
                            QuebraData(modeloVenda.getDtVenda());
                            DtV = java.sql.Date.valueOf(DataFormatada);
                            
                            pst.setDate(5, DtV);
                            pst.setDate(6, DtV);
                            
                            pst.setInt(7, 1);
                            pst.setInt(8, 1);
                            pst.setDouble(9, modeloVenda.getValorVenda());
                            pst.setDouble(10, modeloVenda.getValorVenda());
                            pst.setDouble(11, modeloVenda.getValorVenda());
                            pst.setDouble(12, modeloVenda.getValorVenda());
                            pst.setString(13, "NP");
                            pst.execute();
                            
                            } catch (SQLException ex) {
                                JOptionPane.showMessageDialog(null,"Erro ao Gerar Nota do Cliente\nno cadastro de Contas a Receber.\nErro: "+ex);
                            }
        connVenda.desconecta();
    }



}





