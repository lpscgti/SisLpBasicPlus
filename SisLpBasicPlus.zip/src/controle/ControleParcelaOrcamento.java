/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modelo.ModeloParcelaOrcamento;

/**
 *
 * @author Lindembergue
 */
public class ControleParcelaOrcamento {
    ConectaBanco connParOs = new ConectaBanco();
    String DataFormatada;
    
    public void QuebraData(String data){
        
        String dia = "" + data.charAt(0) + data.charAt(1);
        String mes = "" + data.charAt(3) + data.charAt(4);
        String ano = "" + data.charAt(6) + data.charAt(7) + data.charAt(8) + data.charAt(9);
    
        DataFormatada = ano+"-"+mes+"-"+dia;
        
     }
     
    public void SalvaParcela(ModeloParcelaOrcamento mod){
        connParOs.conecta();
        try {
            
            PreparedStatement pst = connParOs.conn.prepareStatement("insert into orcamentos_parcelados (id_orcamento, dtlancamento, dtvencimento, nparcela, parcelan, v_t_orcamento, v_t_orcamentocj, v_t_parcela, entrada, v_entrada) values (?,?,?,?,?,?,?,?,?,?)");
            
            pst.setInt(1, mod.getCodOrc());
            
            QuebraData(mod.getDtLanc());
            java.sql.Date DtL = java.sql.Date.valueOf(DataFormatada);
            pst.setDate(2,DtL);
            
            QuebraData(mod.getDtVenc());
            java.sql.Date DtV = java.sql.Date.valueOf(DataFormatada);
            pst.setDate(3, DtV);
            
            pst.setInt(4, mod.getNumParcelas());
            pst.setInt(5, mod.getParcelaNum());
            pst.setDouble(6, mod.getValorTotal());
            pst.setDouble(7, mod.getValorTotalTCJ());
            pst.setDouble(8, mod.getValorParcela());
            pst.setString(9, mod.getEntrada());
            pst.setDouble(10, mod.getValorEntrada());
            pst.execute();
        
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao salvar as parcelas.\nErro: " + ex);
        }
        
        connParOs.desconecta();
        
        }
}
