/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;


import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import javax.imageio.ImageIO;
import javax.swing.border.Border;
import visual.FormPrincipal;

/**
 *
 * @author Lindembergue
 */



public class PlanodeFundo implements Border{
    ConectaBanco conPlF = new ConectaBanco();
            
    String caminhoImagem;
    int TamTelaAltura, TamTelaLargura, TA, TL;
    
    //public Graphics2D fundo;
    public BufferedImage back;
 
    public PlanodeFundo(){
        
        Dimension TamTela = Toolkit.getDefaultToolkit().getScreenSize(); //Código para obter o tamenho de altura e largura da tela.
        TamTelaAltura = (int) TamTela.getHeight();//Armazena a altura
        TamTelaLargura = (int) TamTela.getWidth();//Armazena a largura
        TA = FormPrincipal.AreaDeTrabalhoPrincipal.getHeight();
        TL = FormPrincipal.AreaDeTrabalhoPrincipal.getWidth();
        
        String NomePlanoFundo = "";
        
        if (TL>=1360&&TA>=606){
            NomePlanoFundo = "plano_de_fundo_1366x606.png";
        }else if (TL==1024&&TA==606){
            NomePlanoFundo = "plano_de_fundo_1024x606.png";
        }else if (TA==638&&TL==1280){
            NomePlanoFundo = "plano_de_fundo_1280x638.png";
        }else if (TL==1280&&TA<638){
            NomePlanoFundo = "plano_de_fundo_1280x558.png";
        }
                
        try {

            Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/Plano_de_fundo");
            File file = new File(caminhoTXT+"/"+NomePlanoFundo);
            back = ImageIO.read(file);
            
        } catch (Exception ex) {            
        }
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        //g.drawImage(back, (x + (width - back.getWidth())/2),(y + (height - back.getHeight())/2), null);
        g.drawImage(back, x, y, TL, TA, c);
    }
 
    public Insets getBorderInsets(Component c) {
        return new Insets(0,0,0,0);
    }
 
    public boolean isBorderOpaque() {
        return false;
    }
 
}
   
         