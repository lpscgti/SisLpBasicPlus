/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import modelo.ModeloRecibo;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Lindembergue
 */
public class ControleRecibo {
    ConectaBanco conCtrlRecibo = new ConectaBanco();
    
    
    public void GeraRecibo (ModeloRecibo modRecibo){
        conCtrlRecibo.conecta();
        try {
            PreparedStatement pst = conCtrlRecibo.conn.prepareStatement("update recibo set nome=?, valor=?, valorext=?, referencia=?, cidade=?, estado=?, data=?, obs=? where codigo=?");
            pst.setString(1, modRecibo.getNome());
            pst.setDouble(2, modRecibo.getValor());
            pst.setString(3, modRecibo.getValorExt());
            pst.setString(4, modRecibo.getRef());
            pst.setString(5, modRecibo.getCidade());
            pst.setString(6, modRecibo.getEstado());
            pst.setString(7, modRecibo.getData());
            pst.setString(8, modRecibo.getObs());
            pst.setInt(9, modRecibo.getId());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Recibo Gerado com Sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Gerar recibo no Banco de Dados!\nErro: "+ex);
        }
        
        conCtrlRecibo.desconecta();
    }
    
}
