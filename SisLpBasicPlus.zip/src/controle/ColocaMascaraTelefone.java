/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controle;

import javax.swing.JFormattedTextField;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;

/**
 *
 * @author linde
 */
public class ColocaMascaraTelefone {
    public void mudaMascaraTelefone(JFormattedTextField format) {
        try {
            format.setValue(null);
            String nome = format.getText().replaceAll("-", "").replaceAll("\\(", "").replaceAll("\\)", "");
            final MaskFormatter mask = new MaskFormatter();
            switch (nome.length()) {
                case 8:
                    mask.setMask("####-####");
                    format.setFormatterFactory(new DefaultFormatterFactory(mask));
                    break;
                case 9:
                    mask.setMask("#####-####");
                    format.setFormatterFactory(new DefaultFormatterFactory(mask));
                    break;
                case 10:
                    mask.setMask("(##)####-####");
                    format.setFormatterFactory(new DefaultFormatterFactory(mask));
                    break;
                case 11:
                    mask.setMask("(##)#####-####");
                    format.setFormatterFactory(new DefaultFormatterFactory(mask));
                    break;
                default:
                    break;
            }
            format.setText(nome);
        } catch (Exception asd) {
            System.out.println(asd);
        }
    }

}
