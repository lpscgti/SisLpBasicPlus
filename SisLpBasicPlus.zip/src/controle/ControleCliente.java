/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import modelo.ModeloCliente;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Lindembergue
 */
public class ControleCliente {
    ConectaBanco ConCliente = new ConectaBanco();
    ModeloCliente ModCliente = new ModeloCliente();
    
    public void SalvaDados (ModeloCliente modCliente){
        
        ConCliente.conecta();
        
        try {
            PreparedStatement pst = ConCliente.conn.prepareStatement("update clientes set nome=?, endereco=?, bairro=?, cidade=?, estado=?, cep=?, fone1=?, fone2=?, rg=?, cpf=?, cnpj=?, DataNasc=?, obs=?, PessoaJuridica=? where Codigo=?");
            pst.setString(1, modCliente.getNome());
            pst.setString(2, modCliente.getEndereco());
            pst.setString(3, modCliente.getBairro());
            pst.setString(4, modCliente.getCidade());
            pst.setString(5, modCliente.getEstado());
            pst.setString(6, modCliente.getCep());
            pst.setString(7, modCliente.getTel1());
            pst.setString(8, modCliente.getTel2());
            pst.setString(9, modCliente.getRg());
            pst.setString(10, modCliente.getCpf());
            pst.setString(11, modCliente.getCnpj());
            pst.setString(12, modCliente.getDtNascimento());
            pst.setString(13, modCliente.getObs());
            pst.setString(14, modCliente.getPj());
            pst.setInt(15, modCliente.getId());
            pst.execute();
            //JOptionPane.showMessageDialog(null, "Venda finalizada com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao finalizar Salvar dados!\n"+ex);
        }
        
        
    }
    
    public void ExcluiDados (ModeloCliente modCliente){
        ConCliente.conecta();
        PreparedStatement pst;
        try {
            pst = ConCliente.conn.prepareStatement("delete from clientes where Codigo=?");
            pst.setInt(1, modCliente.getId());
            pst.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Excluir dados\n Erro código: "+ex);
        }
        
        ConCliente.desconecta();
    }
    
}
