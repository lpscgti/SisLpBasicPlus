/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modelo.ModeloDadosEmpresa;

/**
 *
 * @author ProgXBERGUE
 */
public class ControleEmpresa {
ConectaBanco ConCE = new ConectaBanco();
public String menssagem;
public String de_nomefantasia, de_rasao, de_cnpj, de_ie, de_endereco, de_bairro, de_cidade, de_estado, de_cep, de_fone1, de_fone2, de_site, de_email;
String sql;
       
    
    public void Obtem_Dados_da_Empresa(){
        ConCE.conecta();
        sql = "select * from dados_empresa where codigo='1'";
        ConCE.executaSQL(sql);
        try {
            if (ConCE.rs.first()){
                de_nomefantasia = ConCE.rs.getString("nomefantasia");
                de_rasao = ConCE.rs.getString("razaosocial");
                de_cnpj = ConCE.rs.getString("cnpj");
                de_ie = ConCE.rs.getString("ie");
                de_endereco = ConCE.rs.getString("endereco");
                de_bairro = ConCE.rs.getString("bairro");
                de_cidade = ConCE.rs.getString("cidade");
                de_estado = ConCE.rs.getString("estado");
                de_cep = ConCE.rs.getString("cep");
                de_fone1 = ConCE.rs.getString("fone1");
                de_fone2 = ConCE.rs.getString("fone2");
                de_site =  ConCE.rs.getString("site");
                de_email = ConCE.rs.getString("email");
            }
        } catch (SQLException ex) {
            menssagem = ex.toString();
        }
        ConCE.desconecta();
    }
    
    public void AlteraDados(ModeloDadosEmpresa modDE){
    
    ConCE.conecta();
       
    try {
        
        PreparedStatement pst = ConCE.conn.prepareStatement("update dados_empresa set nomefantasia=?, razaosocial=?, cnpj=?, ie=?, endereco=?, bairro=?, cidade=?, estado=?, cep=?, fone1=?, fone2=?, site=?, email=? where codigo=?");
        pst.setString(1, modDE.getNF());
        pst.setString(2, modDE.getRS());
        pst.setString(3, modDE.getCNPJ());
        pst.setString(4, modDE.getIE());
        pst.setString(5, modDE.getEnd());
        pst.setString(6, modDE.getBai());
        pst.setString(7, modDE.getCid());
        pst.setString(8, modDE.getEst());
        pst.setString(9, modDE.getCep());
        pst.setString(10, modDE.getF1());
        pst.setString(11, modDE.getF2());
        pst.setString(12, modDE.getSite());
        pst.setString(13, modDE.getEmail());
        pst.setInt(14, modDE.getCod());
        pst.execute();
        
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, "Erro ao Alterar dados. "+ex);
    }
        
       
    ConCE.desconecta();
    
    }
    
}
