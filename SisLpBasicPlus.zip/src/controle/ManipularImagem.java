/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;

/**
 *
 * @author Lindembergue
 */
public class ManipularImagem {
    
    
    public static BufferedImage setIamegemDimensao(String caminhoImg, Integer imgLargura, Integer imgAltura){
        
        Graphics2D g2d = null;
        BufferedImage imagem = null, novaImagemTMP = null, novaImagem = null;
        try {
            //--- Obtem a imagem a ser redimensionada
            imagem = ImageIO.read(new File(caminhoImg));
            
        } catch (IOException ex) {
            Logger.getLogger(ManipularImagem.class.getName()).log(Level.SEVERE, null, ex);
        }
        novaImagem = new BufferedImage(imgLargura, imgAltura, BufferedImage.SCALE_SMOOTH);
//        g2d.setRenderingHint(RenderingHints.KEY_INTERPOLATION,RenderingHints.VALUE_INTERPOLATION_BILINEAR); //VALUE_INTERPOLATION_BICUBIC - For speed better use RenderingHints.VALUE_INTERPOLATION_BILINEAR
        g2d = novaImagem.createGraphics();
        g2d.drawImage(imagem, 0, 0, imgLargura, imgAltura,null);
        
        return novaImagem;
        
    }
    
    public static  byte[] getImgBytes(BufferedImage image){
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        try {
            ImageIO.write(image, "JPEG", baos);
        } catch (IOException ex) {
            Logger.getLogger(ManipularImagem.class.getName()).log(Level.SEVERE, null, ex);
        }
        InputStream is = new ByteArrayInputStream(baos.toByteArray());
        
        return baos.toByteArray();
    }
    
    public static void exibiImagemLabel(byte[] minhaImagem, javax.swing.JLabel label){
        
        if (minhaImagem!=null){
            InputStream input = new ByteArrayInputStream(minhaImagem);
            try {
                BufferedImage imagem = ImageIO.read(input);
                label.setIcon(new ImageIcon(imagem));
            } catch (IOException ex) {
                
            }
            
        } else {
            label.setIcon(null);
        }
        
        
    }
    
            
            
            
   public static void gravaImagem(){
      
       
       
   }
    
    
    
    
    
    
    
}
