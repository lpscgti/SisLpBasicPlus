/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 *
 * @author Lindembergue
 */
public class Conf {
    
    public  String host;
    public  String porta;
    
    
     public static Properties LerConfig() throws FileNotFoundException, IOException{
        
        Properties props = new Properties();
        Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
        FileInputStream arquivo = new FileInputStream(caminhoTXT+"/"+"config.ini");
        
        props.load(arquivo);
        
        return props;
        
    }
        
    public void ConfigLido() throws IOException{
        
        Properties prop = LerConfig();
        host = prop.getProperty("Servidor.bd.host");
        porta = prop.getProperty("Servidor.bd.porta");
//        JOptionPane.showMessageDialog(null, host + " "+porta);
    }
    
//    public void GravaLido( String nhost) throws FileNotFoundException, IOException{
//        
//        Properties propsS = new Properties();
//        Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
//        FileOutputStream arquivoS = new FileOutputStream(caminhoTXT+"/"+"config.ini");
//        propsS.setProperty("Servidor.bd.host", nhost);
//        propsS.store(arquivoS, null);
//        
//        
//    }
    
    
}
