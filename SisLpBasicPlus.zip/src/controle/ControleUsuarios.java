/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modelo.ModeloUsuarios;

/**
 *
 * @author ProgXBERGUE
 */
public class ControleUsuarios {
    ConectaBanco conLogin = new ConectaBanco();
    ModeloUsuarios  modLogin = new ModeloUsuarios();
    
   
   public void SalvaUsuario(ModeloUsuarios mod){
       
       conLogin.conecta();
       PreparedStatement pst;
       try {
       pst = conLogin.conn.prepareStatement("update usuarios set nome=?, login=?, senha=?, permissao=? where codigo=?");
       pst.setString(1, mod.getNome());
       pst.setString(2, mod.getLogin());
       pst.setString(3, mod.getSenha());
       pst.setString(4, mod.getPermissao());
       pst.setInt(5, mod.getCodigo());
       pst.execute();
       } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, ex);
        Logger.getLogger(ControleUsuarios.class.getName()).log(Level.SEVERE, null, ex);
       }
       conLogin.desconecta();
   }
   
   public void AtualizaUsuario(ModeloUsuarios mod){
       
       conLogin.conecta();
       PreparedStatement pst;
       try {
       pst = conLogin.conn.prepareStatement("update usuarios set senha=?, permissao=? where codigo=?");
       pst.setString(1, mod.getSenha());
       pst.setString(2, mod.getPermissao());
       pst.setInt(3, mod.getCodigo());
       pst.execute();
       } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, ex);
        Logger.getLogger(ControleUsuarios.class.getName()).log(Level.SEVERE, null, ex);
       }
       conLogin.desconecta();
   }
   
   public void ExcluirUsuario(ModeloUsuarios mod){
       
       conLogin.conecta();
       PreparedStatement pst;
       try {
       pst = conLogin.conn.prepareStatement("delete from usuarios where codigo=?");
       pst.setInt(1, mod.getCodigo());
       pst.execute();
       } catch (SQLException ex) {
        JOptionPane.showMessageDialog(null, ex);
        Logger.getLogger(ControleUsuarios.class.getName()).log(Level.SEVERE, null, ex);
       }
       conLogin.desconecta();
   
    }
    
    }
