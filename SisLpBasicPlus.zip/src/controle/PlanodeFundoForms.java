/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.net.URL;
import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.border.Border;

/**
 *
 * @author Lindembergue
 */



public class PlanodeFundoForms implements Border{
    ConectaBanco conPlF = new ConectaBanco();
            
    String caminhoImagem;
    int TamTelaAltura, TamTelaLargura;
    
    //public Graphics2D fundo;
    public BufferedImage back;
 
    public PlanodeFundoForms(int Altura, int Largura){
        
//        Dimension TamTela = Toolkit.getDefaultToolkit().getScreenSize(); //Código para obter o tamenho de altura e largura da tela.
        TamTelaAltura = Altura;
        TamTelaLargura = Largura;
        
        
        try {
//           conPlF.conecta();
//           conPlF.executaSQL("select * from config where id_conf=1");
//           conPlF.rs.first();
//           caminhoImagem = conPlF.rs.getString("dados_conf_String");//obtem da tabela config o nome do arquivo de imagem
           URL imagePath = new URL(this.getClass().getResource("/imagens/fundo_panel.png").toString());
           
           
            back = ImageIO.read(imagePath);
        } catch (Exception ex) {            
        }
    }

    public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
        //g.drawImage(back, (x + (width - back.getWidth())/2),(y + (height - back.getHeight())/2), null);
        g.drawImage(back, x, y, TamTelaLargura, TamTelaAltura, c);
    }
 
    public Insets getBorderInsets(Component c) {
        return new Insets(0,0,0,0);
    }
 
    public boolean isBorderOpaque() {
        return false;
    }
 
}
   
         