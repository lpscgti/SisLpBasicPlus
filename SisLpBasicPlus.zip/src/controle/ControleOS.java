/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import visual.FormPesqVendas;
import modelo.ModeloOS;
import modelo.ModeloTabela;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Lindembergue
 */
public class ControleOS {
ModeloOS modOs = new ModeloOS();
ConectaBanco conOS = new ConectaBanco();
ModeloTabela modTab = new ModeloTabela(null, null);
 Double ValorObra, TotalOS;
 String DataFormatada;


    
    public void QuebraData(String data){
        
        String dia = "" + data.charAt(0) + data.charAt(1);
        String mes = "" + data.charAt(3) + data.charAt(4);
        String ano = "" + data.charAt(6) + data.charAt(7) + data.charAt(8) + data.charAt(9);
    
        DataFormatada = ano+"-"+mes+"-"+dia;
        
     }
    
    public void GravaOsAberta (ModeloOS modOs){
        conOS.conecta();
        try {
            PreparedStatement pst = conOS.conn.prepareStatement("update os set id_cliente=?, dt_abertura=?, tipo_pag=?, equipamento=?, defeito=?, status=?, valor_obra=?, total_os=?, desconto_smo=?  where id=?");
            pst.setInt(1, modOs.getIdCliente());
            
            QuebraData(modOs.getDt_abertura());
            java.sql.Date DtIa = java.sql.Date.valueOf(DataFormatada);
            pst.setDate(2, DtIa);
            
            pst.setString(3, modOs.getTipoPag());
            pst.setString(4, modOs.getEquipamento());
            pst.setString(5, modOs.getDefeito());
            pst.setString(6, modOs.getStatus());
            pst.setDouble(7, modOs.getValor_obra());
            pst.setDouble(8, modOs.getTotal_os());
            pst.setDouble(9, modOs.getDesconto());
            pst.setInt(10, modOs.getId());
            pst.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
        
        conOS.desconecta();
    }
    
    public void GravaOsFechada (ModeloOS modOs){
        conOS.conecta();
        try {
            PreparedStatement pst = conOS.conn.prepareStatement("update os set id_cliente=?, dt_abertura=?, dt_fechamento=?, tipo_pag=?, equipamento=?, valor_obra=?, defeito=?, conserto=?, total_os=?, status=?, desconto_smo=? where id=?");
            pst.setInt(1, modOs.getIdCliente());
            
            QuebraData(modOs.getDt_abertura());
            java.sql.Date DtIa = java.sql.Date.valueOf(DataFormatada);
            pst.setDate(2, DtIa);
            
            QuebraData(modOs.getDt_fechamento());
            java.sql.Date DtIf = java.sql.Date.valueOf(DataFormatada);
            pst.setDate(3, DtIf);
            
            pst.setString(4, modOs.getTipoPag());
            pst.setString(5, modOs.getEquipamento());
            ValorObra = modOs.getValor_obra();
            if (ValorObra==null){
            pst.setDouble(6, 0);    
            }else{
            pst.setDouble(6, modOs.getValor_obra());    
            }
            pst.setString(7, modOs.getDefeito());
            pst.setString(8, modOs.getConserto());
            TotalOS = modOs.getValor_obra();
            if (TotalOS==null){
            pst.setDouble(9, 0);
            }else{
            pst.setDouble(9, modOs.getTotal_os());    
            }
            pst.setString(10, modOs.getStatus());
            pst.setDouble(11, modOs.getDesconto());
            pst.setInt(12, modOs.getId());
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(ControleOS.class.getName()).log(Level.SEVERE, null, ex);
        }
        conOS.desconecta();
    }
    

    public void GravaOsEditadaFechada (ModeloOS modOs){
        conOS.conecta();
        try {
            PreparedStatement pst = conOS.conn.prepareStatement("update os set dt_fechamento=?, tipo_pag=?, equipamento=?, valor_obra=?, defeito=?, conserto=?, total_os=?, status=?, desconto_smo=? where id=?");
            
            QuebraData(modOs.getDt_fechamento());
            java.sql.Date DtIf = java.sql.Date.valueOf(DataFormatada);
            pst.setDate(1, DtIf);
            
            pst.setString(2, modOs.getTipoPag());
            pst.setString(3, modOs.getEquipamento());
            ValorObra = modOs.getValor_obra();
            if (ValorObra==null){
            pst.setDouble(4, 0);    
            }else{
            pst.setDouble(4, modOs.getValor_obra());    
            }
            pst.setString(5, modOs.getDefeito());
            pst.setString(6, modOs.getConserto());
            TotalOS = modOs.getValor_obra();
            if (TotalOS==null){
            pst.setDouble(7, 0);
            }else{
            pst.setDouble(7, modOs.getTotal_os());    
            }
            pst.setString(8, modOs.getStatus());
            pst.setDouble(9, modOs.getDesconto());
            pst.setInt(10, modOs.getId());
            pst.execute();
        } catch (SQLException ex) {
            Logger.getLogger(ControleOS.class.getName()).log(Level.SEVERE, null, ex);
        }
        conOS.desconecta();
    }
    
    public void ExcluiOS (ModeloOS modOs){
        conOS.conecta();
        try {
            conOS.executaSQL("select * from contas_receber where origem='SERVIÇO'and codorigem='"+modOs.getId()+"'");
                if(conOS.rs.first()){
                do{
                    int CodConta = conOS.rs.getInt("codigo");
                    PreparedStatement pst = conOS.conn.prepareStatement("delete  from contas_receber_historico where conta=?");
                    pst.setInt(1, CodConta);
                    pst.execute();
                
            }while(conOS.rs.next());
            }    
            PreparedStatement pst = conOS.conn.prepareStatement("delete  from contas_receber where origem='SERVIÇO'and codorigem=?");
            pst.setInt(1, modOs.getId());
            pst.execute();
            
            pst = conOS.conn.prepareStatement("delete from os_descricao where id_os=?");
            pst.setInt(1, modOs.getId());
            pst.execute();
            
            pst = conOS.conn.prepareStatement("delete from os where id=?");
            pst.setInt(1, modOs.getId());
            pst.execute();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Excluir Dados. \nCódigo do Erro: "+ex);
        }
        
        conOS.desconecta();
    }
    
    public void CancelaAlteracaoEstoque (ModeloOS modOs){
        
        int codprod_tmp = 0;
        int qtdprod_tmp = 0;
        int estoque_tmp = 0;
        int estoque_up = 0;
        conOS.conecta();
        conOS.executaSQL("select * from os_descricao where id_os='"+modOs.getId()+"'");
        ConectaBanco contmp = new ConectaBanco();
        contmp.conecta();
         try {
            if(conOS.rs.first()){
                do{
                    codprod_tmp = conOS.rs.getInt("id_produto");
                    qtdprod_tmp = conOS.rs.getInt("qtd_vendida");
                    
                    contmp.executaSQL("select * from produtos where Codigo='"+codprod_tmp+"'");
                    if (contmp.rs.first()){
                        estoque_tmp = contmp.rs.getInt("quantidade");
                    }
                   estoque_up = estoque_tmp+qtdprod_tmp;
                   
                   PreparedStatement pst = contmp.conn.prepareStatement("update produtos set quantidade=? where codigo=?");
                   pst.setInt(1, estoque_up);
                   pst.setInt(2, codprod_tmp);
                   pst.execute();
                    
                }while(conOS.rs.next());
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Excluir Dados. \nCódigo do Erro: "+ex);
        }
        contmp.desconecta();
        conOS.desconecta();
        
    }
    
    public void CancelaAlteracaoEstoqueNaoSalvos (ModeloOS modOs){
        
        int codprod_tmp = 0;
        int qtdprod_tmp = 0;
        int estoque_tmp = 0;
        int estoque_up = 0;
        conOS.conecta();
        conOS.executaSQL("select * from os_descricao where id_os='"+modOs.getId()+"' and tmp=true");
        ConectaBanco contmp = new ConectaBanco();
        contmp.conecta();
         try {
            if(conOS.rs.first()){
                do{
                    codprod_tmp = conOS.rs.getInt("id_produto");
                    qtdprod_tmp = conOS.rs.getInt("qtd_vendida");
                    
                    contmp.executaSQL("select * from produtos where Codigo='"+codprod_tmp+"'");
                    if (contmp.rs.first()){
                        estoque_tmp = contmp.rs.getInt("quantidade");
                    }
                   estoque_up = estoque_tmp+qtdprod_tmp;
                   
                   PreparedStatement pst = contmp.conn.prepareStatement("update produtos set quantidade=? where codigo=?");
                   pst.setInt(1, estoque_up);
                   pst.setInt(2, codprod_tmp);
                   pst.execute();
                    
                }while(conOS.rs.next());
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Excluir Dados. \nCódigo do Erro: "+ex);
        }
        contmp.desconecta();
        conOS.desconecta();
        
    }
    
    public void ValidaItensAdicionados(ModeloOS modOs){
        
        conOS.conecta();
        conOS.executaSQL("select * from os_descricao where id_os='"+modOs.getId()+"' and tmp=true");
        ConectaBanco contmp = new ConectaBanco();
        contmp.conecta();
        
        try {
            if(conOS.rs.first()){
                do{
                    PreparedStatement pst = contmp.conn.prepareStatement("update os_descrição set tmp=? where id_descricao=?");
                    pst.setInt(1, conOS.rs.getInt("id_descricao"));
                    pst.setBoolean(2, false);
                    pst.execute();
                }while(conOS.rs.next());
            }
        } catch (SQLException ex) {
            Logger.getLogger(ControleOS.class.getName()).log(Level.SEVERE, null, ex);
        }
        contmp.desconecta();
        conOS.desconecta();
        
    }
    
}
