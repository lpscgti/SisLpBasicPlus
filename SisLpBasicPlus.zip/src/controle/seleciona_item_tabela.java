/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import javax.swing.JTable;

/**
 *
 * @author Lindembergue
 */

public class seleciona_item_tabela {

    public void EncontraNaTabela(JTable tabela, String Valor){
        
        String value = Valor;

            for (int row = 0; row <= tabela.getRowCount() - 1; row++) {

                for (int col = 0; col <= tabela.getColumnCount() - 1; col++) {

                    if (value.equals(tabela.getValueAt(row, col))) {

                        // this will automatically set the view of the scroll in the location of the value
                        tabela.scrollRectToVisible(tabela.getCellRect(row, 0, true));

                        // this will automatically set the focus of the searched/selected row/value
                        tabela.setRowSelectionInterval(row, row);

                        for (int i = 0; i <= tabela.getColumnCount() - 1; i++) {
                            
//                        tabela.getColumnModel().getColumn(i).setCellRenderer(new ModeloTabelaColorRenderDestaque());
                        
                        }
                    }
                }
            }
        
    }
    
}