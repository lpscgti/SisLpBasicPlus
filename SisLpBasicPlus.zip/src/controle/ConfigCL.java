/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 *
 * @author Lindembergue
 */
public class ConfigCL {
    
    public static String host;
    public static String porta;
    public static String porta_r;
    public static String nome;
    static Properties propS;
    
    
     public Properties GetConf() throws FileNotFoundException, IOException{
        
        Properties props = new Properties();
        Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
        FileInputStream arquivo = new FileInputStream(caminhoTXT+"/"+"config.ini");
        
        props.load(arquivo);
        
        return props;
        
    }
        
    public void LoadProp() throws IOException{
        
        Properties prop = GetConf();
        host = prop.getProperty("Servidor.bd.host");
        porta = prop.getProperty("Servidor.bd.porta");
     
//        JOptionPane.showMessageDialog(null, host + " "+porta);

    }
    
    public static Properties GetConfS() throws FileNotFoundException, IOException{
        
        Properties props = new Properties();
        Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
        FileInputStream arquivo = new FileInputStream(caminhoTXT+"/"+"config.ini");
        
        props.load(arquivo);
        
        return props;
        
    }
    
    /**
     *
     * @throws IOException
     */
    public static void LoadPropS() throws IOException{
        
        propS = GetConfS();
        host = propS.getProperty("Servidor.bd.host");
        porta = propS.getProperty("Servidor.bd.porta");
      
//        JOptionPane.showMessageDialog(null, host + " "+porta);

    }
    
    public void SaveProp() throws IOException{
        
        Properties prop = new Properties();
        prop.setProperty("Servidor.bd.host", host);
        prop.setProperty("Servidor.bd.porta", porta);
        
        
        Path caminhoTXT = Paths.get(System.getProperty("user.dir")+"/Base/");
        File file = new File(caminhoTXT+"/"+"config.ini");
        FileOutputStream fos = new FileOutputStream(file);
        prop.store(fos, "Arquivo de Configuração:");
        fos.close();
        
        
    }
    
   
    
}
