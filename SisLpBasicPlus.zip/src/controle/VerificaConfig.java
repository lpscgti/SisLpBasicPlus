/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author ProgXBERGUE
 */
public class VerificaConfig {
    
    ConfigCL cfg = new ConfigCL();
    public int Flag = 0;
    
    public void CompararDados(){
        
        try {
            cfg.LoadProp();
            if (cfg.porta.equals("")||(cfg.porta==null)){
                Flag = 1;
            }else{
                Flag = 0;
            }
        } catch (IOException ex) {
            Logger.getLogger(VerificaConfig.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
        
    
    
}
