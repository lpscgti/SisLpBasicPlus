/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

/**
 *
 * @author Lindembergue
 */
public class ControleAbreForms {
    
        public  int RetornoAbreEditaClientes = 0;
        public  int RetornoAbreEditaFuncionarios = 0;
        public  int RetornoAbreEditaOS = 0;
        public  int RetornoAbreEditaProdutos = 0;
        public  int RetornoAbreEditaFornecedores = 0;
        public  int RetornoAlteraSenha = 0;
        public  int RetornoCadClintes = 0;
        public  int RetornoCadFornecedores = 0;
        public  int RetornoCadFuncionario = 0;
        public  int RetornoCadProdutos = 0;
        public  int RetornoCadUsuario = 0;
        public  int RetornoCadConfig = 0;
        public  int RetornoContasReceber = 0;
        public  int RetornoContrleCaixa = 0;
        public  int RetornoGeraRecibo = 0;
        public  int RetornoOS = 0;
        public  int RetornoParcelaOS = 0;
        public  int RetornoParcelaVendas = 0;
        public  int RetornoPesqClientes = 0;
        public  int RetornoPesqFornecedor = 0;
        public  int RetornoPesqFuncionarios = 0;
        public  int RetornoPesqOS = 0;
        public  int RetornoPesqProdutos = 0;
        public  int RetornoPesqRecibo = 0;
        public  int RetornoPesqUsuarios = 0;
        public  int RetornoPesqVendas = 0;
        public  int RetornoReipressComprovantes = 0;
        public  int RetornoSobre = 0;
        public  int RetornoVendas = 0;
    
        
        public void CadClientes(){
            if (RetornoCadClintes==0){
                RetornoCadClintes=1;
            }else{
                RetornoCadClintes=0;
            }
        }
                
}
