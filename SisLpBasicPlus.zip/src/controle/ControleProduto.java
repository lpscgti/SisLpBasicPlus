/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import modelo.ModeloProduto;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Lindembergue
 */
public class ControleProduto {
    ConectaBanco conProdto = new ConectaBanco();
    ModeloProduto ModProduto = new ModeloProduto();
    
    
    public void SalvaDados (ModeloProduto ModProduto){
       
        conProdto.conecta();
        try {
            
            PreparedStatement pst = conProdto.conn.prepareStatement("update produtos set produto=?, codigobarras=?, fornecedor=?, fabricante=?, prcusto=?, prvenda=?, margemlucro=?, quantidade=?, unidademedida=?, data_atual=?, obs=? where Codigo=?");
            pst.setString(1, ModProduto.getNome());
            pst.setString(2, ModProduto.getCodBarras());
            pst.setInt(3, ModProduto.getForn_id());
            pst.setInt(4, ModProduto.getCat_id());
            pst.setDouble(5, ModProduto.getPr_custo());
            pst.setDouble(6, ModProduto.getPr_venda());
            pst.setDouble(7, ModProduto.getM_lucro());
            pst.setInt(8, ModProduto.getEstoque());
            pst.setInt(9, ModProduto.getU_medida());
            pst.setString(10, ModProduto.getDt_atual());
            pst.setString(11, ModProduto.getObs());
            pst.setInt(12, ModProduto.getId());
            pst.execute();
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar dados "+ex);
        } conProdto.desconecta();
        
    }
    
    public void ExcluiDados (ModeloProduto ModProduto){
        conProdto.conecta();
        PreparedStatement pst;
        try {
            pst = conProdto.conn.prepareStatement("delete from produtos where Codigo=?");
            pst.setInt(1, ModProduto.getId());
            pst.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Excluir dados\n Erro código: "+ex);
        }
        
        conProdto.desconecta();
    }
    
    
}
