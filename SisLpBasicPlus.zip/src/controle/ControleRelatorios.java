/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import com.toedter.calendar.JDateChooser;
import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;
import visual.FormOS;
import visual.FormParcelaOS;
import visual.FormParcelaVendas;
import visual.FormPesqOS;
import visual.FormPrincipal;

/**
 *
 * @author ProgXBERGUE
 */
public class ControleRelatorios {
    ConectaBanco conCRel = new ConectaBanco();
    Date hoje = new Date();
    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
    String DataHoje = (df.format(hoje));
    ControleEmpresa ctrl_de = new ControleEmpresa();
    
   
    
    public void CaixaPorPeriodo(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteudo que deseja pesquisar.<br /></HTML>");
        JLabel labelMdtI = new JLabel("Data inicial:");
        JLabel labelMdtF = new JLabel("Data Final:");
        JLabel labelMOrigem = new JLabel("Origem do Fluxo:");
        JDateChooser jdcDTI = new JDateChooser();
        JDateChooser jdcDTF = new JDateChooser();
        JComboBox jcbOrigem = new JComboBox();
        jcbOrigem.removeAllItems();
        jcbOrigem.addItem("Entrada");
        jcbOrigem.addItem("Saída");
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, labelMdtI,jdcDTI,labelMdtF,jdcDTF, labelMOrigem,jcbOrigem},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
    
                        
            try {
            
            
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");//                    JOptionPane.showMessageDialog(jMenuMovOSMenu, ex);
            //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
            //dados empresa
            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "endereco", ctrl_de.de_endereco );
            parametros.put( "bairro", ctrl_de.de_bairro );
            parametros.put( "cidade", ctrl_de.de_cidade );
            parametros.put( "estado", ctrl_de.de_estado );
            parametros.put( "cep", ctrl_de.de_cep );
            parametros.put( "telefone1", ctrl_de.de_fone1 );
            parametros.put( "telefone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "email", ctrl_de.de_email );
            parametros.put("logoimg",imagePath);
            parametros.put( "dtInicial", (jdcDTI.getDate()) );
            parametros.put( "dtFinal", (jdcDTF.getDate()) );
            parametros.put( "origem", (String.valueOf(jcbOrigem.getSelectedItem())) );
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"CaixaPorPeriodo.jasper", parametros, ConnectionFactory2.getSlpConnection());
            JRViewer viewer = new JRViewer(jpPrint);
            viewer.setZoomRatio((float) 0.5);
            JFrame frameRelatorio = new JFrame();
            frameRelatorio.add( viewer, BorderLayout.CENTER );
            frameRelatorio.setTitle("SisLp - Impressão - Relatório Caixa");
            frameRelatorio.setSize( 500, 500 );
            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
            frameRelatorio.toFront();
            frameRelatorio.setVisible( true );
            
            } catch (SQLException ex) {
                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                } catch (JRException ex) {
                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            
        }
    }//Final CaixaPorPeriodo
    
    public void CaixaPorPeriodoReferencia(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteudo que deseja pesquisar.<br /></HTML>");
        JLabel labelMdtI = new JLabel("Data inicial:");
        JLabel labelMdtF = new JLabel("Data Final:");
        JLabel labelMOrigem = new JLabel("Origem do Fluxo:");
        JLabel labelMRef = new JLabel("Digite a Referência do Fluxo:");
        JDateChooser jdcDTI = new JDateChooser();
        JDateChooser jdcDTF = new JDateChooser();
        JComboBox jcbOrigem = new JComboBox();
        jcbOrigem.removeAllItems();
        jcbOrigem.addItem("Entrada");
        jcbOrigem.addItem("Saída");
        JTextField jtexRef =  new JTextField();
        
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, labelMdtI,jdcDTI,labelMdtF,jdcDTF, labelMOrigem,jcbOrigem,labelMRef,jtexRef},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
    
            String Texto = jtexRef.getText();
                        
            try {
            
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");//                    JOptionPane.showMessageDialog(jMenuMovOSMenu, ex);
            //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
            //dados empresa
            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "endereco", ctrl_de.de_endereco );
            parametros.put( "bairro", ctrl_de.de_bairro );
            parametros.put( "cidade", ctrl_de.de_cidade );
            parametros.put( "estado", ctrl_de.de_estado );
            parametros.put( "cep", ctrl_de.de_cep );
            parametros.put( "telefone1", ctrl_de.de_fone1 );
            parametros.put( "telefone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "email", ctrl_de.de_email );
            parametros.put("logoimg",imagePath);
            parametros.put( "dtInicial", (jdcDTI.getDate()) );
            parametros.put( "dtFinal", (jdcDTF.getDate()) );
            parametros.put( "origem", (String.valueOf(jcbOrigem.getSelectedItem())) );
            parametros.put( "referencia", (Texto+"%") );
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"CaixaPorPeriodoReferencia.jasper", parametros, ConnectionFactory2.getSlpConnection());
            JRViewer viewer = new JRViewer(jpPrint);
            viewer.setZoomRatio((float) 0.5);
            JFrame frameRelatorio = new JFrame();
            frameRelatorio.add( viewer, BorderLayout.CENTER );
            frameRelatorio.setTitle("SisLp - Impressão - Relatório Caixa");
            frameRelatorio.setSize( 500, 500 );
            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
            frameRelatorio.toFront();
            frameRelatorio.setVisible( true );
            
            
            } catch (SQLException ex) {
                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                } catch (JRException ex) {
                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            
        }
    }//Final CaixaPorPeriodoReferencia
    
    public void ClientesTodos(){
        int totcli = 0;
        conCRel.conecta();
        ctrl_de.Obtem_Dados_da_Empresa();
        conCRel.executaSQL("select count (codigo) from clientes");
        try {
            conCRel.rs.first();
            totcli = conCRel.rs.getInt(1);
        } catch (SQLException ex) {
            Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
        }conCRel.desconecta();
        
        try {
                try {
                Thread.sleep(2000);
                Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                Map<String, Object> parametros = new HashMap<String, Object>();
                Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                //dados empresa
                parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                parametros.put( "cnpj", ctrl_de.de_cnpj );
                parametros.put( "de_ie", ctrl_de.de_ie );
                parametros.put( "endereco", ctrl_de.de_endereco );
                parametros.put( "bairro", ctrl_de.de_bairro );
                parametros.put( "cidade", ctrl_de.de_cidade );
                parametros.put( "estado", ctrl_de.de_estado );
                parametros.put( "cep", ctrl_de.de_cep );
                parametros.put( "telefone1", ctrl_de.de_fone1 );
                parametros.put( "telefone2", ctrl_de.de_fone2 );
                parametros.put( "de_site", ctrl_de.de_site );
                parametros.put( "email", ctrl_de.de_email );
                parametros.put("logoimg",imagePath);
                parametros.put("totclientes",totcli);
                JasperPrint jpPrint;
                jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"Clientes.jasper", parametros, ConnectionFactory2.getSlpConnection());
                JRViewer viewer = new JRViewer(jpPrint);
                viewer.setZoomRatio((float) 0.5);
                JFrame frameRelatorio = new JFrame();
                frameRelatorio.add( viewer, BorderLayout.CENTER );
                frameRelatorio.setTitle("SisLp - Impressão - Relatório Clientes");
                frameRelatorio.setSize( 500, 500 );
                frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                frameRelatorio.toFront();
                frameRelatorio.setVisible( true );
                } catch (SQLException ex) {
                    //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InterruptedException ex) {
                Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }
            } catch (JRException ex) {
                //                  Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }  
    }//Clientes
    
    public void ClientesNome(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteudo que deseja pesquisar.<br /></HTML>");
        JComboBox jcbS = new JComboBox();
        ClassUpperField jtfS = new ClassUpperField();
        jcbS.removeAllItems();
        jcbS.addItem("Inicia com:");
        jcbS.addItem("Contém:");
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, jcbS,jtfS},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
    
            String NomeMod;
            String Nome = new String(jtfS.getText());//Define uma String com a senha digitada
            String TipoPesq =  String.valueOf(jcbS.getSelectedItem());
            if (TipoPesq.equals("Inicia com:")){
            NomeMod = Nome+"%";
            } else{
            NomeMod = "%"+Nome+"%";
            }
            
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");//                    JOptionPane.showMessageDialog(jMenuMovOSMenu, ex);
            //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
            //dados empresa
            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "endereco", ctrl_de.de_endereco );
            parametros.put( "bairro", ctrl_de.de_bairro );
            parametros.put( "cidade", ctrl_de.de_cidade );
            parametros.put( "estado", ctrl_de.de_estado );
            parametros.put( "cep", ctrl_de.de_cep );
            parametros.put( "telefone1", ctrl_de.de_fone1 );
            parametros.put( "telefone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "email", ctrl_de.de_email );
            parametros.put("logoimg",imagePath);
            parametros.put("Nome", NomeMod);
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"Clientes_Consulta.jasper", parametros, ConnectionFactory2.getSlpConnection());
            JRViewer viewer = new JRViewer(jpPrint);
            viewer.setZoomRatio((float) 0.5);
            JFrame frameRelatorio = new JFrame();
            frameRelatorio.add( viewer, BorderLayout.CENTER );
            frameRelatorio.setTitle("SisLp - Impressão - Relatório Clientes");
            frameRelatorio.setSize( 500, 500 );
            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
            frameRelatorio.toFront();
            frameRelatorio.setVisible( true );
            
            } catch (SQLException ex) {
                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                } catch (JRException ex) {
                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            
        }
        
    }//ClientesNome
    
    public void ContasVencidas(){
        ctrl_de.Obtem_Dados_da_Empresa();
        java.sql.Date DataConvertidaSQL = java.sql.Date.valueOf(DataHoje);
        
        try {
                try {
                Thread.sleep(2000);
                Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                Map<String, Object> parametros = new HashMap<String, Object>();
                Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                //dados empresa
                parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                parametros.put( "cnpj", ctrl_de.de_cnpj );
                parametros.put( "de_ie", ctrl_de.de_ie );
                parametros.put( "endereco", ctrl_de.de_endereco );
                parametros.put( "bairro", ctrl_de.de_bairro );
                parametros.put( "cidade", ctrl_de.de_cidade );
                parametros.put( "estado", ctrl_de.de_estado );
                parametros.put( "cep", ctrl_de.de_cep );
                parametros.put( "telefone1", ctrl_de.de_fone1 );
                parametros.put( "telefone2", ctrl_de.de_fone2 );
                parametros.put( "de_site", ctrl_de.de_site );
                parametros.put( "email", ctrl_de.de_email );
                parametros.put("logoimg",imagePath);
                parametros.put("dtHoje",DataConvertidaSQL);
                JasperPrint jpPrint;
                jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"ContasVencidas.jasper", parametros, ConnectionFactory2.getSlpConnection());
                JRViewer viewer = new JRViewer(jpPrint);
                viewer.setZoomRatio((float) 0.5);
                JFrame frameRelatorio = new JFrame();
                frameRelatorio.add( viewer, BorderLayout.CENTER );
                frameRelatorio.setTitle("SisLp - Impressão - Relatório Contas Vencidas");
                frameRelatorio.setSize( 500, 500 );
                frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                frameRelatorio.toFront();
                frameRelatorio.setVisible( true );
                } catch (SQLException ex) {
                    //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InterruptedException ex) {
                Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }
            } catch (JRException ex) {
                //                  Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }  
        
    }//Contas Vencidas
    
    public void ContasVencidasCliente(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteudo que deseja pesquisar.<br /></HTML>");
        JComboBox jcbS = new JComboBox();
        ClassUpperField jtfS = new ClassUpperField();
        jcbS.removeAllItems();
        jcbS.addItem("Inicia com:");
        jcbS.addItem("Contém:");
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, jcbS,jtfS},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
    
            String NomeMod;
            String Nome = new String(jtfS.getText());//Define uma String com a senha digitada
            String TipoPesq =  String.valueOf(jcbS.getSelectedItem());
            if (TipoPesq.equals("Inicia com:")){
            NomeMod = Nome+"%";
            } else{
            NomeMod = "%"+Nome+"%";
            }
            
            try {
            Thread.sleep(2000);
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");//                    JOptionPane.showMessageDialog(jMenuMovOSMenu, ex);
            //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
            //dados empresa
            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "endereco", ctrl_de.de_endereco );
            parametros.put( "bairro", ctrl_de.de_bairro );
            parametros.put( "cidade", ctrl_de.de_cidade );
            parametros.put( "estado", ctrl_de.de_estado );
            parametros.put( "cep", ctrl_de.de_cep );
            parametros.put( "telefone1", ctrl_de.de_fone1 );
            parametros.put( "telefone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "email", ctrl_de.de_email );
            parametros.put("logoimg",imagePath);
            parametros.put("Nome", NomeMod);
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"ContasVencidasporCliente.jasper", parametros, ConnectionFactory2.getSlpConnection());
            JRViewer viewer = new JRViewer(jpPrint);
            viewer.setZoomRatio((float) 0.5);
            JFrame frameRelatorio = new JFrame();
            frameRelatorio.add( viewer, BorderLayout.CENTER );
            frameRelatorio.setTitle("SisLp - Impressão - Relatório Contas Vencidas");
            frameRelatorio.setSize( 500, 500 );
            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
            frameRelatorio.toFront();
            frameRelatorio.setVisible( true );
            
            } catch (SQLException ex) {
                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            } catch (JRException ex) {
                Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            } catch (InterruptedException ex) {
                Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }//ContasVencidasporCliente
    
    public void ContasVencidasData(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteudo que deseja pesquisar.<br /></HTML>");
        JLabel labelMdtI = new JLabel("Data inicial:");
        JLabel labelMdtF = new JLabel("Data Final:");
        JDateChooser jdcDTI = new JDateChooser();
        JDateChooser jdcDTF = new JDateChooser();
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, labelMdtI,jdcDTI,labelMdtF,jdcDTF},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
                        
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");//                    JOptionPane.showMessageDialog(jMenuMovOSMenu, ex);
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
            //dados empresa
            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "endereco", ctrl_de.de_endereco );
            parametros.put( "bairro", ctrl_de.de_bairro );
            parametros.put( "cidade", ctrl_de.de_cidade );
            parametros.put( "estado", ctrl_de.de_estado );
            parametros.put( "cep", ctrl_de.de_cep );
            parametros.put( "telefone1", ctrl_de.de_fone1 );
            parametros.put( "telefone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "email", ctrl_de.de_email );
            parametros.put("logoimg",imagePath);
            parametros.put( "DataI", (jdcDTI.getDate()) );
            parametros.put( "DataF", (jdcDTF.getDate()) );
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"ContasVencidasporData.jasper", parametros, ConnectionFactory2.getSlpConnection());
            JRViewer viewer = new JRViewer(jpPrint);
            viewer.setZoomRatio((float) 0.5);
            JFrame frameRelatorio = new JFrame();
            frameRelatorio.add( viewer, BorderLayout.CENTER );
            frameRelatorio.setTitle("SisLp - Impressão - Relatório Contas Vencidas");
            frameRelatorio.setSize( 500, 500 );
            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
            frameRelatorio.toFront();
            frameRelatorio.setVisible( true );
            } catch (SQLException ex) {
                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                } catch (JRException ex) {
                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            
        }
    }//ContasVencidasData
    
    public void ContasPagas(){
        ctrl_de.Obtem_Dados_da_Empresa();
        try {
                try {
                Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                Map<String, Object> parametros = new HashMap<String, Object>();
                Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                //dados empresa
                parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                parametros.put( "cnpj", ctrl_de.de_cnpj );
                parametros.put( "de_ie", ctrl_de.de_ie );
                parametros.put( "endereco", ctrl_de.de_endereco );
                parametros.put( "bairro", ctrl_de.de_bairro );
                parametros.put( "cidade", ctrl_de.de_cidade );
                parametros.put( "estado", ctrl_de.de_estado );
                parametros.put( "cep", ctrl_de.de_cep );
                parametros.put( "telefone1", ctrl_de.de_fone1 );
                parametros.put( "telefone2", ctrl_de.de_fone2 );
                parametros.put( "de_site", ctrl_de.de_site );
                parametros.put( "email", ctrl_de.de_email );
                parametros.put("logoimg",imagePath);
                JasperPrint jpPrint;
                jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"ContasPagas.jasper", parametros, ConnectionFactory2.getSlpConnection());
                JRViewer viewer = new JRViewer(jpPrint);
                viewer.setZoomRatio((float) 0.5);
                JFrame frameRelatorio = new JFrame();
                frameRelatorio.add( viewer, BorderLayout.CENTER );
                frameRelatorio.setTitle("SisLp - Impressão - Relatório de Contas Pagas");
                frameRelatorio.setSize( 500, 500 );
                frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                frameRelatorio.toFront();
                frameRelatorio.setVisible( true );
                } catch (SQLException ex) {
                    //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (JRException ex) {
                //                  Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//ContasPagas
    
    public void ContasPagasData(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteúdo que deseja pesquisar.<br /></HTML>");
        JLabel labelMdtI = new JLabel("Data inicial:");
        JLabel labelMdtF = new JLabel("Data Final:");
        JDateChooser jdcDTI = new JDateChooser();
        JDateChooser jdcDTF = new JDateChooser();
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, labelMdtI,jdcDTI,labelMdtF,jdcDTF},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
                        
            try {
            Thread.sleep(2000);
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");//                    JOptionPane.showMessageDialog(jMenuMovOSMenu, ex);
            //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
            //dados empresa
            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "endereco", ctrl_de.de_endereco );
            parametros.put( "bairro", ctrl_de.de_bairro );
            parametros.put( "cidade", ctrl_de.de_cidade );
            parametros.put( "estado", ctrl_de.de_estado );
            parametros.put( "cep", ctrl_de.de_cep );
            parametros.put( "telefone1", ctrl_de.de_fone1 );
            parametros.put( "telefone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "email", ctrl_de.de_email );
            parametros.put("logoimg",imagePath);
            parametros.put( "DataI", (jdcDTI.getDate()) );
            parametros.put( "DataF", (jdcDTF.getDate()) );
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"ContasPagasporData.jasper", parametros, ConnectionFactory2.getSlpConnection());
            JRViewer viewer = new JRViewer(jpPrint);
            viewer.setZoomRatio((float) 0.5);
            JFrame frameRelatorio = new JFrame();
            frameRelatorio.add( viewer, BorderLayout.CENTER );
            frameRelatorio.setTitle("SisLp - Impressão - Relatório de Contas Pagas");
            frameRelatorio.setSize( 500, 500 );
            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
            frameRelatorio.toFront();
            frameRelatorio.setVisible( true );
            } catch (SQLException ex) {
                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                } catch (JRException ex) {
                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                } catch (InterruptedException ex) {
                Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }//ContasPagasData
    
    public void Fabricantes(){
        ctrl_de.Obtem_Dados_da_Empresa();
        try {
                try {
                Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                Map<String, Object> parametros = new HashMap<String, Object>();
                Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                //dados empresa
                parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                parametros.put( "cnpj", ctrl_de.de_cnpj );
                parametros.put( "de_ie", ctrl_de.de_ie );
                parametros.put( "endereco", ctrl_de.de_endereco );
                parametros.put( "bairro", ctrl_de.de_bairro );
                parametros.put( "cidade", ctrl_de.de_cidade );
                parametros.put( "estado", ctrl_de.de_estado );
                parametros.put( "cep", ctrl_de.de_cep );
                parametros.put( "telefone1", ctrl_de.de_fone1 );
                parametros.put( "telefone2", ctrl_de.de_fone2 );
                parametros.put( "de_site", ctrl_de.de_site );
                parametros.put( "email", ctrl_de.de_email );
                parametros.put("logoimg",imagePath);
                JasperPrint jpPrint;
                jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"Fabricantes.jasper", parametros, ConnectionFactory2.getSlpConnection());
                JRViewer viewer = new JRViewer(jpPrint);
                viewer.setZoomRatio((float) 0.5);
                JFrame frameRelatorio = new JFrame();
                frameRelatorio.add( viewer, BorderLayout.CENTER );
                frameRelatorio.setTitle("SisLp - Impressão - Relatório de Fabricantes");
                frameRelatorio.setSize( 500, 500 );
                frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                frameRelatorio.toFront();
                frameRelatorio.setVisible( true );
                } catch (SQLException ex) {
                    //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (JRException ex) {
                //                  Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//fabricantes
    
    public void Fornecedores(){
        ctrl_de.Obtem_Dados_da_Empresa();
        int totforn = 0;
        conCRel.conecta();
        
        conCRel.executaSQL("select count (codigo) from fornecedores");
        try {
            conCRel.rs.first();
            totforn = conCRel.rs.getInt(1);
        } catch (SQLException ex) {
            Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
        }conCRel.desconecta();
        
        try {
                try {
                Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                Map<String, Object> parametros = new HashMap<String, Object>();
                Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                //dados empresa
                parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                parametros.put( "cnpj", ctrl_de.de_cnpj );
                parametros.put( "de_ie", ctrl_de.de_ie );
                parametros.put( "endereco", ctrl_de.de_endereco );
                parametros.put( "bairro", ctrl_de.de_bairro );
                parametros.put( "cidade", ctrl_de.de_cidade );
                parametros.put( "estado", ctrl_de.de_estado );
                parametros.put( "cep", ctrl_de.de_cep );
                parametros.put( "telefone1", ctrl_de.de_fone1 );
                parametros.put( "telefone2", ctrl_de.de_fone2 );
                parametros.put( "de_site", ctrl_de.de_site );
                parametros.put( "email", ctrl_de.de_email );
                parametros.put("logoimg",imagePath);
                parametros.put("totfornecedores",totforn);
                JasperPrint jpPrint;
                jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"Fornecedores.jasper", parametros, ConnectionFactory2.getSlpConnection());
                JRViewer viewer = new JRViewer(jpPrint);
                viewer.setZoomRatio((float) 0.5);
                JFrame frameRelatorio = new JFrame();
                frameRelatorio.add( viewer, BorderLayout.CENTER );
                frameRelatorio.setTitle("SisLp - Impressão - Relatório de Fornecedores");
                frameRelatorio.setSize( 500, 500 );
                frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                frameRelatorio.toFront();
                frameRelatorio.setVisible( true );
                } catch (SQLException ex) {
                    //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (JRException ex) {
                //                  Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
    }//Fornecedores
    
    public void FornecedoresNome(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteúdo que deseja pesquisar.<br /></HTML>");
        JComboBox jcbS = new JComboBox();
        ClassUpperField jtfS = new ClassUpperField();
        jcbS.removeAllItems();
        jcbS.addItem("Inicia com:");
        jcbS.addItem("Contém:");
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, jcbS,jtfS},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
    
            String NomeMod;
            String Nome = new String(jtfS.getText());//Define uma String com a senha digitada
            String TipoPesq =  String.valueOf(jcbS.getSelectedItem());
            if (TipoPesq.equals("Inicia com:")){
            NomeMod = Nome+"%";
            } else{
            NomeMod = "%"+Nome+"%";
            }
            int totforn = 0;
            
            conCRel.conecta();
            conCRel.executaSQL("select count (codigo) from fornecedores where nome='"+NomeMod+"'");
            try {
            conCRel.rs.first();
            totforn = conCRel.rs.getInt(1);
            } catch (SQLException ex) {
            Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }conCRel.desconecta();
        
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");//                    JOptionPane.showMessageDialog(jMenuMovOSMenu, ex);
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
            //dados empresa
            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "endereco", ctrl_de.de_endereco );
            parametros.put( "bairro", ctrl_de.de_bairro );
            parametros.put( "cidade", ctrl_de.de_cidade );
            parametros.put( "estado", ctrl_de.de_estado );
            parametros.put( "cep", ctrl_de.de_cep );
            parametros.put( "telefone1", ctrl_de.de_fone1 );
            parametros.put( "telefone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "email", ctrl_de.de_email );
            parametros.put("logoimg",imagePath);
            parametros.put("Nome", NomeMod);
            parametros.put("totfornecedores",totforn);
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"Fornecedores_Consulta.jasper", parametros, ConnectionFactory2.getSlpConnection());
            JRViewer viewer = new JRViewer(jpPrint);
            viewer.setZoomRatio((float) 0.5);
            JFrame frameRelatorio = new JFrame();
            frameRelatorio.add( viewer, BorderLayout.CENTER );
            frameRelatorio.setTitle("SisLp - Impressão - Relatório de Fornecedores");
            frameRelatorio.setSize( 500, 500 );
            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
            frameRelatorio.toFront();
            frameRelatorio.setVisible( true );
            
            } catch (SQLException ex) {
                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                } catch (JRException ex) {
                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            
        }
    }//FornecedoresNome
    
    public void VendasGeraCarne(String NomeEmpresa){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Digite o Código da Venda.</HTML>");
        //JComboBox jcbS = new JComboBox();
        JTextField jfCod = new JTextField();
        jfCod.addKeyListener(new KeyAdapter() {
          
            public void keyTyped(KeyEvent e){
                String caracteres="0987654321";
                if(!caracteres.contains(e.getKeyChar()+"")){
                e.consume();
                }
            } 
        });
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM,jfCod},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION);
        if(pi == JOptionPane.OK_OPTION) {
            
            try {
                    Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                    Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                    Map<String, Object> parametros = new HashMap<String, Object>();
                    Image imagePath = new ImageIcon(caminho+"/"+"img_relat_logo.png").getImage();
                    parametros.put( "CodVenda", Integer.valueOf(jfCod.getText()) );
                    parametros.put("NomeFantasia",NomeEmpresa);
                    JasperPrint jpPrint;
                    jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraCarnesVenda.jasper", parametros, ConnectionFactory2.getSlpConnection());
                    JRViewer viewer = new JRViewer(jpPrint);
                    viewer.setZoomRatio((float) 0.5);
                    JFrame frameRelatorio = new JFrame();
                    frameRelatorio.add( viewer, BorderLayout.CENTER );
                    frameRelatorio.setTitle("SisLp - Impressão - Carnês");
                    frameRelatorio.setSize( 500, 500 );
                    frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                    frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                    Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                    frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                    frameRelatorio.toFront();
                    frameRelatorio.setVisible( true );
            } catch (SQLException ex) {
                        Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }       catch (JRException ex) {
                        Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }
    
    public void Vendas(){
        ctrl_de.Obtem_Dados_da_Empresa();
        try {
        try {
        Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
        Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
        Map<String, Object> parametros = new HashMap<String, Object>();
        Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
        //dados empresa
        parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
        parametros.put( "de_razaosocial", ctrl_de.de_rasao );
        parametros.put( "cnpj", ctrl_de.de_cnpj );
        parametros.put( "de_ie", ctrl_de.de_ie );
        parametros.put( "endereco", ctrl_de.de_endereco );
        parametros.put( "bairro", ctrl_de.de_bairro );
        parametros.put( "cidade", ctrl_de.de_cidade );
        parametros.put( "estado", ctrl_de.de_estado );
        parametros.put( "cep", ctrl_de.de_cep );
        parametros.put( "telefone1", ctrl_de.de_fone1 );
        parametros.put( "telefone2", ctrl_de.de_fone2 );
        parametros.put( "de_site", ctrl_de.de_site );
        parametros.put( "email", ctrl_de.de_email );
        parametros.put("logoimg",imagePath);
        JasperPrint jpPrint;
        jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"Vendas.jasper", parametros, ConnectionFactory2.getSlpConnection());
        JRViewer viewer = new JRViewer(jpPrint);
        viewer.setZoomRatio((float) 0.5);
        JFrame frameRelatorio = new JFrame();
        frameRelatorio.add( viewer, BorderLayout.CENTER );
        frameRelatorio.setTitle("SisLp - Impressão - Relatório de Vendas");
        frameRelatorio.setSize( 500, 500 );
        frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
        frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
        Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
        frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
        frameRelatorio.toFront();
        frameRelatorio.setVisible( true );
        } catch (SQLException ex) {
            //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        }
        } catch (JRException ex) {
            //                  Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
    }
    
    public void VendasClienteData(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteúdo que deseja pesquisar.<br /></HTML>");
        JLabel labelMdtI = new JLabel("Data inicial:");
        JLabel labelMdtF = new JLabel("Data inicial:");
        JDateChooser jdcDTI = new JDateChooser();
        JDateChooser jdcDTF = new JDateChooser();
        JComboBox jcbS = new JComboBox();
        ClassUpperField jtfS = new ClassUpperField();
        jcbS.removeAllItems();
        jcbS.addItem("Inicia com:");
        jcbS.addItem("Contém:");
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, labelMdtI,jcbS,jtfS,jdcDTI, labelMdtF,jdcDTF},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
    
            String NomeMod;
            String Nome = new String(jtfS.getText());//Define uma String com a senha digitada
            String TipoPesq =  String.valueOf(jcbS.getSelectedItem());
            if (TipoPesq.equals("Inicia com:")){
            NomeMod = Nome+"%";
            } else{
            NomeMod = "%"+Nome+"%";
            }
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");//                    JOptionPane.showMessageDialog(jMenuMovOSMenu, ex);
            //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
            //dados empresa
            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "endereco", ctrl_de.de_endereco );
            parametros.put( "bairro", ctrl_de.de_bairro );
            parametros.put( "cidade", ctrl_de.de_cidade );
            parametros.put( "estado", ctrl_de.de_estado );
            parametros.put( "cep", ctrl_de.de_cep );
            parametros.put( "telefone1", ctrl_de.de_fone1 );
            parametros.put( "telefone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "email", ctrl_de.de_email );
            parametros.put("logoimg",imagePath);
            parametros.put("NomeCliente", NomeMod);
            parametros.put( "dataInicial", (jdcDTI.getDate()) );
            parametros.put( "dataFinal", (jdcDTF.getDate()) );
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"VendasporClientesData.jasper", parametros, ConnectionFactory2.getSlpConnection());
            JRViewer viewer = new JRViewer(jpPrint);
            viewer.setZoomRatio((float) 0.5);
            JFrame frameRelatorio = new JFrame();
            frameRelatorio.add( viewer, BorderLayout.CENTER );
            frameRelatorio.setTitle("SisLp - Impressão - Relatório de Vendas");
            frameRelatorio.setSize( 500, 500 );
            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
            frameRelatorio.toFront();
            frameRelatorio.setVisible( true );
            } catch (SQLException ex) {
                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            } catch (JRException ex) {
                Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
    
    public void VendasCliente(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteúdo que deseja pesquisar.<br /></HTML>");
        JComboBox jcbS = new JComboBox();
        ClassUpperField jtfS = new ClassUpperField();
        jcbS.removeAllItems();
        jcbS.addItem("Inicia com:");
        jcbS.addItem("Contém:");
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, jcbS,jtfS},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
    
            String NomeMod;
            String Nome = new String(jtfS.getText());//Define uma String com a senha digitada
            String TipoPesq =  String.valueOf(jcbS.getSelectedItem());
            if (TipoPesq.equals("Inicia com:")){
            NomeMod = Nome+"%";
            } else{
            NomeMod = "%"+Nome+"%";
            }
            
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");//                    JOptionPane.showMessageDialog(jMenuMovOSMenu, ex);
            //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
            //dados empresa
            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "endereco", ctrl_de.de_endereco );
            parametros.put( "bairro", ctrl_de.de_bairro );
            parametros.put( "cidade", ctrl_de.de_cidade );
            parametros.put( "estado", ctrl_de.de_estado );
            parametros.put( "cep", ctrl_de.de_cep );
            parametros.put( "telefone1", ctrl_de.de_fone1 );
            parametros.put( "telefone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "email", ctrl_de.de_email );
            parametros.put("logoimg",imagePath);
            parametros.put("NomeCliente", NomeMod);
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"VendasporCliente.jasper", parametros, ConnectionFactory2.getSlpConnection());
            JRViewer viewer = new JRViewer(jpPrint);
            viewer.setZoomRatio((float) 0.5);
            JFrame frameRelatorio = new JFrame();
            frameRelatorio.add( viewer, BorderLayout.CENTER );
            frameRelatorio.setTitle("SisLp - Impressão - Relatório de Vendas");
            frameRelatorio.setSize( 500, 500 );
            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
            frameRelatorio.toFront();
            frameRelatorio.setVisible( true );
            
            } catch (SQLException ex) {
                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            } catch (JRException ex) {
                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
    
    public void VendasData(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteúdo que deseja pesquisar.<br /></HTML>");
        JLabel labelMdtI = new JLabel("Data inicial:");
        JLabel labelMdtF = new JLabel("Data inicial:");
        JDateChooser jdcDTI = new JDateChooser();
        JDateChooser jdcDTF = new JDateChooser();
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, labelMdtI,jdcDTI, labelMdtF,jdcDTF},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
    
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");//                    JOptionPane.showMessageDialog(jMenuMovOSMenu, ex);
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
            //dados empresa
            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "endereco", ctrl_de.de_endereco );
            parametros.put( "bairro", ctrl_de.de_bairro );
            parametros.put( "cidade", ctrl_de.de_cidade );
            parametros.put( "estado", ctrl_de.de_estado );
            parametros.put( "cep", ctrl_de.de_cep );
            parametros.put( "telefone1", ctrl_de.de_fone1 );
            parametros.put( "telefone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "email", ctrl_de.de_email );
            parametros.put("logoimg",imagePath);
            parametros.put( "dataInicial", (jdcDTI.getDate()) );
            parametros.put( "dataFinal", (jdcDTF.getDate()) );
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"VendasporData.jasper", parametros, ConnectionFactory2.getSlpConnection());
            JRViewer viewer = new JRViewer(jpPrint);
            viewer.setZoomRatio((float) 0.5);
            JFrame frameRelatorio = new JFrame();
            frameRelatorio.add( viewer, BorderLayout.CENTER );
            frameRelatorio.setTitle("SisLp - Impressão - Relatório de Vendas");
            frameRelatorio.setSize( 500, 500 );
            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
            frameRelatorio.toFront();
            frameRelatorio.setVisible( true );
            } catch (SQLException ex) {
                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            } catch (JRException ex) {
                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
    
    public void VendaAVista(){
       ctrl_de.Obtem_Dados_da_Empresa();
                    JLabel labelM = new JLabel("<HTML>Digite o Código da Venda.</HTML>");
                    //JComboBox jcbS = new JComboBox();
                    JTextField jfCod = new JTextField();
                    jfCod.addKeyListener(new KeyAdapter() {

                        public void keyTyped(KeyEvent e){
                            String caracteres="0987654321";
                            if(!caracteres.contains(e.getKeyChar()+"")){
                            e.consume();
                            }
                        } 
                    });
                    int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM,jfCod},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION);
                    if(pi == JOptionPane.OK_OPTION) {
            

                                try {
                                    Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                                    Map<String, Object> parametros = new HashMap<String, Object>();
                                    Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                                    //dados empresa
                                    parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                                    parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                                    parametros.put( "cnpj", ctrl_de.de_cnpj );
                                    parametros.put( "de_ie", ctrl_de.de_ie );
                                    parametros.put( "endereco", ctrl_de.de_endereco );
                                    parametros.put( "bairro", ctrl_de.de_bairro );
                                    parametros.put( "cidade", ctrl_de.de_cidade );
                                    parametros.put( "estado", ctrl_de.de_estado );
                                    parametros.put( "cep", ctrl_de.de_cep );
                                    parametros.put( "telefone1", ctrl_de.de_fone1 );
                                    parametros.put( "telefone2", ctrl_de.de_fone2 );
                                    parametros.put( "de_site", ctrl_de.de_site );
                                    parametros.put( "email", ctrl_de.de_email );
                                    parametros.put("logoimg",imagePath);
                                    parametros.put( "CodVenda", Integer.valueOf(jfCod.getText()));
                                    JasperPrint jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteVendaAVista.jasper", parametros, ConnectionFactory2.getSlpConnection());
                                    JRViewer viewer = new JRViewer(jpPrint);
                                    viewer.setZoomRatio((float) 0.5);
                                    JFrame frameRelatorio = new JFrame();
                                    frameRelatorio.add( viewer, BorderLayout.CENTER );
                                    frameRelatorio.setTitle("SisLp - Impressão - Comprovante de Venda");
                                    frameRelatorio.setSize( 500, 500 );
                                    frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                                    frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                                    Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                                    frameRelatorio.setVisible( true );
                                    }catch (JRException ex) {
                                    JOptionPane.showMessageDialog(null, "Erro ao Gerar Venda para Impressão!/nErro: "+ex);
//                                    } catch (SQLException ex) {
//                                    Logger.getLogger(FormVendas.class.getName()).log(Level.SEVERE, null, ex);
                                }   catch (SQLException ex) {
                                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
                                }
                                    //conOs.desconecta(); //conOs.desconecta();
                                     //conOs.desconecta(); //conOs.desconecta();
                                }
    
                                
    }
    
    public void VendaAPrazo(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Digite o Código da Venda.</HTML>");
        //JComboBox jcbS = new JComboBox();
        JTextField jfCod = new JTextField();
        jfCod.addKeyListener(new KeyAdapter() {
          
            public void keyTyped(KeyEvent e){
                String caracteres="0987654321";
                if(!caracteres.contains(e.getKeyChar()+"")){
                e.consume();
                }
            } 
        });
        
        int CodConta = 0;
        boolean ientrada = false;
        
       
            
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM,jfCod},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION);
        if(pi == JOptionPane.OK_OPTION) {
            
            
            conCRel.conecta();
            conCRel.executaSQL("select * from contas_receber where origem='VENDA' and codorigem='"+Integer.parseInt(jfCod.getText())+"'");
            try {
                conCRel.rs.first();
                CodConta = conCRel.rs.getInt("codigo");
                if (conCRel.rs.getString("entrada").equals("Sim")){
                    ientrada = true;
                }else{
                    ientrada = false;
                }
            } catch (SQLException ex) {
                Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
            }conCRel.desconecta();
           
            try {
                    Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                    Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                    Map<String, Object> parametros = new HashMap<String, Object>();
                    Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                    //dados empresa
                    parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                    parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                    parametros.put( "cnpj", ctrl_de.de_cnpj );
                    parametros.put( "de_ie", ctrl_de.de_ie );
                    parametros.put( "endereco", ctrl_de.de_endereco );
                    parametros.put( "bairro", ctrl_de.de_bairro );
                    parametros.put( "cidade", ctrl_de.de_cidade );
                    parametros.put( "estado", ctrl_de.de_estado );
                    parametros.put( "cep", ctrl_de.de_cep );
                    parametros.put( "telefone1", ctrl_de.de_fone1 );
                    parametros.put( "telefone2", ctrl_de.de_fone2 );
                    parametros.put( "de_site", ctrl_de.de_site );
                    parametros.put( "email", ctrl_de.de_email );
                    parametros.put("logoimg",imagePath);
                    parametros.put( "CodConta", CodConta );
                    JasperPrint jpPrint;
                    if (ientrada == true){
                        jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteVendaAPEntrada.jasper", parametros, ConnectionFactory2.getSlpConnection());
                    }else{
                        jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteVendaAP.jasper", parametros, ConnectionFactory2.getSlpConnection());
                    }
                    JRViewer viewer = new JRViewer(jpPrint);
                    viewer.setZoomRatio((float) 0.5);
                    JFrame frameRelatorio = new JFrame();
                    frameRelatorio.add( viewer, BorderLayout.CENTER );
                    frameRelatorio.setTitle("SisLp - Impressão - Comprovante de Venda");
                    frameRelatorio.setSize( 500, 500 );
                    frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                    frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                    Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                    frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                    frameRelatorio.setVisible( true );
            } catch (SQLException ex) {
                        Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
            }       catch (JRException ex) {
                        Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
                                        
    }
    
    public void Produtos(){
        ctrl_de.Obtem_Dados_da_Empresa();
            try {
                try {
                Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                Map<String, Object> parametros = new HashMap<String, Object>();
                Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                //dados empresa
                parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                parametros.put( "cnpj", ctrl_de.de_cnpj );
                parametros.put( "de_ie", ctrl_de.de_ie );
                parametros.put( "endereco", ctrl_de.de_endereco );
                parametros.put( "bairro", ctrl_de.de_bairro );
                parametros.put( "cidade", ctrl_de.de_cidade );
                parametros.put( "estado", ctrl_de.de_estado );
                parametros.put( "cep", ctrl_de.de_cep );
                parametros.put( "telefone1", ctrl_de.de_fone1 );
                parametros.put( "telefone2", ctrl_de.de_fone2 );
                parametros.put( "de_site", ctrl_de.de_site );
                parametros.put( "email", ctrl_de.de_email );
                parametros.put("logoimg",imagePath);
                JasperPrint jpPrint;
                jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"Produtos.jasper", parametros, ConnectionFactory2.getSlpConnection());
                JRViewer viewer = new JRViewer(jpPrint);
                viewer.setZoomRatio((float) 0.5);
                JFrame frameRelatorio = new JFrame();
                frameRelatorio.add( viewer, BorderLayout.CENTER );
                frameRelatorio.setTitle("SisLp - Impressão - Relatório de Produtos");
                frameRelatorio.setSize( 500, 500 );
                frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                frameRelatorio.toFront();
                frameRelatorio.setVisible( true );
                } catch (SQLException ex) {
                    //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            } catch (JRException ex) {
                //                  Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }   
    }
    
    public void ProdutosFabricantes(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteudo que deseja pesquisar.<br /></HTML>");
        JComboBox jcbS = new JComboBox();
        ClassUpperField jtfS = new ClassUpperField();
        jcbS.removeAllItems();
        jcbS.addItem("Inicia com:");
        jcbS.addItem("Contém:");
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, jcbS,jtfS},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
    
            String NomeMod;
            String Nome = new String(jtfS.getText());//Define uma String com a senha digitada
            String TipoPesq =  String.valueOf(jcbS.getSelectedItem());
            if (TipoPesq.equals("Inicia com:")){
            NomeMod = Nome+"%";
            } else{
            NomeMod = "%"+Nome+"%";
            }
            
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");//                    JOptionPane.showMessageDialog(jMenuMovOSMenu, ex);
            //                    Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
            //dados empresa
            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "endereco", ctrl_de.de_endereco );
            parametros.put( "bairro", ctrl_de.de_bairro );
            parametros.put( "cidade", ctrl_de.de_cidade );
            parametros.put( "estado", ctrl_de.de_estado );
            parametros.put( "cep", ctrl_de.de_cep );
            parametros.put( "telefone1", ctrl_de.de_fone1 );
            parametros.put( "telefone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "email", ctrl_de.de_email );
            parametros.put("logoimg",imagePath);
            parametros.put("Fabricante", NomeMod);
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"ProdutosporFabricante.jasper", parametros, ConnectionFactory2.getSlpConnection());
            JRViewer viewer = new JRViewer(jpPrint);
            viewer.setZoomRatio((float) 0.5);
            JFrame frameRelatorio = new JFrame();
            frameRelatorio.add( viewer, BorderLayout.CENTER );
            frameRelatorio.setTitle("SisLp - Impressão - Relatório de Produtos");
            frameRelatorio.setSize( 500, 500 );
            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
            frameRelatorio.toFront();
            frameRelatorio.setVisible( true );
            
            } catch (SQLException ex) {
                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            } catch (JRException ex) {
                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
    
    public void ProdutosFornecedor(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteudo que deseja pesquisar.<br /></HTML>");
        JComboBox jcbS = new JComboBox();
        ClassUpperField jtfS = new ClassUpperField();
        jcbS.removeAllItems();
        jcbS.addItem("Inicia com:");
        jcbS.addItem("Contém:");
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, jcbS,jtfS},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
    
            String NomeMod;
            String Nome = new String(jtfS.getText());//Define uma String com a senha digitada
            String TipoPesq =  String.valueOf(jcbS.getSelectedItem());
            if (TipoPesq.equals("Inicia com:")){
            NomeMod = Nome+"%";
            } else{
            NomeMod = "%"+Nome+"%";
            }
            
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");//                    JOptionPane.showMessageDialog(jMenuMovOSMenu, ex);
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
            //dados empresa
            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "endereco", ctrl_de.de_endereco );
            parametros.put( "bairro", ctrl_de.de_bairro );
            parametros.put( "cidade", ctrl_de.de_cidade );
            parametros.put( "estado", ctrl_de.de_estado );
            parametros.put( "cep", ctrl_de.de_cep );
            parametros.put( "telefone1", ctrl_de.de_fone1 );
            parametros.put( "telefone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "email", ctrl_de.de_email );
            parametros.put("logoimg",imagePath);
            parametros.put("Fornecedor", NomeMod);
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"ProdutosporFornecedor.jasper", parametros, ConnectionFactory2.getSlpConnection());
            JRViewer viewer = new JRViewer(jpPrint);
            viewer.setZoomRatio((float) 0.5);
            JFrame frameRelatorio = new JFrame();
            frameRelatorio.add( viewer, BorderLayout.CENTER );
            frameRelatorio.setTitle("SisLp - Impressão - Relatório de Produtos");
            frameRelatorio.setSize( 500, 500 );
            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
            frameRelatorio.toFront();
            frameRelatorio.setVisible( true );
            } catch (SQLException ex) {
                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            } catch (JRException ex) {
                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
    
    public void ProdutosNome(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Escolha um Método de pesquisa e digite no<br>campo o conteudo que deseja pesquisar.<br /></HTML>");
        JComboBox jcbS = new JComboBox();
        ClassUpperField jtfS = new ClassUpperField();
        jcbS.removeAllItems();
        jcbS.addItem("Inicia com:");
        jcbS.addItem("Contém:");
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM, jcbS,jtfS},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION); //JOptionPane que ira trazer a mensagem com o componente de senha
        
        if(pi == JOptionPane.OK_OPTION) {
    
            String NomeMod;
            String Nome = new String(jtfS.getText());//Define uma String com a senha digitada
            String TipoPesq =  String.valueOf(jcbS.getSelectedItem());
            if (TipoPesq.equals("Inicia com:")){
            NomeMod = Nome+"%";
            } else{
            NomeMod = "%"+Nome+"%";
            }
            
            try {
            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");//                    JOptionPane.showMessageDialog(jMenuMovOSMenu, ex);
            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
            Map<String, Object> parametros = new HashMap<String, Object>();
            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
            //dados empresa
            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
            parametros.put( "cnpj", ctrl_de.de_cnpj );
            parametros.put( "de_ie", ctrl_de.de_ie );
            parametros.put( "endereco", ctrl_de.de_endereco );
            parametros.put( "bairro", ctrl_de.de_bairro );
            parametros.put( "cidade", ctrl_de.de_cidade );
            parametros.put( "estado", ctrl_de.de_estado );
            parametros.put( "cep", ctrl_de.de_cep );
            parametros.put( "telefone1", ctrl_de.de_fone1 );
            parametros.put( "telefone2", ctrl_de.de_fone2 );
            parametros.put( "de_site", ctrl_de.de_site );
            parametros.put( "email", ctrl_de.de_email );
            parametros.put("logoimg",imagePath);
            parametros.put("Produto", NomeMod);
            JasperPrint jpPrint;
            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"ProdutosporProdutos.jasper", parametros, ConnectionFactory2.getSlpConnection());
            JRViewer viewer = new JRViewer(jpPrint);
            viewer.setZoomRatio((float) 0.5);
            JFrame frameRelatorio = new JFrame();
            frameRelatorio.add( viewer, BorderLayout.CENTER );
            frameRelatorio.setTitle("SisLp - Impressão - Relatório de Produtos");
            frameRelatorio.setSize( 500, 500 );
            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
            frameRelatorio.toFront();
            frameRelatorio.setVisible( true );
            } catch (SQLException ex) {
                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            } catch (JRException ex) {
                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }
            
        }
    }
    
    public void ComprovantePagContaReceber(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Digite o Código de Controle da Conta.</HTML>");
        //JComboBox jcbS = new JComboBox();
        JTextField jfCod = new JTextField();
        jfCod.addKeyListener(new KeyAdapter() {
          
            public void keyTyped(KeyEvent e){
                String caracteres="0987654321";
                if(!caracteres.contains(e.getKeyChar()+"")){
                e.consume();
                }
            } 
        });
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM,jfCod},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION);
        if(pi == JOptionPane.OK_OPTION) {
        
        try {
           
                                    Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                                    Map<String, Object> parametros = new HashMap<String, Object>();
                                    Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                                    //dados empresa
                                    parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                                    parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                                    parametros.put( "cnpj", ctrl_de.de_cnpj );
                                    parametros.put( "de_ie", ctrl_de.de_ie );
                                    parametros.put( "endereco", ctrl_de.de_endereco );
                                    parametros.put( "bairro", ctrl_de.de_bairro );
                                    parametros.put( "cidade", ctrl_de.de_cidade );
                                    parametros.put( "estado", ctrl_de.de_estado );
                                    parametros.put( "cep", ctrl_de.de_cep );
                                    parametros.put( "telefone1", ctrl_de.de_fone1 );
                                    parametros.put( "telefone2", ctrl_de.de_fone2 );
                                    parametros.put( "de_site", ctrl_de.de_site );
                                    parametros.put( "email", ctrl_de.de_email );
                                    parametros.put("logoimg",imagePath);
                                    parametros.put( "idconta", Integer.valueOf(jfCod.getText()) );
                                    JasperPrint jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteContaReceber.jasper", parametros, ConnectionFactory2.getSlpConnection());
                                    JRViewer viewer = new JRViewer(jpPrint);
                                    viewer.setZoomRatio((float) 0.5);
                                    JFrame frameRelatorio = new JFrame();
                                    frameRelatorio.add( viewer, BorderLayout.CENTER );
                                    frameRelatorio.setTitle("SisLp - Impressão - Comprovante de Pagamento");
                                    frameRelatorio.setSize( 500, 500 );
                                    frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                                    frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                                    Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                                    frameRelatorio.setVisible( true );
                                    } catch (JRException ex) {
                                    JOptionPane.showMessageDialog(null, "Erro ao Gerar Comprovante de Pagamento para Impressão!/nErro: "+ex);
                                    } catch (SQLException ex) {
                                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
                                }
        }
        
    }
    
    
    
    
     public void ContratoVendaAPrazo(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Digite o Código da Venda.</HTML>");
        //JComboBox jcbS = new JComboBox();
        JTextField jfCod = new JTextField();
        jfCod.addKeyListener(new KeyAdapter() {
          
            public void keyTyped(KeyEvent e){
                String caracteres="0987654321";
                if(!caracteres.contains(e.getKeyChar()+"")){
                e.consume();
                }
            } 
        });
        
        DecimalFormat formatMoeda = new DecimalFormat("¤ #,##0.00");
        DecimalFormat formatPorcentagem = new DecimalFormat("#,##0.0 %");
        SimpleDateFormat dtEx = new SimpleDateFormat("d' de 'MMMM' de 'yyyy");
        int CodConta = 0;
        
        String NomeFantasia=null, EndEmp=null, BaiEmp=null, CidEmp=null, EstEmp=null, CepEmp=null, CNPJEmp=null, NParcela=null, DtVencParcela1=null, ValorTotalVenda=null, DtVendaExt=null;
        SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
        CurrencyWriter cw = new CurrencyWriter();
        
        String JurosTempoDias = null, JurosDia = null, JurosMes = null;
        
            
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM,jfCod},"Relatório a Gerar:", JOptionPane.OK_CANCEL_OPTION);
        if(pi == JOptionPane.OK_OPTION) {
            
            
            conCRel.conecta();
            
            try {
                
                conCRel.executaSQL("select * from dados_empresa where codigo=1");
                if(conCRel.rs.first()){
                    NomeFantasia =  conCRel.rs.getString("nomefantasia");
                    EndEmp = conCRel.rs.getString("endereco");
                    BaiEmp = conCRel.rs.getString("bairro");
                    CidEmp = conCRel.rs.getString("cidade");
                    EstEmp = conCRel.rs.getString("estado");
                    CepEmp = conCRel.rs.getString("cep");
                    CNPJEmp = conCRel.rs.getString("cnpj");
                }
                
                
                conCRel.executaSQL("select * from contas_receber where origem='VENDA' and codorigem='"+Integer.parseInt(jfCod.getText())+"'");
                if(conCRel.rs.first()){
                    CodConta = conCRel.rs.getInt("codigo");
                    NParcela = String.valueOf(conCRel.rs.getInt("nparcela"));
                    java.sql.Date Data = conCRel.rs.getDate("dtvencimento");
                    DtVencParcela1 = df.format(Data);
                }
                
                
                conCRel.executaSQL("select * from vendas where codigo='"+Integer.parseInt(jfCod.getText())+"'");
                if(conCRel.rs.first()){
                    ValorTotalVenda = String.valueOf(formatMoeda.format(conCRel.rs.getDouble("valorvenda")));
                    java.sql.Date DataExt = conCRel.rs.getDate("data");
                    DtVendaExt = dtEx.format(DataExt);
                }
                
                
                conCRel.executaSQL("select * from config where codigo=1");
                if(conCRel.rs.first()){
                    JurosDia = String.valueOf((conCRel.rs.getDouble("jurosdia")))+"%";
                    JurosMes = String.valueOf((conCRel.rs.getDouble("jurosmes")))+"%";
                    JurosTempoDias = String.valueOf(conCRel.rs.getInt("cobrarjuros"));
                }
                
                
            } catch (SQLException ex) {
                Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
            }conCRel.desconecta();
           
            try {
                    Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                    Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                    Map<String, Object> parametros = new HashMap<String, Object>();
                    Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                    //dados empresa cabeçalho
                    parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                    parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                    parametros.put( "cnpj", ctrl_de.de_cnpj );
                    parametros.put( "de_ie", ctrl_de.de_ie );
                    parametros.put( "endereco", ctrl_de.de_endereco );
                    parametros.put( "bairro", ctrl_de.de_bairro );
                    parametros.put( "cidade", ctrl_de.de_cidade );
                    parametros.put( "estado", ctrl_de.de_estado );
                    parametros.put( "cep", ctrl_de.de_cep );
                    parametros.put( "telefone1", ctrl_de.de_fone1 );
                    parametros.put( "telefone2", ctrl_de.de_fone2 );
                    parametros.put( "de_site", ctrl_de.de_site );
                    parametros.put( "email", ctrl_de.de_email );
                    parametros.put("logoimg",imagePath);
                    //dados do texto do relatorio
                    parametros.put( "CodConta", CodConta );
                    parametros.put( "NomeFantasia", NomeFantasia );
                    parametros.put( "EndEmpresa", EndEmp );
                    parametros.put( "BaiEmpresa", BaiEmp );
                    parametros.put( "CidEmpresa", CidEmp );
                    parametros.put( "EstEmpresa", EstEmp );
                    parametros.put( "CepEmpresa", CepEmp );
                    parametros.put( "CNPJEmpresa", CNPJEmp );
                    parametros.put( "NParcela", NParcela );
                    parametros.put( "DtVencParcela1", DtVencParcela1 );
                    parametros.put( "ValorTotalVenda", ValorTotalVenda );
                    parametros.put( "DtVendaExt", DtVendaExt );
                    parametros.put( "JurosDia", JurosDia );
                    parametros.put( "jurosMes", JurosMes );
                    parametros.put( "DiasJuros", JurosTempoDias );
                    JasperPrint jpPrint;
                    jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraContratoVendaAP.jasper", parametros, ConnectionFactory2.getSlpConnection());
                    JRViewer viewer = new JRViewer(jpPrint);
                    viewer.setZoomRatio((float) 0.5);
                    JFrame frameRelatorio = new JFrame();
                    frameRelatorio.add( viewer, BorderLayout.CENTER );
                    frameRelatorio.setTitle("SisLp - Impressão - Contrato de Venda");
                    frameRelatorio.setSize( 500, 500 );
                    frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                    frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                    Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                    frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                    frameRelatorio.setVisible( true );
            } catch (SQLException ex) {
                        Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
            }       catch (JRException ex) {
                        Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
            }
            }
                                        
    }
     
     public void PrintOSAberta(int CodOs){
         ctrl_de.Obtem_Dados_da_Empresa();
        int i = JOptionPane.showConfirmDialog(null, "OS Gerada com Sucesso.\nDeseja realizar a impressão?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
                                if(i == JOptionPane.YES_OPTION) {
                                    try {                               
                                    Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                                    Map<String, Object> parametros = new HashMap<String, Object>();
                                    Image imagePathCorte = new ImageIcon(caminho+"/"+"corte_ico.png").getImage();
                                    parametros.put("imgCort",imagePathCorte);
                                    Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                                    //dados empresa cabeçalho
                                    parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                                    parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                                    parametros.put( "cnpj", ctrl_de.de_cnpj );
                                    parametros.put( "de_ie", ctrl_de.de_ie );
                                    parametros.put( "endereco", ctrl_de.de_endereco );
                                    parametros.put( "bairro", ctrl_de.de_bairro );
                                    parametros.put( "cidade", ctrl_de.de_cidade );
                                    parametros.put( "estado", ctrl_de.de_estado );
                                    parametros.put( "cep", ctrl_de.de_cep );
                                    parametros.put( "telefone1", ctrl_de.de_fone1 );
                                    parametros.put( "telefone2", ctrl_de.de_fone2 );
                                    parametros.put( "de_site", ctrl_de.de_site );
                                    parametros.put( "email", ctrl_de.de_email );
                                    parametros.put("logoimg",imagePath);
                                    parametros.put( "OS_id", CodOs );
                                    JasperPrint jpPrint;
                                    jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraOsAberta.jasper", parametros, ConnectionFactory2.getSlpConnection());
                                    JRViewer viewer = new JRViewer(jpPrint);
                                    viewer.setZoomRatio((float) 0.5);
                                    JFrame frameRelatorio = new JFrame();
                                    frameRelatorio.add( viewer, BorderLayout.CENTER );
                                    frameRelatorio.setTitle("SisLp - Impressão - Ordem de Serviço");
                                    frameRelatorio.setSize( 500, 500 );
                                    frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                                    frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                                    Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                                    frameRelatorio.toFront();
                                    frameRelatorio.setVisible( true );
                                    } catch (JRException ex) {
                                        Logger.getLogger(FormOS.class.getName()).log(Level.SEVERE, null, ex);
                                    } catch (SQLException ex) {
                Logger.getLogger(FormPesqOS.class.getName()).log(Level.SEVERE, null, ex);
            }
                                }
    }
    
    public  void PrintOSFechada(int CodOs, double totProdsOS){
        ctrl_de.Obtem_Dados_da_Empresa();
        int i = JOptionPane.showConfirmDialog(null, "OS Gerada com Sucesso.\nDeseja realizar a impressão?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
                                if(i == JOptionPane.YES_OPTION) {
                                try {
                                    Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                                    Map<String, Object> parametros = new HashMap<String, Object>();
                                    Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                                    //dados empresa cabeçalho
                                    parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                                    parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                                    parametros.put( "cnpj", ctrl_de.de_cnpj );
                                    parametros.put( "de_ie", ctrl_de.de_ie );
                                    parametros.put( "endereco", ctrl_de.de_endereco );
                                    parametros.put( "bairro", ctrl_de.de_bairro );
                                    parametros.put( "cidade", ctrl_de.de_cidade );
                                    parametros.put( "estado", ctrl_de.de_estado );
                                    parametros.put( "cep", ctrl_de.de_cep );
                                    parametros.put( "telefone1", ctrl_de.de_fone1 );
                                    parametros.put( "telefone2", ctrl_de.de_fone2 );
                                    parametros.put( "de_site", ctrl_de.de_site );
                                    parametros.put( "email", ctrl_de.de_email );
                                    parametros.put("logoimg",imagePath);
                                    parametros.put( "OS_id", CodOs );
                                    parametros.put( "TotProds", totProdsOS );
                                    JasperPrint jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraOsFechada.jasper", parametros, ConnectionFactory2.getSlpConnection());
                                    JRViewer viewer = new JRViewer(jpPrint);
                                    viewer.setZoomRatio((float) 0.5);
                                    JFrame frameRelatorio = new JFrame();
                                    frameRelatorio.add( viewer, BorderLayout.CENTER );
                                    frameRelatorio.setTitle("SisLp - Impressão - Ordem de Serviço");
                                    frameRelatorio.setSize( 500, 500 );
                                    frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                                    frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                                    Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                                    frameRelatorio.toFront();
                                    frameRelatorio.setVisible( true );
                                    } catch (JRException ex) {
                                    JOptionPane.showMessageDialog(null, "Erro ao Gerar OS para Impressão!\nErro: "+ex);
                                    } catch (SQLException ex) { 
                Logger.getLogger(FormPesqOS.class.getName()).log(Level.SEVERE, null, ex);
            } 
                                
                                
                                }
    }
    
    public void PrintOSParcelada(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Digite o Código da Ordem de Serviço (OS).</HTML>");
        //JComboBox jcbS = new JComboBox();
        JTextField jfCod = new JTextField();
        jfCod.addKeyListener(new KeyAdapter() {
          
            public void keyTyped(KeyEvent e){
                String caracteres="0987654321";
                if(!caracteres.contains(e.getKeyChar()+"")){
                e.consume();
                }
            } 
        });
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM,jfCod},"Comprovante a Gerar:", JOptionPane.OK_CANCEL_OPTION);
        if(pi == JOptionPane.OK_OPTION) {
            
        int CodigoOs = Integer.parseInt(jfCod.getText());
        
        conCRel.conecta();
        conCRel.executaSQL("select * from os_descricao where id_os='"+CodigoOs+"'");
        double TotalProd = 0;
        int CodConta = 0;
        String Entrada = "";
        try {
            if(conCRel.rs.first()){
                do{
                    TotalProd = TotalProd+conCRel.rs.getDouble("total_vendido");
                }while(conCRel.rs.next());
            }
            conCRel.executaSQL("select * from contas_receber where  origem='SERVIÇO' and codorigem='"+CodigoOs+"'");
            if (conCRel.rs.first()){
                CodConta = conCRel.rs.getInt("codigo");
                if (conCRel.rs.getString("entrada")==(null)){
                    Entrada = "Não";
                }else{
                    Entrada = conCRel.rs.getString("entrada");
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(FormParcelaOS.class.getName()).log(Level.SEVERE, null, ex);
        }
        conCRel.desconecta();
        
                                 
                    try {
                            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                            Map<String, Object> parametros = new HashMap<String, Object>();
                            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                            //dados empresa cabeçalho
                            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                            parametros.put( "cnpj", ctrl_de.de_cnpj );
                            parametros.put( "de_ie", ctrl_de.de_ie );
                            parametros.put( "endereco", ctrl_de.de_endereco );
                            parametros.put( "bairro", ctrl_de.de_bairro );
                            parametros.put( "cidade", ctrl_de.de_cidade );
                            parametros.put( "estado", ctrl_de.de_estado );
                            parametros.put( "cep", ctrl_de.de_cep );
                            parametros.put( "telefone1", ctrl_de.de_fone1 );
                            parametros.put( "telefone2", ctrl_de.de_fone2 );
                            parametros.put( "de_site", ctrl_de.de_site );
                            parametros.put( "email", ctrl_de.de_email );
                            parametros.put("logoimg",imagePath);
                            parametros.put( "CodConta", CodConta );
                            parametros.put("TotProds",TotalProd);
                            JasperPrint jpPrint;
                            if (Entrada.equals("Sim")){
                            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteOSAPEntrada.jasper", parametros, ConnectionFactory2.getSlpConnection());    
                            }else{
                            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteOSAP.jasper", parametros, ConnectionFactory2.getSlpConnection());
                            }
                            JRViewer viewer = new JRViewer(jpPrint);
                            viewer.setZoomRatio((float) 0.5);
                            JFrame frameRelatorio = new JFrame();
                            frameRelatorio.add( viewer, BorderLayout.CENTER );
                            frameRelatorio.setTitle("Comprovante de Parcelamento");
                            frameRelatorio.setSize( 500, 500 );
                            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                            frameRelatorio.setVisible( true );
                    }   catch (SQLException ex) {
                            Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
                    }   catch (JRException ex) {
                            Logger.getLogger(FormParcelaVendas.class.getName()).log(Level.SEVERE, null, ex);
                    }
                               
    }
    }
    
    public void PrintOrcamento(){
        ctrl_de.Obtem_Dados_da_Empresa();
        JLabel labelM = new JLabel("<HTML>Digite o Código do Orçamento.</HTML>");
        //JComboBox jcbS = new JComboBox();
        JTextField jfCod = new JTextField();
        jfCod.addKeyListener(new KeyAdapter() {
          
            public void keyTyped(KeyEvent e){
                String caracteres="0987654321";
                if(!caracteres.contains(e.getKeyChar()+"")){
                e.consume();
                }
            } 
        });
        
        int pi = JOptionPane.showConfirmDialog(null,new Object[]{labelM,jfCod},"Comprovante a Gerar:", JOptionPane.OK_CANCEL_OPTION);
        if(pi == JOptionPane.OK_OPTION) {
            
        int CodigoOrc = Integer.parseInt(jfCod.getText());
        String Tipo = "";
        int CodConta = 0;
        String Entrada = "";
        
        conCRel.conecta();
            try {
                conCRel.executaSQL("select * from orcamentos where id_orcamento='"+CodigoOrc+"'");
                if (conCRel.rs.first()){
                    Tipo = conCRel.rs.getString("tipo_pag");
                    
                    if(Tipo.equals("À Prazo")){
                        conCRel.executaSQL("select * from orcamentos_parcelados where id_orcamento='"+CodigoOrc+"'");
                        conCRel.rs.first();
                        CodConta = conCRel.rs.getInt("id");
                        
                            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                            Map<String, Object> parametros = new HashMap<String, Object>();
                            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                            //dados empresa cabeçalho
                            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                            parametros.put( "cnpj", ctrl_de.de_cnpj );
                            parametros.put( "de_ie", ctrl_de.de_ie );
                            parametros.put( "endereco", ctrl_de.de_endereco );
                            parametros.put( "bairro", ctrl_de.de_bairro );
                            parametros.put( "cidade", ctrl_de.de_cidade );
                            parametros.put( "estado", ctrl_de.de_estado );
                            parametros.put( "cep", ctrl_de.de_cep );
                            parametros.put( "telefone1", ctrl_de.de_fone1 );
                            parametros.put( "telefone2", ctrl_de.de_fone2 );
                            parametros.put( "de_site", ctrl_de.de_site );
                            parametros.put( "email", ctrl_de.de_email );
                            parametros.put("logoimg",imagePath);
                            parametros.put( "CodConta", CodConta );
                            JasperPrint jpPrint;
                            if (Entrada.equals("Sim")){
                            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteOrcAPEntrada.jasper", parametros, ConnectionFactory2.getSlpConnection());    
                            }else{
                            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteOrcAP.jasper", parametros, ConnectionFactory2.getSlpConnection());
                            }
                            JRViewer viewer = new JRViewer(jpPrint);
                            viewer.setZoomRatio((float) 0.5);
                            JFrame frameRelatorio = new JFrame();
                            frameRelatorio.add( viewer, BorderLayout.CENTER );
                            frameRelatorio.setTitle("Comprovante de Parcelamento");
                            frameRelatorio.setSize( 500, 500 );
                            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                            frameRelatorio.setVisible( true );
                        
                    }else{
                            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                            Map<String, Object> parametros = new HashMap<String, Object>();
                            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                            //dados empresa cabeçalho
                            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                            parametros.put( "cnpj", ctrl_de.de_cnpj );
                            parametros.put( "de_ie", ctrl_de.de_ie );
                            parametros.put( "endereco", ctrl_de.de_endereco );
                            parametros.put( "bairro", ctrl_de.de_bairro );
                            parametros.put( "cidade", ctrl_de.de_cidade );
                            parametros.put( "estado", ctrl_de.de_estado );
                            parametros.put( "cep", ctrl_de.de_cep );
                            parametros.put( "telefone1", ctrl_de.de_fone1 );
                            parametros.put( "telefone2", ctrl_de.de_fone2 );
                            parametros.put( "de_site", ctrl_de.de_site );
                            parametros.put( "email", ctrl_de.de_email );
                            parametros.put("logoimg",imagePath);
                            parametros.put( "CodOrc", CodigoOrc );
                            JasperPrint jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraOrcamentoAVista.jasper", parametros, ConnectionFactory2.getConnection2());
                            JRViewer viewer = new JRViewer(jpPrint);
                            viewer.setZoomRatio((float) 0.5);
                            JFrame frameRelatorio = new JFrame();
                            frameRelatorio.add( viewer, BorderLayout.CENTER );
                            frameRelatorio.setTitle("Novo Orcamento Gerado");
                            frameRelatorio.setSize( 500, 500 );
                            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                            frameRelatorio.setVisible( true );
                    }
                    conCRel.desconecta();
                    
                }   
            } catch (SQLException ex) {
                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            } catch (JRException ex) {
                Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }
        
        }
    }
    
    
    public void RePrintOrcamento(int CodigoOrc){
        ctrl_de.Obtem_Dados_da_Empresa();
        String Tipo = "";
        int CodConta = 0;
        String Entrada = "";
        
        conCRel.conecta();
            try {
                conCRel.executaSQL("select * from orcamentos where id_orcamento='"+CodigoOrc+"'");
                if (conCRel.rs.first()){
                    Tipo = conCRel.rs.getString("tipo_pag");
                    
                    if(Tipo.equals("À Prazo")){
                        conCRel.executaSQL("select * from orcamentos_parcelados where id_orcamento='"+CodigoOrc+"'");
                        if(conCRel.rs.first()){
                            
                            CodConta = conCRel.rs.getInt("id");
                        
                            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                            Map<String, Object> parametros = new HashMap<String, Object>();
                            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                            //dados empresa cabeçalho
                            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                            parametros.put( "cnpj", ctrl_de.de_cnpj );
                            parametros.put( "de_ie", ctrl_de.de_ie );
                            parametros.put( "endereco", ctrl_de.de_endereco );
                            parametros.put( "bairro", ctrl_de.de_bairro );
                            parametros.put( "cidade", ctrl_de.de_cidade );
                            parametros.put( "estado", ctrl_de.de_estado );
                            parametros.put( "cep", ctrl_de.de_cep );
                            parametros.put( "telefone1", ctrl_de.de_fone1 );
                            parametros.put( "telefone2", ctrl_de.de_fone2 );
                            parametros.put( "de_site", ctrl_de.de_site );
                            parametros.put( "email", ctrl_de.de_email );
                            parametros.put("logoimg",imagePath);
                            parametros.put( "CodConta", CodConta );
                            JasperPrint jpPrint;
                            if (Entrada.equals("Sim")){
                            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteOrcAPEntrada.jasper", parametros, ConnectionFactory2.getSlpConnection());    
                            }else{
                            jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraComprovanteOrcAP.jasper", parametros, ConnectionFactory2.getSlpConnection());
                            }
                            JRViewer viewer = new JRViewer(jpPrint);
                            viewer.setZoomRatio((float) 0.5);
                            JFrame frameRelatorio = new JFrame();
                            frameRelatorio.add( viewer, BorderLayout.CENTER );
                            frameRelatorio.setTitle("Comprovante de Parcelamento");
                            frameRelatorio.setSize( 500, 500 );
                            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                            frameRelatorio.setVisible( true );
                        }else{
                            JOptionPane.showMessageDialog(null, "Dados não encontrados ou corrompidos.");
                        }
                        
                    }else{
                            Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                            Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                            Map<String, Object> parametros = new HashMap<String, Object>();
                            Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                            //dados empresa cabeçalho
                            parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                            parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                            parametros.put( "cnpj", ctrl_de.de_cnpj );
                            parametros.put( "de_ie", ctrl_de.de_ie );
                            parametros.put( "endereco", ctrl_de.de_endereco );
                            parametros.put( "bairro", ctrl_de.de_bairro );
                            parametros.put( "cidade", ctrl_de.de_cidade );
                            parametros.put( "estado", ctrl_de.de_estado );
                            parametros.put( "cep", ctrl_de.de_cep );
                            parametros.put( "telefone1", ctrl_de.de_fone1 );
                            parametros.put( "telefone2", ctrl_de.de_fone2 );
                            parametros.put( "de_site", ctrl_de.de_site );
                            parametros.put( "email", ctrl_de.de_email );
                            parametros.put("logoimg",imagePath);
                            parametros.put( "CodOrc", CodigoOrc );
                            JasperPrint jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraOrcamentoAVista.jasper", parametros, ConnectionFactory2.getConnection2());
                            JRViewer viewer = new JRViewer(jpPrint);
                            viewer.setZoomRatio((float) 0.5);
                            JFrame frameRelatorio = new JFrame();
                            frameRelatorio.add( viewer, BorderLayout.CENTER );
                            frameRelatorio.setTitle("Novo Orcamento Gerado");
                            frameRelatorio.setSize( 500, 500 );
                            frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                            frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                            Path caminhoICON = Paths.get(System.getProperty("user.dir")+"/Base/");
                            frameRelatorio.setIconImage(Toolkit.getDefaultToolkit().getImage(caminhoICON+"/"+"SisLpICO.png"));
                            frameRelatorio.setVisible( true );
                    }
                    conCRel.desconecta();
                    
                }   
            } catch (SQLException ex) {
                    Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            } catch (JRException ex) {
                Logger.getLogger(ControleRelatorios.class.getName()).log(Level.SEVERE, null, ex);
            }
        
    }
    
    public void PrintPedido(int CodPedido){
       ctrl_de.Obtem_Dados_da_Empresa();
        int i = JOptionPane.showConfirmDialog(null, "Deseja realizar a reimpressão deste pedido?","Confirmando Impressão", JOptionPane.YES_NO_OPTION);
                                if(i == JOptionPane.YES_OPTION) {
                               
                                try {
                                    Path caminho = Paths.get(System.getProperty("user.dir")+"/Base/");
                                    Path caminhoRel = Paths.get(System.getProperty("user.dir")+"/Base/Relatorios");
                                    Map<String, Object> parametros = new HashMap<String, Object>();
                                    Image imagePath = new ImageIcon(caminho+"/"+"logo.jpg").getImage();
                                    //dados empresa cabeçalho
                                    parametros.put( "nomefantasia", ctrl_de.de_nomefantasia );
                                    parametros.put( "de_razaosocial", ctrl_de.de_rasao );
                                    parametros.put( "cnpj", ctrl_de.de_cnpj );
                                    parametros.put( "de_ie", ctrl_de.de_ie );
                                    parametros.put( "endereco", ctrl_de.de_endereco );
                                    parametros.put( "bairro", ctrl_de.de_bairro );
                                    parametros.put( "cidade", ctrl_de.de_cidade );
                                    parametros.put( "estado", ctrl_de.de_estado );
                                    parametros.put( "cep", ctrl_de.de_cep );
                                    parametros.put( "telefone1", ctrl_de.de_fone1 );
                                    parametros.put( "telefone2", ctrl_de.de_fone2 );
                                    parametros.put( "de_site", ctrl_de.de_site );
                                    parametros.put( "email", ctrl_de.de_email );
                                    parametros.put("logoimg",imagePath);
                                    parametros.put( "CodPedido", CodPedido );
                                    JasperPrint jpPrint = JasperFillManager.fillReport(caminhoRel+"/"+"GeraListaPedido.jasper", parametros, ConnectionFactory2.getSlpConnection());
                                    JRViewer viewer = new JRViewer(jpPrint);
                                    viewer.setZoomRatio((float) 0.5);
                                    JFrame frameRelatorio = new JFrame();
                                    frameRelatorio.add( viewer, BorderLayout.CENTER );
                                    frameRelatorio.setTitle("Novo Pedido Gerado");
                                    frameRelatorio.setSize( 500, 500 );
                                    frameRelatorio.setExtendedState( JFrame.MAXIMIZED_BOTH );
                                    frameRelatorio.setDefaultCloseOperation( JFrame.DISPOSE_ON_CLOSE );
                                    frameRelatorio.setVisible( true );
                                    }catch (JRException ex) {
                                    JOptionPane.showMessageDialog(null, "Erro ao Gerar Pedido para Impressão!/nErro: "+ex);
//                                    } catch (SQLException ex) {
//                                    Logger.getLogger(FormPedidos.class.getName()).log(Level.SEVERE, null, ex);
                                }   catch (SQLException ex) {
                                        Logger.getLogger(FormPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                                    }
                                    //conOs.desconecta(); //conOs.desconecta();
                                     //conOs.desconecta(); //conOs.desconecta();
                                
                                }
    
                                
    }
    
    
}
