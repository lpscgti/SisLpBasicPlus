/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import modelo.ModeloFornecedor;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Lindembergue
 */
public class ControleFornecedor {
    ConectaBanco ConFornecedor = new ConectaBanco();
    ModeloFornecedor ModFornecedor = new ModeloFornecedor();
    
    public void SalvaDados (ModeloFornecedor ModFornecedor){
        
        ConFornecedor.conecta();
        
        try {
            PreparedStatement pst = ConFornecedor.conn.prepareStatement("update fornecedores set nome=?, endereco=?, bairro=?, cidade=?, estado=?, cep=?, tel1=?, tel2=?, email=?, site=?, cnpj=?, cpf=?, obs=? where Codigo=?");
            pst.setString(1, ModFornecedor.getNome());
            pst.setString(2, ModFornecedor.getEndereco());
            pst.setString(3, ModFornecedor.getBairro());
            pst.setString(4, ModFornecedor.getCidade());
            pst.setString(5, ModFornecedor.getEstado());
            pst.setString(6, ModFornecedor.getCep());
            pst.setString(7, ModFornecedor.getTel1());
            pst.setString(8, ModFornecedor.getTel2());
            pst.setString(9, ModFornecedor.getEmail());
            pst.setString(10, ModFornecedor.getSite());
            pst.setString(11, ModFornecedor.getCnpj());
            pst.setString(12, ModFornecedor.getCpf());
            pst.setString(13, ModFornecedor.getObs());
            pst.setInt(14, ModFornecedor.getId());
            pst.execute();
            //JOptionPane.showMessageDialog(null, "Venda finalizada com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao finalizar Salvar dados!\n"+ex);
        }ConFornecedor.desconecta();
        
        
    }
    
    public void ExcluiDados (ModeloFornecedor ModFornecedor){
        ConFornecedor.conecta();
        PreparedStatement pst;
        try {
            pst = ConFornecedor.conn.prepareStatement("delete from fornecedores where Codigo=?");
            pst.setInt(1, ModFornecedor.getId());
            pst.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Excluir dados\n Erro código: "+ex);
        }
        
        ConFornecedor.desconecta();
    }
}
