/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import modelo.ModeloPedido;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author Lindembergue
 */
public class ControlePedido {  
    int codProduto;
    int codCliente;
    ConectaBanco connVenda = new ConectaBanco();
    String DataFormatada;
    
    
    
     public void QuebraData(String data){
        
        String dia = "" + data.charAt(0) + data.charAt(1);
        String mes = "" + data.charAt(3) + data.charAt(4);
        String ano = "" + data.charAt(6) + data.charAt(7) + data.charAt(8) + data.charAt(9);
    
        DataFormatada = ano+"-"+mes+"-"+dia;
        
     }
    
    public void AddItem(ModeloPedido ModPedido){
        connVenda.conecta();
        try {
            PreparedStatement pst = connVenda.conn.prepareStatement("insert into pedidos_desc (pedido, produto, quantidade)values(?,?,?)");
            pst.setInt(1, ModPedido.getIdPedido());
            pst.setInt(2, ModPedido.getIdProduto());
            pst.setInt(3, ModPedido.getQtd_produto());
            pst.execute();
        } catch (SQLException ex) {
            
            JOptionPane.showMessageDialog(null, "Erro ao adicionar item.\n Erro:" + ex);
        }
        connVenda.desconecta();
        return;
    }
    
      
    
    public void FechaPedido (ModeloPedido ModPedido){
        
        connVenda.conecta();
        
        try {
            PreparedStatement pst = connVenda.conn.prepareStatement("update pedidos set data=?, valortotal=?, fornecedor=? where id_pedido=?");
            
            QuebraData(ModPedido.getDtPedido());
            java.sql.Date DtI = java.sql.Date.valueOf(DataFormatada);
            pst.setDate(1, DtI);
            pst.setDouble(2, ModPedido.getValorPedido());
            pst.setInt(3, ModPedido.getIdFornecedor());
            pst.setInt(4, ModPedido.getIdPedido());
            pst.execute();
            //JOptionPane.showMessageDialog(null, "Venda finalizada com sucesso!");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao finalizar pedido!\n"+ex);
        }
        
        connVenda.desconecta();
        
    }
    
        public void CancelaPedido(){
        connVenda.conecta();
        PreparedStatement pst;
        connVenda.executaSQL("select * from pedidos where valortotal=0");
        
        
        try {
            connVenda.rs.first();
            int codTempPedido = connVenda.rs.getInt("id_pedido");
           // JOptionPane.showMessageDialog(null, "Codivo venda: "+codTempVenda);
            connVenda.executaSQL("select * from (pedidos_desc inner join produtos on produtos.codigo=pedidos_desc.produto) where pedidos_desc.pedido='"+codTempPedido+"'");
            connVenda.rs.first();
            if (connVenda.rs.getRow()==(0)){
            pst = connVenda.conn.prepareStatement("delete from pedidos where valortotal=?");
            pst.setInt(1, 0);
            pst.execute();
            }else{
            
                do{
                pst = connVenda.conn.prepareStatement("delete from pedidos_desc where pedido=?");
                pst.setInt(1, codTempPedido);
                pst.execute();
                                
            } while(connVenda.rs.next());
            pst = connVenda.conn.prepareStatement("delete from pedidos where valortotal=?");
            pst.setInt(1, 0);
            pst.execute();
        } 
        
        }catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao cancelar a pedido!\nErro:" + ex );
            connVenda.desconecta();
        }     
        }
        


}





