/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import modelo.ModeloFabricantes;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author Lindembergue
 */
public class ControleFabricantes {
    ConectaBanco conCatPro = new ConectaBanco();
     public int id_fabricante;
    String sql,novoreg;
    public String menssagem_erro,mensagem_erro_comp;
    
            
    
    public void novo(){
        conCatPro.conecta();
        //SimpleDateFormat dhcf = new SimpleDateFormat("HHmmss");
        SimpleDateFormat df = new SimpleDateFormat("HHmmss");
        Date Data = new Date();
        String Hagora = (df.format(Data));
        java.sql.Date Dagora = new java.sql.Date(Data.getTime());//passa a data util para sql diretamente
        novoreg = "Fabricante"+Hagora;
        sql = "insert into fabricantes (fabricante) values (?)";

        try {
                PreparedStatement pst = conCatPro.conn.prepareStatement(sql);
                pst.setString(1, novoreg);
                pst.execute();
        
        } catch (SQLException ex) {
            Logger.getLogger(ControleFabricantes.class.getName()).log(Level.SEVERE, null, ex);
            menssagem_erro = ex.toString();
        }
        try {
                sql= "select * from fabricantes where fabricante='"+novoreg+"'";
                conCatPro.executaSQL(sql);
                conCatPro.rs.first();
                id_fabricante = conCatPro.rs.getInt("codigo");
        } catch (SQLException ex) {
            Logger.getLogger(ControleFabricantes.class.getName()).log(Level.SEVERE, null, ex);
            menssagem_erro = ex.toString();
        }
        conCatPro.desconecta();
        
    }
    
    
    public void salva(ModeloFabricantes modFab){
        conCatPro.conecta();
        try {
            PreparedStatement pst = conCatPro.conn.prepareStatement("insert into fabricantes(fabricante, fornecedor)values(?,?)");
            pst.setString(1, modFab.getFabricante());
            pst.setInt(2, modFab.getFornecedor());
            pst.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar "+ex);
            //Logger.getLogger(ControleCategoriaProdutos.class.getName()).log(Level.SEVERE, null, ex);
        }
        conCatPro.desconecta();
    }
 
    public void edita(ModeloFabricantes modFab){
        conCatPro.conecta();
        try {
            PreparedStatement pst = conCatPro.conn.prepareStatement("update fabricantes set fabricante=?, fornecedor=? where codigo=?");
            pst.setString(1, modFab.getFabricante());
            pst.setInt(2, modFab.getFornecedor());
            pst.setInt(3, modFab.getId());
            pst.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao atualizar dados "+ex);
            //Logger.getLogger(ControleCategoriaProdutos.class.getName()).log(Level.SEVERE, null, ex);
        }
        conCatPro.desconecta();
    }
    
    public void exclui (ModeloFabricantes modFab){
        conCatPro.conecta();
        try {
            PreparedStatement pst = conCatPro.conn.prepareStatement("delete from fabricantes where codigo=?");
            pst.setInt(1, modFab.getId());
            pst.execute();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir dados "+ex);
        }
                conCatPro.desconecta();
    }
    
    
    public void NavPrireg (ModeloFabricantes modFab){
        conCatPro.conecta();
        
        try {
            conCatPro.executaSQL("select * from fabricantes");
            conCatPro.rs.first();
            modFab.setId(conCatPro.rs.getInt("codigo"));
            modFab.setFabricante(conCatPro.rs.getString("fabricante"));
            modFab.setFornecedor(conCatPro.rs.getInt("fornecedor"));
        } catch (SQLException ex) {
            Logger.getLogger(ControleFabricantes.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void NavRegAnt (ModeloFabricantes modFab){
        conCatPro.conecta();
        
        try {
            //conCatPro.executaSQL("select * from categoria_produtos");
            conCatPro.rs.previous();
            modFab.setId(conCatPro.rs.getInt("codigo"));
            modFab.setFabricante(conCatPro.rs.getString("fabricante"));
            modFab.setFornecedor(conCatPro.rs.getInt("fornecedor"));
        } catch (SQLException ex) {
            Logger.getLogger(ControleFabricantes.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void NavProxReg (ModeloFabricantes modFab){
        conCatPro.conecta();
        
        try {
            //conCatPro.executaSQL("select * from categoria_produtos");
            conCatPro.rs.next();
           modFab.setId(conCatPro.rs.getInt("codigo"));
            modFab.setFabricante(conCatPro.rs.getString("fabricante"));
            modFab.setFornecedor(conCatPro.rs.getInt("fornecedor"));
        } catch (SQLException ex) {
            Logger.getLogger(ControleFabricantes.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void NavUltiReg (ModeloFabricantes modFab){
        conCatPro.conecta();
        
        try {
            conCatPro.executaSQL("select * from fabricantes");
            conCatPro.rs.last();
           modFab.setId(conCatPro.rs.getInt("codigo"));
            modFab.setFabricante(conCatPro.rs.getString("fabricante"));
            modFab.setFornecedor(conCatPro.rs.getInt("fornecedor"));
        } catch (SQLException ex) {
            Logger.getLogger(ControleFabricantes.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
